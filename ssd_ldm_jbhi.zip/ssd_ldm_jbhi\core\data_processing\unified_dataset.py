#!/usr/bin/env python3
"""
统一的 EEG 数据集模块
整合所有模型使用的数据加载功能，避免代码重复
"""

import os
import numpy as np
import torch
from torch.utils.data import Dataset
from typing import List, Tuple, Optional, Union
import warnings


class UnifiedEEGDataset(Dataset):
    """
    统一的 EEG 数据集类
    支持所有生成模型的数据加载需求
    
    功能特性：
    - 支持滑动窗口和非滑动窗口模式
    - 自动数据集分割（train/val/test）
    - 灵活的窗口大小和步长设置
    - 数据类型转换和形状验证
    - 详细的错误提示和调试信息
    """
    
    def __init__(
        self,
        dataset_dir: str,
        split: str = "train",
        window_size: int = 750,
        step: int = 100,
        random_seed: int = 42,
        train_ratio: float = 0.7,
        val_ratio: float = 0.15,
        include_tail: bool = True,
        no_sliding: bool = False,
        normalize: bool = False,
        dtype: torch.dtype = torch.float32,
        verbose: bool = False
    ) -> None:
        """
        初始化统一数据集
        
        Args:
            dataset_dir: 数据目录路径，包含 X.npy 和 y.npy
            split: 数据分割 ("train", "val", "test")
            window_size: 滑动窗口大小
            step: 滑动步长，0表示step=1
            random_seed: 随机种子
            train_ratio: 训练集比例
            val_ratio: 验证集比例
            include_tail: 是否包含尾部不完整窗口
            no_sliding: 是否禁用滑动窗口（每个trial作为一个样本）
            normalize: 是否标准化数据
            dtype: 数据类型
            verbose: 是否显示详细信息
        """
        assert split in {"train", "val", "test"}, f"split 必须是 train/val/test 之一，得到: {split}"
        
        self.dataset_dir = dataset_dir
        self.split = split
        self.window_size = window_size
        self.step = max(1, step)  # step为0时设为1
        self.random_seed = random_seed
        self.train_ratio = train_ratio
        self.val_ratio = val_ratio
        self.include_tail = include_tail
        self.no_sliding = no_sliding
        self.normalize = normalize
        self.dtype = dtype
        self.verbose = verbose
        
        # 加载和处理数据
        self._load_data()
        self._split_data()
        self._create_windows()
        
        if self.verbose:
            self._print_summary()
    
    def _load_data(self) -> None:
        """加载原始数据文件"""
        x_path = os.path.join(self.dataset_dir, "X.npy")
        y_path = os.path.join(self.dataset_dir, "y.npy")
        
        if not os.path.exists(x_path):
            raise FileNotFoundError(f"找不到数据文件: {x_path}")
        if not os.path.exists(y_path):
            raise FileNotFoundError(f"找不到标签文件: {y_path}")
        
        # 加载数据
        self.X_full = np.load(x_path, allow_pickle=True)
        self.y_full = np.load(y_path, allow_pickle=True).astype(int)
        
        # 数据验证
        if self.X_full.ndim != 3:
            raise ValueError(f"期望 X 维度为 3 [N, C, T]，但得到 {self.X_full.shape}")
        if self.X_full.shape[0] != self.y_full.shape[0]:
            raise ValueError(f"样本数不匹配：X={self.X_full.shape[0]} vs y={self.y_full.shape[0]}")
        
        self.n_trials, self.n_channels, self.seq_len = self.X_full.shape
        self.n_classes = len(np.unique(self.y_full))
        
        if self.verbose:
            print(f"数据加载完成: {self.X_full.shape}, 标签: {self.y_full.shape}")
            print(f"通道数: {self.n_channels}, 序列长度: {self.seq_len}, 类别数: {self.n_classes}")
    
    def _split_data(self) -> None:
        """分割数据集"""
        np.random.seed(self.random_seed)
        indices = np.random.permutation(self.n_trials)
        
        # 计算分割点
        train_end = int(self.n_trials * self.train_ratio)
        val_end = train_end + int(self.n_trials * self.val_ratio)
        
        # 分割索引
        if self.split == "train":
            self.indices = indices[:train_end]
        elif self.split == "val":
            self.indices = indices[train_end:val_end]
        else:  # test
            self.indices = indices[val_end:]
        
        # 提取对应数据
        self.X = self.X_full[self.indices]
        self.y = self.y_full[self.indices]
        
        if self.verbose:
            print(f"{self.split} 集: {len(self.indices)} 个trial")
    
    def _create_windows(self) -> None:
        """创建滑动窗口索引"""
        self.windows = []  # 存储 (trial_idx, start_pos, end_pos) 的窗口信息
        
        for i, trial_idx in enumerate(self.indices):
            T = self.X[i].shape[1]  # 当前trial的时间长度
            
            if self.no_sliding:
                # 非滑动模式：整个trial作为一个样本
                self.windows.append((i, 0, T))
                continue
            
            if self.window_size >= T:
                # 窗口大小大于等于序列长度，使用整个序列
                self.windows.append((i, 0, T))
                continue
            
            # 滑动窗口模式
            pos = 0
            while pos + self.window_size <= T:
                self.windows.append((i, pos, pos + self.window_size))
                pos += self.step
            
            # 处理尾部
            if self.include_tail and pos < T:
                # 包含尾部：对齐到末尾
                self.windows.append((i, T - self.window_size, T))
        
        if self.verbose:
            print(f"创建了 {len(self.windows)} 个窗口")
    
    def _normalize_data(self, x: np.ndarray) -> np.ndarray:
        """标准化数据"""
        if self.normalize:
            # 按通道标准化
            mean = x.mean(axis=-1, keepdims=True)
            std = x.std(axis=-1, keepdims=True) + 1e-8
            x = (x - mean) / std
        return x
    
    def _print_summary(self) -> None:
        """打印数据集摘要"""
        print(f"\n{'='*50}")
        print(f"统一 EEG 数据集摘要")
        print(f"{'='*50}")
        print(f"数据目录: {self.dataset_dir}")
        print(f"分割: {self.split}")
        print(f"原始数据: {self.X_full.shape}")
        print(f"当前分割: {self.X.shape}")
        print(f"窗口大小: {self.window_size}")
        print(f"滑动步长: {self.step}")
        print(f"窗口数量: {len(self.windows)}")
        print(f"类别数: {self.n_classes}")
        print(f"标准化: {self.normalize}")
        print(f"数据类型: {self.dtype}")
        print(f"{'='*50}\n")
    
    def __len__(self) -> int:
        """返回数据集大小"""
        return len(self.windows)
    
    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        """获取单个样本"""
        trial_idx, start_pos, end_pos = self.windows[idx]
        
        # 提取窗口数据
        x = self.X[trial_idx, :, start_pos:end_pos].copy()
        y = self.y[trial_idx]
        
        # 标准化
        x = self._normalize_data(x)
        
        # 转换为张量
        x = torch.tensor(x, dtype=self.dtype)
        # 标签转换为0-based索引 (如果标签从1开始)
        y_val = int(y)
        if y_val >= 1 and self.n_classes <= 4:
            y_val = y_val - 1  # 1-4 -> 0-3
        y = torch.tensor(y_val, dtype=torch.long)
        
        return x, y
    
    def get_data_info(self) -> dict:
        """获取数据集信息"""
        return {
            'n_channels': self.n_channels,
            'seq_len': self.seq_len,
            'n_classes': self.n_classes,
            'n_trials': len(self.indices),
            'n_windows': len(self.windows),
            'window_size': self.window_size,
            'step': self.step,
            'split': self.split
        }
    
    def get_sample_shape(self) -> Tuple[int, int]:
        """获取单个样本的形状"""
        sample_x, _ = self[0]
        return sample_x.shape


# 为了向后兼容，提供别名
EEGNPYDataset = UnifiedEEGDataset


def create_dataloaders(
    dataset_dir: str,
    batch_size: int = 32,
    window_size: int = 750,
    step: int = 100,
    num_workers: int = 0,
    **kwargs
) -> Tuple[torch.utils.data.DataLoader, torch.utils.data.DataLoader, torch.utils.data.DataLoader]:
    """
    便捷函数：创建训练、验证、测试数据加载器
    
    Args:
        dataset_dir: 数据目录
        batch_size: 批大小
        window_size: 窗口大小
        step: 滑动步长
        num_workers: 数据加载进程数
        **kwargs: 其他参数传递给 UnifiedEEGDataset
    
    Returns:
        train_loader, val_loader, test_loader
    """
    from torch.utils.data import DataLoader
    
    # 创建数据集
    train_dataset = UnifiedEEGDataset(dataset_dir, split='train', window_size=window_size, step=step, **kwargs)
    val_dataset = UnifiedEEGDataset(dataset_dir, split='val', window_size=window_size, step=step, **kwargs)
    test_dataset = UnifiedEEGDataset(dataset_dir, split='test', window_size=window_size, step=step, **kwargs)
    
    # 创建数据加载器
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=num_workers)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers)
    
    return train_loader, val_loader, test_loader


def test_dataset(dataset_dir: str = None):
    """测试数据集功能"""
    if dataset_dir is None:
        # 使用默认测试目录
        from pathlib import Path
        dataset_dir = str(Path(__file__).parent.parent.parent / 'data' / 'processed' / 'BCI2a')
    
    print("🧪 测试统一数据集...")
    
    try:
        # 测试基本功能
        dataset = UnifiedEEGDataset(
            dataset_dir=dataset_dir,
            split='train',
            window_size=500,
            step=100,
            verbose=True
        )
        
        print(f"✅ 数据集创建成功，大小: {len(dataset)}")
        
        # 测试数据获取
        x, y = dataset[0]
        print(f"✅ 样本获取成功，形状: {x.shape}, 标签: {y}")
        
        # 测试数据加载器
        train_loader, val_loader, test_loader = create_dataloaders(
            dataset_dir, batch_size=8, window_size=500, step=100, verbose=False
        )
        
        print(f"✅ 数据加载器创建成功")
        print(f"   训练集: {len(train_loader.dataset)} 样本")
        print(f"   验证集: {len(val_loader.dataset)} 样本") 
        print(f"   测试集: {len(test_loader.dataset)} 样本")
        
        # 测试批次加载
        batch_x, batch_y = next(iter(train_loader))
        print(f"✅ 批次加载成功，形状: {batch_x.shape}, 标签: {batch_y.shape}")
        
        print("🎉 所有测试通过！")
        
    except Exception as e:
        print(f"❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    # 运行测试
    test_dataset()