"""
修复版BCI Competition IV Dataset 2a 数据处理器
解决25%准确率问题，参考高准确率论文的标准方法
"""

import os
import argparse
from pathlib import Path
import numpy as np
import mne
from scipy.io import loadmat
from typing import List, Tuple
import warnings
warnings.filterwarnings('ignore')

try:
    from .common import (
        DEFAULT_PATHS, get_default_paths, save_processed_dataset,
        apply_preprocessing
    )
except ImportError:
    from common import (
        DEFAULT_PATHS, get_default_paths, save_processed_dataset,
        apply_preprocessing
    )

class FixedBCICompetition4Set2A:
    """修复版BCI Competition IV Dataset 2a 数据加载器"""
    
    def __init__(self, filename: str, labels_filename: str = None) -> None:
        self.filename = filename
        self.labels_filename = labels_filename

    def load(self) -> mne.io.BaseRaw:
        """加载GDF文件"""
        cnt = self.extract_data()
        events, artifact_trial_mask = self.extract_events(cnt)
        cnt.info['temp'] = {'events': events, 'artifact_trial_mask': artifact_trial_mask}
        return cnt

    def extract_data(self) -> mne.io.BaseRaw:
        """提取原始数据"""
        raw_gdf = mne.io.read_raw_gdf(
            self.filename,
            stim_channel="auto",
            verbose='ERROR',
            exclude=(['EOG-left', 'EOG-central', 'EOG-right'])
        )
        
        # 重命名通道
        raw_gdf.rename_channels({
            'EEG-Fz': 'Fz', 'EEG-0': 'FC3', 'EEG-1': 'FC1', 'EEG-2': 'FCz', 'EEG-3': 'FC2', 'EEG-4': 'FC4',
            'EEG-5': 'C5', 'EEG-C3': 'C3', 'EEG-6': 'C1', 'EEG-Cz': 'Cz', 'EEG-7': 'C2', 'EEG-C4': 'C4',
            'EEG-8': 'C6', 'EEG-9': 'CP3', 'EEG-10': 'CP1', 'EEG-11': 'CPz', 'EEG-12': 'CP2', 'EEG-13': 'CP4',
            'EEG-14': 'P1', 'EEG-15': 'Pz', 'EEG-16': 'P2', 'EEG-Pz': 'POz'
        })
        
        raw_gdf.load_data()
        
        # 处理异常值
        data = raw_gdf.get_data()
        for i_chan in range(data.shape[0]):
            this_chan = data[i_chan]
            data[i_chan] = np.where(this_chan == np.min(this_chan), np.nan, this_chan)
            mask = np.isnan(data[i_chan])
            chan_mean = np.nanmean(data[i_chan])
            data[i_chan, mask] = chan_mean

        gdf_events = mne.events_from_annotations(raw_gdf)
        raw_gdf = mne.io.RawArray(data, raw_gdf.info, verbose='ERROR')
        raw_gdf.info['temp'] = {'gdf_events': gdf_events}
        return raw_gdf

    def extract_events(self, raw_gdf: mne.io.BaseRaw) -> Tuple[np.ndarray, np.ndarray]:
        """提取事件信息（与原版相同）"""
        events, name_to_code = raw_gdf.info['temp']['gdf_events']

        print(f"  所有事件代码: {name_to_code}")
        print(f"  事件数组形状: {events.shape}")

        # 判断是否为训练集
        if '769' in name_to_code and '770' in name_to_code:
            train_set = True
            print(f"  检测到训练集事件代码")
        else:
            train_set = False
            print(f"  检测到测试集事件代码")

        # 确定试验代码
        if train_set:
            trial_codes = []
            for code_str in ['769', '770', '771', '772']:
                if code_str in name_to_code:
                    trial_codes.append(name_to_code[code_str])
                    
            if not trial_codes:
                unique_codes = sorted(set(events[:, 2]))
                trial_codes = [code for code in unique_codes if code > 100]
                print(f"  使用备用方案，试验代码: {trial_codes}")
            
            trial_mask = [ev_code in trial_codes for ev_code in events[:, 2]]
            trial_events = events[trial_mask]
            print(f"  训练集: 找到 {len(trial_events)} 个试验")
        else:
            if '783' in name_to_code:
                trial_codes = [name_to_code['783']]
            else:
                unique_codes = sorted(set(events[:, 2]))
                trial_codes = [code for code in unique_codes if code > 100]
            
            trial_mask = [ev_code in trial_codes for ev_code in events[:, 2]]
            trial_events = events[trial_mask]
            print(f"  测试集: 找到 {len(trial_events)} 个试验")

        # 调整标签
        if train_set:
            code_to_class = {}
            if all(code_str in name_to_code for code_str in ['769', '770', '771', '772']):
                # ✅ 修复：直接映射到0-3而非1-4
                code_to_class = {
                    name_to_code['769']: 0,  # 左手 -> 0
                    name_to_code['770']: 1,  # 右手 -> 1
                    name_to_code['771']: 2,  # 脚 -> 2
                    name_to_code['772']: 3   # 舌头 -> 3
                }
                print(f"  ✅ 使用标准BCI2a事件代码映射到0-3: {code_to_class}")
            else:
                unique_codes = sorted(set(trial_events[:, 2]))
                if len(unique_codes) >= 4:
                    code_to_class = {code: i for i, code in enumerate(unique_codes[:4])}
                    print(f"  使用备用事件代码映射到0-3: {code_to_class}")
            
            # 应用映射
            new_labels = []
            for code in trial_events[:, 2]:
                if code in code_to_class:
                    new_labels.append(code_to_class[code])
                else:
                    print(f"  警告: 未找到事件代码 {code} 的映射")
                    new_labels.append(0)  # 默认为类别0
            
            trial_events[:, 2] = new_labels

        # 加载标签文件
        if self.labels_filename is not None and os.path.exists(self.labels_filename):
            classes = loadmat(self.labels_filename)["classlabel"].squeeze()
            if train_set:
                # ✅ 修复：标签文件也转换为0-3
                classes = classes - 1  # 1,2,3,4 -> 0,1,2,3
                if len(trial_events) == len(classes):
                    trial_events[:, 2] = classes
                else:
                    print(f"警告: 试验事件数量({len(trial_events)})与标签数量({len(classes)})不匹配")
            else:
                # 测试集标签也转换
                classes = classes - 1  # 1,2,3,4 -> 0,1,2,3  
                trial_events[:, 2] = classes

        # 验证标签
        unique_classes = np.unique(trial_events[:, 2])
        if train_set:
            expected_classes = [0, 1, 2, 3]
            if not np.array_equal(sorted(unique_classes), expected_classes):
                print(f"警告: BCI2a训练集期望标签为{expected_classes}，实际得到: {sorted(unique_classes)}")
            else:
                print(f"✅ 标签验证通过: {sorted(unique_classes)}")

        artifact_trial_mask = np.zeros(len(trial_events), dtype=np.uint8)
        print(f"  处理完成: {len(trial_events)} 个试验")

        return trial_events, artifact_trial_mask

def extract_fixed_segment_trial(raw_gdb: mne.io.BaseRaw, 
                               tmin: float = 0.5, tmax: float = 2.5,
                               baseline_tmin: float = 0.0, baseline_tmax: float = 0.1,
                               standardize: bool = True) -> Tuple[np.ndarray, np.ndarray]:
    """
    修复版试验数据提取
    
    关键修复:
    1. 使用运动想象关键时段 (0.5-2.5秒)
    2. 基线校正 (减去0-0.1秒的均值)
    3. 试次内标准化
    """
    events = raw_gdb.info['temp']['events']
    raw_data = raw_gdb.get_data()
    sfreq = raw_gdb.info['sfreq']
    
    print(f"  ✅ 修复版数据提取:")
    print(f"     时间窗口: {tmin}-{tmax}秒 (运动想象关键时段)")
    print(f"     基线校正: {baseline_tmin}-{baseline_tmax}秒")
    print(f"     试次内标准化: {standardize}")
    
    # 计算时间窗口的样本偏移
    start_offset = int(round(sfreq * tmin))
    end_offset = int(round(sfreq * tmax))
    window_length = end_offset - start_offset
    
    # 基线校正窗口
    baseline_start = int(round(sfreq * baseline_tmin))
    baseline_end = int(round(sfreq * baseline_tmax))
    
    labels = np.array(events[:, 2])
    trials = []
    valid_labels = []
    
    for i, ev in enumerate(events):
        # 检查边界
        trial_start = int(ev[0]) + start_offset
        trial_stop = int(ev[0]) + end_offset
        baseline_trial_start = int(ev[0]) + baseline_start
        baseline_trial_end = int(ev[0]) + baseline_end
        
        if (trial_start < 0 or trial_stop > raw_data.shape[1] or 
            baseline_trial_start < 0 or baseline_trial_end > raw_data.shape[1]):
            print(f"警告: 事件 {i} 超出数据边界，跳过")
            continue
        
        # 提取试验数据
        segment = raw_data[:, trial_start:trial_stop].copy()
        
        # ✅ 修复1: 基线校正
        if baseline_trial_end > baseline_trial_start:
            baseline_data = raw_data[:, baseline_trial_start:baseline_trial_end]
            baseline_mean = np.mean(baseline_data, axis=1, keepdims=True)
            segment = segment - baseline_mean
        
        # ✅ 修复2: 试次内标准化
        if standardize:
            for ch in range(segment.shape[0]):
                ch_data = segment[ch, :]
                ch_std = np.std(ch_data)
                if ch_std > 1e-10:  # 避免除零
                    segment[ch, :] = (ch_data - np.mean(ch_data)) / ch_std
        
        # ✅ 修复3: 异常值处理 (截断到±5σ)
        segment = np.clip(segment, -5, 5)
        
        if segment.shape[-1] != window_length:
            print(f"警告: 事件 {i} 段长度不匹配，跳过")
            continue
            
        trials.append(segment)
        valid_labels.append(labels[i])
    
    if len(trials) == 0:
        raise ValueError("没有成功提取任何数据段")
        
    X = np.stack(trials, axis=0)
    y = np.array(valid_labels)
    
    print(f"  ✅ 数据提取完成:")
    print(f"     X形状: {X.shape}")
    print(f"     y分布: {np.bincount(y)}")
    print(f"     数据范围: {X.min():.2f} 到 {X.max():.2f}")
    print(f"     数据均值: {X.mean():.2e}")
    print(f"     数据标准差: {X.std():.2f}")
    
    return X, y

def apply_fixed_preprocessing(raw: mne.io.BaseRaw, 
                             l_freq: float = 4.0, h_freq: float = 38.0,
                             notch_freq: float = 50.0, car: bool = True, 
                             resample_freq: float = 250.0) -> mne.io.BaseRaw:
    """
    修复版数据预处理
    
    关键修复:
    1. 提高滤波上限到38Hz (包含更多β波)
    2. 保持其他标准预处理步骤
    """
    print(f"  ✅ 修复版预处理:")
    print(f"     带通滤波: {l_freq}-{h_freq} Hz (提高到38Hz)")
    print(f"     陷波滤波: {notch_freq} Hz")
    print(f"     重采样: {resample_freq} Hz") 
    print(f"     共同平均参考: {car}")
    
    # 陷波滤波
    if notch_freq and notch_freq > 0:
        try:
            raw.notch_filter(freqs=[notch_freq, notch_freq * 2], verbose='ERROR')
        except Exception:
            pass
    
    # ✅ 修复: 带通滤波范围扩展到38Hz
    if l_freq is not None or h_freq is not None:
        raw.filter(l_freq=l_freq, h_freq=h_freq, verbose='ERROR')
    
    # 重采样
    if resample_freq is not None:
        raw.resample(resample_freq, npad='auto')
    
    # 公共平均参考
    if car:
        try:
            raw, _ = mne.set_eeg_reference(raw, 'average', projection=False, verbose='ERROR')
        except Exception:
            pass
    
    return raw

def process_bci2a_dataset_fixed(data_dir: str, label_dir: str, output_dir: str, 
                               subject: str = None, l_freq: float = 4.0, h_freq: float = 38.0,
                               notch_freq: float = 50.0, car: bool = True, resample_freq: float = 250.0,
                               tmin: float = 0.5, tmax: float = 2.5,
                               baseline_tmin: float = 0.0, baseline_tmax: float = 0.1,
                               standardize: bool = True):
    """
    修复版BCI2a数据集处理
    
    主要修复:
    1. 时间窗口: 0.5-2.5秒 (运动想象关键时段)
    2. 滤波范围: 4-38Hz (包含更多β波)
    3. 基线校正: 减去0-0.1秒均值
    4. 试次内标准化
    5. 标签编码: 0-3
    """
    print('=' * 60)
    print('[BCI2a Fixed] 开始修复版数据集处理...')
    print('=' * 60)
    print('主要修复:')
    print(f'  ✅ 时间窗口: {tmin}-{tmax}秒 (原来0-4秒 -> 关键2秒)')
    print(f'  ✅ 滤波范围: {l_freq}-{h_freq}Hz (原来4-30Hz -> 4-38Hz)')
    print(f'  ✅ 基线校正: {baseline_tmin}-{baseline_tmax}秒')
    print(f'  ✅ 试次内标准化: {standardize}')
    print(f'  ✅ 标签编码: 0-3 (原来1-4)')
    print()
    
    # 检查原始数据目录
    if not os.path.exists(data_dir):
        print(f'[BCI2a Fixed] 错误: 原始数据目录不存在: {data_dir}')
        return False
    
    # 获取所有GDF文件
    gdf_files = []
    for root, _, files in os.walk(data_dir):
        for f in files:
            if f.lower().endswith('.gdf'):
                gdf_files.append(os.path.join(root, f))
    gdf_files.sort()
    
    # 如果指定了特定被试，只处理该被试
    if subject:
        want = subject.strip().lower()
        gdf_files = [p for p in gdf_files if os.path.basename(p).lower() == f"{want}.gdf"]
        print(f"[BCI2a Fixed] 仅处理: {subject}, 匹配到 {len(gdf_files)} 个文件")
    
    if len(gdf_files) == 0:
        print(f'[BCI2a Fixed] 错误: 未找到任何GDF文件')
        return False
    
    all_X: List[np.ndarray] = []
    all_y: List[np.ndarray] = []
    used_files: List[str] = []
    per_file_data: List[Tuple[str, np.ndarray, np.ndarray]] = []
    
    for gdf_path in gdf_files:
        base = os.path.basename(gdf_path)
        print(f'[BCI2a Fixed] 处理文件: {base}')
        
        # 查找对应的标签文件
        lab = None
        if label_dir is not None:
            cand = os.path.join(label_dir, base.replace('.gdf', '.mat'))
            if os.path.exists(cand):
                lab = cand
        
        try:
            # ✅ 使用修复版加载器
            cnt = FixedBCICompetition4Set2A(gdf_path, labels_filename=lab).load()
            
            # ✅ 使用修复版预处理
            cnt = apply_fixed_preprocessing(cnt, l_freq=l_freq, h_freq=h_freq, 
                                          notch_freq=notch_freq, car=car, resample_freq=resample_freq)
            
            # ✅ 使用修复版数据提取
            X, y = extract_fixed_segment_trial(cnt, tmin=tmin, tmax=tmax,
                                              baseline_tmin=baseline_tmin, baseline_tmax=baseline_tmax,
                                              standardize=standardize)
            
            # 打印标签信息
            uniq = sorted(set(y.tolist()))
            counts = {int(k): int((y == k).sum()) for k in uniq}
            print(f"[BCI2a Fixed] 标签分布: {counts}")
            
            # 保存每个文件的数据
            sub_name = os.path.splitext(base)[0]
            dir2a_sub = os.path.join(output_dir, 'BCI2a_Fixed', sub_name)
            Path(dir2a_sub).mkdir(parents=True, exist_ok=True)
            np.save(os.path.join(dir2a_sub, 'X.npy'), X)
            np.save(os.path.join(dir2a_sub, 'y.npy'), y)
            
            all_X.append(X)
            all_y.append(y)
            used_files.append(gdf_path)
            per_file_data.append((gdf_path, X, y))
            
            print(f'[BCI2a Fixed] ✅ 成功处理: {base}, X={X.shape}, y={y.shape}')
            
        except Exception as e:
            print(f'[BCI2a Fixed] ❌ 跳过 {base}: {e}')
            import traceback
            traceback.print_exc()
    
    if len(all_X) == 0:
        print('[BCI2a Fixed] 错误: 未成功读取任何数据')
        return False
    
    # 合并所有数据
    X_cat = np.concatenate(all_X, axis=0)
    y_cat = np.concatenate(all_y, axis=0)
    
    print(f'\n[BCI2a Fixed] 合并后数据统计:')
    print(f'  X形状: {X_cat.shape}')
    print(f'  y分布: {np.bincount(y_cat)}')
    print(f'  X范围: {X_cat.min():.2f} 到 {X_cat.max():.2f}')
    print(f'  X均值: {X_cat.mean():.2e}')
    print(f'  X标准差: {X_cat.std():.2f}')
    
    # 保存数据集
    metadata = {
        'files': used_files,
        'preprocessing_version': 'fixed_v1.0',
        'fixes_applied': [
            'time_window_optimization: 4s -> 2s (0.5-2.5s)',
            'baseline_correction: subtract 0-0.1s mean',
            'trial_wise_standardization: z-score',
            'label_encoding: 1-4 -> 0-3',
            'filter_range_extension: 30Hz -> 38Hz',
            'outlier_clipping: ±5σ'
        ],
        'preprocessing': {
            'l_freq': l_freq,
            'h_freq': h_freq,
            'notch_freq': notch_freq,
            'car': car,
            'resample_freq': resample_freq,
            'tmin': tmin,
            'tmax': tmax,
            'baseline_tmin': baseline_tmin,
            'baseline_tmax': baseline_tmax,
            'standardize': standardize
        },
        'expected_improvement': 'from 25% to 50-70% accuracy'
    }
    
    save_processed_dataset(output_dir, 'BCI2a_Fixed', X_cat, y_cat, metadata, per_file_data)
    
    print('[BCI2a Fixed] ✅ 修复版处理完成!')
    print(f'数据已保存到: {output_dir}/BCI2a_Fixed/')
    print('预期改进: 准确率从25%提升到50-70%')
    return True

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='修复版BCI Competition IV Dataset 2a处理器')
    parser.add_argument('--data_dir', type=str, default=None, help='原始数据目录')
    parser.add_argument('--label_dir', type=str, default=None, help='标签文件目录')
    parser.add_argument('--output_dir', type=str, default='data/processed', help='输出目录')
    parser.add_argument('--subject', type=str, default=None, help='仅处理指定被试 (如: A01E)')
    parser.add_argument('--l_freq', type=float, default=4.0, help='低通滤波频率')
    parser.add_argument('--h_freq', type=float, default=38.0, help='高通滤波频率 (修复: 30->38)')
    parser.add_argument('--notch', type=float, default=50.0, help='陷波频率(Hz)')
    parser.add_argument('--car', type=int, default=1, help='1=使用CAR，0=不使用')
    parser.add_argument('--resample', type=float, default=250.0, help='重采样频率')
    parser.add_argument('--tmin', type=float, default=0.5, help='试验开始时间(秒) (修复: 0->0.5)')
    parser.add_argument('--tmax', type=float, default=2.5, help='试验结束时间(秒) (修复: 4->2.5)')
    parser.add_argument('--baseline_tmin', type=float, default=0.0, help='基线开始时间(秒)')
    parser.add_argument('--baseline_tmax', type=float, default=0.1, help='基线结束时间(秒)')
    parser.add_argument('--standardize', type=int, default=1, help='1=试次内标准化，0=不标准化')
    
    args = parser.parse_args()
    
    # 使用默认路径（如果未指定）
    if args.data_dir is None:
        args.data_dir = get_default_paths('2a')['data_dir']
    if args.label_dir is None:
        args.label_dir = get_default_paths('2a')['label_dir']
    
    print(f'[BCI2a Fixed] 修复版数据处理器')
    print(f'[BCI2a Fixed] 数据目录: {args.data_dir}')
    print(f'[BCI2a Fixed] 标签目录: {args.label_dir}')
    print(f'[BCI2a Fixed] 输出目录: {args.output_dir}')
    
    # 处理数据集
    success = process_bci2a_dataset_fixed(
        data_dir=args.data_dir,
        label_dir=args.label_dir,
        output_dir=args.output_dir,
        subject=args.subject,
        l_freq=args.l_freq,
        h_freq=args.h_freq,
        notch_freq=args.notch,
        car=bool(args.car),
        resample_freq=args.resample,
        tmin=args.tmin,
        tmax=args.tmax,
        baseline_tmin=args.baseline_tmin,
        baseline_tmax=args.baseline_tmax,
        standardize=bool(args.standardize)
    )
    
    if success:
        print('\n' + '=' * 60)
        print('[BCI2a Fixed] ✅ 修复版处理成功完成!')
        print('主要改进:')
        print('  ✅ 时间窗口: 4秒 -> 2秒关键时段')
        print('  ✅ 基线校正: 减去前100ms均值')
        print('  ✅ 试次内标准化: Z-score')
        print('  ✅ 标签编码: 1-4 -> 0-3')
        print('  ✅ 滤波范围: 30Hz -> 38Hz')
        print('\n预期效果: 准确率从25%提升到50-70%')
        print('下一步: 使用 processed/BCI2a_Fixed/ 重新训练模型')
    else:
        print('[BCI2a Fixed] ❌ 处理失败!')
        exit(1)

if __name__ == '__main__':
    main()