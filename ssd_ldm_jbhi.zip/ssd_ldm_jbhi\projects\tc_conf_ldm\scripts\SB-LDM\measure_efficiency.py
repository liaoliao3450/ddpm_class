#!/usr/bin/env python3
"""快速测量 Shared SB-LDM vs Non-shared LDM 的效率数据。"""
import sys
import time
from pathlib import Path

import torch
import torch.nn.functional as F
import yaml

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from core.models.latent_diffusion.model_shared import (
    SharedVAEUNetLDM1D,
    SharedBackboneConfig,
)
from projects.tc_conf_ldm.scripts.ablation_sb_ldm import NonSharedVAEUNetLDM1D

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
CONFIG_YAML = 'projects/tc_conf_ldm/configs/bci2a_tc_conf_ldm_shared.yaml'

# Shared SB-LDM checkpoint (500 epochs, same as three-scenario experiment)
SHARED_CKPT = 'checkpoints/tc_conf_ldm/sb_ldm_bci2a/sb_ldm_epoch_500.pt'
# Non-shared LDM checkpoint (200 epochs, from ablation)
NONSHARED_CKPT = 'checkpoints/tc_conf_ldm/ablation_no_shared_s42/sb_ldm_epoch_200.pt'


def load_config(yaml_path):
    with open(yaml_path, 'r') as f:
        return yaml.safe_load(f)


def build_model(cfg, model_cfg, shared=True):
    backbone = SharedBackboneConfig(
        base=int(model_cfg.get("backbone_base", 64)),
        levels=tuple(int(x) for x in model_cfg.get("backbone_levels", [1, 2, 4])),
        blocks_per_level=int(model_cfg.get("backbone_blocks_per_level", 2)),
    )
    cond_dim = int(model_cfg.get("cond_embed_dim", 64))
    cls = SharedVAEUNetLDM1D if shared else NonSharedVAEUNetLDM1D
    model = cls(
        channels=cfg["channels"],
        input_length=cfg["input_length"],
        z_channels=int(model_cfg.get("z_channels", 64)),
        timesteps=int(model_cfg.get("timesteps", 1000)),
        t_dim=int(model_cfg.get("t_dim", 128)),
        cond_dim=cond_dim,
        backbone=backbone,
        num_subjects=cfg.get("num_subjects", 9),
        adv_alpha=0.0,
    ).to(DEVICE)
    return model, cond_dim


def _compute_diffusion_loss(model, x, t, cond_input):
    """调用 model.forward 并从返回的 tuple 中提取 diffusion loss。

    forward 返回 (eps_pred, noise, mu, logvar, None)。
    """
    out = model(x, t, cond=cond_input)
    if isinstance(out, (tuple, list)):
        eps_pred, noise = out[0], out[1]
        return F.mse_loss(eps_pred, noise)
    if isinstance(out, dict):
        return sum(v for v in out.values() if isinstance(v, torch.Tensor))
    return out


def _make_ddim_schedule(alpha_bar, steps):
    """与 evaluate 脚本一致的 DDIM 调度。"""
    total = len(alpha_bar)
    step = total // steps
    return list(reversed(range(0, total, step)))[:steps]


def _ddim_sample(model, n_samples, latent_shape, cond, guidance_scale=2.0, ddim_steps=50):
    """DDIM 采样 (与 evaluate_sb_ldm_3datasets.generate_sb_ldm 一致)。"""
    device = next(model.parameters()).device
    z_channels, Lz = latent_shape
    z = torch.randn(n_samples, z_channels, Lz, device=device)
    ddim_seq = _make_ddim_schedule(model.alpha_bar, ddim_steps)
    eps = 1e-8

    for i, t_idx in enumerate(ddim_seq):
        t = torch.full((n_samples,), t_idx, device=device, dtype=torch.long)
        ec = model.denoise_eps(z, t, cond=cond)
        if guidance_scale > 1.0:
            eu = model.denoise_eps(z, t, cond=None)
            eps_pred = torch.clamp(eu + guidance_scale * (ec - eu), -100, 100)
        else:
            eps_pred = ec

        ab = model.alpha_bar[t_idx]
        ab_prev = model.alpha_bar[ddim_seq[i + 1]] if i + 1 < len(ddim_seq) else model.alpha_bar[0]
        ab = ab.to(device) if isinstance(ab, torch.Tensor) else torch.tensor(ab, device=device)
        ab_prev = ab_prev.to(device) if isinstance(ab_prev, torch.Tensor) else torch.tensor(ab_prev, device=device)

        sab = torch.sqrt(ab.clamp(min=eps))
        s1mb = torch.sqrt((1 - ab).clamp(min=eps))
        sab_prev = torch.sqrt(ab_prev.clamp(min=eps))
        s1mb_prev = torch.sqrt((1 - ab_prev).clamp(min=eps))

        pred_x0 = ((z - s1mb * eps_pred) / sab).clamp(-5, 5)
        z = sab_prev * pred_x0 + s1mb_prev * eps_pred

    # decode
    x = model.decode(z, target_length=model.input_length, cond=cond)
    return x


def measure_model(name, model, cond_dim, channels, input_length, timesteps=1000, num_classes=4):
    print(f"\n{'=' * 60}")
    print(f"测量: {name}")
    print(f"{'=' * 60}")

    # 1. 参数量
    total_params = sum(p.numel() for p in model.parameters())
    param_M = total_params / 1e6
    print(f"参数量: {total_params:,} ({param_M:.2f}M)")

    # 2. 模型大小 (fp32 = 4 bytes/param)
    model_size_MB = total_params * 4 / 1e6
    print(f"模型大小: {model_size_MB:.2f} MB")

    # 确定 latent_shape (通过编码一个 dummy 输入)
    model.eval()
    with torch.no_grad():
        dummy_x = torch.randn(1, channels, input_length, device=DEVICE)
        z, mu, _ = model.encode(dummy_x)
        latent_shape = (mu.shape[1], mu.shape[2])  # (z_channels, latent_length)
    print(f"Latent shape: {latent_shape}")

    cond_embed = torch.nn.Embedding(num_classes, cond_dim).to(DEVICE)

    # 3. 训练单步时间 (forward + backward)
    model.train()
    optim = torch.optim.AdamW(model.parameters(), lr=1e-4)
    batch_size = 64

    def _train_step():
        """生成新输入并执行一次 forward + backward + step。"""
        x = torch.randn(batch_size, channels, input_length, device=DEVICE)
        y = torch.randint(0, num_classes, (batch_size,), device=DEVICE)
        cond_input = cond_embed(y)
        t = torch.randint(0, timesteps, (batch_size,), device=DEVICE)
        optim.zero_grad()
        loss = _compute_diffusion_loss(model, x, t, cond_input)
        loss.backward()
        optim.step()

    # warmup
    for _ in range(3):
        _train_step()

    if DEVICE.type == 'cuda':
        torch.cuda.synchronize()
    t0 = time.time()
    n_steps = 20
    for _ in range(n_steps):
        _train_step()
    if DEVICE.type == 'cuda':
        torch.cuda.synchronize()
    train_time_per_step = (time.time() - t0) / n_steps
    print(f"训练单步时间: {train_time_per_step:.4f}s")

    # 4. DDIM-50 采样时间 (50 trials)
    model.eval()
    n_samples = 50
    sample_y = torch.randint(0, num_classes, (n_samples,), device=DEVICE)
    sample_cond = cond_embed(sample_y)
    with torch.no_grad():
        # warmup
        warmup_y = torch.randint(0, num_classes, (4,), device=DEVICE)
        warmup_cond = cond_embed(warmup_y)
        try:
            _ = _ddim_sample(model, 4, latent_shape, warmup_cond, guidance_scale=2.0, ddim_steps=50)
        except Exception as e:
            print(f"  (warmup sample 异常: {e})")

        if DEVICE.type == 'cuda':
            torch.cuda.synchronize()
        t0 = time.time()
        try:
            _ = _ddim_sample(model, n_samples, latent_shape, sample_cond, guidance_scale=2.0, ddim_steps=50)
        except Exception as e:
            print(f"  采样失败: {e}")
            t0 = time.time()
        if DEVICE.type == 'cuda':
            torch.cuda.synchronize()
        ddim_time = time.time() - t0
    print(f"DDIM-50 采样 ({n_samples} samples): {ddim_time:.4f}s")
    throughput = n_samples / ddim_time if ddim_time > 0 else 0
    print(f"吞吐量: {throughput:.2f} samples/s")

    return {
        "params_M": param_M,
        "model_size_MB": model_size_MB,
        "train_time_per_step": train_time_per_step,
        "ddim_50_time": ddim_time,
        "throughput": throughput,
    }


def main():
    cfg_yaml = load_config(CONFIG_YAML)
    model_cfg = cfg_yaml.get("model", {})
    channels = cfg_yaml.get("model", {}).get("channels", 22)
    input_length = cfg_yaml.get("model", {}).get("input_length", 1000)

    # 从 ablation 脚本的 TRAIN_DATASET_CONFIG 获取真实值
    from projects.tc_conf_ldm.scripts.ablation_sb_ldm import TRAIN_DATASET_CONFIG, DATASET
    train_cfg = TRAIN_DATASET_CONFIG[DATASET]
    channels = train_cfg["channels"]
    input_length = train_cfg["input_length"]

    timesteps = int(model_cfg.get("timesteps", 1000))
    print(f"配置: channels={channels}, input_length={input_length}, timesteps={timesteps}")

    # --- 1. Shared SB-LDM ---
    shared_model, cond_dim = build_model(train_cfg, model_cfg, shared=True)
    if Path(SHARED_CKPT).exists():
        ckpt = torch.load(SHARED_CKPT, map_location=DEVICE, weights_only=False)
        sd = ckpt.get('model_state_dict', ckpt.get('model', ckpt))
        shared_model.load_state_dict(sd, strict=False)
        print(f"已加载: {SHARED_CKPT}")
    else:
        print(f"警告: checkpoint 不存在 {SHARED_CKPT}, 使用随机权重")

    shared_results = measure_model("Shared SB-LDM", shared_model, cond_dim, channels, input_length, timesteps=timesteps)
    del shared_model
    if DEVICE.type == 'cuda':
        torch.cuda.empty_cache()

    # --- 2. Non-shared LDM ---
    nonshared_model, cond_dim = build_model(train_cfg, model_cfg, shared=False)
    if Path(NONSHARED_CKPT).exists():
        ckpt = torch.load(NONSHARED_CKPT, map_location=DEVICE, weights_only=False)
        sd = ckpt.get('model_state_dict', ckpt.get('model', ckpt))
        nonshared_model.load_state_dict(sd, strict=False)
        print(f"已加载: {NONSHARED_CKPT}")
    else:
        print(f"警告: checkpoint 不存在 {NONSHARED_CKPT}, 使用随机权重")

    nonshared_results = measure_model("Non-shared LDM", nonshared_model, cond_dim, channels, input_length, timesteps=timesteps)
    del nonshared_model
    if DEVICE.type == 'cuda':
        torch.cuda.empty_cache()

    # --- 3. 对比 ---
    print(f"\n{'=' * 60}")
    print("效率对比")
    print(f"{'=' * 60}")
    print(f"{'Metric':<25} {'Non-shared LDM':<20} {'SB-LDM (shared)':<20} {'Ratio':<10}")
    print("-" * 75)
    print(f"{'Parameters (M)':<25} {nonshared_results['params_M']:<20.2f} {shared_results['params_M']:<20.2f} {nonshared_results['params_M']/shared_results['params_M']:.2f}x")
    print(f"{'Model size (MB)':<25} {nonshared_results['model_size_MB']:<20.2f} {shared_results['model_size_MB']:<20.2f} {nonshared_results['model_size_MB']/shared_results['model_size_MB']:.2f}x")
    print(f"{'Train time/step (s)':<25} {nonshared_results['train_time_per_step']:<20.4f} {shared_results['train_time_per_step']:<20.4f} {nonshared_results['train_time_per_step']/shared_results['train_time_per_step']:.2f}x")
    print(f"{'DDIM-50 time (s)':<25} {nonshared_results['ddim_50_time']:<20.4f} {shared_results['ddim_50_time']:<20.4f} {nonshared_results['ddim_50_time']/shared_results['ddim_50_time']:.2f}x")
    print(f"{'Throughput (samp/s)':<25} {nonshared_results['throughput']:<20.2f} {shared_results['throughput']:<20.2f} {shared_results['throughput']/nonshared_results['throughput']:.2f}x")


if __name__ == '__main__':
    main()
