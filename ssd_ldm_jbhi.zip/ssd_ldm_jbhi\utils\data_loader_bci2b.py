#!/usr/bin/env python3
"""
BCI2b 数据加载工具（单独版本）

目标：
- 从 `data/processed/BCI2b` 的子目录（如 B0102T, B0104E）读取 X/y
- 解析被试与会话：被试键=前三位(B01)，会话=T->0, E->1
- 统一输出：X, y, subjects, sessions 以及 subject_key->idx 映射

注意：
- BCI2b 通常为二分类（标签会被标准化到 {0,1}）
- 通道数/时间长度以读取到的 X.shape 为准
"""

from __future__ import annotations

import os
from typing import Dict, Tuple

import numpy as np


def parse_bci2b_subject_session(name: str) -> Tuple[str, int]:
    """
    根据 BCI2b 处理后子目录名解析被试与会话类型。

    约定：
    - 子目录名形如: B0102T, B0104E 等
    - 被试键：前三个字符（如 'B01'）
    - 会话类型：最后一个字符，'T' 视为 session 0，'E' 视为 session 1
    """
    if len(name) < 4:
        return name, 0

    subject_key = name[:3]
    sess_char = name[-1].upper()
    if sess_char == "T":
        session_idx = 0
    elif sess_char == "E":
        session_idx = 1
    else:
        session_idx = 0
    return subject_key, session_idx


def load_bci2b_data(
    data_root: str = "data/processed/BCI2b",
    standardize: bool = True,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, Dict[str, int]]:
    """
    加载 BCI2b 预处理数据，并构造被试 / 会话标签。

    Returns:
        X: float32, [N, C, T]
        y: int64, [N], 标准化到从0开始
        subjects: int64, [N], 内部被试索引 0..n_subjects-1
        sessions: int64, [N], 0/1 (T/E)
        subject_key_to_idx: dict, 原始被试键 -> 内部索引
    """
    if not os.path.isdir(data_root):
        raise FileNotFoundError(f"BCI2b 处理后数据目录不存在: {data_root}")

    subdirs = sorted(
        d for d in os.listdir(data_root)
        if os.path.isdir(os.path.join(data_root, d))
    )

    if not subdirs:
        raise FileNotFoundError(f"在 {data_root} 下未找到任何子目录，请确认已运行 BCI2b 预处理脚本。")

    X_list = []
    y_list = []
    subjects_list = []
    sessions_list = []

    subject_key_to_idx: Dict[str, int] = {}
    next_subj_idx = 0

    for name in subdirs:
        sub_path = os.path.join(data_root, name)
        X_path = os.path.join(sub_path, "X.npy")
        y_path = os.path.join(sub_path, "y.npy")

        if not (os.path.exists(X_path) and os.path.exists(y_path)):
            continue

        print(f"[BCI2b] 加载子目录: {name}")
        X_file = np.load(X_path).astype(np.float32)
        y_file = np.load(y_path)

        # 标签标准化到从 0 开始
        y_file = (y_file - y_file.min()).astype(np.int64)

        subject_key, session_idx = parse_bci2b_subject_session(name)
        if subject_key not in subject_key_to_idx:
            subject_key_to_idx[subject_key] = next_subj_idx
            next_subj_idx += 1
        subj_idx = subject_key_to_idx[subject_key]

        n_trials = int(X_file.shape[0])
        X_list.append(X_file)
        y_list.append(y_file)
        subjects_list.extend([subj_idx] * n_trials)
        sessions_list.extend([session_idx] * n_trials)

        uniq = np.unique(y_file).tolist()
        print(f"  X: {X_file.shape}, y: {y_file.shape}, y_unique={uniq}, subject={subject_key}({subj_idx}), session={session_idx}")

    if not X_list:
        raise RuntimeError(f"在 {data_root} 下未成功加载任何 BCI2b 子目录数据。")

    X = np.concatenate(X_list, axis=0).astype(np.float32)
    y = np.concatenate(y_list, axis=0).astype(np.int64)
    subjects = np.array(subjects_list, dtype=np.int64)
    sessions = np.array(sessions_list, dtype=np.int64)

    if standardize:
        X = (X - X.mean(axis=(0, 2), keepdims=True)) / (X.std(axis=(0, 2), keepdims=True) + 1e-8)

    print("\n[BCI2b] 数据加载完成：")
    print(f"  总样本数: {len(X)}")
    print(f"  数据形状: {X.shape}")
    if y.min() >= 0:
        print(f"  类别分布: {np.bincount(y)}")
    print(f"  被试数: {len(np.unique(subjects))} (映射: {subject_key_to_idx})")
    print(f"  会话标签值: {sorted(np.unique(sessions).tolist())}（0 ≈ T, 1 ≈ E）")

    return X, y, subjects, sessions, subject_key_to_idx


