"""
SEED数据集处理器
专门处理SEED情感识别数据集
"""

import os
import argparse
from pathlib import Path
import numpy as np
import mne
import scipy.io as sio
from typing import List, Dict, Optional, Callable
import warnings
warnings.filterwarnings('ignore')

try:
    from .common import (
        DEFAULT_PATHS, get_default_paths, save_processed_dataset
    )
except ImportError:
    # 当直接运行模块时，使用绝对导入
    from common import (
        DEFAULT_PATHS, get_default_paths, save_processed_dataset
    )

def load_seed_dataset(data_dir: str, seed_sfreq: float = 200.0, 
                     per_file_consumer: Optional[Callable[[str, np.ndarray, np.ndarray], None]] = None, 
                     verbose: bool = True) -> Dict[str, np.ndarray]:
    """加载SEED数据集"""
    exclude = ['label.mat']
    mat_files = []
    for root, _, files in os.walk(data_dir):
        for f in files:
            if f.lower().endswith('.mat') and f.lower() != 'label.mat':
                mat_files.append(os.path.join(root, f))
    mat_files.sort()
    
    if verbose:
        print(f'[SEED] 在 {data_dir} 共发现 {len(mat_files)} 个数据 MAT 文件 (已排除 label.mat)')

    segments: List[np.ndarray] = []  # list of (C,T)
    labels: List[int] = []
    used_files: List[str] = []

    # SEED数据集的通道名称
    chs = ['FP1', 'FPZ', 'FP2', 'AF3', 'AF4', 'F7', 'F5', 'F3', 'F1',
           'FZ', 'F2', 'F4', 'F6', 'F8', 'FT7', 'FC5', 'FC3', 'FC1',
           'FCZ', 'FC2', 'FC4', 'FC6', 'FT8', 'T7', 'C5', 'C3', 'C1',
           'CZ', 'C2', 'C4', 'C6', 'T8', 'TP7', 'CP5', 'CP3', 'CP1',
           'CPZ', 'CP2', 'CP4', 'CP6', 'TP8', 'P7', 'P5', 'P3', 'P1',
           'PZ', 'P2', 'P4', 'P6', 'P8', 'PO7', 'PO5', 'PO3', 'POZ',
           'PO4', 'PO6', 'PO8', 'CB1', 'O1', 'OZ', 'O2', 'CB2']
    
    info = mne.create_info(ch_names=chs, sfreq=seed_sfreq, ch_types='eeg')

    # 情感标签映射
    base_labels = [1, 0, -1, -1, 0, 1, -1, 0, 1, 1, 0, -1, 0, 1, -1]

    for mat_path in mat_files:
        base = os.path.basename(mat_path)
        try:
            data = sio.loadmat(mat_path)
            keys = list(data.keys())[3:]  # 跳过MAT文件的元数据键
            
            if len(keys) == 0:
                if verbose:
                    print(f'[SEED] 跳过 {base}: 未发现数据键')
                continue
            
            seg_count = min(len(keys), len(base_labels))
            this_file_segments: List[np.ndarray] = []
            this_file_labels: List[int] = []
            
            for i in range(seg_count):
                stamp = np.array(data[keys[i]], dtype=np.float32)
                
                # 确保数据形状正确 (channels, time)
                if stamp.ndim == 2 and stamp.shape[0] > stamp.shape[1]:
                    stamp = stamp.T
                
                # 创建MNE Raw对象并裁剪前5秒
                raw = mne.io.RawArray(stamp, info, verbose='ERROR').crop(tmin=5)
                seg = raw.get_data().astype(np.float32, copy=False)
                
                this_file_segments.append(seg)
                this_file_labels.append(base_labels[i])

            if len(this_file_segments) == 0:
                continue
                
            # 如果提供了文件级消费者，调用它
            if per_file_consumer is not None:
                X_file = np.stack(this_file_segments, axis=0)
                y_file = np.array(this_file_labels, dtype=np.int64)
                per_file_consumer(mat_path, X_file, y_file)
            
            segments.extend(this_file_segments)
            labels.extend(this_file_labels)
            used_files.append(mat_path)
            
            if verbose:
                print(f"[SEED] 已读取: {base}, 段数={len(this_file_segments)}, "
                      f"C={this_file_segments[0].shape[0]}, T~{this_file_segments[0].shape[1]}")
                      
        except Exception as e:
            print(f'[SEED] 跳过 {base}: {e}')

    if len(segments) == 0:
        raise RuntimeError('[SEED] 未成功读取任何数据，请检查目录与文件完整性。')

    # 统一所有段的时间长度
    min_len = min(seg.shape[1] for seg in segments)
    X_cat = np.stack([seg[:, :min_len].astype(np.float32, copy=False) for seg in segments], axis=0)
    y_cat = np.array(labels, dtype=np.int64)
    
    if verbose:
        print(f'[SEED] 合并后: X={X_cat.shape}, y={y_cat.shape}')
    
    return {'X': X_cat, 'y': y_cat, 'files': used_files}

def process_seed_dataset(data_dir: str, output_dir: str, seed_sfreq: float = 200.0):
    """处理SEED数据集"""
    print('[SEED] 开始处理数据集...')
    
    # 检查原始数据目录
    if not os.path.exists(data_dir):
        print(f'[SEED] 错误: 原始数据目录不存在: {data_dir}')
        return False
    
    try:
        # 加载数据集
        seed_data = load_seed_dataset(
            data_dir=data_dir,
            seed_sfreq=seed_sfreq,
            verbose=True,
        )
        
        # 保存数据集
        metadata = {
            'files': seed_data['files'],
            'preprocessing': {
                'seed_sfreq': seed_sfreq,
                'crop_tmin': 5.0,  # 裁剪前5秒
                'description': 'SEED情感识别数据集'
            }
        }
        
        save_processed_dataset(output_dir, 'SEED', seed_data['X'], seed_data['y'], metadata)
        
        print('[SEED] 处理完成!')
        return True
        
    except Exception as e:
        print(f'[SEED] 处理失败: {e}')
        import traceback
        traceback.print_exc()
        return False

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='处理SEED情感识别数据集')
    parser.add_argument('--data_dir', type=str, default=None, help='原始数据目录')
    parser.add_argument('--output_dir', type=str, default='processed', help='输出目录')
    parser.add_argument('--sfreq', type=float, default=200.0, help='采样频率')
    
    args = parser.parse_args()
    
    # 使用默认路径（如果未指定）
    if args.data_dir is None:
        args.data_dir = get_default_paths('seed')['data_dir']
    
    print(f'[SEED] 数据目录: {args.data_dir}')
    print(f'[SEED] 输出目录: {args.output_dir}')
    print(f'[SEED] 采样频率: {args.sfreq} Hz')
    
    # 处理数据集
    success = process_seed_dataset(
        data_dir=args.data_dir,
        output_dir=args.output_dir,
        seed_sfreq=args.sfreq
    )
    
    if success:
        print('[SEED] 处理成功完成!')
    else:
        print('[SEED] 处理失败!')
        exit(1)

if __name__ == '__main__':
    main()