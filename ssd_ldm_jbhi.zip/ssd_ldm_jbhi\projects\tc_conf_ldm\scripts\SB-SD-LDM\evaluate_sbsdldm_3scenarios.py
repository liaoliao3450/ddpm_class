#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SB-SD-LDM 三场景统一协议评测 (journal 增强主表 Ours 行)
===============================================================
协议与 SB-LDM 会议版 (evaluate_sb_ldm_3datasets.py) 逐字对齐
(ICASSP Table II 三场景协议), 实现数据增强论文框架的主表:

  数据:        ev.load_dataset_data (全局按通道 z-score)
  Within:      每被试 80/20 分层划分 (train_test_split, seed 42)
  Cross-Sess.: session 0 训练 / session 1 测试
  Cross-Subj.: LOSO (BCI2a/2b) / LMSO 10-fold (PhysioNet, seed 42)
  分类器:      EEGNet x3 集成, 200 epochs, 软投票 (ev.train_classifier)
  GEN_RATIO:   1.0

Ours 生成 = 对齐融合生成 (L1+L2+L3, 与 ea_latentEA_combo 同款):
  encoder mu_z (零标签噪声) + 潜空间矩匹配 (L1)
  + chart(cov_target) 协方差条件风格 (L2, cov_only 模式)
  + 白化-重着色 (L3, 生成批协方差 == R_target)

目标域统计 (40 无标签 trial 统一预算, 与 EA-40/few-shot 协议一致):
  Within:        该被试训练 fold 前 40 trial (标签可用 -> latent_match 用真标签)
  Cross-Session: session-1 前 40 trial (无标签, teacher 伪标签)
  Cross-Subject: 测试被试前 40 trial (无标签, teacher 伪标签)

纯增强协议: 真实训练数据(原始) + 生成数据(原始) -> EEGNet x3 -> 测试(原始)
  (无任何 EA 白化 — 生成模型自己完成域对齐, 与表内全部增强基线对称)

real_only 模式: 不生成, 纯真实数据训练 (协议 replication sanity check,
  对照 ICASSP/ERD-DDPM 引用的 No-Aug 行)

锚点 (BCI2a, ev 协议): real-only CS 51.99 / SB-LDM CS 53.38 (ICASSP 发表)
  / Latent-EA full 纯增强 CS 53.80

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/evaluate_sbsdldm_3scenarios.py --dataset bci2a --scenario within
    $env:PYTHONUTF8='1'; python ... --dataset bci2a --scenario cross_session
    $env:PYTHONUTF8='1'; python ... --dataset bci2a --scenario cross_subject
    $env:PYTHONUTF8='1'; python ... --dataset physionet --scenario cross_subject
    $env:PYTHONUTF8='1'; python ... --dataset bci2a --method real_only --scenario all
"""
import sys
import json
import argparse
from pathlib import Path

import numpy as np
import torch
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, cohen_kappa_score

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from style_vae import load_style_vae
from style_vae_cov import load_p5, compute_subject_R
from ea_latentEA_combo import load_p2_model_ds, make_folds, DS_CONFIG
from evaluate_p5_cross_subject import generate_p5
from evaluate_p4_cross_subject import set_seed, DEVICE, N_ENSEMBLE

import importlib.util


def _load_ev():
    spec = importlib.util.spec_from_file_location(
        'evaluate_sb_ldm_3datasets',
        str(PROJECT_ROOT / 'projects/tc_conf_ldm/scripts/SB-LDM/evaluate_sb_ldm_3datasets.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


SEED = 42
GEN_RATIO = 1.0
N_FEWSHOT = 40


def _agg(results):
    accs = [r['acc'] for r in results]
    kappas = [r['kappa'] for r in results]
    print(f'\n平均: {np.mean(accs) * 100:.2f}% ± {np.std(accs) * 100:.2f}%, '
          f'Kappa: {np.mean(kappas):.4f}')
    return {'mean': float(np.mean(accs)), 'std': float(np.std(accs)),
            'mean_kappa': float(np.mean(kappas)), 'std_kappa': float(np.std(kappas)),
            'per_subject': accs, 'per_subject_kappa': kappas}


def _make_gen_fn(model, cond_embed, style_enc, chart, covemb, sigma0_p5,
                 W_subj, num_classes, z_source='encoder'):
    """闭包: cov_only 模式对齐融合生成 (L1+L2+L3).

    z_source='encoder': 真实 trial mu_z 重渲染 (零标签噪声路径)
    z_source='ddim':    扩散先验 DDIM 采样 + 复合仿射 L1 (真生成路径,
                        latent_match 内含 CFG 幅度修复, 无需 z_rescale)
    """

    def gen(spc, X_few, y_few_pl, X_pool, y_pool, train_ids):
        set_seed()
        gX, gy = generate_p5(
            model, cond_embed, style_enc, chart, covemb,
            spc, num_classes, 'cov_only', train_ids, W_subj,
            X_few=X_few, sigma0=sigma0_p5,
            z_source=z_source, X_pool=X_pool, y_pool=y_pool,
            latent_match=True, X_few_pl=X_few, y_few_pl=y_few_pl,
            amp_calib='full')
        return np.nan_to_num(gX.astype(np.float32), nan=0.0), gy

    return gen


# ============================================================================
# 场景 1: Within-Subject (80/20 分层, 与 ev.within_subject_test 逐字对齐)
# ============================================================================
def run_within(ev, gen, X, y, subjects, num_classes, channels, input_length):
    print('\n' + '=' * 72)
    print('场景 1: Within-Subject (80/20 分层划分)')
    print('=' * 72)
    results = []
    for si, subj in enumerate(np.unique(subjects)):
        m = subjects == subj
        X_s, y_s = X[m], y[m]
        X_tr, X_te, y_tr, y_te = train_test_split(
            X_s, y_s, test_size=0.2, random_state=42, stratify=y_s)

        if gen is not None:
            # 目标域 = 训练分布; 前 40 trial 统计 (标签可用 -> 真标签)
            n_use = min(N_FEWSHOT, len(X_tr))
            X_few, y_few = X_tr[:n_use], y_tr[:n_use]
            spc = max(1, int(GEN_RATIO * len(X_tr)) // num_classes)
            gX, gy = gen(spc, X_few, y_few, X_tr, y_tr, [int(subj)])
            X_aug = np.concatenate([X_tr, gX])
            y_aug = np.concatenate([y_tr, gy])
        else:
            X_aug, y_aug = X_tr, y_tr

        clf = ev.train_classifier(X_aug, y_aug, channels, input_length, num_classes)
        pred = ev.predict(clf, X_te)
        acc = float(accuracy_score(y_te, pred))
        kappa = float(cohen_kappa_score(y_te, pred))
        results.append({'acc': acc, 'kappa': kappa})
        print(f'  被试 {si + 1}/{len(np.unique(subjects))}: '
              f'Acc {acc * 100:.2f}%, Kappa {kappa:.4f}')
    return _agg(results)


# ============================================================================
# 场景 2: Cross-Session (session 0 训练 / session 1 测试)
# ============================================================================
def run_cross_session(ev, gen, X, y, subjects, sessions, num_classes,
                      channels, input_length, pseudo_label):
    print('\n' + '=' * 72)
    print('场景 2: Cross-Session (session 0 训练 / session 1 测试)')
    print('=' * 72)
    results = []
    for si, subj in enumerate(np.unique(subjects)):
        m_tr = (subjects == subj) & (sessions == 0)
        m_te = (subjects == subj) & (sessions == 1)
        X_tr, y_tr = X[m_tr], y[m_tr]
        X_te, y_te = X[m_te], y[m_te]
        if len(X_tr) == 0 or len(X_te) == 0:
            continue

        if gen is not None:
            # 目标域 = session 1 (测试); 前 40 trial 无标签统计 (伪标签)
            n_use = min(N_FEWSHOT, len(X_te))
            X_few = X_te[:n_use]
            y_few_pl = pseudo_label(X_few)
            spc = max(1, int(GEN_RATIO * len(X_tr)) // num_classes)
            gX, gy = gen(spc, X_few, y_few_pl, X_tr, y_tr, [int(subj)])
            X_aug = np.concatenate([X_tr, gX])
            y_aug = np.concatenate([y_tr, gy])
        else:
            X_aug, y_aug = X_tr, y_tr

        clf = ev.train_classifier(X_aug, y_aug, channels, input_length, num_classes)
        pred = ev.predict(clf, X_te)
        acc = float(accuracy_score(y_te, pred))
        kappa = float(cohen_kappa_score(y_te, pred))
        results.append({'acc': acc, 'kappa': kappa})
        print(f'  被试 {si + 1}/{len(np.unique(subjects))}: '
              f'Acc {acc * 100:.2f}%, Kappa {kappa:.4f}')
    return _agg(results)


# ============================================================================
# 场景 3: Cross-Subject (LOSO / LMSO 10-fold, 纯增强协议, 测试原始)
# ============================================================================
def run_cross_subject(ev, gen, X, y, subjects, sessions, num_classes,
                      channels, input_length, mode, pseudo_label):
    print('\n' + '=' * 72)
    print(f'场景 3: Cross-Subject ({mode.upper()}, 纯增强协议)')
    print('=' * 72)
    n_subj = len(np.unique(subjects))
    results = []
    folds = make_folds(subjects, mode)
    for fold_idx, test_group in enumerate(folds):
        m_tr = ~np.isin(subjects, test_group)
        m_te = np.isin(subjects, test_group)
        X_tr, y_tr = X[m_tr], y[m_tr]
        X_te, y_te = X[m_te], y[m_te]
        train_ids = [int(s) for s in np.unique(subjects[m_tr])]

        if gen is not None:
            # 每个测试被试: 对齐到其 R_test 的生成样本 (无标签 40 trial)
            spc = max(1, int(GEN_RATIO * len(X_tr))
                      // (len(test_group) * num_classes))
            parts_X, parts_y = [], []
            for s in test_group:
                m_s = subjects == s
                X_s_raw, _ = X[m_s], y[m_s]
                n_use = min(N_FEWSHOT, len(X_s_raw))
                X_few = X_s_raw[:n_use]
                y_few_pl = pseudo_label(X_few)
                gX, gy = gen(spc, X_few, y_few_pl, X_tr, y_tr, train_ids)
                parts_X.append(gX)
                parts_y.append(gy)
            X_aug = np.concatenate([X_tr] + parts_X)
            y_aug = np.concatenate([y_tr] + parts_y)
        else:
            X_aug, y_aug = X_tr, y_tr

        clf = ev.train_classifier(X_aug, y_aug, channels, input_length, num_classes)
        pred = ev.predict(clf, X_te)
        acc = float(accuracy_score(y_te, pred))
        kappa = float(cohen_kappa_score(y_te, pred))
        results.append({'acc': acc, 'kappa': kappa})
        print(f'  折 {fold_idx + 1}/{len(folds)} (测试被试 {test_group}): '
              f'Acc {acc * 100:.2f}%, Kappa {kappa:.4f}')
    return _agg(results)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', type=str, default='bci2a',
                        choices=['bci2a', 'bci2b', 'physionet'])
    parser.add_argument('--scenario', type=str, default='all',
                        choices=['within', 'cross_session', 'cross_subject', 'all'])
    parser.add_argument('--method', type=str, default='ours',
                        choices=['ours', 'real_only'],
                        help='ours=对齐融合生成增强 / real_only=纯真实 (协议 sanity)')
    parser.add_argument('--z_source', type=str, default='encoder',
                        choices=['encoder', 'ddim'],
                        help='z 来源: encoder=真实trial重渲染 / ddim=扩散先验采样 (真生成路径)')
    parser.add_argument('--tag', type=str, default='')
    args = parser.parse_args()

    ds = DS_CONFIG[args.dataset]
    channels = ds['channels']
    input_length = ds['input_length']
    num_classes = ds['num_classes']
    mode = ds['mode']

    print('=' * 72)
    print(f'SB-SD-LDM 三场景统一协议评测: {args.dataset} / {args.method} / '
          f'{args.scenario} (GEN_RATIO={GEN_RATIO}, N_FEWSHOT={N_FEWSHOT})')
    print('=' * 72)

    ev = _load_ev()
    ev.GEN_RATIO = GEN_RATIO
    ev.N_ENSEMBLE = N_ENSEMBLE

    # 数据 (ev 全局按通道 z-score, 与 ICASSP 协议一致)
    X, y, subjects, sessions = ev.load_dataset_data(args.dataset)
    subj_uniq = np.unique(subjects)
    if subj_uniq.max() != len(subj_uniq) - 1:
        remap = {s: i for i, s in enumerate(subj_uniq)}
        subjects = np.array([remap[s] for s in subjects])
    sessions = np.asarray(sessions)
    channels, input_length = X.shape[1], X.shape[2]

    gen = None
    if args.method == 'ours':
        model, cond_embed = load_p2_model_ds(
            PROJECT_ROOT / ds['p2_ckpt'], channels, input_length, num_classes)
        W_subj = model.subj_embed.weight.detach()
        style_enc, _, _ = load_style_vae(
            PROJECT_ROOT / ds['p4_ckpt'], channels=channels,
            input_length=input_length, num_classes=num_classes, device=DEVICE)
        chart, covemb, sigma0_p5 = load_p5(
            PROJECT_ROOT / ds['p5_ckpt'], device=DEVICE)
        gen = _make_gen_fn(model, cond_embed, style_enc, chart, covemb,
                           sigma0_p5, W_subj, num_classes,
                           z_source=args.z_source)

    # teacher 伪标签 (cross_session / cross_subject 的 40-trial 无标签统计)
    from core.classifiers.eegnet import EEGNet
    teacher = EEGNet(n_channels=channels, n_samples=input_length,
                     n_classes=num_classes).to(DEVICE)
    state = torch.load(str(PROJECT_ROOT / ds['teacher_ckpt']),
                       map_location=DEVICE, weights_only=False)
    if isinstance(state, dict) and 'model_state_dict' in state:
        state = state['model_state_dict']
    teacher.load_state_dict(state, strict=False)
    teacher.eval()

    def pseudo_label(Xf):
        with torch.no_grad():
            xb = torch.FloatTensor(np.asarray(Xf)).unsqueeze(1).to(DEVICE)
            return teacher(xb).argmax(1).cpu().numpy()

    zs_tag = '' if args.z_source == 'encoder' else f'_{args.z_source}'
    results_path = (PROJECT_ROOT / 'outputs' / 'results' /
                    f'sbsdldm_3scenarios_{args.dataset}_{args.method}'
                    f'{zs_tag}{args.tag}.json')
    results_path.parent.mkdir(parents=True, exist_ok=True)
    out = {'config': {'dataset': args.dataset, 'method': args.method,
                      'z_source': args.z_source,
                      'gen_ratio': GEN_RATIO, 'n_fewshot': N_FEWSHOT,
                      'protocol': 'ICASSP ev 三场景, 纯增强 (无 EA 白化)'}}
    if results_path.exists():
        with open(results_path, 'r', encoding='utf-8') as f:
            try:
                out.update(json.load(f))
            except Exception:
                pass

    if args.scenario in ('within', 'all') and args.dataset != 'physionet':
        out['within_subject'] = run_within(
            ev, gen, X, y, subjects, num_classes, channels, input_length)
    if args.scenario in ('cross_session', 'all') and args.dataset != 'physionet':
        out['cross_session'] = run_cross_session(
            ev, gen, X, y, subjects, sessions, num_classes,
            channels, input_length, pseudo_label)
    if args.scenario in ('cross_subject', 'all'):
        out['cross_subject'] = run_cross_subject(
            ev, gen, X, y, subjects, sessions, num_classes,
            channels, input_length, mode, pseudo_label)

    with open(results_path, 'w', encoding='utf-8') as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f'\n结果已保存: {results_path}')

    print('\n' + '=' * 72)
    print(f'汇总 ({args.dataset} / {args.method}):')
    for k in ('within_subject', 'cross_session', 'cross_subject'):
        if k in out and isinstance(out[k], dict) and 'mean' in out[k]:
            r = out[k]
            print(f'  {k:<16} Acc {r["mean"] * 100:.2f}% ± {r["std"] * 100:.2f}%  '
                  f'Kappa {r["mean_kappa"]:.4f}')
    print('=' * 72)


if __name__ == '__main__':
    main()
