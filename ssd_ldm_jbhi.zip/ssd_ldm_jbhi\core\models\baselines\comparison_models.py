"""
Baseline Models for Comparative Experiments

5 comparison methods for ERD-DDPM paper:
1. WaveGAN - GAN-based baseline (1D transposed convolution)
2. Cond-DDPM - Standard conditional DDPM (no ERD/spectral guidance)
3. BrainDiff - RL-guided diffusion (simplified actor-critic weight guidance)
4. EEGDiff - Transformer-based diffusion with multi-scale conv + Fourier spectrum
5. DiffEEGBooth - 3D structured EEG diffusion with ERD/ERS constraints

References:
- WaveGAN: Donahue et al., "Adversarial Audio Synthesis", ICLR 2019
- BrainDiff: An et al., "Enhancing EEG Signal Generation through RL and Diffusion", 2024
- EEGDiff: Chen et al., "Improving EEG Classification with Transformer-based Diffusion", 2024
- DiffEEGBooth: Huang et al., "DiffEEGBooth: A diffusion-based EEG generation framework", 2026
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


# ============================================================================
# 1. WaveGAN - GAN Baseline
# ============================================================================

class WaveGANGenerator(nn.Module):
    """WaveGAN generator: 1D transposed convolution with class conditioning"""

    def __init__(self, z_dim=100, channels=22, out_length=1000, num_classes=4):
        super().__init__()
        self.z_dim = z_dim
        self.out_length = out_length
        self.num_classes = num_classes
        self.class_embed = nn.Embedding(num_classes, 32)

        # Calculate base length
        # 4 upsampling stages: x16
        self.base_len = out_length // 16
        if self.base_len < 1:
            self.base_len = 1

        self.fc = nn.Linear(z_dim + 32, 256 * self.base_len)

        self.net = nn.Sequential(
            nn.ConvTranspose1d(256, 128, kernel_size=5, stride=4, padding=1),
            nn.BatchNorm1d(128), nn.ReLU(True),
            nn.ConvTranspose1d(128, 64, kernel_size=5, stride=4, padding=1),
            nn.BatchNorm1d(64), nn.ReLU(True),
            nn.ConvTranspose1d(64, 32, kernel_size=5, stride=1, padding=2),
            nn.BatchNorm1d(32), nn.ReLU(True),
            nn.ConvTranspose1d(32, channels, kernel_size=5, stride=1, padding=2),
        )

    def forward(self, z, y):
        y_emb = self.class_embed(y)
        z_cond = torch.cat([z, y_emb], dim=1)
        h = self.fc(z_cond)
        h = h.view(z.size(0), 256, -1)
        x = self.net(h)
        if x.size(-1) != self.out_length:
            x = F.interpolate(x, size=self.out_length, mode='linear', align_corners=False)
        return x


class WaveGANDiscriminator(nn.Module):
    """WaveGAN discriminator with spectral normalization and class conditioning"""

    def __init__(self, channels=22, in_length=1000, num_classes=4):
        super().__init__()
        self.num_classes = num_classes
        self.class_embed = nn.Embedding(num_classes, 32)

        self.net = nn.Sequential(
            nn.utils.spectral_norm(nn.Conv1d(channels, 32, kernel_size=5, stride=4, padding=1)),
            nn.LeakyReLU(0.2, True),
            nn.utils.spectral_norm(nn.Conv1d(32, 64, kernel_size=5, stride=4, padding=1)),
            nn.LeakyReLU(0.2, True),
            nn.utils.spectral_norm(nn.Conv1d(64, 128, kernel_size=5, stride=4, padding=1)),
            nn.LeakyReLU(0.2, True),
            nn.utils.spectral_norm(nn.Conv1d(128, 256, kernel_size=5, stride=1, padding=2)),
            nn.LeakyReLU(0.2, True),
        )
        self.gap = nn.AdaptiveAvgPool1d(1)
        self.fc = nn.utils.spectral_norm(nn.Linear(256 + 32, 1))

    def forward(self, x, y):
        h = self.net(x)
        h = self.gap(h).squeeze(-1)
        y_emb = self.class_embed(y)
        h = torch.cat([h, y_emb], dim=1)
        return self.fc(h)


class WaveGAN(nn.Module):
    """WaveGAN wrapper for unified interface"""

    def __init__(self, channels=22, out_length=1000, num_classes=4, z_dim=100, fs=250):
        super().__init__()
        self.generator = WaveGANGenerator(z_dim, channels, out_length, num_classes)
        self.discriminator = WaveGANDiscriminator(channels, out_length, num_classes)
        self.channels = channels
        self.out_length = out_length
        self.num_classes = num_classes
        self.z_dim = z_dim
        self.fs = fs

    def generate(self, n_samples, y, device='cuda'):
        """Generate samples"""
        z = torch.randn(n_samples, self.z_dim, device=device)
        return self.generator(z, y)


# ============================================================================
# 2. Cond-DDPM - Standard Conditional DDPM (No ERD/Spectral Guidance)
# ============================================================================

class CondDDPMUNet(nn.Module):
    """Standard conditional UNet - same architecture as ERD-DDPM but without
    ERD/spectral loss components during training"""

    def __init__(self, channels=22, num_classes=4, time_dim=256, base_ch=64):
        super().__init__()
        self.channels = channels
        self.num_classes = num_classes
        self.time_dim = time_dim

        # Simple class embedding (not enhanced)
        self.class_embed = nn.Embedding(num_classes, 256)
        self.time_mlp = nn.Sequential(
            nn.Linear(time_dim, 512), nn.SiLU(), nn.Linear(512, 256),
        )

        cond_dim = 256
        self.in_proj = nn.Conv1d(channels, base_ch, 3, padding=1)

        # Encoder
        self.down1 = nn.ModuleList([
            self._resblock(base_ch, base_ch * 2, cond_dim),
            self._resblock(base_ch * 2, base_ch * 2, cond_dim),
        ])
        self.down2 = nn.ModuleList([
            self._resblock(base_ch * 2, base_ch * 4, cond_dim),
            self._resblock(base_ch * 4, base_ch * 4, cond_dim),
        ])
        self.down3 = nn.ModuleList([
            self._resblock(base_ch * 4, base_ch * 8, cond_dim),
            self._resblock(base_ch * 8, base_ch * 8, cond_dim),
        ])

        # Bottleneck
        self.mid = nn.ModuleList([
            self._resblock(base_ch * 8, base_ch * 8, cond_dim),
            self._resblock(base_ch * 8, base_ch * 8, cond_dim),
        ])

        # Decoder
        self.up3 = nn.ModuleList([
            self._resblock(base_ch * 16, base_ch * 8, cond_dim),
            self._resblock(base_ch * 8, base_ch * 4, cond_dim),
        ])
        self.up2 = nn.ModuleList([
            self._resblock(base_ch * 8, base_ch * 4, cond_dim),
            self._resblock(base_ch * 4, base_ch * 2, cond_dim),
        ])
        self.up1 = nn.ModuleList([
            self._resblock(base_ch * 4, base_ch * 2, cond_dim),
            self._resblock(base_ch * 2, base_ch, cond_dim),
        ])

        self.out = nn.Sequential(
            nn.GroupNorm(8, base_ch), nn.SiLU(), nn.Conv1d(base_ch, channels, 3, padding=1),
        )
        self.pool = nn.AvgPool1d(2)

    def _resblock(self, in_ch, out_ch, cond_dim):
        return nn.ModuleDict({
            'conv1': nn.Conv1d(in_ch, out_ch, 3, padding=1),
            'conv2': nn.Conv1d(out_ch, out_ch, 3, padding=1),
            'norm1': nn.GroupNorm(8, out_ch),
            'norm2': nn.GroupNorm(8, out_ch),
            'cond_proj': nn.Linear(cond_dim, out_ch),
            'skip': nn.Conv1d(in_ch, out_ch, 1) if in_ch != out_ch else nn.Identity(),
        })

    def _forward_resblock(self, x, block, cond):
        h = block['norm1'](F.silu(block['conv1'](x)))
        h = h + block['cond_proj'](cond).unsqueeze(-1)
        h = block['norm2'](F.silu(block['conv2'](h)))
        return h + block['skip'](x)

    def forward(self, x, t, y):
        t_emb = sinusoidal_embedding(t, self.time_dim)
        t_emb = self.time_mlp(t_emb)
        c_emb = self.class_embed(y)
        cond = t_emb + c_emb

        h = self.in_proj(x)
        h1 = self._forward_resblock(h, self.down1[0], cond)
        h1 = self._forward_resblock(h1, self.down1[1], cond)
        h2 = self._forward_resblock(self.pool(h1), self.down2[0], cond)
        h2 = self._forward_resblock(h2, self.down2[1], cond)
        h3 = self._forward_resblock(self.pool(h2), self.down3[0], cond)
        h3 = self._forward_resblock(h3, self.down3[1], cond)

        m = self._forward_resblock(self.pool(h3), self.mid[0], cond)
        m = self._forward_resblock(m, self.mid[1], cond)

        m = F.interpolate(m, size=h3.size(-1), mode='linear', align_corners=False)
        u3 = self._forward_resblock(torch.cat([m, h3], dim=1), self.up3[0], cond)
        u3 = self._forward_resblock(u3, self.up3[1], cond)

        u3 = F.interpolate(u3, size=h2.size(-1), mode='linear', align_corners=False)
        u2 = self._forward_resblock(torch.cat([u3, h2], dim=1), self.up2[0], cond)
        u2 = self._forward_resblock(u2, self.up2[1], cond)

        u2 = F.interpolate(u2, size=h1.size(-1), mode='linear', align_corners=False)
        u1 = self._forward_resblock(torch.cat([u2, h1], dim=1), self.up1[0], cond)
        u1 = self._forward_resblock(u1, self.up1[1], cond)

        return self.out(u1)


class CondDDPM(nn.Module):
    """Standard Conditional DDPM - only noise loss, no ERD/spectral guidance"""

    def __init__(self, channels=22, n_samples=1000, num_classes=4, n_timesteps=1000, fs=250):
        super().__init__()
        self.eps_model = CondDDPMUNet(channels, num_classes)
        self.n_timesteps = n_timesteps
        self.channels = channels
        self.n_samples = n_samples
        self.fs = fs
        self.num_classes = num_classes

        # Cosine schedule
        steps = torch.arange(0, n_timesteps + 1, dtype=torch.float32)
        ac = torch.cos(((steps / n_timesteps) + 0.008) / 1.008 * (np.pi / 2)) ** 2
        ac = ac / ac[0]
        betas = torch.clamp(1 - ac[1:] / ac[:-1], 1e-4, 0.02)

        self.register_buffer('beta', betas)
        self.register_buffer('alpha', 1 - betas)
        self.register_buffer('alpha_bar', torch.cumprod(self.alpha, 0))
        self.register_buffer('sqrt_ab', torch.sqrt(self.alpha_bar))
        self.register_buffer('sqrt_1_ab', torch.sqrt(1 - self.alpha_bar))

    def loss(self, x0, y):
        B = x0.size(0)
        device = x0.device
        t = torch.randint(0, self.n_timesteps, (B,), device=device)
        eps = torch.randn_like(x0)
        x_t = self.sqrt_ab[t].view(B, 1, 1) * x0 + self.sqrt_1_ab[t].view(B, 1, 1) * eps
        eps_pred = self.eps_model(x_t, t, y)
        return F.mse_loss(eps_pred, eps)

    @torch.no_grad()
    def sample_ddim(self, batch_size, y, steps=50, guidance_scale=0.0, device=None):
        if device is None:
            device = next(self.parameters()).device
        x = torch.randn(batch_size, self.channels, self.n_samples, device=device)
        timesteps = torch.linspace(self.n_timesteps - 1, 0, steps, dtype=torch.long, device=device)

        for i, ti in enumerate(timesteps):
            t = torch.full((batch_size,), ti.item(), device=device, dtype=torch.long)
            eps = self.eps_model(x, t, y)
            alpha_bar_t = self.alpha_bar[ti]
            x0_pred = (x - torch.sqrt(1 - alpha_bar_t) * eps) / torch.sqrt(alpha_bar_t)
            if i < len(timesteps) - 1:
                alpha_bar_prev = self.alpha_bar[timesteps[i + 1]]
                # DDIM deterministic (eta=0): direction pointing to x_t
                dir_xt = (x - torch.sqrt(alpha_bar_t) * x0_pred) / torch.sqrt(1 - alpha_bar_t)
                x = torch.sqrt(alpha_bar_prev) * x0_pred + torch.sqrt(1 - alpha_bar_prev) * dir_xt
            else:
                x = x0_pred
        return x

    @torch.no_grad()
    def sample(self, batch_size, y, device=None):
        """Standard DDPM sampling (1000 steps)."""
        if device is None:
            device = next(self.parameters()).device
        x = torch.randn(batch_size, self.channels, self.n_samples, device=device)
        for ti in reversed(range(self.n_timesteps)):
            t = torch.full((batch_size,), ti, device=device, dtype=torch.long)
            eps_pred = self.eps_model(x, t, y)
            beta_t = self.beta[ti]
            alpha_t = self.alpha[ti]
            alpha_bar_t = self.alpha_bar[ti]
            # Predict x0
            x0_pred = (x - torch.sqrt(1 - alpha_bar_t) * eps_pred) / torch.sqrt(alpha_bar_t)
            # Posterior mean
            mean = (1 / torch.sqrt(alpha_t)) * (x - (beta_t / torch.sqrt(1 - alpha_bar_t)) * eps_pred)
            if ti > 0:
                noise = torch.randn_like(x)
                sigma = torch.sqrt(beta_t)
                x = mean + sigma * noise
            else:
                x = mean
        return x


# ============================================================================
# 3. BrainDiff - RL-Guided Diffusion (Simplified)
# ============================================================================

class BrainDiffUNet(nn.Module):
    """BrainDiff UNet with RL weight guidance mechanism.
    Simplified from An et al. (2024): actor-critic selects loss weights dynamically."""

    def __init__(self, channels=22, num_classes=4, time_dim=256, base_ch=64):
        super().__init__()
        self.channels = channels
        self.num_classes = num_classes
        self.time_dim = time_dim

        self.class_embed = nn.Embedding(num_classes, 256)
        self.time_mlp = nn.Sequential(
            nn.Linear(time_dim, 512), nn.SiLU(), nn.Linear(512, 256),
        )
        cond_dim = 256
        self.in_proj = nn.Conv1d(channels, base_ch, 3, padding=1)

        # Same UNet structure as CondDDPM
        self.down1 = self._make_stage(base_ch, base_ch * 2, cond_dim)
        self.down2 = self._make_stage(base_ch * 2, base_ch * 4, cond_dim)
        self.down3 = self._make_stage(base_ch * 4, base_ch * 8, cond_dim)
        self.mid = self._make_stage(base_ch * 8, base_ch * 8, cond_dim)
        self.up3 = self._make_stage(base_ch * 16, base_ch * 4, cond_dim)
        self.up2 = self._make_stage(base_ch * 8, base_ch * 2, cond_dim)
        self.up1 = self._make_stage(base_ch * 4, base_ch, cond_dim)

        self.out = nn.Sequential(
            nn.GroupNorm(8, base_ch), nn.SiLU(), nn.Conv1d(base_ch, channels, 3, padding=1),
        )
        self.pool = nn.AvgPool1d(2)

        # RL Actor: predicts loss weights [noise_w, spectral_w, temporal_w]
        self.actor = nn.Sequential(
            nn.Linear(4, 64), nn.ReLU(),
            nn.Linear(64, 32), nn.ReLU(),
            nn.Linear(32, 3), nn.Softmax(dim=-1),
        )

        # RL Critic: estimates value
        self.critic = nn.Sequential(
            nn.Linear(4, 64), nn.ReLU(),
            nn.Linear(64, 32), nn.ReLU(),
            nn.Linear(32, 1),
        )

    def _make_stage(self, in_ch, out_ch, cond_dim):
        return nn.ModuleDict({
            'block1': self._resblock(in_ch, out_ch, cond_dim),
            'block2': self._resblock(out_ch, out_ch, cond_dim),
        })

    def _resblock(self, in_ch, out_ch, cond_dim):
        return nn.ModuleDict({
            'conv1': nn.Conv1d(in_ch, out_ch, 3, padding=1),
            'conv2': nn.Conv1d(out_ch, out_ch, 3, padding=1),
            'norm1': nn.GroupNorm(8, out_ch),
            'norm2': nn.GroupNorm(8, out_ch),
            'cond_proj': nn.Linear(cond_dim, out_ch),
            'skip': nn.Conv1d(in_ch, out_ch, 1) if in_ch != out_ch else nn.Identity(),
        })

    def _forward_resblock(self, x, block, cond):
        h = block['norm1'](F.silu(block['conv1'](x)))
        h = h + block['cond_proj'](cond).unsqueeze(-1)
        h = block['norm2'](F.silu(block['conv2'](h)))
        return h + block['skip'](x)

    def forward(self, x, t, y):
        t_emb = sinusoidal_embedding(t, self.time_dim)
        t_emb = self.time_mlp(t_emb)
        c_emb = self.class_embed(y)
        cond = t_emb + c_emb

        h = self.in_proj(x)
        h1 = self._forward_resblock(h, self.down1['block1'], cond)
        h1 = self._forward_resblock(h1, self.down1['block2'], cond)
        h2 = self._forward_resblock(self.pool(h1), self.down2['block1'], cond)
        h2 = self._forward_resblock(h2, self.down2['block2'], cond)
        h3 = self._forward_resblock(self.pool(h2), self.down3['block1'], cond)
        h3 = self._forward_resblock(h3, self.down3['block2'], cond)

        m = self._forward_resblock(self.pool(h3), self.mid['block1'], cond)
        m = self._forward_resblock(m, self.mid['block2'], cond)

        m = F.interpolate(m, size=h3.size(-1), mode='linear', align_corners=False)
        u3 = self._forward_resblock(torch.cat([m, h3], dim=1), self.up3['block1'], cond)
        u3 = self._forward_resblock(u3, self.up3['block2'], cond)

        u3 = F.interpolate(u3, size=h2.size(-1), mode='linear', align_corners=False)
        u2 = self._forward_resblock(torch.cat([u3, h2], dim=1), self.up2['block1'], cond)
        u2 = self._forward_resblock(u2, self.up2['block2'], cond)

        u2 = F.interpolate(u2, size=h1.size(-1), mode='linear', align_corners=False)
        u1 = self._forward_resblock(torch.cat([u2, h1], dim=1), self.up1['block1'], cond)
        u1 = self._forward_resblock(u1, self.up1['block2'], cond)

        return self.out(u1)

    def get_rl_weights(self, state):
        """Get RL-predicted loss weights. state = [noise_loss, spectral_loss, temporal_loss, epoch_progress]"""
        return self.actor(state)


class BrainDiff(nn.Module):
    """BrainDiff: RL-guided diffusion model.
    Uses actor-critic to dynamically adjust loss weights during training."""

    def __init__(self, channels=22, n_samples=1000, num_classes=4, n_timesteps=1000, fs=250):
        super().__init__()
        self.eps_model = BrainDiffUNet(channels, num_classes)
        self.n_timesteps = n_timesteps
        self.channels = channels
        self.n_samples = n_samples
        self.fs = fs
        self.num_classes = num_classes

        # Cosine schedule
        steps = torch.arange(0, n_timesteps + 1, dtype=torch.float32)
        ac = torch.cos(((steps / n_timesteps) + 0.008) / 1.008 * (np.pi / 2)) ** 2
        ac = ac / ac[0]
        betas = torch.clamp(1 - ac[1:] / ac[:-1], 1e-4, 0.02)

        self.register_buffer('beta', betas)
        self.register_buffer('alpha', 1 - betas)
        self.register_buffer('alpha_bar', torch.cumprod(self.alpha, 0))
        self.register_buffer('sqrt_ab', torch.sqrt(self.alpha_bar))
        self.register_buffer('sqrt_1_ab', torch.sqrt(1 - self.alpha_bar))

        # Spectral loss components
        freqs = torch.fft.rfftfreq(n_samples, 1.0 / fs)
        self.register_buffer('freqs', freqs)

    def compute_spectral_loss(self, x0_pred, x0):
        """Log-PSD MSE loss"""
        fft_pred = torch.fft.rfft(x0_pred, dim=-1)
        psd_pred = (fft_pred.abs() ** 2).mean(dim=(0, 1))
        fft_real = torch.fft.rfft(x0, dim=-1)
        psd_real = (fft_real.abs() ** 2).mean(dim=(0, 1))
        return F.mse_loss(torch.log(psd_pred + 1e-10), torch.log(psd_real + 1e-10))

    def compute_temporal_loss(self, x0_pred, x0):
        """Temporal correlation loss"""
        x0_pred_norm = (x0_pred - x0_pred.mean(dim=-1, keepdim=True)) / (x0_pred.std(dim=-1, keepdim=True) + 1e-8)
        x0_norm = (x0 - x0.mean(dim=-1, keepdim=True)) / (x0.std(dim=-1, keepdim=True) + 1e-8)
        corr = (x0_pred_norm * x0_norm).mean(dim=-1).mean()
        return 1 - corr

    def loss(self, x0, y, rl_weights=None):
        B = x0.size(0)
        device = x0.device
        t = torch.randint(0, self.n_timesteps, (B,), device=device)
        eps = torch.randn_like(x0)
        x_t = self.sqrt_ab[t].view(B, 1, 1) * x0 + self.sqrt_1_ab[t].view(B, 1, 1) * eps
        eps_pred = self.eps_model(x_t, t, y)

        # Compute individual losses
        noise_loss = F.mse_loss(eps_pred, eps)

        # Only compute spectral/temporal at low noise steps
        low_t_mask = t < 200
        if low_t_mask.sum() > 0:
            x0_pred = (x_t[low_t_mask] - self.sqrt_1_ab[t[low_t_mask]].view(-1, 1, 1) * eps_pred[low_t_mask]) / \
                      (self.sqrt_ab[t[low_t_mask]].view(-1, 1, 1) + 1e-8)
            spectral_loss = self.compute_spectral_loss(x0_pred, x0[low_t_mask])
            temporal_loss = self.compute_temporal_loss(x0_pred, x0[low_t_mask])
        else:
            spectral_loss = torch.tensor(0.0, device=device)
            temporal_loss = torch.tensor(0.0, device=device)

        # RL-guided weighting or default weights
        if rl_weights is not None:
            w = rl_weights
        else:
            w = torch.tensor([1.0, 0.5, 0.3], device=device)

        total_loss = w[0] * noise_loss + w[1] * spectral_loss + w[2] * temporal_loss

        return total_loss, {
            'noise': noise_loss.item(),
            'spectral': spectral_loss.item() if torch.is_tensor(spectral_loss) else spectral_loss,
            'temporal': temporal_loss.item() if torch.is_tensor(temporal_loss) else temporal_loss,
            'total': total_loss.item(),
        }

    @torch.no_grad()
    def sample_ddim(self, batch_size, y, steps=50, guidance_scale=0.0, device=None):
        if device is None:
            device = next(self.parameters()).device
        x = torch.randn(batch_size, self.channels, self.n_samples, device=device)
        timesteps = torch.linspace(self.n_timesteps - 1, 0, steps, dtype=torch.long, device=device)

        for i, ti in enumerate(timesteps):
            t = torch.full((batch_size,), ti.item(), device=device, dtype=torch.long)
            eps = self.eps_model(x, t, y)
            alpha_bar_t = self.alpha_bar[ti]
            x0_pred = (x - torch.sqrt(1 - alpha_bar_t) * eps) / torch.sqrt(alpha_bar_t)
            if i < len(timesteps) - 1:
                alpha_bar_prev = self.alpha_bar[timesteps[i + 1]]
                dir_xt = (x - torch.sqrt(alpha_bar_t) * x0_pred) / torch.sqrt(1 - alpha_bar_t)
                x = torch.sqrt(alpha_bar_prev) * x0_pred + torch.sqrt(1 - alpha_bar_prev) * dir_xt
            else:
                x = x0_pred
        return x

    @torch.no_grad()
    def sample(self, batch_size, y, device=None):
        """Standard DDPM sampling (1000 steps)."""
        if device is None:
            device = next(self.parameters()).device
        x = torch.randn(batch_size, self.channels, self.n_samples, device=device)
        for ti in reversed(range(self.n_timesteps)):
            t = torch.full((batch_size,), ti, device=device, dtype=torch.long)
            eps_pred = self.eps_model(x, t, y)
            beta_t = self.beta[ti]
            alpha_t = self.alpha[ti]
            alpha_bar_t = self.alpha_bar[ti]
            x0_pred = (x - torch.sqrt(1 - alpha_bar_t) * eps_pred) / torch.sqrt(alpha_bar_t)
            mean = (1 / torch.sqrt(alpha_t)) * (x - (beta_t / torch.sqrt(1 - alpha_bar_t)) * eps_pred)
            if ti > 0:
                noise = torch.randn_like(x)
                sigma = torch.sqrt(beta_t)
                x = mean + sigma * noise
            else:
                x = mean
        return x


# ============================================================================
# 4. EEGDiff - Transformer-based Diffusion with Multi-Scale Conv + Fourier
# ============================================================================

class MultiScaleConv(nn.Module):
    """Multi-scale convolution module from EEGDiff (Chen et al., 2024)"""

    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.conv3 = nn.Conv1d(in_ch, out_ch, 3, padding=1)
        self.conv5 = nn.Conv1d(in_ch, out_ch, 5, padding=2)
        self.conv7 = nn.Conv1d(in_ch, out_ch, 7, padding=3)
        self.proj = nn.Conv1d(out_ch * 3, out_ch, 1)

    def forward(self, x):
        h3 = self.conv3(x)
        h5 = self.conv5(x)
        h7 = self.conv7(x)
        return self.proj(torch.cat([h3, h5, h7], dim=1))


class FourierSpectrumModule(nn.Module):
    """Dynamic Fourier Spectrum Information module from EEGDiff.
    Captures frequency-domain features."""

    def __init__(self, channels, n_samples, fs=250):
        super().__init__()
        self.channels = channels
        self.n_samples = n_samples
        self.fs = fs
        num_freqs = n_samples // 2 + 1
        self.freq_proj = nn.Linear(num_freqs, num_freqs)
        self.channel_proj = nn.Linear(channels, channels)

    def forward(self, x):
        B, C, T = x.shape
        # FFT
        fft = torch.fft.rfft(x, dim=-1)
        mag = fft.abs()  # [B, C, num_freqs]
        phase = fft.angle()

        # Dynamic weighting
        mag_weight = torch.sigmoid(self.freq_proj(mag))
        mag_new = mag * mag_weight

        # Channel interaction
        mag_new = mag_new.permute(0, 2, 1)  # [B, num_freqs, C]
        mag_new = self.channel_proj(mag_new)
        mag_new = mag_new.permute(0, 2, 1)  # [B, C, num_freqs]

        # IFFT
        fft_new = mag_new * torch.exp(1j * phase)
        x_freq = torch.fft.irfft(fft_new, n=T, dim=-1)
        return x + x_freq


class EEGDiffBlock(nn.Module):
    """EEGDiff Transformer block with multi-scale conv and Fourier spectrum"""

    def __init__(self, hidden_size, num_heads, channels, n_samples, fs=250):
        super().__init__()
        self.norm1 = nn.LayerNorm(hidden_size)
        self.attn = nn.MultiheadAttention(hidden_size, num_heads, batch_first=True)
        self.norm2 = nn.LayerNorm(hidden_size)
        self.mlp = nn.Sequential(
            nn.Linear(hidden_size, hidden_size * 4),
            nn.GELU(),
            nn.Linear(hidden_size * 4, hidden_size),
        )
        # AdaLN for time + class conditioning
        self.adaLN = nn.Sequential(
            nn.SiLU(),
            nn.Linear(hidden_size, 6 * hidden_size),
        )
        self.fourier = FourierSpectrumModule(channels, n_samples, fs)

    def forward(self, x, cond, x_raw=None):
        # x: [B, L, D], cond: [B, D]
        shift_msa, scale_msa, gate_msa, shift_mlp, scale_mlp, gate_mlp = \
            self.adaLN(cond).chunk(6, dim=-1)

        x_norm = self.norm1(x) * (1 + scale_msa.unsqueeze(1)) + shift_msa.unsqueeze(1)
        attn_out, _ = self.attn(x_norm, x_norm, x_norm)
        x = x + gate_msa.unsqueeze(1) * attn_out

        x_norm = self.norm2(x) * (1 + scale_mlp.unsqueeze(1)) + shift_mlp.unsqueeze(1)
        x = x + gate_mlp.unsqueeze(1) * self.mlp(x_norm)

        return x


class EEGDiffTransformer(nn.Module):
    """EEGDiff: Transformer-based diffusion with multi-scale conv + Fourier spectrum.
    Based on Chen et al. (2024). Simplified for faster training."""

    def __init__(self, channels=22, n_samples=1000, num_classes=4, hidden_size=128,
                 num_heads=4, num_layers=3, fs=250):
        super().__init__()
        self.channels = channels
        self.n_samples = n_samples
        self.num_classes = num_classes
        self.hidden_size = hidden_size
        self.fs = fs

        # Multi-scale convolution input
        self.ms_conv = MultiScaleConv(channels, hidden_size)

        # Fourier spectrum module (only at input)
        self.fourier = FourierSpectrumModule(channels, n_samples, fs)

        # Positional encoding
        self.pos_embed = nn.Parameter(torch.randn(1, n_samples, hidden_size) * 0.02)

        # Time + class embedding
        self.time_embed = nn.Sequential(
            nn.Linear(256, hidden_size), nn.SiLU(), nn.Linear(hidden_size, hidden_size),
        )
        self.class_embed = nn.Embedding(num_classes, hidden_size)

        # Simplified Transformer blocks (no Fourier inside)
        self.blocks = nn.ModuleList([
            nn.TransformerEncoderLayer(
                d_model=hidden_size, nhead=num_heads, dim_feedforward=hidden_size * 4,
                dropout=0.1, activation='gelu', batch_first=True
            )
            for _ in range(num_layers)
        ])

        # Output
        self.norm_out = nn.LayerNorm(hidden_size)
        self.proj_out = nn.Linear(hidden_size, channels)

    def forward(self, x, t, y):
        B, C, T = x.shape

        # Fourier-enhanced input
        x_freq = self.fourier(x)

        # Multi-scale conv: [B, C, T] -> [B, D, T] -> [B, T, D]
        h = self.ms_conv(x_freq)
        h = h.permute(0, 2, 1) + self.pos_embed

        # Condition (add to input)
        t_emb = sinusoidal_embedding(t, 256)
        t_emb = self.time_embed(t_emb)
        c_emb = self.class_embed(y)
        cond = (t_emb + c_emb).unsqueeze(1)  # [B, 1, D]
        h = h + cond

        # Transformer blocks
        for block in self.blocks:
            h = block(h)

        # Output
        h = self.norm_out(h)
        h = self.proj_out(h)  # [B, T, C]
        return h.permute(0, 2, 1)  # [B, C, T]


class EEGDiff(nn.Module):
    """EEGDiff: Transformer-based diffusion model with multi-scale conv and Fourier spectrum.
    Reference: Chen et al., "Improving EEG Classification with Transformer-based Diffusion", 2024."""

    def __init__(self, channels=22, n_samples=1000, num_classes=4, n_timesteps=1000, fs=250):
        super().__init__()
        self.eps_model = EEGDiffTransformer(channels, n_samples, num_classes, fs=fs)
        self.n_timesteps = n_timesteps
        self.channels = channels
        self.n_samples = n_samples
        self.fs = fs
        self.num_classes = num_classes

        # Cosine schedule
        steps = torch.arange(0, n_timesteps + 1, dtype=torch.float32)
        ac = torch.cos(((steps / n_timesteps) + 0.008) / 1.008 * (np.pi / 2)) ** 2
        ac = ac / ac[0]
        betas = torch.clamp(1 - ac[1:] / ac[:-1], 1e-4, 0.02)

        self.register_buffer('beta', betas)
        self.register_buffer('alpha', 1 - betas)
        self.register_buffer('alpha_bar', torch.cumprod(self.alpha, 0))
        self.register_buffer('sqrt_ab', torch.sqrt(self.alpha_bar))
        self.register_buffer('sqrt_1_ab', torch.sqrt(1 - self.alpha_bar))

    def loss(self, x0, y):
        B = x0.size(0)
        device = x0.device
        t = torch.randint(0, self.n_timesteps, (B,), device=device)
        eps = torch.randn_like(x0)
        x_t = self.sqrt_ab[t].view(B, 1, 1) * x0 + self.sqrt_1_ab[t].view(B, 1, 1) * eps
        eps_pred = self.eps_model(x_t, t, y)
        return F.mse_loss(eps_pred, eps)

    @torch.no_grad()
    def sample_ddim(self, batch_size, y, steps=50, guidance_scale=0.0, device=None):
        if device is None:
            device = next(self.parameters()).device
        x = torch.randn(batch_size, self.channels, self.n_samples, device=device)
        timesteps = torch.linspace(self.n_timesteps - 1, 0, steps, dtype=torch.long, device=device)

        for i, ti in enumerate(timesteps):
            t = torch.full((batch_size,), ti.item(), device=device, dtype=torch.long)
            eps = self.eps_model(x, t, y)
            alpha_bar_t = self.alpha_bar[ti]
            x0_pred = (x - torch.sqrt(1 - alpha_bar_t) * eps) / torch.sqrt(alpha_bar_t)
            if i < len(timesteps) - 1:
                alpha_bar_prev = self.alpha_bar[timesteps[i + 1]]
                dir_xt = (x - torch.sqrt(alpha_bar_t) * x0_pred) / torch.sqrt(1 - alpha_bar_t)
                x = torch.sqrt(alpha_bar_prev) * x0_pred + torch.sqrt(1 - alpha_bar_prev) * dir_xt
            else:
                x = x0_pred
        return x

    @torch.no_grad()
    def sample(self, batch_size, y, device=None):
        """Standard DDPM sampling (1000 steps)."""
        if device is None:
            device = next(self.parameters()).device
        x = torch.randn(batch_size, self.channels, self.n_samples, device=device)
        for ti in reversed(range(self.n_timesteps)):
            t = torch.full((batch_size,), ti, device=device, dtype=torch.long)
            eps_pred = self.eps_model(x, t, y)
            beta_t = self.beta[ti]
            alpha_t = self.alpha[ti]
            alpha_bar_t = self.alpha_bar[ti]
            x0_pred = (x - torch.sqrt(1 - alpha_bar_t) * eps_pred) / torch.sqrt(alpha_bar_t)
            mean = (1 / torch.sqrt(alpha_t)) * (x - (beta_t / torch.sqrt(1 - alpha_bar_t)) * eps_pred)
            if ti > 0:
                noise = torch.randn_like(x)
                sigma = torch.sqrt(beta_t)
                x = mean + sigma * noise
            else:
                x = mean
        return x


# ============================================================================
# 5. DiffEEGBooth - 3D Structured EEG + ERD/ERS Constraints
# ============================================================================

class CrossFrameAttention(nn.Module):
    """Cross-frame attention for temporal consistency (DiffEEGBooth)"""

    def __init__(self, ch, prev_ch=None):
        super().__init__()
        prev_ch = prev_ch or ch
        self.norm = nn.GroupNorm(8, ch)
        self.norm_prev = nn.GroupNorm(8, prev_ch)
        self.qkv = nn.Conv1d(ch, ch * 3, 1)
        self.kv_prev = nn.Conv1d(prev_ch, ch * 2, 1)  # project prev to ch
        self.proj = nn.Conv1d(ch, ch, 1)
        self.scale = ch ** -0.5

    def forward(self, x, prev_frame=None):
        B, C, L = x.shape
        h = self.norm(x)
        qkv = self.qkv(h).reshape(B, 3, C, L)
        q, k, v = qkv[:, 0], qkv[:, 1], qkv[:, 2]

        if prev_frame is not None:
            # Interpolate prev_frame to match x length
            if prev_frame.size(-1) != L:
                prev_frame = F.interpolate(prev_frame, size=L, mode='linear', align_corners=False)
            # Cross-attention with previous frame
            h_prev = self.norm_prev(prev_frame)
            kv_prev = self.kv_prev(h_prev).reshape(B, 2, C, L)
            k_prev, v_prev = kv_prev[:, 0], kv_prev[:, 1]
            k = torch.cat([k, k_prev], dim=-1)
            v = torch.cat([v, v_prev], dim=-1)

        attn = torch.einsum('bcl,bcm->blm', q, k) * self.scale
        attn = F.softmax(attn, dim=-1)
        h = torch.einsum('blm,bcm->bcl', attn, v)
        return x + self.proj(h)


class TemporalOptimizationModule(nn.Module):
    """Temporal series optimization module for global temporal consistency (DiffEEGBooth)"""

    def __init__(self, ch, n_frames=4):
        super().__init__()
        self.temporal_conv = nn.Conv2d(ch, ch, (n_frames, 1), padding=(0, 0))
        self.norm = nn.GroupNorm(8, ch)
        self.gate = nn.Sequential(nn.Conv1d(ch, ch, 1), nn.Sigmoid())

    def forward(self, x):
        # x: [B, C, T] - treat as single frame
        return x  # Simplified for single-frame generation


class DiffEEGBoothUNet(nn.Module):
    """DiffEEGBooth UNet with cross-frame attention and ERD/ERS constraints.
    Based on Huang et al. (2026)."""

    def __init__(self, channels=22, num_classes=4, time_dim=256, base_ch=64, fs=250, n_samples=1000):
        super().__init__()
        self.channels = channels
        self.num_classes = num_classes
        self.time_dim = time_dim
        self.fs = fs
        self.n_samples = n_samples

        self.class_embed = nn.Embedding(num_classes, 256)
        self.time_mlp = nn.Sequential(
            nn.Linear(time_dim, 512), nn.SiLU(), nn.Linear(512, 256),
        )
        cond_dim = 256
        self.in_proj = nn.Conv1d(channels, base_ch, 3, padding=1)

        # Encoder with cross-frame attention
        self.down1 = self._make_stage(base_ch, base_ch * 2, cond_dim, use_cross_attn=False)
        self.down2 = self._make_stage(base_ch * 2, base_ch * 4, cond_dim, use_cross_attn=True, prev_ch=base_ch * 2)
        self.down3 = self._make_stage(base_ch * 4, base_ch * 8, cond_dim, use_cross_attn=False)
        self.mid = self._make_stage(base_ch * 8, base_ch * 8, cond_dim, use_cross_attn=True, prev_ch=base_ch * 8)
        self.up3 = self._make_stage(base_ch * 16, base_ch * 4, cond_dim, use_cross_attn=False)
        self.up2 = self._make_stage(base_ch * 8, base_ch * 2, cond_dim, use_cross_attn=True, prev_ch=base_ch * 4)
        self.up1 = self._make_stage(base_ch * 4, base_ch, cond_dim, use_cross_attn=True, prev_ch=base_ch * 2)

        # Temporal optimization module
        self.temporal_opt = TemporalOptimizationModule(base_ch * 2)

        self.out = nn.Sequential(
            nn.GroupNorm(8, base_ch), nn.SiLU(), nn.Conv1d(base_ch, channels, 3, padding=1),
        )
        self.pool = nn.AvgPool1d(2)

    def _make_stage(self, in_ch, out_ch, cond_dim, use_cross_attn=False, prev_ch=None):
        blocks = nn.ModuleDict({
            'block1': self._resblock(in_ch, out_ch, cond_dim),
            'block2': self._resblock(out_ch, out_ch, cond_dim),
        })
        if use_cross_attn:
            blocks['cross_attn'] = CrossFrameAttention(out_ch, prev_ch=prev_ch)
        return blocks

    def _resblock(self, in_ch, out_ch, cond_dim):
        return nn.ModuleDict({
            'conv1': nn.Conv1d(in_ch, out_ch, 3, padding=1),
            'conv2': nn.Conv1d(out_ch, out_ch, 3, padding=1),
            'norm1': nn.GroupNorm(8, out_ch),
            'norm2': nn.GroupNorm(8, out_ch),
            'cond_proj': nn.Linear(cond_dim, out_ch),
            'skip': nn.Conv1d(in_ch, out_ch, 1) if in_ch != out_ch else nn.Identity(),
        })

    def _forward_resblock(self, x, block, cond):
        h = block['norm1'](F.silu(block['conv1'](x)))
        h = h + block['cond_proj'](cond).unsqueeze(-1)
        h = block['norm2'](F.silu(block['conv2'](h)))
        return h + block['skip'](x)

    def _forward_stage(self, x, stage, cond, prev=None):
        h = self._forward_resblock(x, stage['block1'], cond)
        h = self._forward_resblock(h, stage['block2'], cond)
        if 'cross_attn' in stage:
            h = stage['cross_attn'](h, prev)
        return h

    def forward(self, x, t, y):
        t_emb = sinusoidal_embedding(t, self.time_dim)
        t_emb = self.time_mlp(t_emb)
        c_emb = self.class_embed(y)
        cond = t_emb + c_emb

        h = self.in_proj(x)
        h1 = self._forward_stage(h, self.down1, cond)
        h2 = self._forward_stage(self.pool(h1), self.down2, cond, prev=h1)
        h3 = self._forward_stage(self.pool(h2), self.down3, cond)

        m = self._forward_stage(self.pool(h3), self.mid, cond, prev=h3)

        m = F.interpolate(m, size=h3.size(-1), mode='linear', align_corners=False)
        u3 = self._forward_stage(torch.cat([m, h3], dim=1), self.up3, cond)

        u3 = F.interpolate(u3, size=h2.size(-1), mode='linear', align_corners=False)
        u2 = self._forward_stage(torch.cat([u3, h2], dim=1), self.up2, cond, prev=u3)

        u2 = F.interpolate(u2, size=h1.size(-1), mode='linear', align_corners=False)
        u1 = self._forward_stage(torch.cat([u2, h1], dim=1), self.up1, cond, prev=u2)

        # Temporal optimization
        u1 = self.temporal_opt(u1)

        return self.out(u1)


class DiffEEGBooth(nn.Module):
    """DiffEEGBooth: 3D structured EEG diffusion with ERD/ERS constraints.
    Reference: Huang et al., "DiffEEGBooth: A diffusion-based EEG generation framework", 2026.

    Key differences from ERD-DDPM:
    - Cross-frame attention for temporal consistency
    - Region-based ERD/ERS constraints (not just C3/C4 laterality)
    - Temporal series optimization module
    - No classifier guidance (only ERD/ERS constraint in loss)
    """

    def __init__(self, channels=22, n_samples=1000, num_classes=4, n_timesteps=1000, fs=250,
                 c3_idx=7, c4_idx=11):
        super().__init__()
        self.eps_model = DiffEEGBoothUNet(channels, num_classes, fs=fs, n_samples=n_samples)
        self.n_timesteps = n_timesteps
        self.channels = channels
        self.n_samples = n_samples
        self.fs = fs
        self.num_classes = num_classes
        self.c3_idx = c3_idx
        self.c4_idx = c4_idx

        # Cosine schedule
        steps = torch.arange(0, n_timesteps + 1, dtype=torch.float32)
        ac = torch.cos(((steps / n_timesteps) + 0.008) / 1.008 * (np.pi / 2)) ** 2
        ac = ac / ac[0]
        betas = torch.clamp(1 - ac[1:] / ac[:-1], 1e-4, 0.02)

        self.register_buffer('beta', betas)
        self.register_buffer('alpha', 1 - betas)
        self.register_buffer('alpha_bar', torch.cumprod(self.alpha, 0))
        self.register_buffer('sqrt_ab', torch.sqrt(self.alpha_bar))
        self.register_buffer('sqrt_1_ab', torch.sqrt(1 - self.alpha_bar))

        # Frequency masks for ERD/ERS
        freqs = torch.fft.rfftfreq(n_samples, 1.0 / fs)
        self.register_buffer('freqs', freqs)
        alpha_mask = (freqs >= 8) & (freqs <= 13)
        beta_mask = (freqs >= 13) & (freqs <= 30)
        self.register_buffer('alpha_mask', alpha_mask)
        self.register_buffer('beta_mask', beta_mask)

        # Target laterality (will be set during training)
        self.register_buffer('target_laterality', torch.zeros(num_classes))

    def compute_erd_ers_loss(self, x0_pred, y):
        """Region-based ERD/ERS constraint loss.
        Computes alpha and beta band laterality for contralateral vs ipsilateral channels."""

        # Alpha band ERD
        c3_alpha = torch.abs(torch.fft.rfft(x0_pred[:, self.c3_idx, :])[:, self.alpha_mask]) ** 2
        c4_alpha = torch.abs(torch.fft.rfft(x0_pred[:, self.c4_idx, :])[:, self.alpha_mask]) ** 2
        alpha_lat = (c4_alpha.mean(dim=-1) - c3_alpha.mean(dim=-1)) / (c4_alpha.mean(dim=-1) + c3_alpha.mean(dim=-1) + 1e-10)

        # Beta band ERD
        c3_beta = torch.abs(torch.fft.rfft(x0_pred[:, self.c3_idx, :])[:, self.beta_mask]) ** 2
        c4_beta = torch.abs(torch.fft.rfft(x0_pred[:, self.c4_idx, :])[:, self.beta_mask]) ** 2
        beta_lat = (c4_beta.mean(dim=-1) - c3_beta.mean(dim=-1)) / (c4_beta.mean(dim=-1) + c3_beta.mean(dim=-1) + 1e-10)

        # Combined ERD/ERS loss
        target_lat = self.target_laterality[y]
        alpha_loss = F.mse_loss(alpha_lat, target_lat)
        beta_loss = F.mse_loss(beta_lat, target_lat)

        return alpha_loss + 0.5 * beta_loss

    def compute_spectral_loss(self, x0_pred, x0):
        """Log-PSD MSE loss"""
        fft_pred = torch.fft.rfft(x0_pred, dim=-1)
        psd_pred = (fft_pred.abs() ** 2).mean(dim=(0, 1))
        fft_real = torch.fft.rfft(x0, dim=-1)
        psd_real = (fft_real.abs() ** 2).mean(dim=(0, 1))
        return F.mse_loss(torch.log(psd_pred + 1e-10), torch.log(psd_real + 1e-10))

    def loss(self, x0, y, noise_weight=1.0, spectral_weight=0.5, erd_ers_weight=0.5):
        B = x0.size(0)
        device = x0.device
        t = torch.randint(0, self.n_timesteps, (B,), device=device)
        eps = torch.randn_like(x0)
        x_t = self.sqrt_ab[t].view(B, 1, 1) * x0 + self.sqrt_1_ab[t].view(B, 1, 1) * eps
        eps_pred = self.eps_model(x_t, t, y)

        noise_loss = F.mse_loss(eps_pred, eps)

        low_t_mask = t < 200
        if low_t_mask.sum() > 0:
            x0_pred = (x_t[low_t_mask] - self.sqrt_1_ab[t[low_t_mask]].view(-1, 1, 1) * eps_pred[low_t_mask]) / \
                      (self.sqrt_ab[t[low_t_mask]].view(-1, 1, 1) + 1e-8)
            spectral_loss = self.compute_spectral_loss(x0_pred, x0[low_t_mask])
            erd_ers_loss = self.compute_erd_ers_loss(x0_pred, y[low_t_mask])
        else:
            spectral_loss = torch.tensor(0.0, device=device)
            erd_ers_loss = torch.tensor(0.0, device=device)

        total_loss = noise_weight * noise_loss + spectral_weight * spectral_loss + erd_ers_weight * erd_ers_loss

        return total_loss, {
            'noise': noise_loss.item(),
            'spectral': spectral_loss.item() if torch.is_tensor(spectral_loss) else spectral_loss,
            'erd_ers': erd_ers_loss.item() if torch.is_tensor(erd_ers_loss) else erd_ers_loss,
            'total': total_loss.item(),
        }

    @torch.no_grad()
    def sample_ddim(self, batch_size, y, steps=50, guidance_scale=0.0, device=None):
        if device is None:
            device = next(self.parameters()).device
        x = torch.randn(batch_size, self.channels, self.n_samples, device=device)
        timesteps = torch.linspace(self.n_timesteps - 1, 0, steps, dtype=torch.long, device=device)

        for i, ti in enumerate(timesteps):
            t = torch.full((batch_size,), ti.item(), device=device, dtype=torch.long)
            eps = self.eps_model(x, t, y)
            alpha_bar_t = self.alpha_bar[ti]
            x0_pred = (x - torch.sqrt(1 - alpha_bar_t) * eps) / torch.sqrt(alpha_bar_t)
            if i < len(timesteps) - 1:
                alpha_bar_prev = self.alpha_bar[timesteps[i + 1]]
                dir_xt = (x - torch.sqrt(alpha_bar_t) * x0_pred) / torch.sqrt(1 - alpha_bar_t)
                x = torch.sqrt(alpha_bar_prev) * x0_pred + torch.sqrt(1 - alpha_bar_prev) * dir_xt
            else:
                x = x0_pred
        return x

    @torch.no_grad()
    def sample(self, batch_size, y, device=None):
        """Standard DDPM sampling (1000 steps)."""
        if device is None:
            device = next(self.parameters()).device
        x = torch.randn(batch_size, self.channels, self.n_samples, device=device)
        for ti in reversed(range(self.n_timesteps)):
            t = torch.full((batch_size,), ti, device=device, dtype=torch.long)
            eps_pred = self.eps_model(x, t, y)
            beta_t = self.beta[ti]
            alpha_t = self.alpha[ti]
            alpha_bar_t = self.alpha_bar[ti]
            x0_pred = (x - torch.sqrt(1 - alpha_bar_t) * eps_pred) / torch.sqrt(alpha_bar_t)
            mean = (1 / torch.sqrt(alpha_t)) * (x - (beta_t / torch.sqrt(1 - alpha_bar_t)) * eps_pred)
            if ti > 0:
                noise = torch.randn_like(x)
                sigma = torch.sqrt(beta_t)
                x = mean + sigma * noise
            else:
                x = mean
        return x


# ============================================================================
# Utility: Sinusoidal Embedding (shared)
# ============================================================================

def sinusoidal_embedding(timesteps, dim=128, max_period=10000):
    half = dim // 2
    device = timesteps.device
    t = timesteps.float()
    freqs = torch.exp(-math.log(max_period) * torch.arange(0, half, device=device).float() / half)
    args = t[:, None] * freqs[None]
    emb = torch.cat([torch.cos(args), torch.sin(args)], dim=-1)
    if dim % 2 == 1:
        emb = F.pad(emb, (0, 1))
    return emb


# ============================================================================
# Model Registry
# ============================================================================

BASELINE_MODELS = {
    'wavegan': {
        'class': WaveGAN,
        'type': 'gan',
        'description': 'WaveGAN: GAN-based EEG generation with 1D transposed convolution',
    },
    'cond_ddpm': {
        'class': CondDDPM,
        'type': 'diffusion',
        'description': 'Cond-DDPM: Standard conditional DDPM without ERD/spectral guidance',
    },
    'braindiff': {
        'class': BrainDiff,
        'type': 'diffusion',
        'description': 'BrainDiff: RL-guided diffusion with actor-critic weight selection',
    },
    'eegdiff': {
        'class': EEGDiff,
        'type': 'diffusion',
        'description': 'EEGDiff: Transformer-based diffusion with multi-scale conv + Fourier spectrum',
    },
    'diffeegbooth': {
        'class': DiffEEGBooth,
        'type': 'diffusion',
        'description': 'DiffEEGBooth: 3D structured EEG diffusion with ERD/ERS constraints',
    },
}


def create_baseline_model(model_name, channels=22, n_samples=1000, num_classes=4, fs=250):
    """Create a baseline model by name"""
    if model_name not in BASELINE_MODELS:
        raise ValueError(f"Unknown model: {model_name}. Available: {list(BASELINE_MODELS.keys())}")

    config = BASELINE_MODELS[model_name]
    model_class = config['class']

    # Infer C3/C4 channel indices based on channel count
    c3_c4_map = {
        3: (0, 2),      # BCI2b: [C3, Cz, C4]
        22: (7, 11),     # BCI2a
        64: (26, 30),    # PhysioNet
        128: (52, 60),   # HighGamma
    }
    c3_idx, c4_idx = c3_c4_map.get(channels, (7, 11))
    c3_idx = min(c3_idx, channels - 1)
    c4_idx = min(c4_idx, channels - 1)

    if model_name == 'wavegan':
        return model_class(channels=channels, out_length=n_samples, num_classes=num_classes, fs=fs)
    elif model_name == 'diffeegbooth':
        return model_class(channels=channels, n_samples=n_samples, num_classes=num_classes, fs=fs,
                           c3_idx=c3_idx, c4_idx=c4_idx)
    else:
        return model_class(channels=channels, n_samples=n_samples, num_classes=num_classes, fs=fs)
