import os
import json
import argparse
from pathlib import Path
import numpy as np
import mne
import scipy.io as sio
from scipy.io import loadmat
from scipy.signal import butter, filtfilt, resample as sp_resample
from typing import Dict, List, Optional, Tuple, Callable

# NumPy 2.x兼容性补丁
import warnings

def apply_numpy_compatibility_patch():
    """应用NumPy兼容性补丁"""
    # 忽略fromstring的废弃警告
    warnings.filterwarnings('ignore', message='.*fromstring.*', category=DeprecationWarning)
    warnings.filterwarnings('ignore', message='.*fromstring.*', category=FutureWarning)
    
    # 保存原始的fromstring函数
    if hasattr(np, 'fromstring'):
        _original_fromstring = np.fromstring
        
        def _compat_fromstring(string, dtype=float, count=-1, sep='', like=None):
            """NumPy 2.x 兼容的fromstring包装器"""
            try:
                return _original_fromstring(string, dtype=dtype, count=count, sep=sep, like=like)
            except (DeprecationWarning, TypeError, ValueError, FutureWarning) as e:
                error_msg = str(e).lower()
                if 'fromstring' in error_msg and 'frombuffer' in error_msg:
                    # 确保string是字节对象
                    if isinstance(string, str):
                        string = string.encode('latin-1')
                    
                    # 使用frombuffer作为替代
                    if sep == '' and count == -1:
                        return np.frombuffer(string, dtype=dtype)
                    elif sep == '':
                        return np.frombuffer(string, dtype=dtype, count=count)
                    else:
                        with warnings.catch_warnings():
                            warnings.simplefilter("ignore", (DeprecationWarning, FutureWarning))
                            return _original_fromstring(string, dtype=dtype, count=count, sep=sep, like=like)
                else:
                    raise e
        
        # 替换numpy的fromstring函数
        np.fromstring = _compat_fromstring

# 应用兼容性补丁
apply_numpy_compatibility_patch()

# -----------------------------
# 默认路径（根据你的需求已配置到 E:\data...）
# -----------------------------
DEFAULT_PATHS = {
    '2a': {
        'data_dir': r'E:\data\BCICIV_2a',
        'label_dir': r'E:\data\BCICIV_2a_label',
    },
    '2b': {
        'data_dir': r'E:\data\BCICIV_2b',
        'label_dir': r'E:\data\BCICIV_2b_label',
    },
    'seed': {
        'data_dir': r'E:\data\SEED\Preprocessed_EEG',
        'label_file': r'E:\data\SEED\Preprocessed_EEG\label.mat',
    },
}


# -----------------------------
# BCI Competition IV 2a 
# -----------------------------
class BCICompetition4Set2A:
    def __init__(self, filename: str, labels_filename: Optional[str] = None) -> None:
        self.filename = filename
        self.labels_filename = labels_filename

    def load(self) -> mne.io.BaseRaw:
        cnt = self.extract_data()
        events, artifact_trial_mask = self.extract_events(cnt)
        cnt.info['temp'] = {'events': events, 'artifact_trial_mask': artifact_trial_mask}
        return cnt

    def extract_data(self) -> mne.io.BaseRaw:
        raw_gdf = mne.io.read_raw_gdf(
            self.filename,
            stim_channel="auto",
            verbose='ERROR',
            exclude=(['EOG-left', 'EOG-central', 'EOG-right'])
        )
        raw_gdf.rename_channels({
            'EEG-Fz': 'Fz', 'EEG-0': 'FC3', 'EEG-1': 'FC1', 'EEG-2': 'FCz', 'EEG-3': 'FC2', 'EEG-4': 'FC4',
            'EEG-5': 'C5', 'EEG-C3': 'C3', 'EEG-6': 'C1', 'EEG-Cz': 'Cz', 'EEG-7': 'C2', 'EEG-C4': 'C4',
            'EEG-8': 'C6', 'EEG-9': 'CP3', 'EEG-10': 'CP1', 'EEG-11': 'CPz', 'EEG-12': 'CP2', 'EEG-13': 'CP4',
            'EEG-14': 'P1', 'EEG-15': 'Pz', 'EEG-16': 'P2', 'EEG-Pz': 'POz'
        })
        raw_gdf.load_data()
        data = raw_gdf.get_data()

        for i_chan in range(data.shape[0]):
            this_chan = data[i_chan]
            data[i_chan] = np.where(this_chan == np.min(this_chan), np.nan, this_chan)
            mask = np.isnan(data[i_chan])
            chan_mean = np.nanmean(data[i_chan])
            data[i_chan, mask] = chan_mean

        gdf_events = mne.events_from_annotations(raw_gdf)
        raw_gdf = mne.io.RawArray(data, raw_gdf.info, verbose='ERROR')
        raw_gdf.info['temp'] = {'gdf_events': gdf_events}
        return raw_gdf

    def extract_events(self, raw_gdf: mne.io.BaseRaw) -> Tuple[np.ndarray, np.ndarray]:
        events, name_to_code = raw_gdf.info['temp']['gdf_events']

        # 处理MNE 1.10.1+返回的字符串格式事件代码
        if len(name_to_code) > 0 and isinstance(list(name_to_code.keys())[0], str):
            # 将字符串键转换为整数
            name_to_code = {str(k): int(k) for k in name_to_code.keys()}
            # 将事件代码转换为整数
            events = events.copy()
            events[:, 2] = [name_to_code.get(str(code), code) for code in events[:, 2]]

        if '769' and '770' and '771' and '772' in name_to_code:
            train_set = True
        else:
            train_set = False
            assert '783' in name_to_code

        if train_set:
            if self.filename[-8:] == 'A04T.gdf':
                trial_codes = [5, 6, 7, 8]
            else:
                trial_codes = [7, 8, 9, 10]
        else:
            trial_codes = [7]

        trial_mask = [ev_code in trial_codes for ev_code in events[:, 2]]
        trial_events = events[trial_mask]

        assert len(trial_events) == 288, f'Got {len(trial_events):d} markers'

        if train_set and self.filename[-8:-4] == 'A04T':
            trial_events[:, 2] = trial_events[:, 2] - 4
        else:
            trial_events[:, 2] = trial_events[:, 2] - 6

        if self.labels_filename is not None and os.path.exists(self.labels_filename):
            classes = loadmat(self.labels_filename)["classlabel"].squeeze()
            if train_set:
                np.testing.assert_array_equal(trial_events[:, 2], classes)
            trial_events[:, 2] = classes

        unique_classes = np.unique(trial_events[:, 2])
        assert np.array_equal([1, 2, 3, 4], unique_classes), f'Expect 1,2,3,4 as class labels, got {str(unique_classes)}'

        if train_set and self.filename[-8:-5] == 'A04':
            trial_start_events = events[events[:, 2] == 4]
        else:
            trial_start_events = events[events[:, 2] == 6]
        assert len(trial_start_events) == len(trial_events)

        artifact_trial_mask = np.zeros(len(trial_events), dtype=np.uint8)
        artifact_events = events[events[:, 2] == 1]
        for artifact_time in artifact_events[:, 0]:
            i_trial = trial_start_events[:, 0].tolist().index(artifact_time)
            artifact_trial_mask[i_trial] = 1

        return trial_events, artifact_trial_mask


# -----------------------------
# BCI Competition IV 2b 
# -----------------------------
class BCICompetition4Set2B:
    def __init__(self, filename: str, labels_filename: Optional[str] = None) -> None:
        self.filename = filename
        self.labels_filename = labels_filename

    def load(self) -> mne.io.BaseRaw:
        cnt = self.extract_data()
        events, artifact_trial_mask = self.extract_events(cnt)
        cnt.info['temp'] = {'events': events, 'artifact_trial_mask': artifact_trial_mask}
        return cnt

    def extract_data(self) -> mne.io.BaseRaw:
        raw_gdf = mne.io.read_raw_gdf(
            self.filename,
            stim_channel="auto",
            verbose='ERROR',
            exclude=(['EOG:ch01', 'EOG:ch02', 'EOG:ch03'])
        )
        raw_gdf.rename_channels({'EEG:C3': 'C3', 'EEG:Cz': 'Cz', 'EEG:C4': 'C4'})
        raw_gdf.load_data()
        data = raw_gdf.get_data()

        for i_chan in range(data.shape[0]):
            this_chan = data[i_chan]
            data[i_chan] = np.where(this_chan == np.min(this_chan), np.nan, this_chan)
            mask = np.isnan(data[i_chan])
            chan_mean = np.nanmean(data[i_chan])
            data[i_chan, mask] = chan_mean

        gdf_events = mne.events_from_annotations(raw_gdf)
        raw_gdf = mne.io.RawArray(data, raw_gdf.info, verbose='ERROR')
        raw_gdf.info['temp'] = {'gdf_events': gdf_events}
        return raw_gdf

    def extract_events(self, raw_gdf: mne.io.BaseRaw) -> Tuple[np.ndarray, np.ndarray]:
        events, name_to_code = raw_gdf.info['temp']['gdf_events']

        if '769' and '770' in name_to_code:
            train_set = True
        else:
            train_set = False
            assert '783' in name_to_code

        if train_set:
            if self.filename[-10:] == 'B0102T.gdf':
                trial_codes = [4, 5]
            else:
                trial_codes = [10, 11]
            trial_mask = [ev_code in trial_codes for ev_code in events[:, 2]]
            trial_events = events[trial_mask]
        else:
            if self.filename[-10:] == 'B0504E.gdf':
                trial_codes = [5]
            else:
                trial_codes = [11]
            trial_mask = [ev_code in trial_codes for ev_code in events[:, 2]]
            trial_events = events[trial_mask]

        if train_set:
            if self.filename[-10:] == 'B0102T.gdf':
                trial_events[:, 2] = trial_events[:, 2] - 3
            else:
                trial_events[:, 2] = trial_events[:, 2] - 9
        else:
            if self.filename[-10:] == 'B0504E.gdf':
                trial_events[:, 2] = trial_events[:, 2] - 4
            else:
                trial_events[:, 2] = trial_events[:, 2] - 10

        if self.labels_filename is not None and os.path.exists(self.labels_filename):
            classes = loadmat(self.labels_filename)["classlabel"].squeeze()
            if train_set:
                np.testing.assert_array_equal(trial_events[:, 2], classes)
            trial_events[:, 2] = classes

        unique_classes = np.unique(trial_events[:, 2])
        assert np.array_equal([1, 2], unique_classes), f'Expect 1,2, as class labels, got {str(unique_classes)}'

        if train_set:
            if self.filename[-10:] == 'B0102T.gdf':
                trial_start_events = events[events[:, 2] == 3]
            else:
                trial_start_events = events[events[:, 2] == 9]
        else:
            if self.filename[-10:] == 'B0504E.gdf':
                trial_start_events = events[events[:, 2] == 3]
            else:
                trial_start_events = events[events[:, 2] == 9]
        assert len(trial_start_events) == len(trial_events)

        artifact_trial_mask = np.zeros(len(trial_events), dtype=np.uint8)
        artifact_events = events[events[:, 2] == 1]
        for artifact_time in artifact_events[:, 0]:
            i_trial = trial_start_events[:, 0].tolist().index(artifact_time)
            artifact_trial_mask[i_trial] = 1

        return trial_events, artifact_trial_mask




# =============================
# Trial slicing helper for 2a/2b
# =============================
def _extract_segment_trial(raw_gdb: mne.io.BaseRaw, tmin: float = 2.0, tmax: float = 6.0) -> Tuple[np.ndarray, np.ndarray]:
    """提取指定时间窗口的试验数据 (tmin到tmax秒)"""
    events = raw_gdb.info['temp']['events']
    raw_data = raw_gdb.get_data()
    sfreq = raw_gdb.info['sfreq']
    
    # 计算时间窗口的样本偏移
    start_offset = int(round(sfreq * tmin))  # 从事件开始后tmin秒开始
    end_offset = int(round(sfreq * tmax))    # 到事件开始后tmax秒结束
    window_length = end_offset - start_offset  # 窗口长度
    
    labels = np.array(events[:, 2])
    trials = []
    valid_labels = []
    
    for i, ev in enumerate(events):
        start = int(ev[0]) + start_offset
        stop = int(ev[0]) + end_offset
        
        # 检查边界
        if start < 0 or stop > raw_data.shape[1]:
            print(f"警告: 事件 {i} 超出数据边界 (start={start}, stop={stop}, data_shape={raw_data.shape})")
            continue
            
        segment = raw_data[:, start:stop]
        if segment.shape[-1] != window_length:
            print(f"警告: 事件 {i} 段长度不匹配 (expected={window_length}, actual={segment.shape[-1]})")
            continue
            
        trials.append(segment)
        valid_labels.append(labels[i])  # 只保存有效试验的标签
    
    if len(trials) == 0:
        raise ValueError("没有成功提取任何数据段")
        
    X = np.stack(trials, axis=0)
    y = np.array(valid_labels)
    return X, y


# =============================
# SEED Loader (refer to Untitled.py)
# =============================

def load_seed_dataset(data_dir: str, seed_sfreq: float = 200.0, per_file_consumer: Optional[Callable[[str, np.ndarray, np.ndarray], None]] = None, verbose: bool = True) -> Dict[str, np.ndarray]:
    exclude = ['label.mat']
    mat_files = []
    for root, _, files in os.walk(data_dir):
        for f in files:
            if f.lower().endswith('.mat') and f.lower() != 'label.mat':
                mat_files.append(os.path.join(root, f))
    mat_files.sort()
    if verbose:
        print(f'[seed] 在 {data_dir} 共发现 {len(mat_files)} 个数据 MAT 文件 (已排除 label.mat)')

    segments: List[np.ndarray] = []  # list of (C,T)
    labels: List[int] = []
    used_files: List[str] = []

    chs = ['FP1', 'FPZ', 'FP2', 'AF3', 'AF4', 'F7', 'F5', 'F3', 'F1',
           'FZ', 'F2', 'F4', 'F6', 'F8', 'FT7', 'FC5', 'FC3', 'FC1',
           'FCZ', 'FC2', 'FC4', 'FC6', 'FT8', 'T7', 'C5', 'C3', 'C1',
           'CZ', 'C2', 'C4', 'C6', 'T8', 'TP7', 'CP5', 'CP3', 'CP1',
           'CPZ', 'CP2', 'CP4', 'CP6', 'TP8', 'P7', 'P5', 'P3', 'P1',
           'PZ', 'P2', 'P4', 'P6', 'P8', 'PO7', 'PO5', 'PO3', 'POZ',
           'PO4', 'PO6', 'PO8', 'CB1', 'O1', 'OZ', 'O2', 'CB2']
    info = mne.create_info(ch_names=chs, sfreq=seed_sfreq, ch_types='eeg')

    for mat_path in mat_files:
        base = os.path.basename(mat_path)
        try:
            data = sio.loadmat(mat_path)
            keys = list(data.keys())[3:]
            if len(keys) == 0:
                if verbose:
                    print(f'[seed] 跳过 {base}: 未发现数据键')
                continue
            base_labels = [1, 0, -1, -1, 0, 1, -1, 0, 1, 1, 0, -1, 0, 1, -1]
            seg_count = min(len(keys), len(base_labels))
            this_file_segments: List[np.ndarray] = []
            this_file_labels: List[int] = []
            for i in range(seg_count):
                stamp = np.array(data[keys[i]], dtype=np.float32)
                if stamp.ndim == 2 and stamp.shape[0] > stamp.shape[1]:
                    stamp = stamp.T
                raw = mne.io.RawArray(stamp, info, verbose='ERROR').crop(tmin=5)
                seg = raw.get_data().astype(np.float32, copy=False)
                this_file_segments.append(seg)
                this_file_labels.append(base_labels[i])

            if len(this_file_segments) == 0:
                continue
            if per_file_consumer is not None:
                X_file = np.stack(this_file_segments, axis=0)
                y_file = np.array(this_file_labels, dtype=np.int64)
                per_file_consumer(mat_path, X_file, y_file)
            segments.extend(this_file_segments)
            labels.extend(this_file_labels)
            used_files.append(mat_path)
            if verbose:
                print(f"[seed] 已读取: {base}, 段数={len(this_file_segments)}, C={this_file_segments[0].shape[0]}, T~{this_file_segments[0].shape[1]}")
        except Exception as e:
            print(f'[seed] 跳过 {base}: {e}')

    if len(segments) == 0:
        raise RuntimeError('[seed] 未成功读取任何数据，请检查目录与文件完整性。')

    min_len = min(seg.shape[1] for seg in segments)
    X_cat = np.stack([seg[:, :min_len].astype(np.float32, copy=False) for seg in segments], axis=0)
    y_cat = np.array(labels, dtype=np.int64)
    if verbose:
        print(f'[seed] 合并后: X={X_cat.shape}, y={y_cat.shape}')
    return {'X': X_cat, 'y': y_cat, 'files': used_files}


def main():
    parser = argparse.ArgumentParser(description='处理指定数据集 (2a / 2b / seed)，并保存到 processed/')
    parser.add_argument('--data2a', type=str, default=r'E:\data\BCICIV_2a')
    parser.add_argument('--label2a', type=str, default=r'E:\data\BCICIV_2a_label')
    parser.add_argument('--data2b', type=str, default=r'E:\data\BCICIV_2b')
    parser.add_argument('--label2b', type=str, default=r'E:\data\BCICIV_2b_label')
    parser.add_argument('--dataseed', type=str, default=r'E:\data\SEED\Preprocessed_EEG')
    parser.add_argument('--processed_root', type=str, default='processed')
    parser.add_argument('--l-freq', type=float, default=4.0)
    parser.add_argument('--h-freq', type=float, default=30.0)
    parser.add_argument('--notch', type=float, default=50.0, help='陷波频率(Hz)，0禁用；常用50或60')
    parser.add_argument('--car', type=int, default=1, help='1=使用CAR(average reference)，0=不使用')
    parser.add_argument('--resample', type=float, default=None)
    parser.add_argument('--dataset', choices=['2a', '2b', 'seed'], default='2a', help='选择处理的数据集')
    parser.add_argument('--subject', type=str, default='A01E', help='仅处理指定被试/会话（2a: A01E/A01T 等；2b: B0102T/B0102E 等）')
    args = parser.parse_args()
    # 调试回显，确认参数与脚本路径
    print(f'dataset = {args.dataset}')
    print(f'__file__ = {__file__}')

    out_root = args.processed_root or str(Path(__file__).resolve().parents[1] / 'data' / 'processed')
    
    print('dataset =', args.dataset)
    print('__file__ =', __file__)

    if args.dataset == '2a':
        data2a = args.data2a or DEFAULT_PATHS['2a']['data_dir']
        label2a = args.label2a or DEFAULT_PATHS['2a']['label_dir']
        print('[2a] Start')
        
        # Check if processed data already exists
        processed_dir = os.path.join(out_root, 'BCI2a')
      
        
        gdf_files = []
        for root, _, files in os.walk(data2a):
            for f in files:
                if f.lower().endswith('.gdf'):
                    gdf_files.append(os.path.join(root, f))
        gdf_files.sort()
        if args.subject:
            want = args.subject.strip().lower()
            gdf_files = [p for p in gdf_files if os.path.basename(p).lower() == f"{want}.gdf"]
            print(f"[2a] 仅处理: {args.subject}, 匹配到 {len(gdf_files)} 个文件")

        all_X: List[np.ndarray] = []
        all_y: List[np.ndarray] = []
        used_files: List[str] = []
        for gdf_path in gdf_files:
            base = os.path.basename(gdf_path)
            lab = None
            if label2a is not None:
                cand = os.path.join(label2a, base.replace('.gdf', '.mat'))
                if os.path.exists(cand):
                    lab = cand
            try:
                cnt = BCICompetition4Set2A(gdf_path, labels_filename=lab).load()
                # 陷波（50/60Hz及其二次谐波）
                if args.notch and args.notch > 0:
                    try:
                        cnt.notch_filter(freqs=[args.notch, args.notch * 2], verbose='ERROR')
                    except Exception:
                        pass
                # 带通
                if args.l_freq is not None or args.h_freq is not None:
                    cnt.filter(l_freq=args.l_freq, h_freq=args.h_freq, verbose='ERROR')
                # 重采样（可选）
                if args.resample is not None:
                    cnt.resample(args.resample, npad='auto')
                # CAR（公共平均参考）
                if int(args.car) == 1:
                    try:
                        cnt, _ = mne.set_eeg_reference(cnt, 'average', projection=False, verbose='ERROR')
                    except Exception:
                        pass
                # BCI2a: 主流复现使用 2-6 秒窗口（4秒，任务期）
                X, y = _extract_segment_trial(cnt, tmin=0, tmax=4.0)
                # 打印标签唯一值，确认是否为 1-4
                uniq = sorted(set(y.tolist()))
                counts = {int(k): int((y == k).sum()) for k in uniq}
                print(f"[2a] 标签唯一值: {uniq}, 计数: {counts}")
                # 每文件单独保存到 processed/BCI2a/<AxxE/T>/
                sub_name = os.path.splitext(base)[0]
                dir2a_sub = os.path.join(out_root, 'BCI2a', sub_name)
                Path(dir2a_sub).mkdir(parents=True, exist_ok=True)
                np.save(os.path.join(dir2a_sub, 'X.npy'), X)
                np.save(os.path.join(dir2a_sub, 'y.npy'), y)
                all_X.append(X)
                all_y.append(y)
                used_files.append(gdf_path)
                print(f'[2a] 读取: {base}, X={X.shape}, y={y.shape}')
            except Exception as e:
                print(f'[2a] 跳过 {base}: {e}')
                import traceback
                print(f'[2a] 详细错误信息:')
                traceback.print_exc()

        if len(all_X) == 0:
            raise RuntimeError('[2a] 未成功读取任何数据')
        X_cat = np.concatenate(all_X, axis=0)
        y_cat = np.concatenate(all_y, axis=0)
        dir2a = os.path.join(out_root, 'BCI2a')
        Path(dir2a).mkdir(parents=True, exist_ok=True)
        np.save(os.path.join(dir2a, 'X.npy'), X_cat)
        np.save(os.path.join(dir2a, 'y.npy'), y_cat)
        with open(os.path.join(dir2a, 'meta.json'), 'w', encoding='utf-8') as f:
            json.dump({'files': used_files, 'dataset': 'bci2a'}, f, ensure_ascii=False, indent=2)
        print('[2a] Done ->', dir2a, X_cat.shape, y_cat.shape)

    elif args.dataset == '2b':
        data2b = args.data2b or DEFAULT_PATHS['2b']['data_dir']
        label2b = args.label2b or DEFAULT_PATHS['2b']['label_dir']
        print('[2b] Start')
        
        # Check if processed data already exists
        processed_dir = os.path.join(out_root, 'BCI2b')
        if os.path.exists(processed_dir) and os.path.exists(os.path.join(processed_dir, 'X.npy')):
            print(f'[2b] 检测到已处理的数据存在于: {processed_dir}')
            print('[2b] 如需重新处理，请删除现有数据或使用不同的输出目录')
            return
        
        # Check if raw data directory exists
        if not os.path.exists(data2b):
            print(f'[2b] 错误: 原始数据目录不存在: {data2b}')
            print('[2b] 请确保BCI Competition IV Dataset 2b已下载并放置在正确位置')
            print('[2b] 或者使用 --data2b 参数指定正确的数据路径')
            return
        
        gdf_files = []
        for root, _, files in os.walk(data2b):
            for f in files:
                if f.lower().endswith('.gdf'):
                    gdf_files.append(os.path.join(root, f))
        gdf_files.sort()
        if args.subject:
            want = args.subject.strip().lower()
            gdf_files = [p for p in gdf_files if os.path.basename(p).lower() == f"{want}.gdf"]
            print(f"[2b] 仅处理: {args.subject}, 匹配到 {len(gdf_files)} 个文件")

        all_X: List[np.ndarray] = []
        all_y: List[np.ndarray] = []
        used_files: List[str] = []
        for gdf_path in gdf_files:
            base = os.path.basename(gdf_path)
            lab = None
            if label2b is not None:
                cand = os.path.join(label2b, base.replace('.gdf', '.mat'))
                if os.path.exists(cand):
                    lab = cand
            try:
                cnt = BCICompetition4Set2B(gdf_path, labels_filename=lab).load()
                if args.l_freq is not None or args.h_freq is not None:
                    cnt.filter(l_freq=args.l_freq, h_freq=args.h_freq, verbose='ERROR')
                if args.resample is not None:
                    cnt.resample(args.resample, npad='auto')
                # BCI2b：保持默认 0-4s（如需也改 1-4s 可同步调整）
                X, y = _extract_segment_trial(cnt)
                # 打印标签唯一值（2b 应为 {1,2}）
                uniq = sorted(set(y.tolist()))
                counts = {int(k): int((y == k).sum()) for k in uniq}
                print(f"[2b] 标签唯一值: {uniq}, 计数: {counts}")
                # 每文件单独保存到 processed/BCI2b/<BxxxxE/T>/
                sub_name = os.path.splitext(base)[0]
                dir2b_sub = os.path.join(out_root, 'BCI2b', sub_name)
                Path(dir2b_sub).mkdir(parents=True, exist_ok=True)
                np.save(os.path.join(dir2b_sub, 'X.npy'), X)
                np.save(os.path.join(dir2b_sub, 'y.npy'), y)
                all_X.append(X)
                all_y.append(y)
                used_files.append(gdf_path)
                print(f'[2b] 读取: {base}, X={X.shape}, y={y.shape}')
            except Exception as e:
                print(f'[2b] 跳过 {base}: {e}')

        if len(all_X) == 0:
            raise RuntimeError('[2b] 未成功读取任何数据')
        X_cat = np.concatenate(all_X, axis=0)
        y_cat = np.concatenate(all_y, axis=0)
        dir2b = os.path.join(out_root, 'BCI2b')
        Path(dir2b).mkdir(parents=True, exist_ok=True)
        np.save(os.path.join(dir2b, 'X.npy'), X_cat)
        np.save(os.path.join(dir2b, 'y.npy'), y_cat)
        with open(os.path.join(dir2b, 'meta.json'), 'w', encoding='utf-8') as f:
            json.dump({'files': used_files, 'dataset': 'bci2b'}, f, ensure_ascii=False, indent=2)
        print('[2b] Done ->', dir2b, X_cat.shape, y_cat.shape)

    elif args.dataset == 'seed':
        dataseed = args.dataseed or DEFAULT_PATHS['seed']['data_dir']
        print('[seed] Start')
        
        # Check if processed data already exists
        processed_dir = os.path.join(out_root, 'SEED')
        if os.path.exists(processed_dir) and os.path.exists(os.path.join(processed_dir, 'X.npy')):
            print(f'[seed] 检测到已处理的数据存在于: {processed_dir}')
            print('[seed] 如需重新处理，请删除现有数据或使用不同的输出目录')
            return
        
        # Check if raw data directory exists
        if not os.path.exists(dataseed):
            print(f'[seed] 错误: 原始数据目录不存在: {dataseed}')
            print('[seed] 请确保SEED数据集已下载并放置在正确位置')
            print('[seed] 或者使用 --dataseed 参数指定正确的数据路径')
            return
        
        rseed = load_seed_dataset(
            data_dir=dataseed,
            seed_sfreq=200.0,
            verbose=True,
        )
        dirseed = os.path.join(out_root, 'SEED')
        Path(dirseed).mkdir(parents=True, exist_ok=True)
        np.save(os.path.join(dirseed, 'X.npy'), rseed['X'])
        np.save(os.path.join(dirseed, 'y.npy'), rseed['y'])
        with open(os.path.join(dirseed, 'meta.json'), 'w', encoding='utf-8') as f:
            json.dump({'files': rseed['files'], 'dataset': 'seed'}, f, ensure_ascii=False, indent=2)
        print('[seed] Done ->', dirseed, rseed['X'].shape, rseed['y'].shape)


if __name__ == '__main__':
    main()




 
