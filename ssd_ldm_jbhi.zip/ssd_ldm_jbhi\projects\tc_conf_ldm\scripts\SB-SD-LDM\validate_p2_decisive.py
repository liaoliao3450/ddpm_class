# -*- coding: utf-8 -*-
"""P2 决定性验证: 被试风格到底住在 z 还是 s? (行为学三重对照)

MLP 探针对被试信息缺乏效力 (fix-SB-LDM 的 z 行为上携带被试风格, 探针却读不出).
改用行为学判据 — P2 训练好的 subj_head (波形->被试, 已验证 100%):

  B0 校准:   subj_head(真实 X)            预期高 (subj_head 泛化到真实波形)
  B1 fix:    subj_head(decode_fix(z))     预期高  -> fix 模型被试风格住在 z
  B2 P2 无s: subj_head(decode_p2(z, s=空)) 预期随机 -> P2 的 z 已无被试风格
  B3 P2 对s: subj_head(decode_p2(z, s真))  预期高  -> 风格全部经 s 通路

若 B1 高 + B2 随机 => 解耦决定性成立: 被试信息从 z (fix) 迁移到了 s 通路 (P2).
辅证: conv 探针直接读 z (fix / P1 / P2).
"""
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from core.models.latent_diffusion.model_shared import (
    SharedBackboneConfig, SharedVAEUNetLDM1D)

from train_sb_sd_ldm import DATASET_CONFIG, load_dataset

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def build(yaml_cfg, dataset, num_subjects, subj_dim, disentangle):
    cfg = DATASET_CONFIG[dataset]
    model_cfg = yaml_cfg.get('model', {})
    backbone = SharedBackboneConfig(
        base=int(model_cfg.get('backbone_base', 64)),
        levels=tuple(int(x) for x in model_cfg.get('backbone_levels', [1, 2, 4])),
        blocks_per_level=int(model_cfg.get('backbone_blocks_per_level', 2)),
    )
    return SharedVAEUNetLDM1D(
        channels=cfg['channels'],
        input_length=cfg['input_length'],
        z_channels=int(model_cfg.get('z_channels', 64)),
        timesteps=int(model_cfg.get('timesteps', 1000)),
        t_dim=int(model_cfg.get('t_dim', 128)),
        cond_dim=int(model_cfg.get('cond_embed_dim', 64)),
        backbone=backbone,
        num_subjects=num_subjects,
        adv_alpha=0.0,
        subj_dim=subj_dim,
        disentangle=disentangle,
    ).to(DEVICE)


@torch.no_grad()
def subj_head_acc(subj_head, X, bs=100):
    preds = []
    for i in range(0, len(X), bs):
        xb = X[i:i + bs].to(DEVICE)
        preds.append(subj_head(xb).argmax(1).cpu())
    return float((torch.cat(preds) == torch.as_tensor(
        np.asarray(SUBJ_GLOBAL)).long()).float().mean())


# conv 探针 (结构同 subj_head, 独立训练于 z)
class ConvProbe(nn.Module):
    def __init__(self, c_in, n_out):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(c_in, 64, 7, padding=3), nn.SiLU(),
            nn.Conv1d(64, 64, 5, padding=2), nn.SiLU(),
            nn.AdaptiveAvgPool1d(1), nn.Flatten(),
            nn.Linear(64, n_out))

    def forward(self, x):
        return self.net(x)


def conv_probe_z(z, labels, n_classes, epochs=100, bs=256, lr=1e-3):
    from sklearn.model_selection import train_test_split
    import torch.nn.functional as F
    torch.manual_seed(0)
    np.random.seed(0)
    idx = np.arange(len(z))
    tr_i, te_i = train_test_split(idx, test_size=0.2, random_state=0, stratify=labels)
    z_tr = torch.FloatTensor(z[tr_i]).to(DEVICE)
    y_tr = torch.LongTensor(labels[tr_i]).to(DEVICE)
    z_te = torch.FloatTensor(z[te_i]).to(DEVICE)
    y_te = torch.LongTensor(labels[te_i]).to(DEVICE)
    probe = ConvProbe(z.shape[1], n_classes).to(DEVICE)
    optim = torch.optim.Adam(probe.parameters(), lr=lr)
    n = len(z_tr)
    for _ in range(epochs):
        probe.train()
        perm = torch.randperm(n, device=DEVICE)
        for i in range(0, n, bs):
            p = perm[i:i + bs]
            loss = F.cross_entropy(probe(z_tr[p]), y_tr[p])
            optim.zero_grad(); loss.backward(); optim.step()
    probe.eval()
    with torch.no_grad():
        pred = probe(z_te).argmax(1)
    return float((pred == y_te).float().mean())


SUBJ_GLOBAL = None


@torch.no_grad()
def encode_all(model, cond_embed, X_t, y_t, bs=100):
    model.eval()
    mus = []
    for i in range(0, len(X_t), bs):
        xb = X_t[i:i + bs].to(DEVICE)
        yb = y_t[i:i + bs].to(DEVICE)
        mu, _, _ = model.encode(xb, cond=cond_embed(yb))
        mus.append(mu.cpu())
    return torch.cat(mus)


def main():
    global SUBJ_GLOBAL
    dataset = 'bci2a'
    cfg = DATASET_CONFIG[dataset]
    num_subjects = cfg['num_subjects']

    X, y, subjects = load_dataset(dataset)
    SUBJ_GLOBAL = subjects
    X_t = torch.FloatTensor(X)
    y_t = torch.LongTensor(y)
    subj_t = torch.LongTensor(subjects)

    # --- 加载三个模型 ---
    p2_ckpt = torch.load(str(PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p2/sb_sd_ldm_p2_epoch_500.pt'),
                         map_location=DEVICE, weights_only=False)
    p1_ckpt = torch.load(str(PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a/sb_sd_ldm_epoch_500.pt'),
                         map_location=DEVICE, weights_only=False)
    fix_ckpt = torch.load(str(PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_ldm_bci2a_fix/sb_ldm_epoch_500.pt'),
                          map_location=DEVICE, weights_only=False)

    model_p2 = build(p2_ckpt['config'], dataset, num_subjects, p2_ckpt.get('subj_dim', 32), True)
    model_p2.load_state_dict(p2_ckpt['model_state_dict'])
    model_p1 = build(p1_ckpt['config'], dataset, num_subjects, p1_ckpt.get('subj_dim', 32), False)
    model_p1.load_state_dict(p1_ckpt['model_state_dict'])
    model_fix = build(fix_ckpt['config'], dataset, 0, 32, False)
    model_fix.load_state_dict(fix_ckpt['model_state_dict'])

    ce_p2 = torch.nn.Embedding(cfg['num_classes'], 64).to(DEVICE)
    ce_p2.load_state_dict(p2_ckpt['cond_embed_state_dict']); ce_p2.eval()
    ce_p1 = torch.nn.Embedding(cfg['num_classes'], 64).to(DEVICE)
    ce_p1.load_state_dict(p1_ckpt['cond_embed_state_dict']); ce_p1.eval()
    ce_fix = torch.nn.Embedding(cfg['num_classes'], 64).to(DEVICE)
    ce_fix.load_state_dict(fix_ckpt['cond_embed_state_dict']); ce_fix.eval()

    subj_head = model_p2.subj_head  # 冻结使用 (波形 -> 被试, 已验证有效)

    # ================= 行为学三重对照 =================
    print('=' * 70)
    print('行为学对照: subj_head (波形->被试) 读各模型 decode 输出')
    print('=' * 70)
    print(f'  B0 校准   subj_head(真实 X):        {subj_head_acc(subj_head, X_t)*100:.1f}%')

    # B1: fix 模型 recon (无 s 通路, 风格只能在 z)
    with torch.no_grad():
        recs = []
        for i in range(0, len(X_t), 100):
            xb = X_t[i:i+100].to(DEVICE); yb = y_t[i:i+100].to(DEVICE)
            mu, _, _ = model_fix.encode(xb, cond=ce_fix(yb))
            recs.append(model_fix.decode(mu, target_length=xb.shape[-1], cond=ce_fix(yb)).cpu())
        rec_fix = torch.cat(recs)
    print(f'  B1 fix    subj_head(decode_fix(z)): {subj_head_acc(subj_head, rec_fix)*100:.1f}%  (fix: 风格住 z?)')

    # B2: P2 decode 无 s (风格通路关闭)
    with torch.no_grad():
        recs = []
        for i in range(0, len(X_t), 100):
            xb = X_t[i:i+100].to(DEVICE); yb = y_t[i:i+100].to(DEVICE)
            mu, _, _ = model_p2.encode(xb, cond=ce_p2(yb))
            recs.append(model_p2.decode(mu, target_length=xb.shape[-1], cond=ce_p2(yb), subject_id=None).cpu())
        rec_p2_nos = torch.cat(recs)
    print(f'  B2 P2无s  subj_head(decode_p2(z,-)): {subj_head_acc(subj_head, rec_p2_nos)*100:.1f}%  (P2: z 还有风格?)')

    # B2b: P1 decode 无 s
    with torch.no_grad():
        recs = []
        for i in range(0, len(X_t), 100):
            xb = X_t[i:i+100].to(DEVICE); yb = y_t[i:i+100].to(DEVICE)
            mu, _, _ = model_p1.encode(xb, cond=ce_p1(yb))
            recs.append(model_p1.decode(mu, target_length=xb.shape[-1], cond=ce_p1(yb), subject_id=None).cpu())
        rec_p1_nos = torch.cat(recs)
    print(f'  B2b P1无s subj_head(decode_p1(z,-)): {subj_head_acc(subj_head, rec_p1_nos)*100:.1f}%  (P1: z 还有风格?)')

    # B3: P2 decode 正确 s
    with torch.no_grad():
        recs = []
        for i in range(0, len(X_t), 100):
            xb = X_t[i:i+100].to(DEVICE); yb = y_t[i:i+100].to(DEVICE)
            sb = subj_t[i:i+100].to(DEVICE)
            mu, _, _ = model_p2.encode(xb, cond=ce_p2(yb))
            recs.append(model_p2.decode(mu, target_length=xb.shape[-1], cond=ce_p2(yb), subject_id=sb).cpu())
        rec_p2_s = torch.cat(recs)
    print(f'  B3 P2对s  subj_head(decode_p2(z,s)): {subj_head_acc(subj_head, rec_p2_s)*100:.1f}%  (风格经 s 通路)')

    # ================= conv 探针辅证 =================
    print('\n' + '=' * 70)
    print('conv 探针直接读 z (辅证)')
    print('=' * 70)
    z_fix = encode_all(model_fix, ce_fix, X_t, y_t)
    z_p1 = encode_all(model_p1, ce_p1, X_t, y_t)
    z_p2 = encode_all(model_p2, ce_p2, X_t, y_t)
    a_fix = conv_probe_z(z_fix.numpy(), subjects, num_subjects)
    a_p1 = conv_probe_z(z_p1.numpy(), subjects, num_subjects)
    a_p2 = conv_probe_z(z_p2.numpy(), subjects, num_subjects)
    print(f'  fix z: {a_fix*100:.1f}% | P1 z: {a_p1*100:.1f}% | P2 z: {a_p2*100:.1f}%  (chance=11.1%)')

    # ================= 判定 =================
    print('\n' + '=' * 70)
    print('判定')
    print('=' * 70)
    b1 = subj_head_acc(subj_head, rec_fix)
    b2 = subj_head_acc(subj_head, rec_p2_nos)
    b3 = subj_head_acc(subj_head, rec_p2_s)
    b0 = subj_head_acc(subj_head, X_t)
    calib_ok = b0 >= 0.85
    decoupled = (b1 >= 0.5) and (b2 <= 0.25) and (b3 >= 0.85)
    if calib_ok and decoupled:
        print(f'  决定性通过: fix 模型风格住在 z ({b1*100:.0f}%), P2 的 z 已无风格 ({b2*100:.0f}%),')
        print(f'  风格全部经 s 通路 ({b3*100:.0f}%) — 解耦成立, 可进入 P3')
    elif not calib_ok:
        print(f'  校准失败 (subj_head 对真实波形 {b0*100:.0f}%), 行为学判据不可用')
    else:
        print(f'  解耦不完全: B1={b1*100:.0f}% B2={b2*100:.0f}% B3={b3*100:.0f}%')

    import json
    out = PROJECT_ROOT / 'outputs/results/sb_sd_ldm_bci2a_p2_decisive.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, 'w', encoding='utf-8') as f:
        json.dump({
            'B0_calib_real': b0, 'B1_fix_recon': b1,
            'B2_p2_no_s': b2, 'B2b_p1_no_s': subj_head_acc(subj_head, rec_p1_nos),
            'B3_p2_true_s': b3,
            'conv_probe_z': {'fix': a_fix, 'p1': a_p1, 'p2': a_p2},
            'calib_ok': calib_ok, 'decoupled': decoupled,
        }, f, indent=2)
    print(f'\n已保存: {out}')


if __name__ == '__main__':
    main()
