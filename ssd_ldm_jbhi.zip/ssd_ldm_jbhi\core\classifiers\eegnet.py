"""EEGNet 模型定义。"""

from __future__ import annotations

import torch
import torch.nn as nn


class EEGNet(nn.Module):
    """标准 EEGNet（近似 EEGNet-8,2）实现。"""

    def __init__(
        self,
        n_channels: int = 22,
        n_samples: int = 1000,
        n_classes: int = 4,
        F1: int = 8,
        D: int = 2,
        F2: int = 16,
        kernel_length: int = 64,
        depthwise_kernel_length: int = 16,
        dropout_rate: float = 0.5,
    ):
        super().__init__()

        self.n_channels = int(n_channels)
        self.n_samples = int(n_samples)
        self.n_classes = int(n_classes)

        self.conv1 = nn.Conv2d(
            1,
            F1,
            kernel_size=(1, kernel_length),
            padding=(0, kernel_length // 2),
            bias=False,
        )
        self.batchnorm1 = nn.BatchNorm2d(F1)

        self.conv2 = nn.Conv2d(
            F1,
            F1 * D,
            kernel_size=(self.n_channels, 1),
            groups=F1,
            bias=False,
        )
        self.batchnorm2 = nn.BatchNorm2d(F1 * D)
        self.elu1 = nn.ELU()
        self.avgpool1 = nn.AvgPool2d(kernel_size=(1, 4))
        self.dropout1 = nn.Dropout(dropout_rate)

        self.sep_depthwise = nn.Conv2d(
            F1 * D,
            F1 * D,
            kernel_size=(1, depthwise_kernel_length),
            padding=(0, depthwise_kernel_length // 2),
            groups=F1 * D,
            bias=False,
        )
        self.sep_pointwise = nn.Conv2d(F1 * D, F2, kernel_size=(1, 1), bias=False)
        self.batchnorm3 = nn.BatchNorm2d(F2)
        self.elu2 = nn.ELU()
        self.avgpool2 = nn.AvgPool2d(kernel_size=(1, 8))
        self.dropout2 = nn.Dropout(dropout_rate)

        self.flatten = nn.Flatten()

        with torch.no_grad():
            dummy_input = torch.zeros(1, 1, self.n_channels, self.n_samples)
            dummy_output = self._forward_features(dummy_input)
            self.feature_dim = int(dummy_output.shape[1])

        self.classifier = nn.Linear(self.feature_dim, self.n_classes)

    def _forward_features(self, x: torch.Tensor) -> torch.Tensor:
        x = self.conv1(x)
        x = self.batchnorm1(x)

        x = self.conv2(x)
        x = self.batchnorm2(x)
        x = self.elu1(x)
        x = self.avgpool1(x)
        x = self.dropout1(x)

        x = self.sep_depthwise(x)
        x = self.sep_pointwise(x)
        x = self.batchnorm3(x)
        x = self.elu2(x)
        x = self.avgpool2(x)
        x = self.dropout2(x)

        return self.flatten(x)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.classifier(self._forward_features(x))


class EEGNetEval(nn.Module):
    """用于评估的 EEGNet 包装。"""

    def __init__(
        self,
        n_channels: int = 22,
        n_samples: int = 1000,
        n_classes: int = 4,
        freeze_backbone: bool = False,
        **kwargs,
    ):
        super().__init__()

        self.backbone = EEGNet(
            n_channels=n_channels,
            n_samples=n_samples,
            n_classes=n_classes,
            **kwargs,
        )

        if freeze_backbone:
            for param in self.backbone.parameters():
                param.requires_grad = False

        self.n_classes = int(n_classes)
        self.feature_dim = int(self.backbone.feature_dim)
        self.classifier = nn.Linear(self.feature_dim, self.n_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.classifier(self.backbone._forward_features(x))

    def get_features(self, x: torch.Tensor) -> torch.Tensor:
        with torch.no_grad():
            return self.backbone._forward_features(x)


def build_eegnet_eval(
    n_channels: int = 22,
    n_samples: int = 1000,
    n_classes: int = 4,
    freeze_backbone: bool = False,
    **kwargs,
):
    return EEGNetEval(
        n_channels=n_channels,
        n_samples=n_samples,
        n_classes=n_classes,
        freeze_backbone=freeze_backbone,
        **kwargs,
    )


def create_eegnet_teacher(n_channels: int = 22, n_samples: int = 1000, n_classes: int = 4, **kwargs):
    return EEGNet(
        n_channels=n_channels,
        n_samples=n_samples,
        n_classes=n_classes,
        **kwargs,
    )


def create_eegnet_model(
    n_classes: int = 4,
    n_channels: int = 22,
    n_samples: int = 1000,
    variant: str = "standard",
    dropout_rate: float = 0.5,
):
    if variant == "standard":
        return EEGNet(
            n_channels=n_channels,
            n_samples=n_samples,
            n_classes=n_classes,
            dropout_rate=dropout_rate,
        )
    return EEGNet(
        n_channels=n_channels,
        n_samples=n_samples,
        n_classes=n_classes,
        dropout_rate=dropout_rate,
    )
