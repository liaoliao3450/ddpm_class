# -*- coding: utf-8 -*-
"""SB-SD-LDM P1 独立验收: 风格通路有效性.

验收门:
  A1 重建判类 (teacher, 正确 s) >= 95%  — 风格注入不破坏重建
  A2 风格判回 (subj_head, 正确 s) >= 90% — 风格信息到达输出
  A3 交换控制 (subj_head 判出 s_other) >= 70% — 风格因果有效
  参考: swap_backfire (交换后仍判回原被试) 越低越好; mse_swap > mse_true
        说明换 s 确实改变输出.

Usage:
    python projects/tc_conf_ldm/scripts/SB-SD-LDM/validate_p1_style.py
    python projects/tc_conf_ldm/scripts/SB-SD-LDM/validate_p1_style.py --epoch 500
"""
import sys
import importlib.util
import argparse
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import numpy as np
import torch

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def _load_module(name, rel):
    spec = importlib.util.spec_from_file_location(name, str(PROJECT_ROOT / rel))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--epoch', type=int, default=500)
    parser.add_argument('--ckpt_dir', type=str,
                        default='checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a')
    args = parser.parse_args()

    torch.manual_seed(42)
    np.random.seed(42)

    tr = _load_module('train_sb_sd_ldm',
                      'projects/tc_conf_ldm/scripts/SB-SD-LDM/train_sb_sd_ldm.py')
    cfg = tr.DATASET_CONFIG['bci2a']

    ckpt_path = PROJECT_ROOT / args.ckpt_dir / f'sb_sd_ldm_epoch_{args.epoch}.pt'
    print(f'[1/3] 加载 checkpoint: {ckpt_path}')
    ckpt = torch.load(str(ckpt_path), map_location=DEVICE, weights_only=False)

    # 2) 重建模型
    yaml_cfg = ckpt['config']
    model_cfg = yaml_cfg.get('model', {})
    from core.models.latent_diffusion.model_shared import (
        SharedBackboneConfig, SharedVAEUNetLDM1D)

    backbone = SharedBackboneConfig(
        base=int(model_cfg.get('backbone_base', 64)),
        levels=tuple(int(x) for x in model_cfg.get('backbone_levels', [1, 2, 4])),
        blocks_per_level=int(model_cfg.get('backbone_blocks_per_level', 2)),
    )
    num_subjects = ckpt.get('num_subjects', 9)
    subj_dim = ckpt.get('subj_dim', 32)
    model = SharedVAEUNetLDM1D(
        channels=cfg['channels'],
        input_length=cfg['input_length'],
        z_channels=int(model_cfg.get('z_channels', 64)),
        timesteps=int(model_cfg.get('timesteps', 1000)),
        t_dim=int(model_cfg.get('t_dim', 128)),
        cond_dim=int(model_cfg.get('cond_embed_dim', 64)),
        backbone=backbone,
        num_subjects=num_subjects,
        adv_alpha=0.0,
        subj_dim=subj_dim,
    ).to(DEVICE)
    model.load_state_dict(ckpt['model_state_dict'])
    model.eval()

    cond_embed = torch.nn.Embedding(cfg['num_classes'],
                                    int(model_cfg.get('cond_embed_dim', 64))).to(DEVICE)
    cond_embed.load_state_dict(ckpt['cond_embed_state_dict'])
    cond_embed.eval()

    # 3) 数据 + teacher
    X, y, subjects = tr.load_dataset('bci2a')
    X_t = torch.FloatTensor(X)
    y_t = torch.LongTensor(y)
    subj_t = torch.LongTensor(subjects)
    teacher = tr.load_teacher('bci2a', cfg['channels'], cfg['input_length'], cfg['num_classes'])

    # 4) 全量评估 (训练脚本同款逻辑, 独立复现)
    print('\n[2/3] P1 三重验收...')
    m = tr.eval_style_quality(model, cond_embed, teacher, X_t, y_t, subj_t,
                              num_subjects, n=1000)

    # 追加: 无 s 重建对照 (subject_id=None, 风格通路关闭)
    with torch.no_grad():
        idx = np.random.RandomState(0).choice(len(X_t), 500, replace=False)
        Xs, ys = X_t[idx], y_t[idx]
        recs_nos, recs_true = [], []
        for i in range(0, len(Xs), 100):
            xb = Xs[i:i + 100].to(DEVICE)
            yb = ys[i:i + 100].to(DEVICE)
            cond = cond_embed(yb)
            mu, _, _ = model.encode(xb, cond=cond)
            recs_nos.append(model.decode(mu, target_length=xb.shape[-1], cond=cond).cpu())
        rec_nos = torch.cat(recs_nos)
    t_pred_nos = []
    with torch.no_grad():
        for i in range(0, len(rec_nos), 100):
            t_pred_nos.append(teacher(rec_nos[i:i + 100].to(DEVICE).unsqueeze(1)).argmax(1).cpu())
    acc_nos = float((torch.cat(t_pred_nos).numpy() == ys.numpy()).mean())
    m['recon_class_acc_nosubj'] = acc_nos

    # 5) 报告
    print('\n' + '=' * 70)
    print(f'P1 验收报告 (epoch {args.epoch})')
    print('=' * 70)
    print(f"  A1 重建判类 (正确 s):   {m['recon_class_acc']*100:.1f}%  "
          f"[{'通过' if m['recon_class_acc'] >= 0.95 else '失败'}] (门: >=95%)")
    print(f"  A1b 重建判类 (无 s):    {m['recon_class_acc_nosubj']*100:.1f}%  (对照)")
    print(f"  A2 风格判回 (正确 s):   {m['style_acc']*100:.1f}%  "
          f"[{'通过' if m['style_acc'] >= 0.90 else '失败'}] (门: >=90%, 随机={100/num_subjects:.1f}%)")
    print(f"  A3 交换控制 (判 s_other): {m['swap_acc']*100:.1f}%  "
          f"[{'通过' if m['swap_acc'] >= 0.70 else '失败'}] (门: >=70%)")
    print(f"  交换误判回原被试:        {m['swap_backfire']*100:.1f}%  (越低越好)")
    print(f"  MSE 正确 s: {m['mse_true']:.4f} | 交换 s: {m['mse_swap']:.4f} "
          f"(比值 {m['mse_swap']/max(m['mse_true'],1e-9):.2f}x, >1 说明 s 因果改变输出)")

    all_pass = (m['recon_class_acc'] >= 0.95 and m['style_acc'] >= 0.90
                and m['swap_acc'] >= 0.70)
    print('=' * 70)
    print(f"  P1 总体验收: {'全部通过 — 可进入 P2 (z 被试不变性)' if all_pass else '未全部通过 — 见上表'}")
    print('=' * 70)

    import json
    out = PROJECT_ROOT / 'outputs/results/sb_sd_ldm_bci2a_p1_validation.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, 'w', encoding='utf-8') as f:
        json.dump({'epoch': args.epoch, 'metrics': m, 'all_pass': all_pass},
                  f, indent=2, ensure_ascii=False)
    print(f'\n已保存: {out}')


if __name__ == '__main__':
    main()
