#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SB-SD-LDM P4: trial 级风格编码器 (StyleEncoder) 训练
===============================================================
前置: P2 checkpoint (checkpoints/tc_conf_ldm/sb_sd_ldm_{ds}_p2/sb_sd_ldm_p2_epoch_500.pt)
      z 已解耦 (只含类内容), decode 风格通路 (subj_proj/subj_head) 已因果可用.

P4 目标: 把风格空间从 9 个离散嵌入点升级为连续分布
  StyleEncoder(x) -> N(mu_s, sigma_s), 锚定到 subj_embed 空间 (宽度 sigma0)

用途 (与 evaluate_p4_cross_subject.py 配合, 消融区分):
  prior   (方向2): 生成时 s ~ N(e_i, sigma0^2 I) — 高斯尾巴突破 Dirichlet 凸包
  fewshot (方向1): 生成时 s = mean(E_style(测试被试少量无标签 trial)) — 定向风格

训练协议:
  P2 主干 + cond_embed 全部冻结; 只训 StyleEncoder (小) + StyleClassDisc (GRL 对抗).
  mu_z 预缓存 (encoder 冻结, 无需每 epoch 重算).

P4 验收门 (训练内监控 + evaluate 时 fresh 探针):
  V1 风格判回: subj_head(decode(mu_z, mu_s)) 判回正确被试 >= 90%
  V2 锚定 margin: ||mu_s - e_s|| 显著小于 ||mu_s - e_other|| (>= 2x)
  V3 类不变: 类别探针在 s 上 ~= chance (25%, 4 类)
  V4 (evaluate 阶段) fewshot 估计: s_test_hat 风格集中于测试被试

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/train_sb_sd_ldm_p4.py --dataset bci2a
"""
import sys
import json
import argparse
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from core.models.latent_diffusion.model_shared import (
    SharedBackboneConfig, SharedVAEUNetLDM1D, GradientReversalFn)

from train_sb_sd_ldm import DATASET_CONFIG, load_config, load_dataset, load_teacher
from style_vae import (
    StyleEncoder, StyleClassDisc, anchor_kl, save_style_vae)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def load_p2_frozen(ckpt_path, dataset):
    """加载 P2 模型并全部冻结."""
    cfg = DATASET_CONFIG[dataset]
    yaml_cfg = load_config(cfg['yaml'])
    model_cfg = yaml_cfg.get('model', {})
    cond_dim = int(model_cfg.get('cond_embed_dim', 64))

    ckpt = torch.load(str(ckpt_path), map_location=DEVICE, weights_only=False)
    subj_dim = int(ckpt.get('subj_dim', 32))

    backbone = SharedBackboneConfig(
        base=int(model_cfg.get('backbone_base', 64)),
        levels=tuple(int(x) for x in model_cfg.get('backbone_levels', [1, 2, 4])),
        blocks_per_level=int(model_cfg.get('backbone_blocks_per_level', 2)),
    )
    model = SharedVAEUNetLDM1D(
        channels=cfg['channels'],
        input_length=cfg['input_length'],
        z_channels=int(model_cfg.get('z_channels', 64)),
        timesteps=int(model_cfg.get('timesteps', 1000)),
        t_dim=int(model_cfg.get('t_dim', 128)),
        cond_dim=cond_dim,
        backbone=backbone,
        num_subjects=cfg['num_subjects'],
        adv_alpha=0.0,
        subj_dim=subj_dim,
        disentangle=True,
    ).to(DEVICE)

    model.load_state_dict(ckpt['model_state_dict'])
    model.eval()
    for p in model.parameters():
        p.requires_grad_(False)

    cond_embed = torch.nn.Embedding(cfg['num_classes'], cond_dim).to(DEVICE)
    cond_embed.load_state_dict(ckpt['cond_embed_state_dict'])
    cond_embed.eval()
    for p in cond_embed.parameters():
        p.requires_grad_(False)

    return model, cond_embed, yaml_cfg


@torch.no_grad()
def cache_mu_z(model, cond_embed, X_t, y_t, bs=128):
    """预缓存全部 trial 的 mu_z (P2 encoder 冻结)."""
    mus = []
    for i in range(0, len(X_t), bs):
        xb = X_t[i:i + bs].to(DEVICE)
        yb = y_t[i:i + bs].to(DEVICE)
        _, mu, _ = model.encode(xb, cond=cond_embed(yb))
        mus.append(mu.cpu())
    return torch.cat(mus, dim=0)


@torch.no_grad()
def style_diagnostics(model, cond_embed, style_enc, X_t, y_t, subj_t, mu_z_cache,
                      n=720, bs=120):
    """训练内诊断: V1 风格判回 + V2 锚定 margin + 被试嵌入范数."""
    idx = np.random.RandomState(0).choice(len(X_t), min(n, len(X_t)), replace=False)
    W = model.subj_embed.weight.detach()          # (S, d)
    norm_mean = float(W.norm(dim=1).mean())

    correct, total = 0, 0
    d_true, d_other = [], []
    for i in range(0, len(idx), bs):
        b = idx[i:i + bs]
        xb = X_t[b].to(DEVICE)
        yb = y_t[b].to(DEVICE)
        sb = subj_t[b].to(DEVICE)
        mu_z = mu_z_cache[b].to(DEVICE)

        mu_s, _ = style_enc(xb)
        x_rec = model.decode(mu_z, target_length=xb.shape[-1],
                             cond=cond_embed(yb), style_vec=mu_s)
        pred = model.subj_head(x_rec).argmax(1)
        correct += int((pred == sb).sum().item())
        total += len(sb)

        # 锚定 margin: 到本被试嵌入 vs 其他被试嵌入的距离
        d_self = (mu_s - W[sb]).norm(dim=1)
        d_mean_other = torch.stack([ (mu_s - W[j]).norm(dim=1) for j in range(W.size(0)) ], 1)
        d_mean_other = (d_mean_other.sum(1) - d_self) / (W.size(0) - 1)
        d_true.append(d_self.cpu())
        d_other.append(d_mean_other.cpu())

    d_true = torch.cat(d_true)
    d_other = torch.cat(d_other)
    return {
        'style_acc': correct / max(total, 1),
        'd_self': float(d_true.mean()),
        'd_other': float(d_other.mean()),
        'margin_ratio': float(d_other.mean() / max(d_true.mean(), 1e-8)),
        'embed_norm': norm_mean,
    }


def train(dataset: str, num_epochs: int = 200, batch_size: int = 64,
          lr: float = 5e-4, sigma0: float = 0.5,
          lambda_recon: float = 1.0, lambda_subj: float = 0.3,
          lambda_anchor: float = 0.1, lambda_cls: float = 0.05,
          init_ckpt: str = None):
    cfg = DATASET_CONFIG[dataset]
    num_subjects = cfg['num_subjects']
    num_classes = cfg['num_classes']

    print('=' * 70)
    print('SB-SD-LDM P4 训练: StyleEncoder (trial 级连续风格)')
    print(f'数据集: {dataset}, 设备: {DEVICE}')
    print(f'sigma0={sigma0} (先验宽度=生成外插半径), epochs={num_epochs}')
    print('=' * 70)

    # 1) 数据
    X_train, y_train, subjects_train = load_dataset(dataset)
    X_t = torch.FloatTensor(X_train)
    y_t = torch.LongTensor(y_train)
    subj_t = torch.LongTensor(subjects_train)

    # 2) P2 冻结主干
    p2_path = PROJECT_ROOT / (init_ckpt or
                              f'checkpoints/tc_conf_ldm/sb_sd_ldm_{dataset}_p2/sb_sd_ldm_p2_epoch_500.pt')
    print(f'\nP2 冻结主干: {p2_path}')
    if not p2_path.exists():
        raise FileNotFoundError(f'P2 checkpoint 不存在: {p2_path}')
    model, cond_embed, yaml_cfg = load_p2_frozen(p2_path, dataset)

    # 3) mu_z 预缓存
    print('预缓存 mu_z (P2 encoder 冻结)...')
    mu_z_cache = cache_mu_z(model, cond_embed, X_t, y_t)
    print(f'  mu_z 缓存: {tuple(mu_z_cache.shape)}')

    # 4) P4 可训练模块
    style_enc = StyleEncoder(cfg['channels'], cfg['input_length'], subj_dim=32).to(DEVICE)
    class_disc = StyleClassDisc(subj_dim=32, num_classes=num_classes).to(DEVICE)
    print(f'StyleEncoder 参数: {sum(p.numel() for p in style_enc.parameters()):,}')

    optim = torch.optim.AdamW(
        list(style_enc.parameters()) + list(class_disc.parameters()),
        lr=lr, weight_decay=1e-5)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optim, T_max=num_epochs, eta_min=1e-6)

    dataset_t = TensorDataset(X_t, y_t, subj_t, mu_z_cache)
    loader = DataLoader(dataset_t, batch_size=batch_size, shuffle=True,
                        num_workers=0, drop_last=True)

    # 5) checkpoint 目录
    ckpt_dir = PROJECT_ROOT / f'checkpoints/tc_conf_ldm/sb_sd_ldm_{dataset}_p4'
    ckpt_dir.mkdir(parents=True, exist_ok=True)

    W_subj = model.subj_embed.weight.detach()     # (S, 32) 冻结锚点

    print(f'\n开始 P4 训练 ({num_epochs} epochs)...')
    print('-' * 70)

    for epoch in range(1, num_epochs + 1):
        style_enc.train()
        class_disc.train()

        ep = {'loss': 0.0, 'recon': 0.0, 'subj': 0.0, 'anchor': 0.0, 'cls': 0.0}
        n_samples = 0

        # GRL alpha ramp (前 50 epochs)
        alpha = min(1.0, epoch / 50.0)

        for X_batch, y_batch, subj_batch, mu_z in loader:
            X_batch = X_batch.to(DEVICE)
            y_batch = y_batch.to(DEVICE)
            subj_batch = subj_batch.to(DEVICE)
            mu_z = mu_z.to(DEVICE)
            B = X_batch.size(0)

            cond = cond_embed(y_batch)

            # StyleEncoder 前向
            mu_s, logvar_s = style_enc(X_batch)
            std_s = torch.exp(0.5 * logvar_s)
            s_vec = mu_s + torch.randn_like(std_s) * std_s

            # 1. 重建: s 补足 z 缺失的被试信息
            x_rec = model.decode(mu_z, target_length=X_batch.shape[-1],
                                 cond=cond, style_vec=s_vec)
            loss_recon = F.mse_loss(x_rec, X_batch)

            # 2. 风格判回: decode 输出被判回正确被试
            loss_subj = F.cross_entropy(model.subj_head(x_rec), subj_batch)

            # 3. 锚定: 风格后验拉向所属被试嵌入 (宽度 sigma0)
            loss_anchor = anchor_kl(mu_s, logvar_s, W_subj[subj_batch], sigma0)

            # 4. 类不变 (GRL): s 上类判别器必须失效
            cls_logits = class_disc(GradientReversalFn.apply(s_vec, alpha))
            loss_cls = F.cross_entropy(cls_logits, y_batch)

            loss = (lambda_recon * loss_recon
                    + lambda_subj * loss_subj
                    + lambda_anchor * loss_anchor
                    + lambda_cls * loss_cls)

            optim.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                list(style_enc.parameters()) + list(class_disc.parameters()), 1.0)
            optim.step()

            ep['loss'] += loss.item() * B
            ep['recon'] += loss_recon.item() * B
            ep['subj'] += loss_subj.item() * B
            ep['anchor'] += loss_anchor.item() * B
            ep['cls'] += loss_cls.item() * B
            n_samples += B

        scheduler.step()

        if epoch % 10 == 0 or epoch == 1:
            n = float(n_samples)
            print(f'[Ep {epoch:3d}/{num_epochs}] Loss:{ep["loss"]/n:.4f} | '
                  f'Recon:{ep["recon"]/n:.4f} | Subj:{ep["subj"]/n:.4f} | '
                  f'Anchor:{ep["anchor"]/n:.4f} | ClsInv:{ep["cls"]/n:.4f}')

        if epoch % 50 == 0 or epoch == num_epochs:
            style_enc.eval()
            d = style_diagnostics(model, cond_embed, style_enc, X_t, y_t, subj_t,
                                  mu_z_cache)
            print(f'  [诊断] style_acc={d["style_acc"]*100:.1f}% | '
                  f'd_self={d["d_self"]:.3f} d_other={d["d_other"]:.3f} '
                  f'(margin_ratio={d["margin_ratio"]:.2f}x) | '
                  f'||e||mean={d["embed_norm"]:.3f}')

            save_style_vae(
                ckpt_dir / f'style_vae_epoch_{epoch}.pt',
                style_enc, class_disc, sigma0,
                meta={'dataset': dataset, 'epoch': epoch,
                      'p2_ckpt': str(p2_path),
                      'lambda': {'recon': lambda_recon, 'subj': lambda_subj,
                                 'anchor': lambda_anchor, 'cls': lambda_cls}})

    # 最终保存
    save_style_vae(
        ckpt_dir / 'style_vae_final.pt',
        style_enc, class_disc, sigma0,
        meta={'dataset': dataset, 'epoch': num_epochs, 'p2_ckpt': str(p2_path)})

    summary = {
        'dataset': dataset,
        'model_type': 'SB-SD-LDM P4 (StyleEncoder)',
        'num_epochs': num_epochs,
        'sigma0': sigma0,
        'lambda': {'recon': lambda_recon, 'subj': lambda_subj,
                   'anchor': lambda_anchor, 'cls': lambda_cls},
        'p2_ckpt': str(p2_path),
    }
    with open(ckpt_dir / 'train_summary.json', 'w', encoding='utf-8') as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print(f'\nP4 训练完成: {ckpt_dir / "style_vae_final.pt"}')


def main():
    parser = argparse.ArgumentParser(description='SB-SD-LDM P4 训练 (StyleEncoder)')
    parser.add_argument('--dataset', type=str, required=True,
                        choices=['bci2a', 'bci2b', 'physionet'])
    parser.add_argument('--epochs', type=int, default=200)
    parser.add_argument('--batch_size', type=int, default=64)
    parser.add_argument('--lr', type=float, default=5e-4)
    parser.add_argument('--sigma0', type=float, default=0.5,
                        help='先验宽度 sigma0 = 被试内风格标准差 = 生成外插半径')
    parser.add_argument('--init_ckpt', type=str, default=None,
                        help='P2 checkpoint 相对路径')
    args = parser.parse_args()

    torch.manual_seed(42)
    np.random.seed(42)

    train(args.dataset, num_epochs=args.epochs, batch_size=args.batch_size,
          lr=args.lr, sigma0=args.sigma0, init_ckpt=args.init_ckpt)


if __name__ == '__main__':
    main()
