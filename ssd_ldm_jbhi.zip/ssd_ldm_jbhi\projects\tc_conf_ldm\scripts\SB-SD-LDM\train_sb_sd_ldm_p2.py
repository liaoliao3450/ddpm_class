#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SB-SD-LDM P2: z 被试不变性 (GRL 对抗解耦)
===============================================================
前置: P1 风格通路已验收 (checkpoints/tc_conf_ldm/sb_sd_ldm_{ds}/sb_sd_ldm_epoch_500.pt)

P2 新增损失:
  L_inv = CE(subject_disc(GRL(mu, alpha)), s)
    - 判别器: 学会从 z 读被试信息 (正向梯度)
    - 编码器: 被反转梯度逼着抹除 z 的被试信息 (负向梯度)
  => 被试信息只能经 P1 风格通路 (subj_embed) 进入 decode, z 只剩类内容.

调度:
  alpha: 0 -> 1.0 线性 ramp (前 alpha_ramp epochs), 之后恒 1.0
    (热启动的 P1 编码器 z 泄漏严重, 缓慢加压避免重建崩坏)
  lambda_inv: 恒定 (默认 0.3)

P2 验收门 (validate_p2_disentangle.py, 独立 fresh probe):
  G1 fresh 被试探针 (z) <= 25%   (chance=11.1%; P1 泄漏基线 ~100%)
  G2 fresh 类别探针 (z) >= 90%   (类信息保留)
  G3 重建判类 (teacher, 正确 s) >= 95%
  G4 交换控制 (subj_head 判 s_other) >= 70%

注意: 训练中打印的 disc_acc 是"同营对抗判别器"读数, 存在低估泄漏的偏倚;
     诚实指标以 validate_p2_disentangle.py 的 fresh probe 为准.

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/train_sb_sd_ldm_p2.py --dataset bci2a
"""
import sys
import json
import argparse
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset

# 项目根路径 (scripts/SB-SD-LDM/ -> 5 级向上)
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
# 同目录模块 (train_sb_sd_ldm)
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from core.models.latent_diffusion.model_shared import (
    SharedBackboneConfig, SharedVAEUNetLDM1D)

from train_sb_sd_ldm import (
    DATASET_CONFIG, load_config, load_dataset, load_teacher, eval_style_quality)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


@torch.no_grad()
def disc_acc_on_z(model, cond_embed, X_t, y_t, subj_t, n=500, bs=100):
    """同营判别器在 z 上的准确率 (粗监控; 诚实指标用 fresh probe)."""
    model.eval()
    idx = np.random.RandomState(0).choice(len(X_t), min(n, len(X_t)), replace=False)
    correct, total = 0, 0
    for i in range(0, len(idx), bs):
        xb = X_t[idx[i:i + bs]].to(DEVICE)
        yb = y_t[idx[i:i + bs]].to(DEVICE)
        sb = subj_t[idx[i:i + bs]].to(DEVICE)
        mu, _, _ = model.encode(xb, cond=cond_embed(yb))
        pred = model.predict_subject_from_z(mu, 0.0).argmax(1)
        correct += int((pred == sb).sum().item())
        total += len(sb)
    model.train()
    return correct / max(total, 1)


def train(dataset: str, num_epochs: int = 500, batch_size: int = 64, lr: float = 1e-4,
          init_ckpt: str = None, ckpt_dir_override: str = None,
          lambda_inv: float = 0.3, alpha_ramp: int = 100,
          subj_dim: int = 32, lambda_style: float = 0.3, swap_p: float = 0.25):
    cfg = DATASET_CONFIG[dataset]
    yaml_cfg = load_config(cfg['yaml'])

    print('=' * 70)
    print('SB-SD-LDM P2 训练 (z 被试不变性, GRL 对抗解耦)')
    print(f'数据集: {dataset}, 设备: {DEVICE}')
    print(f'lambda_inv={lambda_inv}, alpha_ramp={alpha_ramp}')
    print('=' * 70)

    # 1) 数据
    X_train, y_train, subjects_train = load_dataset(dataset)
    channels = cfg['channels']
    input_length = cfg['input_length']
    num_classes = cfg['num_classes']
    fs = cfg['fs']
    num_subjects = cfg['num_subjects']

    X_t = torch.FloatTensor(X_train)
    y_t = torch.LongTensor(y_train)
    subj_t = torch.LongTensor(subjects_train)

    dataset_t = TensorDataset(X_t, y_t, subj_t)
    loader = DataLoader(dataset_t, batch_size=batch_size, shuffle=True,
                        num_workers=0, drop_last=False)

    # 2) 模型 (P1 全部结构 + subject_disc)
    model_cfg = yaml_cfg.get('model', {})
    cond_dim = int(model_cfg.get('cond_embed_dim', 64))
    cond_embed = torch.nn.Embedding(num_classes, cond_dim).to(DEVICE)

    backbone = SharedBackboneConfig(
        base=int(model_cfg.get('backbone_base', 64)),
        levels=tuple(int(x) for x in model_cfg.get('backbone_levels', [1, 2, 4])),
        blocks_per_level=int(model_cfg.get('backbone_blocks_per_level', 2)),
    )
    model = SharedVAEUNetLDM1D(
        channels=channels,
        input_length=input_length,
        z_channels=int(model_cfg.get('z_channels', 64)),
        timesteps=int(model_cfg.get('timesteps', 1000)),
        t_dim=int(model_cfg.get('t_dim', 128)),
        cond_dim=cond_dim,
        backbone=backbone,
        num_subjects=num_subjects,
        adv_alpha=0.0,
        subj_dim=subj_dim,
        disentangle=True,
    ).to(DEVICE)
    assert model.subject_disc is not None, 'P2 模型应创建 subject_disc'

    # 3) 潜空间分类头
    with torch.no_grad():
        dummy_x = torch.zeros(1, channels, input_length, device=DEVICE)
        dummy_cond = torch.zeros(1, cond_dim, device=DEVICE)
        z_dummy, _, _ = model.encode(dummy_x, cond=dummy_cond)
        latent_dim = z_dummy.shape[1] * z_dummy.shape[2]
    classifier_head = torch.nn.Linear(latent_dim, num_classes).to(DEVICE)

    # 4) P1 热启动
    p1_path = PROJECT_ROOT / (init_ckpt or
                              f'checkpoints/tc_conf_ldm/sb_sd_ldm_{dataset}/sb_sd_ldm_epoch_500.pt')
    print(f'\nP1 热启动: {p1_path}')
    if not p1_path.exists():
        raise FileNotFoundError(f'P1 checkpoint 不存在: {p1_path} (P2 前置条件)')
    p1 = torch.load(str(p1_path), map_location=DEVICE, weights_only=False)
    info = model.load_state_dict(p1['model_state_dict'], strict=False)
    assert not info.unexpected_keys, f'意外的键: {info.unexpected_keys[:5]}'
    assert all(k.startswith('subject_disc.') for k in info.missing_keys), \
        f'缺失键异常: {info.missing_keys[:5]}'
    cond_embed.load_state_dict(p1['cond_embed_state_dict'])
    classifier_head.load_state_dict(p1['classifier_head_state_dict'])
    print(f'  热启动完成 (新初始化: {len(info.missing_keys)} 个 subject_disc 参数张量)')

    print(f'\n模型参数: {sum(p.numel() for p in model.parameters()):,}')

    # 5) Teacher
    teacher = load_teacher(dataset, channels, input_length, num_classes)

    # 6) 优化器
    optim = torch.optim.AdamW(
        list(model.parameters()) + list(cond_embed.parameters()) + list(classifier_head.parameters()),
        lr=lr, weight_decay=1e-5,
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optim, T_max=num_epochs, eta_min=1e-6)

    # 7) Checkpoint 目录
    ckpt_dir = PROJECT_ROOT / (ckpt_dir_override or f'checkpoints/tc_conf_ldm/sb_sd_ldm_{dataset}_p2')
    ckpt_dir.mkdir(parents=True, exist_ok=True)

    # 8) 训练循环
    print(f'\n开始 P2 训练 ({num_epochs} epochs)...')
    print('-' * 70)

    beta_kl_base = float(model_cfg.get('beta_kl', 1e-3))
    lambda_cls = float(model_cfg.get('lambda_cls', 1.0))
    lambda_feat = float(model_cfg.get('lambda_feat', 0.4))
    lambda_logit_base = float(model_cfg.get('lambda_logit', 0.8))
    lambda_conf = float(model_cfg.get('lambda_conf', 0.15))
    lambda_erd = float(model_cfg.get('lambda_erd', 2.0))

    c3, c4 = cfg['erd_c3'], cfg['erd_c4']

    for epoch in range(1, num_epochs + 1):
        model.train()
        cond_embed.train()
        classifier_head.train()

        ep = {'loss': 0.0, 'eps': 0.0, 'kl': 0.0, 'cls': 0.0, 'recon': 0.0,
              'feat': 0.0, 'logit': 0.0, 'conf': 0.0, 'erd': 0.0,
              'style': 0.0, 'swap': 0.0, 'inv': 0.0}

        # GRL alpha ramp
        alpha = min(1.0, epoch / max(1, alpha_ramp))

        for X_batch, y_batch, subj_batch in loader:
            X_batch = X_batch.to(DEVICE)
            y_batch = y_batch.to(DEVICE)
            subj_batch = subj_batch.to(DEVICE)

            B = X_batch.size(0)
            cond = cond_embed(y_batch)

            t = torch.randint(0, int(model.timesteps), (B,), device=DEVICE, dtype=torch.long)
            eps_pred, noise, mu, logvar, _ = model(X_batch, t, cond=cond, subject_id=subj_batch)

            # 1. Diffusion loss
            loss_eps = F.mse_loss(eps_pred, noise)

            # 2. KL loss
            logvar_clamped = torch.clamp(logvar, min=-10, max=10)
            kl_per = -0.5 * (1 + logvar_clamped - mu.pow(2) - logvar_clamped.exp())
            kl_loss = torch.mean(kl_per)

            # 3. Reconstruction (带风格注入; 权重恒定)
            x_recon = model.decode(mu, target_length=X_batch.shape[-1],
                                   cond=cond, subject_id=subj_batch)
            loss_recon = F.mse_loss(x_recon, X_batch)
            loss_recon_w = 1.0

            # 4. Latent classification (保类信息, 对抗解耦的制衡项)
            z0_flat = mu.view(B, -1)
            loss_cls = F.cross_entropy(classifier_head(z0_flat), y_batch)

            # 5. Teacher distillation
            X_real_t = X_batch.unsqueeze(1)
            X_recon_t = x_recon.unsqueeze(1)
            with torch.no_grad():
                feat_real = teacher._forward_features(X_real_t)
                logits_real = teacher(X_real_t)
            feat_recon = teacher._forward_features(X_recon_t)
            logits_recon = teacher(X_recon_t)

            loss_feat = F.mse_loss(feat_recon, feat_real)
            loss_logit = F.cross_entropy(logits_recon, y_batch)
            prob_real = F.softmax(logits_real, dim=1)
            prob_recon = F.softmax(logits_recon, dim=1)
            loss_conf = F.kl_div(prob_recon.log(), prob_real, reduction="batchmean")

            # 6. ERD regularization
            loss_erd = torch.tensor(0.0, device=DEVICE)
            if epoch > int(num_epochs * 0.1):
                eps_fft = 1e-8

                def band_power(x_sig, low, high):
                    T_len = x_sig.shape[-1]
                    freqs = torch.fft.rfftfreq(T_len, d=1.0 / fs).to(x_sig.device)
                    spec = torch.fft.rfft(x_sig, dim=-1).abs().pow(2)
                    mask = (freqs >= low) & (freqs <= high)
                    return spec[..., mask].mean(dim=-1).clamp(min=eps_fft)

                mu_recon = band_power(x_recon, 8, 13)
                beta_recon = band_power(x_recon, 13, 30)
                mu_real = band_power(X_batch, 8, 13).detach()
                beta_real = band_power(X_batch, 13, 30).detach()

                lat_mu_recon = (mu_recon[:, c4] - mu_recon[:, c3]) / (mu_recon[:, c4] + mu_recon[:, c3] + eps_fft)
                lat_mu_real = (mu_real[:, c4] - mu_real[:, c3]) / (mu_real[:, c4] + mu_real[:, c3] + eps_fft)
                lat_beta_recon = (beta_recon[:, c4] - beta_recon[:, c3]) / (beta_recon[:, c4] + beta_recon[:, c3] + eps_fft)
                lat_beta_real = (beta_real[:, c4] - beta_real[:, c3]) / (beta_real[:, c4] + beta_real[:, c3] + eps_fft)

                loss_erd = F.mse_loss(lat_mu_recon, lat_mu_real) + F.mse_loss(lat_beta_recon, lat_beta_real)

            # 7. P1 风格损失 (正确 s + 交换 s)
            loss_style = F.cross_entropy(model.subj_head(x_recon), subj_batch)

            n_swap = max(1, int(B * swap_p))
            swap_idx = torch.randperm(B, device=DEVICE)[:n_swap]
            s_other = (subj_batch[swap_idx]
                       + torch.randint(1, num_subjects, (n_swap,), device=DEVICE)) % num_subjects
            x_swap = model.decode(mu[swap_idx].detach(),
                                  target_length=X_batch.shape[-1],
                                  cond=cond[swap_idx].detach(), subject_id=s_other)
            loss_swap = F.cross_entropy(model.subj_head(x_swap), s_other)

            # 8. P2 对抗解耦: GRL 反传 (核心新增)
            subj_logits_z = model.predict_subject_from_z(mu, grl_alpha=alpha)
            loss_inv = F.cross_entropy(subj_logits_z, subj_batch)

            # KL anneal
            if epoch <= num_epochs * 0.2:
                kl_w = (epoch / (num_epochs * 0.2)) * 0.3
            elif epoch <= num_epochs * 0.5:
                kl_w = 0.3 + ((epoch - num_epochs * 0.2) / (num_epochs * 0.3)) * 0.4
            elif epoch <= num_epochs * 0.8:
                kl_w = 0.7 + ((epoch - num_epochs * 0.5) / (num_epochs * 0.3)) * 0.3
            else:
                kl_w = 1.0

            beta_kl = beta_kl_base * kl_w
            lambda_logit = lambda_logit_base * (1.0 + epoch / num_epochs)

            # Total loss
            loss = (
                loss_eps
                + beta_kl * kl_loss
                + lambda_cls * loss_cls
                + loss_recon_w * loss_recon
                + lambda_feat * loss_feat
                + lambda_logit * loss_logit
                + lambda_conf * loss_conf
                + lambda_erd * loss_erd
                + lambda_style * loss_style
                + lambda_style * loss_swap
                + lambda_inv * loss_inv
            )

            optim.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                list(model.parameters()) + list(cond_embed.parameters()), 1.0)
            optim.step()

            bs = float(B)
            ep['loss'] += loss.item() * bs
            ep['eps'] += loss_eps.item() * bs
            ep['kl'] += kl_loss.item() * bs
            ep['cls'] += loss_cls.item() * bs
            ep['recon'] += loss_recon.item() * bs
            ep['feat'] += loss_feat.item() * bs
            ep['logit'] += loss_logit.item() * bs
            ep['conf'] += loss_conf.item() * bs
            ep['erd'] += loss_erd.item() * bs
            ep['style'] += loss_style.item() * bs
            ep['swap'] += loss_swap.item() * bs
            ep['inv'] += loss_inv.item() * bs

        n = float(len(dataset_t))
        for k in ep:
            ep[k] /= n

        scheduler.step()
        lr_now = scheduler.get_last_lr()[0]

        if epoch % 10 == 0 or epoch == 1:
            print(
                f'[Ep {epoch:3d}/{num_epochs}] alpha:{alpha:.2f} | '
                f'Loss:{ep["loss"]:.4f} | Diff:{ep["eps"]:.4f} | Recon:{ep["recon"]:.4f} | '
                f'Cls:{ep["cls"]:.4f} | Style:{ep["style"]:.4f} | Swap:{ep["swap"]:.4f} | '
                f'Inv:{ep["inv"]:.4f} | ERD:{ep["erd"]:.4f} | LR:{lr_now:.1e}'
            )

        if epoch % 50 == 0 or epoch == num_epochs:
            metrics = eval_style_quality(model, cond_embed, teacher, X_t, y_t, subj_t,
                                         num_subjects)
            d_acc = disc_acc_on_z(model, cond_embed, X_t, y_t, subj_t)
            ckpt_path = ckpt_dir / f'sb_sd_ldm_p2_epoch_{epoch}.pt'
            torch.save({
                'epoch': epoch,
                'config': yaml_cfg,
                'model_state_dict': model.state_dict(),
                'cond_embed_state_dict': cond_embed.state_dict(),
                'classifier_head_state_dict': classifier_head.state_dict(),
                'stage': 'P2_disentangle',
                'disentangle': True,
                'subj_dim': subj_dim,
                'num_subjects': num_subjects,
                'lambda_inv': lambda_inv,
                'alpha_ramp': alpha_ramp,
                'p1_metrics': metrics,
            }, ckpt_path)
            m = metrics
            print(f'  保存: {ckpt_path.name} | '
                  f'recon_cls={m["recon_class_acc"]*100:.1f}% '
                  f'style={m["style_acc"]*100:.1f}% '
                  f'swap={m["swap_acc"]*100:.1f}% (backfire={m["swap_backfire"]*100:.1f}%) '
                  f'disc_acc(z)={d_acc*100:.1f}% '
                  f'mse_true={m["mse_true"]:.4f} mse_swap={m["mse_swap"]:.4f}')

    summary = {
        'config': yaml_cfg,
        'dataset': dataset,
        'model_type': 'SB-SD-LDM P2 (GRL disentangle)',
        'num_epochs': num_epochs,
        'lambda_inv': lambda_inv,
        'alpha_ramp': alpha_ramp,
        'init_from': str(p1_path),
    }
    summary_path = ckpt_dir / 'train_summary.json'
    with open(summary_path, 'w', encoding='utf-8') as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print(f'\nP2 训练完成: {summary_path}')


def main():
    parser = argparse.ArgumentParser(description='SB-SD-LDM P2 训练 (GRL 解耦)')
    parser.add_argument('--dataset', type=str, required=True,
                        choices=['bci2a', 'bci2b', 'physionet'])
    parser.add_argument('--epochs', type=int, default=500)
    parser.add_argument('--batch_size', type=int, default=64)
    parser.add_argument('--lr', type=float, default=1e-4)
    parser.add_argument('--init_ckpt', type=str, default=None,
                        help='P1 checkpoint 相对路径 (默认 sb_sd_ldm_{ds}/sb_sd_ldm_epoch_500.pt)')
    parser.add_argument('--ckpt_dir', type=str, default=None)
    parser.add_argument('--inv_w', type=float, default=0.3)
    parser.add_argument('--alpha_ramp', type=int, default=100)
    args = parser.parse_args()

    torch.manual_seed(42)
    np.random.seed(42)

    train(args.dataset, num_epochs=args.epochs, batch_size=args.batch_size, lr=args.lr,
          init_ckpt=args.init_ckpt, ckpt_dir_override=args.ckpt_dir,
          lambda_inv=args.inv_w, alpha_ramp=args.alpha_ramp)


if __name__ == '__main__':
    main()
