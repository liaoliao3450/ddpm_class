#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
P5 LOSO 日志监控: 定时抓取日志, 打印当前 Acc/Kappa 进度
===============================================================
监控 outputs/logs/ 下两个 LOSO 日志 (cfg2 结束后 cfg1 由接力脚本自动启动):
  p5_cov_only_cfg2_loso.log   cfg=2.0 LOSO (类别引导, 快检 d_rel=0.814)
  p5_cov_only_cfg1_loso.log   cfg=1.0 LOSO (协方差定向, 快检 d_rel=0.543)

输出: 每折 Acc/Kappa 表 + 运行均值 + 完成判决; 全部完成后自动退出.

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/monitor_p5_logs.py
    python projects/tc_conf_ldm/scripts/SB-SD-LDM/monitor_p5_logs.py --interval 60   # 1 分钟一次
"""
import re
import time
import argparse
from pathlib import Path
from datetime import datetime

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
LOG_DIR = PROJECT_ROOT / 'outputs' / 'logs'

LOGS = [
    ('EA-40 + Latent-EA-full 组合', LOG_DIR / 'ea_latentEA_combo.log'),
]

PAT_SUBJ = re.compile(r'被试\s+(\d+):\s*Acc\s+([\d.]+)%,\s*Kappa\s+([\d.]+)')
PAT_FINAL = re.compile(r'>>>.*?:\s*([\d.]+)% ± ([\d.]+)% \(Kappa ([\d.]+)\)')

N_FOLDS = 9


def read_text_safe(path: Path) -> str:
    """兼容 UTF-8 / UTF-16 (PowerShell 重定向两种编码都可能)."""
    raw = path.read_bytes()
    if raw.startswith(b'\xff\xfe') or raw.startswith(b'\xfe\xff'):
        return raw.decode('utf-16', errors='replace')
    return raw.decode('utf-8', errors='replace')


def parse_log(path: Path):
    """返回 (per_subject dict, final dict or None, running bool)."""
    if not path.exists():
        return None, None, False
    try:
        text = read_text_safe(path)
    except OSError:
        return None, None, False
    per_subject = {}
    for m in PAT_SUBJ.finditer(text):
        per_subject[int(m.group(1))] = (float(m.group(2)), float(m.group(3)))
    final = None
    m = PAT_FINAL.search(text)
    if m:
        final = {'mean': float(m.group(2)), 'std': float(m.group(3)),
                 'kappa': float(m.group(4))}
    return per_subject, final, '[LOSO]' in text


def print_report():
    print('=' * 58)
    print(f'[{datetime.now():%H:%M:%S}] P5 LOSO 进度')
    print('=' * 58)
    n_done_logs = 0
    for tag, path in LOGS:
        per_subject, final, running = parse_log(path)
        if per_subject is None and final is None:
            print(f'\n--- {tag} ---')
            if path.exists():
                print('  日志存在但暂无可解析结果 (快检阶段)...')
            else:
                print('  日志未出现 (等待 cfg=2.0 完成后接力启动)...')
            continue
        print(f'\n--- {tag} ---')
        if per_subject:
            print(f'{"被试":>4s}   {"Acc(%)":>7s}   {"Kappa":>7s}')
            for s in sorted(per_subject):
                acc, kap = per_subject[s]
                print(f'{s:>4d}   {acc:>7.2f}   {kap:>7.4f}')
            accs = [v[0] for v in per_subject.values()]
            kaps = [v[1] for v in per_subject.values()]
            print(f'{"均值":>4s}   {sum(accs)/len(accs):>7.2f}   {sum(kaps)/len(kaps):>7.4f}'
                  f'   [{len(accs)}/{N_FOLDS} 折]')
        elif running:
            print('  LOSO 已启动, 第 1 折进行中 (每折约 20 分钟)...')
        else:
            print('  快检阶段, LOSO 未开始...')
        if final:
            n_done_logs += 1
            print(f'  *** 完成 ***: {final["mean"]:.2f}% ± {final["std"]:.2f}% '
                  f'(Kappa {final["kappa"]:.4f})')
    print()
    return n_done_logs


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--interval', type=int, default=300,
                        help='轮询间隔秒数 (默认 300 = 5 分钟)')
    args = parser.parse_args()

    print(f'监控间隔 {args.interval}s, Ctrl+C 退出\n')
    while True:
        n_done = print_report()
        if n_done == len(LOGS):
            print('两个 LOSO 均已完成, 监控退出.')
            break
        time.sleep(args.interval)


if __name__ == '__main__':
    main()
