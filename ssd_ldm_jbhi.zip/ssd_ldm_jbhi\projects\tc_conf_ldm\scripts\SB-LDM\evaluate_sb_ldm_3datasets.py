#!/usr/bin/env python3
"""
SB-LDM (Shared-Backbone Latent Diffusion Model) — 纯会议版三场景评估脚本

简化版: 单分类器, 无 AdaIN, 无 MMD DA, 无 scenario/difficulty 条件化
保留: DDIM 生成 + 类别条件化 + normalize_to_real_stats

三个数据集: BCI2a / BCI2b / PhysioNet MI4C
三个场景:   Within-Subject / Cross-Session / Cross-Subject

Usage:
    python projects/tc_conf_ldm/scripts/evaluate_sb_ldm_3datasets.py --dataset bci2a
    python projects/tc_conf_ldm/scripts/evaluate_sb_ldm_3datasets.py --dataset all
"""
import sys
import os
import json
import argparse
import random
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
import yaml
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, cohen_kappa_score
from torch.utils.data import DataLoader, TensorDataset

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from core.classifiers.eegnet import EEGNet
from core.models.latent_diffusion.model_shared import (
    SharedVAEUNetLDM1D,
    SharedBackboneConfig,
)

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

SEED = 42

# 评估超参 (简化版 + 集成)
CLASSIFIER_EPOCHS = 200
CLASSIFIER_BATCH_SIZE = 32
CLASSIFIER_LR = 1e-3
DDIM_STEPS = 50
GUIDANCE_SCALE = 2.0
GEN_RATIO = 1.0
N_ENSEMBLE = 3  # 3 模型集成 (不同随机种子)

# 数据集配置 (使用新的 sb_ldm_ checkpoint)
DATASET_CONFIG = {
    'bci2a': {
        'checkpoint': 'checkpoints/tc_conf_ldm/sb_ldm_bci2a/sb_ldm_epoch_500.pt',
        'config_yaml': 'projects/tc_conf_ldm/configs/bci2a_tc_conf_ldm_shared.yaml',
        'num_classes': 4,
        'cross_subject_mode': 'loso',
        'skip_within': False,
        'skip_cross_session': False,
    },
    'bci2b': {
        'checkpoint': 'checkpoints/tc_conf_ldm/sb_ldm_bci2b/sb_ldm_epoch_500.pt',
        'config_yaml': 'projects/tc_conf_ldm/configs/bci2b_tc_conf_ldm_shared.yaml',
        'num_classes': 2,
        'cross_subject_mode': 'loso',
        'skip_within': False,
        'skip_cross_session': False,
    },
    'physionet': {
        'checkpoint': 'checkpoints/tc_conf_ldm/sb_ldm_physionet/sb_ldm_epoch_500.pt',
        'config_yaml': 'projects/tc_conf_ldm/configs/physionet_mi4c_tc_conf_ldm_shared.yaml',
        'num_classes': 4,
        'cross_subject_mode': 'lmso_10fold',
        'skip_within': True,
        'skip_cross_session': True,
    },
}


def set_seed(seed=SEED):
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def load_dataset_data(dataset):
    print(f'加载 {dataset} 数据...')
    if dataset == 'bci2a':
        from utils.data_loader import load_bci2a_data
        X, y, subjects, sessions = load_bci2a_data()
    elif dataset == 'bci2b':
        from utils.data_loader_bci2b import load_bci2b_data
        X, y, subjects, sessions, _ = load_bci2b_data()
    elif dataset == 'physionet':
        from utils.data_loader_physionet_mi4c import load_physionet_mi4c_data
        X, y, subjects, sessions, _ = load_physionet_mi4c_data()
    else:
        raise ValueError(f'未知数据集: {dataset}')

    X = X.astype(np.float32)
    y = y.astype(np.int64)
    num_classes = DATASET_CONFIG[dataset]['num_classes']
    y = y - y.min()
    mask = y < num_classes
    X, y = X[mask], y[mask]
    subjects = np.asarray(subjects)[mask]
    sessions = np.asarray(sessions)[mask]
    X = (X - X.mean(axis=(0, 2), keepdims=True)) / (X.std(axis=(0, 2), keepdims=True) + 1e-8)
    print(f'  数据: {X.shape}, 被试: {len(np.unique(subjects))}')
    return X, y, subjects, sessions


def load_sb_ldm(dataset, device=DEVICE):
    cfg = DATASET_CONFIG[dataset]
    ckpt_path = PROJECT_ROOT / cfg['checkpoint']
    if not ckpt_path.exists():
        # 兜底: 找最新 epoch
        ckpt_dir = ckpt_path.parent
        if ckpt_dir.exists():
            import re
            cands = sorted(ckpt_dir.glob('sb_ldm_epoch_*.pt'))
            def _ek(p):
                m = re.search(r'epoch_(\d+)\.pt$', p.name)
                return int(m.group(1)) if m else -1
            cands = sorted(cands, key=_ek)
            if cands:
                ckpt_path = cands[-1]
                print(f'  使用最新 checkpoint: {ckpt_path}')
            else:
                raise FileNotFoundError(f'未找到 checkpoint: {cfg["checkpoint"]}')
        else:
            raise FileNotFoundError(f'checkpoint 目录不存在: {ckpt_dir}')

    print(f'加载 SB-LDM: {ckpt_path}')
    checkpoint = torch.load(str(ckpt_path), map_location=device, weights_only=False)

    if isinstance(checkpoint, dict) and 'config' in checkpoint:
        cfg_dict = checkpoint['config']
    else:
        yaml_path = PROJECT_ROOT / cfg['config_yaml']
        if yaml_path.exists():
            with open(yaml_path, 'r', encoding='utf-8') as f:
                cfg_dict = yaml.safe_load(f)
        else:
            cfg_dict = {}

    data_cfg = cfg_dict.get('data', {})
    model_cfg = cfg_dict.get('model', {})
    _ch = {'bci2a': 22, 'bci2b': 3, 'physionet': 64}
    channels = int(data_cfg.get('num_channels', _ch.get(dataset, 22)))
    input_length = int(data_cfg.get('segment_length', 1000 if dataset != 'physionet' else 640))
    cond_dim = int(model_cfg.get('cond_embed_dim', 64))
    backbone = SharedBackboneConfig(
        base=int(model_cfg.get('backbone_base', 64)),
        levels=tuple(int(x) for x in model_cfg.get('backbone_levels', [1, 2, 4])),
        blocks_per_level=int(model_cfg.get('backbone_blocks_per_level', 2)),
    )

    _ns = {'bci2a': 9, 'bci2b': 9, 'physionet': 97}
    num_subjects = int(model_cfg.get('num_subjects', _ns.get(dataset, 0)))

    model = SharedVAEUNetLDM1D(
        channels=channels,
        input_length=input_length,
        z_channels=int(model_cfg.get('z_channels', 64)),
        timesteps=int(model_cfg.get('timesteps', 1000)),
        t_dim=int(model_cfg.get('t_dim', 128)),
        cond_dim=cond_dim,
        backbone=backbone,
        num_subjects=num_subjects,
        adv_alpha=0.0,
    ).to(device)

    num_classes = cfg['num_classes']
    # SB-LDM: 仅类别条件化 (无 scenario/difficulty)
    cond_embed = torch.nn.Embedding(num_classes, cond_dim).to(device)

    if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint:
        model.load_state_dict(checkpoint['model_state_dict'], strict=False)
    if isinstance(checkpoint, dict) and 'cond_embed_state_dict' in checkpoint:
        cond_embed.load_state_dict(checkpoint['cond_embed_state_dict'], strict=False)

    model.eval()
    cond_embed.eval()
    print('  SB-LDM 加载成功')
    return model, cond_embed


def normalize_to_real_stats(X_real, X_gen):
    X_real = X_real.astype(np.float32)
    X_gen = X_gen.astype(np.float32)
    nan_mask = np.isnan(X_gen).any(axis=(1, 2))
    if nan_mask.any():
        X_gen = np.nan_to_num(X_gen, nan=0.0)
    rm = X_real.mean(axis=(0, 2), keepdims=True)
    rs = X_real.std(axis=(0, 2), keepdims=True)
    gm = X_gen.mean(axis=(0, 2), keepdims=True)
    gs = X_gen.std(axis=(0, 2), keepdims=True)
    if float(np.max(gs)) < 1e-8:
        return X_gen
    return (X_gen - gm) / (gs + 1e-8) * (rs + 1e-8) + rm


def train_classifier(X_train, y_train, channels, input_length, num_classes, device=DEVICE):
    """训练 N_ENSEMBLE 个 EEGNet 分类器 (不同随机种子, 投票集成)。"""
    ensemble = []
    for i in range(N_ENSEMBLE):
        set_seed(SEED + i)  # 不同随机种子
        clf = EEGNet(n_channels=channels, n_samples=input_length, n_classes=num_classes).to(device)
        clf.train()
        optimizer = torch.optim.Adam(clf.parameters(), lr=CLASSIFIER_LR)

        X_t = torch.FloatTensor(X_train)
        y_t = torch.LongTensor(y_train)
        if X_t.dim() == 3:
            X_t = X_t.unsqueeze(1)
        loader = DataLoader(TensorDataset(X_t, y_t), batch_size=CLASSIFIER_BATCH_SIZE, shuffle=True)

        for _ in range(CLASSIFIER_EPOCHS):
            for Xb, yb in loader:
                Xb, yb = Xb.to(device), yb.to(device)
                if Xb.dim() == 3:
                    Xb = Xb.unsqueeze(1)
                optimizer.zero_grad()
                F.cross_entropy(clf(Xb), yb).backward()
                optimizer.step()
        ensemble.append(clf)
    return ensemble


def predict(ensemble, X_test, device=DEVICE):
    """N_ENSEMBLE 个分类器软投票 (平均 softmax 概率)。"""
    Xt = torch.FloatTensor(X_test)
    if Xt.dim() == 3:
        Xt = Xt.unsqueeze(1)
    Xt = Xt.to(device)
    with torch.no_grad():
        probs = None
        for clf in ensemble:
            clf.eval()
            p = F.softmax(clf(Xt), dim=1)
            if probs is None:
                probs = p
            else:
                probs += p
    probs /= len(ensemble)
    return probs.argmax(dim=1).cpu().numpy()


def _make_ddim_schedule(alpha_bar, steps):
    total = len(alpha_bar)
    step = total // steps
    return list(reversed(range(0, total, step)))[:steps]


def generate_sb_ldm(model, cond_embed, n_per_class, num_classes,
                    subject_id=None, device=DEVICE):
    """SB-LDM DDIM 生成 (仅类别条件化, 无 scenario/difficulty/AdaIN)。"""
    model.eval()
    cond_embed.eval()
    e = 1e-8
    ddim_seq = _make_ddim_schedule(model.alpha_bar, DDIM_STEPS)

    with torch.no_grad():
        dummy = torch.zeros(1, model.channels, model.input_length, device=device)
        z_d, _, _ = model.encode(dummy, cond=torch.zeros(1, model.cond_dim, device=device))
        z_ch, latent_len = model.z_channels, z_d.shape[-1]

    all_X, all_y = [], []
    with torch.no_grad():
        for c in range(num_classes):
            generated = 0
            while generated < n_per_class:
                bs = min(32, n_per_class - generated)
                cl = torch.full((bs,), c, dtype=torch.long, device=device)
                subj = torch.full((bs,), subject_id, dtype=torch.long, device=device) if subject_id is not None else None
                # SB-LDM: 仅类别条件化
                cond = cond_embed(cl)

                z = torch.randn(bs, z_ch, latent_len, device=device)
                for i, t_idx in enumerate(ddim_seq):
                    t = torch.full((bs,), t_idx, device=device, dtype=torch.long)
                    ec = model.denoise_eps(z, t, cond=cond)
                    if GUIDANCE_SCALE > 1.0:
                        eu = model.denoise_eps(z, t, cond=None)
                        eps_pred = torch.clamp(eu + GUIDANCE_SCALE * (ec - eu), -100, 100)
                    else:
                        eps_pred = ec

                    ab = model.alpha_bar[t_idx]
                    ab_prev = model.alpha_bar[ddim_seq[i + 1]] if i + 1 < len(ddim_seq) else model.alpha_bar[0]
                    ab = ab.to(device) if isinstance(ab, torch.Tensor) else torch.tensor(ab, device=device)
                    ab_prev = ab_prev.to(device) if isinstance(ab_prev, torch.Tensor) else torch.tensor(ab_prev, device=device)

                    sab = torch.sqrt(ab.clamp(min=e))
                    s1mb = torch.sqrt((1 - ab).clamp(min=e))
                    sab_prev = torch.sqrt(ab_prev.clamp(min=e))
                    s1mb_prev = torch.sqrt((1 - ab_prev).clamp(min=e))

                    pred_x0 = ((z - s1mb * eps_pred) / sab).clamp(-5, 5)
                    z = sab_prev * pred_x0 + s1mb_prev * eps_pred

                x = model.decode(z, target_length=model.input_length, cond=cond)
                all_X.append(x.cpu().numpy())
                all_y.extend([c] * bs)
                generated += bs

    return np.concatenate(all_X), np.array(all_y)


SKIP_VAL = {'mean': 0.0, 'std': 0.0, 'per_subject': [], 'skipped': True,
            'mean_kappa': 0.0, 'std_kappa': 0.0, 'per_subject_kappa': []}


def within_subject_test(model, cond_embed, X, y, subjects, num_classes):
    print('\n' + '=' * 70)
    print('1. Within-Subject (SB-LDM, 单分类器)')
    print('=' * 70)

    results = []
    unique_subjects = np.unique(subjects)
    channels, input_length = X.shape[1], X.shape[2]

    for si, subj_id in enumerate(unique_subjects):
        print(f'\n被试 {si+1}/{len(unique_subjects)}:')
        mask = subjects == subj_id
        X_subj, y_subj = X[mask], y[mask]
        X_train, X_test, y_train, y_test = train_test_split(
            X_subj, y_subj, test_size=0.2, random_state=42, stratify=y_subj)

        spc = max(1, int(GEN_RATIO * len(X_train)) // num_classes)
        set_seed()
        subj_for_gen = int(subj_id) if getattr(model, 'num_subjects', 0) > 0 else None
        gen_X, gen_y = generate_sb_ldm(model, cond_embed, spc, num_classes, subj_for_gen)
        gen_X = normalize_to_real_stats(X_train, gen_X)

        X_aug = np.concatenate([X_train, gen_X])
        y_aug = np.concatenate([y_train, gen_y])

        clf = train_classifier(X_aug, y_aug, channels, input_length, num_classes)
        pred = predict(clf, X_test)
        acc = float(accuracy_score(y_test, pred))
        kappa = float(cohen_kappa_score(y_test, pred))
        results.append({'acc': acc, 'kappa': kappa})
        print(f'  Acc: {acc*100:.2f}%, Kappa: {kappa:.4f}')

    if not results:
        return SKIP_VAL
    accs = [r['acc'] for r in results]
    kappas = [r['kappa'] for r in results]
    print(f'\n平均: {np.mean(accs)*100:.2f}% ± {np.std(accs)*100:.2f}%, Kappa: {np.mean(kappas):.4f}')
    return {'mean': float(np.mean(accs)), 'std': float(np.std(accs)),
            'per_subject': accs, 'mean_kappa': float(np.mean(kappas)),
            'std_kappa': float(np.std(kappas)), 'per_subject_kappa': kappas}


def cross_session_test(model, cond_embed, X, y, subjects, sessions, num_classes):
    print('\n' + '=' * 70)
    print('2. Cross-Session (SB-LDM, 单分类器)')
    print('=' * 70)

    results = []
    unique_subjects = np.unique(subjects)
    channels, input_length = X.shape[1], X.shape[2]

    for si, subj_id in enumerate(unique_subjects):
        print(f'\n被试 {si+1}/{len(unique_subjects)}:')
        train_mask = (subjects == subj_id) & (sessions == 0)
        test_mask = (subjects == subj_id) & (sessions == 1)
        X_train, y_train = X[train_mask], y[train_mask]
        X_test, y_test = X[test_mask], y[test_mask]
        if len(X_train) == 0 or len(X_test) == 0:
            continue

        spc = max(1, int(GEN_RATIO * len(X_train)) // num_classes)
        set_seed()
        subj_for_gen = int(subj_id) if getattr(model, 'num_subjects', 0) > 0 else None
        gen_X, gen_y = generate_sb_ldm(model, cond_embed, spc, num_classes, subj_for_gen)
        gen_X = normalize_to_real_stats(X_train, gen_X)

        X_aug = np.concatenate([X_train, gen_X])
        y_aug = np.concatenate([y_train, gen_y])

        clf = train_classifier(X_aug, y_aug, channels, input_length, num_classes)
        pred = predict(clf, X_test)
        acc = float(accuracy_score(y_test, pred))
        kappa = float(cohen_kappa_score(y_test, pred))
        results.append({'acc': acc, 'kappa': kappa})
        print(f'  Acc: {acc*100:.2f}%, Kappa: {kappa:.4f}')

    if not results:
        return SKIP_VAL
    accs = [r['acc'] for r in results]
    kappas = [r['kappa'] for r in results]
    print(f'\n平均: {np.mean(accs)*100:.2f}% ± {np.std(accs)*100:.2f}%, Kappa: {np.mean(kappas):.4f}')
    return {'mean': float(np.mean(accs)), 'std': float(np.std(accs)),
            'per_subject': accs, 'mean_kappa': float(np.mean(kappas)),
            'std_kappa': float(np.std(kappas)), 'per_subject_kappa': kappas}


def cross_subject_test(model, cond_embed, X, y, subjects, sessions, num_classes, mode='loso'):
    print('\n' + '=' * 70)
    print(f'3. Cross-Subject (SB-LDM, 单分类器, {mode.upper()})')
    print('   无 AdaIN, 无 MMD DA')
    print('=' * 70)

    results = []
    unique_subjects = np.unique(subjects)
    n_subjects = len(unique_subjects)
    channels, input_length = X.shape[1], X.shape[2]

    if mode == 'lmso_10fold':
        rng = np.random.RandomState(42)
        shuffled = rng.permutation(unique_subjects).tolist()
        n_folds = 10
        fs = n_subjects // n_folds
        rem = n_subjects % n_folds
        folds, start = [], 0
        for i in range(n_folds):
            sz = fs + (1 if i < rem else 0)
            folds.append(shuffled[start:start+sz])
            start += sz
        print(f'  LMSO 10-Fold: {n_subjects} 被试')
        iter_list = enumerate(folds)
    else:
        iter_list = enumerate(unique_subjects)

    for fold_idx, test_group in iter_list:
        if mode == 'lmso_10fold':
            test_subjects = test_group
            train_subjects = [s for s in unique_subjects if s not in test_subjects]
            print(f'\nFold {fold_idx+1}/10 (test:{len(test_subjects)}, train:{len(train_subjects)})')
            train_mask = np.isin(subjects, train_subjects)
            test_mask = np.isin(subjects, test_subjects)
        else:
            test_subj = test_group
            print(f'\n被试 {test_subj+1}/{n_subjects}:')
            train_mask = subjects != test_subj
            test_mask = subjects == test_subj

        X_train, y_train = X[train_mask], y[train_mask]
        X_test, y_test = X[test_mask], y[test_mask]
        if len(X_train) == 0 or len(X_test) == 0:
            continue

        spc = max(1, int(GEN_RATIO * len(X_train)) // num_classes)
        set_seed()
        subj_for_gen = None
        if getattr(model, 'num_subjects', 0) > 0:
            subj_for_gen = int(test_subjects[0]) if mode == 'lmso_10fold' else int(test_subj)
        gen_X, gen_y = generate_sb_ldm(model, cond_embed, spc, num_classes, subj_for_gen)
        gen_X = normalize_to_real_stats(X_train, gen_X)

        X_aug = np.concatenate([X_train, gen_X])
        y_aug = np.concatenate([y_train, gen_y])

        clf = train_classifier(X_aug, y_aug, channels, input_length, num_classes)
        pred = predict(clf, X_test)
        acc = float(accuracy_score(y_test, pred))
        kappa = float(cohen_kappa_score(y_test, pred))
        results.append({'acc': acc, 'kappa': kappa})
        print(f'  Acc: {acc*100:.2f}%, Kappa: {kappa:.4f}')

    if not results:
        return SKIP_VAL
    accs = [r['acc'] for r in results]
    kappas = [r['kappa'] for r in results]
    print(f'\n平均: {np.mean(accs)*100:.2f}% ± {np.std(accs)*100:.2f}%, Kappa: {np.mean(kappas):.4f}')
    return {'mean': float(np.mean(accs)), 'std': float(np.std(accs)),
            'per_subject': accs, 'mean_kappa': float(np.mean(kappas)),
            'std_kappa': float(np.std(kappas)), 'per_subject_kappa': kappas}


def print_paper_table(results, dataset):
    print('\n' + '=' * 70)
    print(f'SB-LDM 论文表格 - {dataset.upper()}')
    print('=' * 70)
    print(f"\n{'场景':<20} {'Acc (%)':<20} {'Kappa':<20}")
    print('-' * 60)
    for name, key in [('Within-Subject', 'within_subject'),
                       ('Cross-Session', 'cross_session'),
                       ('Cross-Subject', 'cross_subject')]:
        r = results.get(key, SKIP_VAL)
        if r.get('skipped'):
            print(f"{name:<20} {'跳过':<20}")
        else:
            print(f"{name:<20} {r['mean']*100:.2f} ± {r['std']*100:.2f}   {r['mean_kappa']:.4f} ± {r['std_kappa']:.4f}")


def run_dataset(dataset, scenario_filter='all'):
    print('\n' + '#' * 70)
    print(f'# SB-LDM 评估: {dataset.upper()}')
    print('#' * 70)

    cfg = DATASET_CONFIG[dataset]
    X, y, subjects, sessions = load_dataset_data(dataset)
    model, cond_embed = load_sb_ldm(dataset)

    results = {}

    if scenario_filter in ('all', 'within') and not cfg['skip_within']:
        results['within_subject'] = within_subject_test(model, cond_embed, X, y, subjects, cfg['num_classes'])
    else:
        results['within_subject'] = SKIP_VAL

    if scenario_filter in ('all', 'cross_session') and not cfg['skip_cross_session']:
        results['cross_session'] = cross_session_test(model, cond_embed, X, y, subjects, sessions, cfg['num_classes'])
    else:
        results['cross_session'] = SKIP_VAL

    if scenario_filter in ('all', 'cross_subject'):
        results['cross_subject'] = cross_subject_test(
            model, cond_embed, X, y, subjects, sessions, cfg['num_classes'],
            mode=cfg['cross_subject_mode'])
    else:
        results['cross_subject'] = SKIP_VAL

    print_paper_table(results, dataset)

    output_dir = PROJECT_ROOT / 'outputs' / 'results'
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / f'sb_ldm_{dataset}_3scenarios.json'
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f'\n结果: {output_path}')
    return results


def main():
    parser = argparse.ArgumentParser(description='SB-LDM 三场景评估 (简化版)')
    parser.add_argument('--dataset', type=str, default='bci2a',
                        choices=['bci2a', 'bci2b', 'physionet', 'all'])
    parser.add_argument('--scenario', type=str, default='all',
                        choices=['all', 'within', 'cross_session', 'cross_subject'])
    args = parser.parse_args()

    set_seed()

    if args.dataset == 'all':
        all_results = {}
        for ds in ['bci2a', 'bci2b', 'physionet']:
            all_results[ds] = run_dataset(ds, args.scenario)

        print('\n' + '#' * 70)
        print('# 汇总')
        print('#' * 70)
        print(f"\n{'数据集':<15} {'Within':<20} {'Cross-Sess':<20} {'Cross-Subj':<20}")
        print('-' * 75)
        for ds in ['bci2a', 'bci2b', 'physionet']:
            r = all_results[ds]
            parts = []
            for key in ['within_subject', 'cross_session', 'cross_subject']:
                v = r.get(key, SKIP_VAL)
                parts.append('---' if v.get('skipped') else f"{v['mean']*100:.2f}%")
            print(f"{ds:<15} {parts[0]:<20} {parts[1]:<20} {parts[2]:<20}")
    else:
        run_dataset(args.dataset, args.scenario)


if __name__ == '__main__':
    main()
