#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
路线1 验证: 风格空间 <-> 被试通道协方差几何 的相关性
===============================================================
假设 (生成式风格通路 ≈ 可学习版几何对齐 EA):
  若 subj_embed 学到的"风格"本质是被试通道协方差结构 R_s,
  则风格空间的被试间距离结构应与 R_s 的几何结构 (log-Euclid) 强相关.

表示 (每被试一行, n=9):
  风格侧:
    W_subj : P2 subj_embed 学习的被试嵌入 (9 x 32)
    s_bar  : P4 StyleEncoder 在该被试 trial 上的 mu_s 均值 (9 x 32)
  协方差侧 (EA 的对齐对象, 与模型同口径的全局 z-norm 数据上计算):
    R_s    = mean_i x_i x_i^T / T  (22 x 22)
    logm 特征: logm(R_s) 上三角展开 (253 维); 对角 log 方差 (22 维)
    距离: log-Euclid  d(a,b) = ||logm(R_a) - logm(R_b)||_F

检验 (n=9 高维小样本 → 主证据 Mantel, 辅证正则 CCA):
  [A] Mantel 检验 (主证据, 10000 次置换):
      风格 9x9 距离阵 vs 协方差 9x9 距离阵, off-diag (36 对)
      Pearson r + Spearman rho + 双侧置换 p
      附加跨 session 版: 风格用 session1 trial 估计, 协方差用 session0
      (排除"共享 trial"假象; StyleEncoder 训练只见 session0)
  [B] 正则 CCA (辅证, ridge + 1000 次置换):
      X = 风格 (32d), Y = logm 上三角 PCA(6)
      第一典型相关 + 置换 p (n=9 极限下仅作方向参考)

输出: outputs/results/diag_style_cov_cca.json + 控制台摘要

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/diag_style_cov_cca.py
"""
import sys
import json
import argparse
from pathlib import Path

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from core.models.latent_diffusion.model_shared import (
    SharedBackboneConfig, SharedVAEUNetLDM1D)
from style_vae import load_style_vae

import importlib.util


def _load_ev():
    spec = importlib.util.spec_from_file_location(
        'evaluate_sb_ldm_3datasets',
        str(PROJECT_ROOT / 'projects/tc_conf_ldm/scripts/SB-LDM/evaluate_sb_ldm_3datasets.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


DEVICE = torch.device('cpu')  # 诊断脚本用 CPU, 不与训练/评估抢 GPU
N_PERM_MANTEL = 10000
N_PERM_CCA = 1000
RNG = np.random.RandomState(42)


# ============================================================
# 被试协方差几何 (EA 的对齐对象)
# ============================================================

def subject_covariances(X_subj):
    """R_s = mean_i x_i x_i^T / T   (trial 不中心化, 与 EA/Riemannian 口径一致)"""
    Cs = []
    for i in range(len(X_subj)):
        x = X_subj[i]                       # (C, T)
        Cs.append(x @ x.T / x.shape[1])
    return np.mean(np.stack(Cs), axis=0)    # (C, C)


def logm_sym(R, eps=1e-10):
    """对称矩阵 logm (特征值截断防 -inf)."""
    R = (R + R.T) / 2.0
    w, V = np.linalg.eigh(R)
    w = np.clip(w, eps, None)
    return (V * np.log(w)) @ V.T


def log_euclid_dist(logm_list):
    """被试间 log-Euclid 距离阵: ||logm(R_a) - logm(R_b)||_F"""
    n = len(logm_list)
    D = np.zeros((n, n))
    for a in range(n):
        for b in range(a + 1, n):
            d = np.linalg.norm(logm_list[a] - logm_list[b])
            D[a, b] = D[b, a] = d
    return D


def euclid_dist(F):
    """普通欧氏距离阵 (用于风格表示)."""
    n = len(F)
    D = np.zeros((n, n))
    for a in range(n):
        for b in range(a + 1, n):
            d = np.linalg.norm(F[a] - F[b])
            D[a, b] = D[b, a] = d
    return D


# ============================================================
# Mantel 检验
# ============================================================

def _offdiag(D):
    n = D.shape[0]
    iu = np.triu_indices(n, k=1)
    return D[iu]


def mantel_test(D1, D2, n_perm=N_PERM_MANTEL, seed=42):
    """off-diag Pearson + Spearman 相关, 同时置换行列 (保持距离阵结构)."""
    from scipy.stats import pearsonr, spearmanr
    rng = np.random.RandomState(seed)
    v1, v2 = _offdiag(D1), _offdiag(D2)
    r_obs, _ = pearsonr(v1, v2)
    rho_obs, _ = spearmanr(v1, v2)

    n = D1.shape[0]
    r_perm = np.zeros(n_perm)
    for p in range(n_perm):
        perm = rng.permutation(n)
        r_perm[p], _ = pearsonr(_offdiag(D1[np.ix_(perm, perm)]), v2)
    p_pearson = float(np.mean(np.abs(r_perm) >= abs(r_obs) - 1e-12))

    # Spearman 置换 (复用同一组置换)
    rho_perm = np.zeros(n_perm)
    rng2 = np.random.RandomState(seed)
    for p in range(n_perm):
        perm = rng2.permutation(n)
        rho_perm[p], _ = spearmanr(_offdiag(D1[np.ix_(perm, perm)]), v2)
    p_spearman = float(np.mean(np.abs(rho_perm) >= abs(rho_obs) - 1e-12))

    return {'pearson_r': float(r_obs), 'pearson_p': p_pearson,
            'spearman_rho': float(rho_obs), 'spearman_p': p_spearman,
            'n_pairs': int(len(v1)), 'n_perm': n_perm}


# ============================================================
# 正则 CCA (ridge, 第一典型相关 + 置换检验)
# ============================================================

def ridge_cca_first_corr(X, Y, lam=0.5):
    """第一典型相关 (ridge 正则). X:(n,p) Y:(n,q) 均已中心化."""
    n = X.shape[0]
    Sxx = X.T @ X / n + lam * np.eye(X.shape[1])
    Syy = Y.T @ Y / n + lam * np.eye(Y.shape[1])
    Sxy = X.T @ Y / n
    M = np.linalg.solve(Sxx, Sxy @ np.linalg.solve(Syy, Sxy.T))
    eig = np.linalg.eigvals(M).real
    return float(np.sqrt(max(eig.max(), 0.0)))


def cca_perm_test(X, Y, lam=0.5, n_perm=N_PERM_CCA, seed=42):
    """置换检验: 打乱 Y 的行 (被试级), 对比第一典型相关."""
    rng = np.random.RandomState(seed)
    Xc = X - X.mean(0)
    r_obs = ridge_cca_first_corr(Xc, Y - Y.mean(0), lam)
    r_perm = np.zeros(n_perm)
    for p in range(n_perm):
        Yp = Y[rng.permutation(len(Y))]
        r_perm[p] = ridge_cca_first_corr(Xc, Yp - Yp.mean(0), lam)
    pval = float(np.mean(r_perm >= r_obs - 1e-12))
    return {'first_corr': r_obs, 'p': pval, 'n_perm': n_perm, 'lam': lam}


# ============================================================
# 主流程
# ============================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--p2_ckpt', type=str,
                        default='checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p2/sb_sd_ldm_p2_epoch_500.pt')
    parser.add_argument('--p4_ckpt', type=str,
                        default='checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p4/style_vae_final.pt')
    parser.add_argument('--lam', type=float, default=0.5, help='CCA ridge 正则强度')
    args = parser.parse_args()

    print('=' * 72)
    print('路线1 验证: 风格空间 <-> 被试通道协方差几何 (CCA/Mantel)')
    print('=' * 72)

    # 1) 模型 (仅取 subj_embed / StyleEncoder, 不做生成)
    ckpt = torch.load(str(PROJECT_ROOT / args.p2_ckpt), map_location=DEVICE,
                      weights_only=False)
    model_cfg = ckpt['config'].get('model', {})
    backbone = SharedBackboneConfig(
        base=int(model_cfg.get('backbone_base', 64)),
        levels=tuple(int(x) for x in model_cfg.get('backbone_levels', [1, 2, 4])),
        blocks_per_level=int(model_cfg.get('backbone_blocks_per_level', 2)),
    )
    model = SharedVAEUNetLDM1D(
        channels=22, input_length=1000,
        z_channels=int(model_cfg.get('z_channels', 64)),
        timesteps=int(model_cfg.get('timesteps', 1000)),
        t_dim=int(model_cfg.get('t_dim', 128)),
        cond_dim=int(model_cfg.get('cond_embed_dim', 64)),
        backbone=backbone,
        num_subjects=ckpt.get('num_subjects', 9),
        adv_alpha=0.0, subj_dim=ckpt.get('subj_dim', 32), disentangle=True,
    ).to(DEVICE)
    model.load_state_dict(ckpt['model_state_dict'])
    model.eval()
    W_subj = model.subj_embed.weight.detach().cpu().numpy()  # (9, 32)
    print(f'P2 subj_embed: {W_subj.shape}')

    style_enc, _, sigma0 = load_style_vae(
        PROJECT_ROOT / args.p4_ckpt, channels=22, input_length=1000,
        num_classes=4, device=DEVICE)
    print(f'P4 StyleEncoder 加载完成 (sigma0={sigma0})')

    # 2) 数据 (与模型训练同口径: 全局 per-channel z-norm)
    ev = _load_ev()
    X, y, subjects, sessions = ev.load_dataset_data('bci2a')
    subj_uniq = np.unique(subjects)
    if subj_uniq.max() != len(subj_uniq) - 1:
        remap = {s: i for i, s in enumerate(subj_uniq)}
        subjects = np.array([remap[s] for s in subjects])
    n_subj = len(np.unique(subjects))
    print(f'数据: X={X.shape}, 被试数={n_subj}, sessions={np.unique(sessions)}')

    # 3) 被试级表示
    # 协方差侧: R_s (全 trial / 仅 session0), logm 特征
    # 风格侧: s_bar (StyleEncoder, 全 trial / 仅 session0 / 仅 session1)
    logm_all, logm_s0 = [], []
    s_all, s_s0, s_s1 = [], [], []
    with torch.no_grad():
        for s in range(n_subj):
            m = subjects == s
            Xs = X[m]
            logm_all.append(logm_sym(subject_covariances(Xs)))
            m0 = m & (sessions == 0)
            logm_s0.append(logm_sym(subject_covariances(X[m0])))

            # StyleEncoder mu_s 均值 (分批, CPU)
            mus = []
            for i in range(0, len(Xs), 64):
                xb = torch.FloatTensor(Xs[i:i + 64]).to(DEVICE)
                mu_s, _ = style_enc(xb)
                mus.append(mu_s.cpu().numpy())
            s_all.append(np.concatenate(mus).mean(0))

            for sess, bucket in ((0, s_s0), (1, s_s1)):
                ms = m & (sessions == sess)
                if ms.sum() == 0:
                    bucket.append(None)
                    continue
                mus = []
                Xs_sess = X[ms]
                for i in range(0, len(Xs_sess), 64):
                    xb = torch.FloatTensor(Xs_sess[i:i + 64]).to(DEVICE)
                    mu_s, _ = style_enc(xb)
                    mus.append(mu_s.cpu().numpy())
                bucket.append(np.concatenate(mus).mean(0))

    W_subj = W_subj[:n_subj]
    s_all = np.stack(s_all)                       # (9, 32)
    s_s0 = np.stack(s_s0)
    have_s1 = all(v is not None for v in s_s1)
    if have_s1:
        s_s1 = np.stack(s_s1)

    # 4) 距离阵
    D_W = euclid_dist(W_subj)
    D_s_all = euclid_dist(s_all)
    D_s_s0 = euclid_dist(s_s0)
    D_cov_all = log_euclid_dist(logm_all)
    D_cov_s0 = log_euclid_dist(logm_s0)
    if have_s1:
        D_s_s1 = euclid_dist(s_s1)

    # 5) [A] Mantel 检验
    print('\n' + '-' * 72)
    print('[A] Mantel 检验 (风格距离阵 vs 协方差 log-Euclid 距离阵, 36 对)')
    print('-' * 72)
    mantel = {}
    tests = [
        ('W_subj vs cov(all)', D_W, D_cov_all),
        ('W_subj vs cov(s0)', D_W, D_cov_s0),
        ('s_bar(all) vs cov(all)', D_s_all, D_cov_all),
        ('s_bar(s0) vs cov(s0)', D_s_s0, D_cov_s0),
    ]
    if have_s1:
        tests.append(('s_bar(s1) vs cov(s0) [跨session]', D_s_s1, D_cov_s0))
    for name, D1, D2 in tests:
        res = mantel_test(D1, D2)
        mantel[name] = res
        sig = '***' if res['pearson_p'] < 0.001 else \
              '**' if res['pearson_p'] < 0.01 else \
              '*' if res['pearson_p'] < 0.05 else 'n.s.'
        print(f"  {name:34s} r={res['pearson_r']:+.3f} (p={res['pearson_p']:.4f}) "
              f"rho={res['spearman_rho']:+.3f} (p={res['spearman_p']:.4f}) {sig}")

    # 附加: 两个风格表示之间的一致性 (风格空间自洽)
    res_ww = mantel_test(D_W, D_s_all)
    mantel['W_subj vs s_bar(all) [风格自洽]'] = res_ww
    print(f"  {'W_subj vs s_bar(all) [风格自洽]':34s} r={res_ww['pearson_r']:+.3f} "
          f"(p={res_ww['pearson_p']:.4f}) rho={res_ww['spearman_rho']:+.3f} "
          f"(p={res_ww['spearman_p']:.4f})")

    # 6) [B] 正则 CCA
    print('\n' + '-' * 72)
    print(f'[B] 正则 CCA (ridge lam={args.lam}, 风格 32d vs logm上三角 PCA(6), 置换检验)')
    print('-' * 72)

    def pca_feats(logm_list, k=6):
        F = np.stack([m[np.triu_indices(22)] for m in logm_list])  # (9, 253)
        Fc = F - F.mean(0)
        U, S, Vt = np.linalg.svd(Fc, full_matrices=False)
        return Fc @ Vt[:k].T                                        # (9, k)

    cca = {}
    for name, Fx in [('W_subj', W_subj), ('s_bar(all)', s_all)]:
        Yp = pca_feats(logm_all)
        res = cca_perm_test(Fx, Yp, lam=args.lam)
        cca[name] = res
        sig = '***' if res['p'] < 0.001 else '**' if res['p'] < 0.01 else \
              '*' if res['p'] < 0.05 else 'n.s.'
        print(f"  {name:12s} 第一典型相关 r={res['first_corr']:.3f} "
              f"(置换 p={res['p']:.4f}) {sig}  [n=9, 仅方向参考]")

    # 7) 汇总
    print('\n' + '=' * 72)
    primary = mantel['s_bar(all) vs cov(all)']
    verdict_holds = (primary['pearson_p'] < 0.05) or (primary['spearman_p'] < 0.05)
    print(f"主检验 s_bar vs cov: r={primary['pearson_r']:+.3f} "
          f"(p={primary['pearson_p']:.4f}) -> "
          f"{'假设成立: 风格空间几何与协方差几何相关' if verdict_holds else '假设未成立'}")
    print('=' * 72)

    out = PROJECT_ROOT / 'outputs/results/diag_style_cov_cca.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, 'w', encoding='utf-8') as f:
        json.dump({
            'hypothesis': 'style space geometry ~ subject channel-covariance geometry (EA)',
            'n_subjects': int(n_subj),
            'mantel': mantel,
            'cca': cca,
            'W_subj_pairwise_dist': D_W.tolist(),
            'cov_log_euclid_dist': D_cov_all.tolist(),
        }, f, indent=2, ensure_ascii=False)
    print(f'结果已保存: {out}')


if __name__ == '__main__':
    main()
