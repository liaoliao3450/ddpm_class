#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
期刊补充图: 多方法 UMAP 对比 (与前作 ERD-DDPM / SB-LDM 会议版同风格)
================================================================
布局/特征/字号与 SB-LDM/SB_generate_quality_figures.py 逐字对齐:
  - EEGClassifier 特征, 联合 PCA(50)+UMAP
  - Panel 0 = Real Only; 后续面板 = Real(淡o) + Method(x)
  - figsize (28,14), 标题 20 bold, 轴标签 18, 刻度 15, 图例 14, DPI 200

面板: Real, Gaussian Noise, CVAE, WaveGAN, Cond-DDPM, BrainDiff,
      EEGDiffuser, DiffEEGBooth, SSD-LDM (Ours)  → 共 9 面板

SSD-LDM 样本: L1+L2+L3 融合生成 (与论文主方法一致), 在 ev 空间生成后
线性变换回会议版全局 z-score 空间 (两空间均为同一 X.npy 的线性标准化,
可精确互转), 不做 normalize_to_real 后处理 (L3 已完成幅度校准).

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/fig_umap_methods.py
"""
import sys
import importlib.util
from pathlib import Path

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

# ---- 复用会议版脚本的全部管线 ----
# (先插 baselines 与根路径, 会议脚本自身的 PROJECT_ROOT 少一级, 需兜底)
for _p in (str(PROJECT_ROOT / 'core' / 'models' / 'baselines'),
           str(PROJECT_ROOT / 'core' / 'models' / 'ddpm'),
           str(PROJECT_ROOT)):
    if _p not in sys.path:
        sys.path.insert(0, _p)
_CONF = PROJECT_ROOT / 'projects' / 'tc_conf_ldm' / 'scripts' / 'SB-LDM' / 'SB_generate_quality_figures.py'
_spec = importlib.util.spec_from_file_location('sb_gen_quality', str(_CONF))
conf = importlib.util.module_from_spec(_spec)
sys.modules['sb_gen_quality'] = conf
_spec.loader.exec_module(conf)
# 会议脚本 PROJECT_ROOT 少一级, 覆写为正确根目录 (checkpoint/数据路径均依赖它)
conf.PROJECT_ROOT = PROJECT_ROOT
conf.BASELINE_CKPT_DIR = PROJECT_ROOT / 'checkpoints' / 'baselines'

from style_vae import load_style_vae
from style_vae_cov import load_p5
from evaluate_p4_cross_subject import load_p2_model, set_seed, DEVICE
from evaluate_p5_cross_subject import generate_p5
from fig_quality import _gen_ours  # L1+L2+L3 融合生成端

NUM_CLASSES = 4
N_PER_CLASS = 200
N_FEWSHOT = 40
FIGDIR = PROJECT_ROOT / 'outputs/figures'
FIGDIR.mkdir(parents=True, exist_ok=True)


def load_ev_space_and_stats():
    """ev 管线数据 (逐通道 z-score, 全部会话) + 逆变换统计量.

    返回:
      X_ev, y_ev: ev 空间数据 (与 ev.load_dataset_data('bci2a') 完全一致)
      mu_c, sd_c: 逐通道均值/标准差 (22,1), x_np = x_ev*sd_c + mu_c
      m_g, s_g:   会议空间全局标量统计 (作用于 x_np*1e6)
    """
    d = PROJECT_ROOT / 'data' / 'processed' / 'BCI2a'
    X_np = np.load(str(d / 'X.npy')).astype(np.float32)
    y_np = np.load(str(d / 'y.npy')).astype(np.int64)

    # ---- ev 空间 (逐通道) ----
    y_ev = y_np - y_np.min()
    mask = y_ev < NUM_CLASSES
    X_m, y_m = X_np[mask], y_ev[mask]
    mu_c = X_m.mean(axis=(0, 2), keepdims=True)
    sd_c = X_m.std(axis=(0, 2), keepdims=True)
    X_ev = ((X_m - mu_c) / (sd_c + 1e-8)).astype(np.float32)

    # 被试/会话标识 (与 utils.data_loader.load_bci2a_data 同构: 9被试×2会话)
    n_total = len(X_ev)
    tps = n_total // 18
    subj = np.array([s for s in range(9) for _ in range(2 * tps)][:n_total])
    sess = np.array([se for _ in range(9) for se in range(2)
                     for _ in range(tps)][:n_total])

    # ---- 会议空间全局统计 (session 0) ----
    m0 = (sess == 0) & (y_m < NUM_CLASSES)
    Xc0 = X_m[m0] * 1e6
    m_g = float(Xc0.mean())
    s_g = float(Xc0.std())

    return X_ev, y_m, subj, sess, mu_c, sd_c, m_g, s_g


def ev_to_conf(X_ev_gen, mu_c, sd_c, m_g, s_g):
    """ev 空间生成样本 → 会议全局 z-score 空间."""
    x_np = X_ev_gen * (sd_c + 1e-8) + mu_c          # -> X.npy 原值
    return ((x_np * 1e6 - m_g) / s_g).astype(np.float32)


def main():
    set_seed()

    # ============ 1. 会议管线: 数据 + 分类器 ============
    print('[1] 加载真实数据 (会议协议: 9被试 session 0, 全局 z-score)...')
    X_real, y_real = conf.load_real_data_global_norm()

    print('[2] Stage 1: 训练 EEGClassifier (100 epochs)...')
    classifier = conf.load_or_train_classifier(
        X_real, y_real, channels=22, n_samples=1000, num_classes=4, epochs=100)

    # ============ 2. 各方法样本生成 (会议管线原样 + Cond-DDPM) ============
    print('[3] 生成各方法样本...')
    method_dict = {}

    print('  [1/8] Gaussian Noise...')
    gX, gy = conf.gaussian_noise_augment(X_real, y_real, N_PER_CLASS, 4)
    method_dict['Gaussian Noise'] = (np.clip(gX.astype(np.float32), -5.0, 5.0), gy)

    # 期刊版新增: Cond-DDPM 插在 WaveGAN 之后 (与论文质量表顺序一致)
    key_map = list(conf.BASELINE_KEY_MAP.items())
    for idx, (key, name) in enumerate(key_map):
        if name == 'WaveGAN':
            key_map.insert(idx + 1, ('cond_ddpm', 'Cond-DDPM'))
            break

    for i, (key, name) in enumerate(key_map, start=2):
        print(f'  [{i}/8] {name}...')
        if key == 'cond_ddpm':
            # 会议脚本 load_baseline_model 不识别 cond_ddpm, 单独加载
            from comparison_models import CondDDPM
            ckpt = torch.load(str(conf.BASELINE_CKPT_DIR / 'cond_ddpm_bci2a.pt'),
                              map_location='cuda' if torch.cuda.is_available() else 'cpu',
                              weights_only=False)
            bl = CondDDPM(channels=22, n_samples=1000, num_classes=4)
            bl.load_state_dict(ckpt['model_state_dict'])
            bl = bl.to(conf.DEVICE).eval()
        else:
            bl = conf.load_baseline_model(key, channels=22, n_samples=1000,
                                          fs=250, num_classes=4)
        if bl is not None:
            if key == 'cond_ddpm':
                # CondDDPM.sample_ddim 与其余 diffusion baseline 同签名
                gen_X, gen_y = [], []
                for c in range(4):
                    remaining = N_PER_CLASS
                    while remaining > 0:
                        batch = min(16, remaining)
                        y_c = torch.full((batch,), c, dtype=torch.long,
                                         device=conf.DEVICE)
                        with torch.no_grad():
                            samples = bl.sample_ddim(batch, y_c, steps=50,
                                                     device=conf.DEVICE)
                        gen_X.append(samples.cpu().numpy())
                        gen_y.extend([c] * batch)
                        remaining -= batch
                gX = np.concatenate(gen_X, axis=0)
                gy = np.array(gen_y, dtype=np.int64)
            else:
                gX, gy = conf.generate_baseline_samples(bl, key, n_per_class=N_PER_CLASS,
                                                        num_classes=4)
            method_dict[name] = (np.clip(gX.astype(np.float32), -5.0, 5.0), gy)
            del bl
            torch.cuda.empty_cache()
        else:
            print(f'    跳过 {name} (无 checkpoint)')

    # ============ 3. SSD-LDM (Ours): ev 空间融合生成 → 会议空间 ============
    print('  [8/8] SSD-LDM (Ours, L1+L2+L3 fused)...')
    X_ev, y_ev, subj, sess, mu_c, sd_c, m_g, s_g = load_ev_space_and_stats()
    X_few = X_ev[sess == 0][:N_FEWSHOT]      # 目标域 = 会议图真实分布 (session 0 池)
    X_pool, y_pool = X_ev, y_ev              # 期刊协议训练池 (全部会话)

    model, cond_embed = load_p2_model(
        PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p2/sb_sd_ldm_p2_epoch_500.pt')
    style_enc, _, _ = load_style_vae(
        PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p4/style_vae_final.pt',
        channels=22, input_length=1000, num_classes=4, device=DEVICE)
    chart, covemb, sigma0_p5 = load_p5(
        PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p5/cov_chart_final.pt',
        device=DEVICE)

    from core.classifiers.eegnet import EEGNet
    teacher = EEGNet(n_channels=22, n_samples=1000, n_classes=4).to(DEVICE)
    state = torch.load(str(
        PROJECT_ROOT / 'checkpoints/tc_conf_ldm/bci2a_shared_margin/pretrained_teacher_eegnet.pt'),
        map_location=DEVICE, weights_only=False)
    if isinstance(state, dict) and 'model_state_dict' in state:
        state = state['model_state_dict']
    teacher.load_state_dict(state, strict=False)
    teacher.eval()
    with torch.no_grad():
        y_pl = teacher(torch.FloatTensor(X_few).unsqueeze(1).to(DEVICE)).argmax(1).cpu().numpy()

    set_seed()
    gX_ev, gy_ours = _gen_ours(model, cond_embed, style_enc, chart, covemb,
                               sigma0_p5, X_few, y_pl, X_pool, y_pool, N_PER_CLASS)
    del model, cond_embed, style_enc, chart, covemb
    torch.cuda.empty_cache()
    gX_conf = np.clip(ev_to_conf(gX_ev, mu_c, sd_c, m_g, s_g), -5.0, 5.0)
    method_dict['SSD-LDM (Ours)'] = (gX_conf, gy_ours)

    print(f'  共 {len(method_dict)} 个方法: {list(method_dict.keys())}')

    # ============ 4. 微调分类器 + UMAP ============
    print('[4] Stage 2: 微调 EEGClassifier (30 epochs)...')
    names = list(method_dict.keys())
    classifier = conf.finetune_classifier(
        classifier, X_real, y_real,
        [method_dict[n][0] for n in names],
        [method_dict[n][1] for n in names],
        epochs=30, method_names=names)

    print('[5] 绘制多方法 UMAP...')
    out = FIGDIR / 'fig_umap_methods_bci2a.pdf'
    conf.plot_umap_multi(X_real, y_real, method_dict, classifier, str(out))
    print(f'\n完成 -> {out}')


if __name__ == '__main__':
    main()
