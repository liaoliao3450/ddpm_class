#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SB-SD-LDM P5 v3 训练: 协方差图表 CovChart (生成式 EA)
===============================================================
前置: P2 checkpoint (冻结) — 只用其 decode / subj_head / mu_z 缓存

可训练: 仅 CovChart g (cov_embed -> 风格空间 映射图)

初始化 (关键, v1/v2 失败的教训):
  A_ls = argmin ||[cov,1]@A - W_subj||^2 (增广最小二乘)
  => g 初始精确过 9 个锚点 (cov_t -> e_t), 全部 decoder 分布内
  => L_cov 从"锚点渲染"出发精修, 而不是从分布外垃圾出发

损失:
  L_reg = ||g(cov_t) - e_t||^2 / ||e_t||^2      锚点图表 (相对误差)
  L_cov = ||R_gen - R_t||_F^2 / ||R_t||_F^2     协方差匹配 (生成式 EA)
    R_gen = batch 协方差 of decode(mu_z_batch, g(cov_t + jitter))
    内容 mu_z 混合 (P2 已被试不变) -> R_gen 只由 cov 条件决定

验收门:
  G1 协方差可控 ratio = d_wrong / d_correct > 1.5
    (固定 z, decode(z, g(cov_t)) 的批协方差跟踪条件 R_t)
  D2 subj_head 判回: decode(z, g(cov_t)) 判为被试 t (图表渲染正确被试)

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/train_sb_sd_ldm_p5.py --dataset bci2a
"""
import sys
import json
import argparse
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from train_sb_sd_ldm import DATASET_CONFIG
from train_sb_sd_ldm_p4 import load_p2_frozen, cache_mu_z
from style_vae_cov import (
    CovEmbedding, CovChart, compute_subject_R, save_p5, subject_covariances)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


@torch.no_grad()
def chart_diagnostics(model, cond_embed, chart, cov_lookup, W_subj,
                      mu_z_fixed, y_fixed, R_true_list):
    """G1 协方差可控 + D2 图表渲染判回 (固定内容 z, 遍历条件 cov)."""
    model.eval()
    chart.eval()
    S = cov_lookup.size(0)
    n = mu_z_fixed.size(0)
    cond = cond_embed(y_fixed)

    gen_R, subj_correct = [], 0
    for t in range(S):
        cov = cov_lookup[t].unsqueeze(0).expand(n, -1)
        s = chart(cov)
        x = model.decode(mu_z_fixed, target_length=model.input_length,
                         cond=cond, style_vec=s)
        gen_R.append(subject_covariances(x.cpu().numpy()))
        subj_correct += int((model.subj_head(x).argmax(1) == t).sum().item())

    d_correct, d_wrong = [], []
    for t in range(S):
        Rt = R_true_list[t]
        d_correct.append(np.linalg.norm(gen_R[t] - Rt) / (np.linalg.norm(Rt) + 1e-8))
        for u in range(S):
            if u != t:
                Ru = R_true_list[u]
                d_wrong.append(np.linalg.norm(gen_R[t] - Ru) / (np.linalg.norm(Ru) + 1e-8))
    return {
        'd_correct': float(np.mean(d_correct)),
        'd_wrong': float(np.mean(d_wrong)),
        'ratio': float(np.mean(d_wrong) / max(np.mean(d_correct), 1e-8)),
        'subj_acc': subj_correct / (S * n),
    }


def train(dataset: str, num_epochs: int = 100, batch_size: int = 64,
          lr: float = 1e-3, sigma0: float = 0.5, cov_dim: int = 8,
          lambda_reg: float = 1.0, lambda_cov: float = 1.0,
          cov_jitter_frac: float = 0.3):
    cfg = DATASET_CONFIG[dataset]
    num_subjects = cfg['num_subjects']

    print('=' * 70)
    print('SB-SD-LDM P5 v3 训练: CovChart 协方差图表 (生成式 EA)')
    print(f'数据集: {dataset}, 设备: {DEVICE}, epochs={num_epochs}')
    print(f'lambda_reg={lambda_reg}, lambda_cov={lambda_cov}, '
          f'jitter={cov_jitter_frac}*trial_std')
    print('=' * 70)

    # 1) 数据
    from train_sb_sd_ldm_p4 import load_dataset as _ld
    X_train, y_train, subjects_train = _ld(dataset)
    X_t = torch.FloatTensor(X_train)
    y_t = torch.LongTensor(y_train)
    subj_t = torch.LongTensor(subjects_train)

    # 2) P2 冻结主干
    p2_path = PROJECT_ROOT / f'checkpoints/tc_conf_ldm/sb_sd_ldm_{dataset}_p2/sb_sd_ldm_p2_epoch_500.pt'
    if not p2_path.exists():
        raise FileNotFoundError(f'P2 checkpoint 不存在: {p2_path}')
    print(f'\nP2 冻结主干: {p2_path}')
    model, cond_embed, yaml_cfg = load_p2_frozen(p2_path, dataset)
    W_subj = model.subj_embed.weight.detach()          # (S, 32) 冻结锚点

    # 3) mu_z 预缓存 (内容, 已被试不变)
    print('预缓存 mu_z...')
    mu_z_cache = cache_mu_z(model, cond_embed, X_t, y_t)
    print(f'  mu_z 缓存: {tuple(mu_z_cache.shape)}')

    # 4) 协方差嵌入
    print(f'拟合 CovEmbedding (PCA k={cov_dim})...')
    R_true_list = [compute_subject_R(X_train[subjects_train == s])
                   for s in range(num_subjects)]
    covemb = CovEmbedding(k=cov_dim).fit(R_true_list)
    print(f'  PCA 前 {covemb.k} 维解释方差: {covemb.explained_ratio * 100:.1f}%')
    cov_lookup = torch.FloatTensor(
        np.stack([covemb.embed(R) for R in R_true_list])).to(DEVICE)  # (S, k)
    print(f'  cov_lookup 范数 (被试级): {cov_lookup.norm(dim=1).mean().item():.3f}')
    R_true_t = torch.FloatTensor(np.stack(R_true_list)).to(DEVICE)     # (S, C, C)

    # trial 级 jitter 尺度 (被试内协方差变异)
    trial_embeds = []
    rs = np.random.RandomState(0)
    for s in range(num_subjects):
        idx_s = np.where(subjects_train == s)[0]
        pick = rs.choice(idx_s, size=min(60, len(idx_s)), replace=False)
        for i in pick:
            trial_embeds.append(covemb.embed(compute_subject_R(X_train[i][None])))
    jitter_scale = torch.FloatTensor(np.stack(trial_embeds).std(axis=0)).to(DEVICE)
    print(f'  trial 级嵌入散布: {jitter_scale.mean().item():.4f} '
          f'(jitter std = {cov_jitter_frac}*此值)')

    # 5) CovChart (最小二乘锚点初始化)
    chart = CovChart(cov_lookup.cpu().numpy(), W_subj.cpu().numpy()).to(DEVICE)
    n_params = sum(p.numel() for p in chart.mlp.parameters())
    print(f'\nCovChart: 线性图 A (冻结) + MLP 残差 ({n_params:,} 可训练参数)')
    with torch.no_grad():
        init_err = (chart(cov_lookup) - W_subj).norm(dim=1) / W_subj.norm(dim=1)
    print(f'  初始锚点误差 (应为 ~0): {init_err.mean().item():.2e}')

    optim = torch.optim.AdamW(chart.parameters(), lr=lr, weight_decay=1e-5)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optim, T_max=num_epochs, eta_min=1e-6)

    dataset_t = TensorDataset(X_t, y_t, subj_t, mu_z_cache)
    loader = DataLoader(dataset_t, batch_size=batch_size, shuffle=True,
                        num_workers=0, drop_last=True)

    ckpt_dir = PROJECT_ROOT / f'checkpoints/tc_conf_ldm/sb_sd_ldm_{dataset}_p5'
    ckpt_dir.mkdir(parents=True, exist_ok=True)

    # 固定诊断集: 混合被试/类别的 72 个 trial 的 mu_z
    idx_fix = np.linspace(0, len(X_t) - 1, 72).astype(int)
    mu_z_fixed = mu_z_cache[idx_fix].to(DEVICE)
    y_fixed = y_t[idx_fix].to(DEVICE)

    print(f'\n开始 P5 v3 训练 ({num_epochs} epochs)...')
    print('-' * 70)

    for epoch in range(1, num_epochs + 1):
        chart.train()

        ep = {'loss': 0.0, 'reg': 0.0, 'cov': 0.0}
        n_samples = 0

        for X_batch, y_batch, subj_batch, mu_z in loader:
            y_batch = y_batch.to(DEVICE)
            mu_z = mu_z.to(DEVICE)
            B = mu_z.size(0)
            cond = cond_embed(y_batch)

            # L_reg: 全部被试锚点回归 (每步全查表)
            g_all = chart(cov_lookup)                             # (S, 32)
            loss_reg = (((g_all - W_subj) ** 2).sum(1)
                        / ((W_subj ** 2).sum(1) + 1e-8)).mean()

            # L_cov: 随机被试 t, 整 batch 同条件解码 -> 批协方差匹配
            t_idx = int(torch.randint(0, num_subjects, (1,)).item())
            cov_t = cov_lookup[t_idx].unsqueeze(0).expand(B, -1)
            cov_t = cov_t + cov_jitter_frac * jitter_scale.unsqueeze(0) \
                * torch.randn_like(cov_t)
            s_cov = chart(cov_t)
            x_cov = model.decode(mu_z, target_length=model.input_length,
                                 cond=cond, style_vec=s_cov)
            R_gen = torch.einsum('bct,bet->ce', x_cov, x_cov) \
                / (x_cov.shape[0] * x_cov.shape[-1])   # 除以 B*T (batch 均值!)
            R_t = R_true_t[t_idx]
            loss_cov = ((R_gen - R_t) ** 2).sum() / ((R_t ** 2).sum() + 1e-8)

            loss = lambda_reg * loss_reg + lambda_cov * loss_cov

            optim.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(chart.parameters(), 1.0)
            optim.step()

            ep['loss'] += loss.item() * B
            ep['reg'] += loss_reg.item() * B
            ep['cov'] += loss_cov.item() * B
            n_samples += B

        scheduler.step()

        if epoch % 10 == 0 or epoch == 1:
            n = float(n_samples)
            print(f'[Ep {epoch:3d}/{num_epochs}] Loss:{ep["loss"]/n:.4f} | '
                  f'Reg:{ep["reg"]/n:.4f} | Cov:{ep["cov"]/n:.4f}')

        if epoch % 20 == 0 or epoch == num_epochs:
            d = chart_diagnostics(model, cond_embed, chart, cov_lookup,
                                  W_subj, mu_z_fixed, y_fixed, R_true_list)
            print(f'  [诊断] G1 ratio={d["ratio"]:.2f}x '
                  f'(d_correct={d["d_correct"]:.3f}, d_wrong={d["d_wrong"]:.3f}) | '
                  f'D2 图表判回={d["subj_acc"]*100:.1f}%')
            save_p5(ckpt_dir / f'cov_chart_epoch_{epoch}.pt', chart, covemb,
                    sigma0, meta={'dataset': dataset, 'epoch': epoch,
                                  'lambda_reg': lambda_reg,
                                  'lambda_cov': lambda_cov,
                                  'p2_ckpt': str(p2_path)})

    # 最终保存 + 验收
    save_p5(ckpt_dir / 'cov_chart_final.pt', chart, covemb, sigma0,
            meta={'dataset': dataset, 'epoch': num_epochs,
                  'lambda_reg': lambda_reg, 'lambda_cov': lambda_cov,
                  'p2_ckpt': str(p2_path)})
    d = chart_diagnostics(model, cond_embed, chart, cov_lookup,
                          W_subj, mu_z_fixed, y_fixed, R_true_list)
    print('\n' + '=' * 70)
    print('P5 v3 验收门:')
    print(f'  G1 协方差可控 ratio: {d["ratio"]:.2f}x '
          f'{"PASS (>1.5)" if d["ratio"] > 1.5 else "FAIL (<=1.5)"}')
    print(f'  D2 图表渲染判回: {d["subj_acc"]*100:.1f}% '
          f'{"PASS (>=80%)" if d["subj_acc"] >= 0.8 else "WARN (<80%)"}')
    print('=' * 70)

    summary = {
        'dataset': dataset,
        'model_type': 'SB-SD-LDM P5 v3 (CovChart, generative EA)',
        'num_epochs': num_epochs, 'lambda_reg': lambda_reg,
        'lambda_cov': lambda_cov, 'cov_dim': covemb.k,
        'pca_explained': covemb.explained_ratio,
        'g1_ratio': d['ratio'], 'g1_d_correct': d['d_correct'],
        'g1_d_wrong': d['d_wrong'], 'd2_subj_acc': d['subj_acc'],
        'p2_ckpt': str(p2_path),
    }
    with open(ckpt_dir / 'train_summary.json', 'w', encoding='utf-8') as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print(f'\nP5 v3 训练完成: {ckpt_dir / "cov_chart_final.pt"}')


def main():
    parser = argparse.ArgumentParser(description='SB-SD-LDM P5 v3 (CovChart)')
    parser.add_argument('--dataset', type=str, required=True,
                        choices=['bci2a', 'bci2b', 'physionet'])
    parser.add_argument('--epochs', type=int, default=100)
    parser.add_argument('--batch_size', type=int, default=64)
    parser.add_argument('--lr', type=float, default=1e-3)
    parser.add_argument('--cov_dim', type=int, default=8)
    parser.add_argument('--lambda_reg', type=float, default=1.0)
    parser.add_argument('--lambda_cov', type=float, default=1.0)
    args = parser.parse_args()

    torch.manual_seed(42)
    np.random.seed(42)

    train(args.dataset, num_epochs=args.epochs, batch_size=args.batch_size,
          lr=args.lr, cov_dim=args.cov_dim,
          lambda_reg=args.lambda_reg, lambda_cov=args.lambda_cov)


if __name__ == '__main__':
    main()
