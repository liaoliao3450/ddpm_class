#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Journal Table III 基线臂 (多数据集): Real-only / SB-LDM / EA-40
===============================================================
目的: 为 BCI2b / PhysioNet 填补 Table III 的前三行, 协议与 BCI2a 列
严格对齐:
  Real-only: 跨被试 LOSO, 仅真实源数据, EEGNet x3 集成 (200 epochs, 软投票)
  SB-LDM:   GEN_RATIO=1.0, 会议基线生成器, ev.cross_subject_test 同协议
  EA-40:    每源被试独立 EA 白化 (R_s 全 trial), 测试被试用前 40 个
            无标签 trial 估计 R_test 白化 (与 ea_baseline_loso.py 逐字对齐)

协议模式:
  bci2a / bci2b: LOSO (9 折, 每折 1 个测试被试)
  physionet:     LMSO 10-fold (与 evaluate_sb_ldm_3datasets 相同的
                 RandomState(42) 折叠; 每折 ~11 个测试被试, pooled 预测)

输出: outputs/results/journal_table3_{dataset}.json

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/journal_table3_arms.py --dataset bci2b
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/journal_table3_arms.py --dataset physionet --arms real_only,ea_40
"""
import sys
import json
import argparse
from pathlib import Path

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from ea_baseline_loso import ea_transform, subject_Rs

import importlib.util

SEED = 42
N_FEWSHOT = 40
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

DS_CONFIG = {
    'bci2a': {
        'num_classes': 4, 'mode': 'loso',
        'sb_ldm_ckpt': 'checkpoints/tc_conf_ldm/sb_ldm_bci2a_fix/sb_ldm_epoch_500.pt',
    },
    'bci2b': {
        'num_classes': 2, 'mode': 'loso',
        'sb_ldm_ckpt': 'checkpoints/tc_conf_ldm/sb_ldm_bci2b/sb_ldm_epoch_500.pt',
    },
    'physionet': {
        'num_classes': 4, 'mode': 'lmso_10fold',
        'sb_ldm_ckpt': 'checkpoints/tc_conf_ldm/sb_ldm_physionet/sb_ldm_epoch_500.pt',
    },
}


def _load_ev():
    spec = importlib.util.spec_from_file_location(
        'evaluate_sb_ldm_3datasets',
        str(PROJECT_ROOT / 'projects/tc_conf_ldm/scripts/SB-LDM/evaluate_sb_ldm_3datasets.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def make_folds(subjects, mode):
    """LOSO: 每被试一折; lmso_10fold: 与 ev.cross_subject_test 完全一致的折叠."""
    uniq = np.unique(subjects)
    if mode == 'loso':
        return [[int(s)] for s in uniq]
    rng = np.random.RandomState(42)
    shuffled = rng.permutation(uniq).tolist()
    n_folds = 10
    fs = len(shuffled) // n_folds
    rem = len(shuffled) % n_folds
    folds, start = [], 0
    for i in range(n_folds):
        sz = fs + (1 if i < rem else 0)
        folds.append([int(s) for s in shuffled[start:start + sz]])
        start += sz
    return folds


def _agg(results):
    accs = [r['acc'] for r in results]
    kappas = [r['kappa'] for r in results]
    return {'mean': float(np.mean(accs)), 'std': float(np.std(accs)),
            'per_subject': accs, 'mean_kappa': float(np.mean(kappas)),
            'std_kappa': float(np.std(kappas)), 'per_subject_kappa': kappas}


def arm_real_only(ev, X, y, subjects, num_classes, folds):
    """真实源数据 only, 无 EA, 无生成."""
    from sklearn.metrics import accuracy_score, cohen_kappa_score
    channels, input_length = X.shape[1], X.shape[2]
    results = []
    for fold_idx, test_group in enumerate(folds):
        train_mask = ~np.isin(subjects, test_group)
        test_mask = np.isin(subjects, test_group)
        X_tr, y_tr = X[train_mask], y[train_mask]
        X_te, y_te = X[test_mask], y[test_mask]
        np.random.seed(SEED)
        ev.set_seed()
        clf = ev.train_classifier(X_tr, y_tr, channels, input_length, num_classes)
        pred = ev.predict(clf, X_te)
        acc = float(accuracy_score(y_te, pred))
        kappa = float(cohen_kappa_score(y_te, pred))
        results.append({'acc': acc, 'kappa': kappa,
                        'test_subjects': test_group})
        print(f'  折 {fold_idx + 1}/{len(folds)} (测试被试 {test_group}): '
              f'Acc {acc * 100:.2f}%, Kappa {kappa:.4f}')
    return _agg(results)


def arm_ea40(ev, X, y, subjects, num_classes, folds, n_fewshot=N_FEWSHOT):
    """每源被试独立 EA (R_s 全 trial) + 测试被试 R_test (前 n_fewshot 无标签 trial)."""
    from sklearn.metrics import accuracy_score, cohen_kappa_score
    channels, input_length = X.shape[1], X.shape[2]
    results = []
    for fold_idx, test_group in enumerate(folds):
        # 源被试: 各自 EA 白化
        X_tr_parts, y_tr_parts = [], []
        for s in np.unique(subjects):
            if s in test_group:
                continue
            m = subjects == s
            X_tr_parts.append(ea_transform(X[m], subject_Rs(X[m])))
            y_tr_parts.append(y[m])
        X_tr = np.concatenate(X_tr_parts)
        y_tr = np.concatenate(y_tr_parts)

        # 测试被试: 各自用前 n_fewshot trial 估计 R_test 白化
        X_te_parts, y_te_parts = [], []
        per_subj = {}
        for s in test_group:
            m = subjects == s
            Xs, ys = X[m], y[m]
            n_use = min(n_fewshot, len(Xs))
            R_est = subject_Rs(Xs[:n_use])
            Xw = ea_transform(Xs, R_est)
            X_te_parts.append(Xw)
            y_te_parts.append(ys)
        X_te = np.concatenate(X_te_parts)
        y_te = np.concatenate(y_te_parts)

        np.random.seed(SEED)
        ev.set_seed()
        clf = ev.train_classifier(X_tr, y_tr, channels, input_length, num_classes)
        pred = ev.predict(clf, X_te)
        acc = float(accuracy_score(y_te, pred))
        kappa = float(cohen_kappa_score(y_te, pred))
        # 每个测试被试单独的 acc (诊断用)
        ofs = 0
        for s in test_group:
            m = subjects == s
            n_s = int(m.sum())
            per_subj[int(s)] = float(np.mean(pred[ofs:ofs + n_s] == y_te[ofs:ofs + n_s]))
            ofs += n_s
        results.append({'acc': acc, 'kappa': kappa, 'test_subjects': test_group,
                        'per_test_subject_acc': per_subj})
        print(f'  折 {fold_idx + 1}/{len(folds)} (测试被试 {test_group}): '
              f'Acc {acc * 100:.2f}%, Kappa {kappa:.4f}')
    res = _agg(results)
    res['per_test_subject_acc'] = {str(k): v for r in results
                                   for k, v in r['per_test_subject_acc'].items()}
    return res


def arm_sbldm(ev, dataset, X, y, subjects, sessions, num_classes, mode):
    """SB-LDM (会议基线): GEN_RATIO=1.0, ev.cross_subject_test 原协议."""
    ev.DATASET_CONFIG[dataset]['checkpoint'] = DS_CONFIG[dataset]['sb_ldm_ckpt']
    model, cond_embed = ev.load_sb_ldm(dataset, DEVICE)
    ev.GEN_RATIO = 1.0
    ev.N_ENSEMBLE = 3
    return ev.cross_subject_test(model, cond_embed, X, y, subjects,
                                 sessions, num_classes, mode)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', type=str, default='bci2b',
                        choices=['bci2a', 'bci2b', 'physionet'])
    parser.add_argument('--arms', type=str, default='real_only,sb_ldm,ea_40',
                        help='逗号分隔: real_only,sb_ldm,ea_40')
    parser.add_argument('--n_fewshot', type=int, default=N_FEWSHOT)
    args = parser.parse_args()

    cfg = DS_CONFIG[args.dataset]
    num_classes = cfg['num_classes']
    mode = cfg['mode']
    arms = [a.strip() for a in args.arms.split(',') if a.strip()]

    print('=' * 72)
    print(f'Journal Table III 基线臂: dataset={args.dataset}, mode={mode}, '
          f'arms={arms}, N_fewshot={args.n_fewshot}')
    print('=' * 72)

    ev = _load_ev()
    ev.GEN_RATIO = 1.0
    ev.N_ENSEMBLE = 3
    X, y, subjects, sessions = ev.load_dataset_data(args.dataset)
    subj_uniq = np.unique(subjects)
    if subj_uniq.max() != len(subj_uniq) - 1:
        remap = {s: i for i, s in enumerate(subj_uniq)}
        subjects = np.array([remap[s] for s in subjects])
    folds = make_folds(subjects, mode)
    print(f'  数据: {X.shape}, 被试 {len(np.unique(subjects))}, 折数 {len(folds)}')

    results = {'dataset': args.dataset, 'mode': mode,
               'n_fewshot': args.n_fewshot, 'protocol': 'journal Table III arms'}

    if 'real_only' in arms:
        print('\n[1] Real-only (无增强锚点)')
        results['real_only'] = arm_real_only(ev, X, y, subjects, num_classes, folds)
        r = results['real_only']
        print(f'>>> Real-only: {r["mean"] * 100:.2f}% ± {r["std"] * 100:.2f}% '
              f'(Kappa {r["mean_kappa"]:.4f})')

    if 'sb_ldm' in arms:
        print('\n[2] SB-LDM (会议基线, GEN_RATIO=1.0)')
        results['sb_ldm'] = arm_sbldm(ev, args.dataset, X, y, subjects,
                                      sessions, num_classes, mode)
        r = results['sb_ldm']
        print(f'>>> SB-LDM: {r["mean"] * 100:.2f}% ± {r["std"] * 100:.2f}% '
              f'(Kappa {r["mean_kappa"]:.4f})')

    if 'ea_40' in arms:
        print(f'\n[3] EA-40 (测试被试 R_test 用前 {args.n_fewshot} 个无标签 trial)')
        results['ea_40'] = arm_ea40(ev, X, y, subjects, num_classes, folds,
                                    args.n_fewshot)
        r = results['ea_40']
        print(f'>>> EA-40: {r["mean"] * 100:.2f}% ± {r["std"] * 100:.2f}% '
              f'(Kappa {r["mean_kappa"]:.4f})')

    out = PROJECT_ROOT / f'outputs/results/journal_table3_{args.dataset}.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f'\n结果已保存: {out}')


if __name__ == '__main__':
    main()
