#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
P4 诊断: DDIM z 上的风格因果控制测试
===============================================================
问题: fewshot 快检中, 用测试被试风格 s_test 生成的样本, subj_head 风格分布
      与 dirichlet 几乎相同 ([43.5/29.5/27] vs [41/32.5/23.5]) — 未集中到
      测试被试. 但 P2 交换测试 (真实 mu_z) 显示 100% 因果控制.

判别实验: 同一批 DDIM z, 分别用 9 个被试嵌入 e_i 解码:
  - 若 subj_head 分布随 i 变化 → 风格控制在 DDIM z 上有效 (P4 机制成立)
  - 若分布恒为 0/5/7 吸引子 → DDIM z 上风格控制失效 (P4 增益另有来源)

附加诊断:
  D1 fewshot 估计精度: ||s_test_hat - e_test|| vs ||s_test_hat - e_other||
  D2 decode 输出对 style_vec 的敏感度: 同 z 不同 s 的输出 L2 距离

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/diag_p4_style_control.py
"""
import sys
import argparse
from pathlib import Path

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

import importlib.util


def _load_ev():
    spec = importlib.util.spec_from_file_location(
        'evaluate_sb_ldm_3datasets',
        str(PROJECT_ROOT / 'projects/tc_conf_ldm/scripts/SB-LDM/evaluate_sb_ldm_3datasets.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


from evaluate_p4_cross_subject import (
    load_p2_model, make_ddim_schedule, estimate_fewshot_style,
    DDIM_STEPS, GUIDANCE_SCALE, N_FEWSHOT)
from style_vae import load_style_vae

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def ddim_sample_z(model, cond_embed, n, num_classes=4):
    """DDIM 采样 n 个 z (类平衡)."""
    e = 1e-8
    ddim_seq = make_ddim_schedule(model.alpha_bar, DDIM_STEPS)
    with torch.no_grad():
        dummy = torch.zeros(1, model.channels, model.input_length, device=DEVICE)
        z_d, _, _ = model.encode(dummy, cond=torch.zeros(1, model.cond_dim, device=DEVICE))
        z_ch, latent_len = model.z_channels, z_d.shape[-1]

    zs = []
    with torch.no_grad():
        for c in range(num_classes):
            generated = 0
            while generated < n // num_classes:
                bs = min(32, n // num_classes - generated)
                cl = torch.full((bs,), c, dtype=torch.long, device=DEVICE)
                cond = cond_embed(cl)
                z = torch.randn(bs, z_ch, latent_len, device=DEVICE)
                for i, t_idx in enumerate(ddim_seq):
                    t = torch.full((bs,), t_idx, device=DEVICE, dtype=torch.long)
                    ec = model.denoise_eps(z, t, cond=cond)
                    if GUIDANCE_SCALE > 1.0:
                        eu = model.denoise_eps(z, t, cond=None)
                        eps_pred = torch.clamp(eu + GUIDANCE_SCALE * (ec - eu), -100, 100)
                    else:
                        eps_pred = ec
                    ab = model.alpha_bar[t_idx]
                    ab_prev = model.alpha_bar[ddim_seq[i + 1]] if i + 1 < len(ddim_seq) else model.alpha_bar[0]
                    sab = torch.sqrt(ab.clamp(min=e))
                    s1mb = torch.sqrt((1 - ab).clamp(min=e))
                    sab_prev = torch.sqrt(ab_prev.clamp(min=e))
                    s1mb_prev = torch.sqrt((1 - ab_prev).clamp(min=e))
                    pred_x0 = ((z - s1mb * eps_pred) / sab).clamp(-5, 5)
                    z = sab_prev * pred_x0 + s1mb_prev * eps_pred
                zs.append(z)
                generated += bs
    return torch.cat(zs, dim=0)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--p2_ckpt', type=str,
                        default='checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p2/sb_sd_ldm_p2_epoch_500.pt')
    parser.add_argument('--p4_ckpt', type=str,
                        default='checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p4/style_vae_final.pt')
    parser.add_argument('--n_z', type=int, default=72, help='每批 DDIM z 数')
    args = parser.parse_args()

    torch.manual_seed(42)
    np.random.seed(42)

    ev = _load_ev()
    model, cond_embed = load_p2_model(PROJECT_ROOT / args.p2_ckpt)
    style_enc, _, sigma0 = load_style_vae(
        PROJECT_ROOT / args.p4_ckpt, channels=22, input_length=1000,
        num_classes=4, device=DEVICE)

    X, y, subjects, sessions = ev.load_dataset_data('bci2a')
    subj_uniq = np.unique(subjects)
    if subj_uniq.max() != len(subj_uniq) - 1:
        remap = {s: i for i, s in enumerate(subj_uniq)}
        subjects = np.array([remap[s] for s in subjects])

    W = model.subj_embed.weight.detach()  # (9, 32)

    # ============================================================
    # [测试 1] 同一批 DDIM z + 9 个被试嵌入 -> subj_head 分布
    # ============================================================
    print('\n' + '=' * 70)
    print(f'[测试 1] 同一批 {args.n_z} 个 DDIM z, 换 9 个风格解码')
    print('=' * 70)

    z_batch = ddim_sample_z(model, cond_embed, args.n_z)
    print(f'  DDIM z 批次: {tuple(z_batch.shape)}')

    outputs = {}
    with torch.no_grad():
        for i in range(9):
            s_vec = W[i].unsqueeze(0).expand(args.n_z, -1)
            x_i = model.decode(z_batch, target_length=model.input_length,
                               cond=None, style_vec=s_vec)
            outputs[i] = x_i
            pred = model.subj_head(x_i).argmax(1).cpu().numpy()
            dist = np.bincount(pred, minlength=9) / len(pred)
            # 敏感度: 与 i=0 输出的 L2 距离
            if i > 0:
                d_out = float((x_i - outputs[0]).norm(dim=(1, 2)).mean())
            else:
                d_out = 0.0
            print(f'  s=e_{i}: 判为被试 {np.argmax(dist)} 的比例 {dist.max()*100:.0f}% | '
                  f'分布 {np.round(dist*100, 0).astype(int).tolist()} | '
                  f'||x_i - x_0||={d_out:.3f}')

    # 输出间成对距离 (不同 s 的输出差异)
    print('\n  输出敏感度矩阵 (不同 s 的平均 L2):')
    with torch.no_grad():
        cross_d, self_d = [], []
        for i in range(9):
            for j in range(9):
                if i < j:
                    cross_d.append(float((outputs[i] - outputs[j]).norm(dim=(1, 2)).mean()))
        # 同 s 但不同 z 的输出距离对照
        half = args.n_z // 2
        x_a = model.decode(z_batch[:half], target_length=model.input_length,
                           cond=None, style_vec=W[4].unsqueeze(0).expand(half, -1))
        x_b = model.decode(z_batch[half:], target_length=model.input_length,
                           cond=None, style_vec=W[4].unsqueeze(0).expand(args.n_z - half, -1))
        print(f'    换 s (同 z): 平均 L2 = {np.mean(cross_d):.4f}  (9 组)')
        print(f'    (对照) 不同 z (同 s): 输出均值差 = '
              f'{float((x_a.mean(0) - x_b.mean(0)).norm()):.4f}')

    # ============================================================
    # [测试 2] fewshot 估计精度 (每个被试)
    # ============================================================
    print('\n' + '=' * 70)
    print(f'[测试 2] fewshot 风格估计精度 (N={N_FEWSHOT} trial/被试)')
    print('=' * 70)
    print(f'  嵌入范数 ||e_i||: {np.round(W.norm(dim=1).cpu().numpy(), 2).tolist()}')

    for test_subj in range(9):
        X_few = X[subjects == test_subj][:N_FEWSHOT]
        s_hat = estimate_fewshot_style(style_enc, X_few, DEVICE).to(DEVICE)
        d_self = float((s_hat - W[test_subj]).norm())
        d_others = [float((s_hat - W[j]).norm()) for j in range(9) if j != test_subj]
        # proj: s_hat 在其他被试方向上的最近距离
        print(f'  被试 {test_subj+1}: ||s_hat - e_self||={d_self:.3f} | '
              f'min||s_hat - e_other||={min(d_others):.3f} (被试 {int(np.argmin([999 if j==test_subj else float((s_hat - W[j]).norm()) for j in range(9)]))+1}) | '
              f'{"OK" if d_self < min(d_others) else "FAIL"}')

    # ============================================================
    # [测试 3] 真实 mu_z 上的对照 (P2 交换测试口径)
    # ============================================================
    print('\n' + '=' * 70)
    print('[测试 3] 真实 mu_z 对照 (P2 交换测试口径, 用被试 1 的 trials)')
    print('=' * 70)
    X_s0 = X[subjects == 0][:72]
    y_s0 = y[subjects == 0][:72]
    with torch.no_grad():
        xb = torch.FloatTensor(X_s0).to(DEVICE)
        yb = torch.LongTensor(y_s0).to(DEVICE)
        _, mu_z, _ = model.encode(xb, cond=cond_embed(yb))
        for i in [0, 4, 8]:
            s_vec = W[i].unsqueeze(0).expand(len(X_s0), -1)
            x_i = model.decode(mu_z, target_length=model.input_length,
                               cond=cond_embed(yb), style_vec=s_vec)
            pred = model.subj_head(x_i).argmax(1).cpu().numpy()
            dist = np.bincount(pred, minlength=9) / len(pred)
            print(f'  真实 z + s=e_{i}: 判为被试 {np.argmax(dist)} 的比例 {dist.max()*100:.0f}% | '
                  f'分布 {np.round(dist*100, 0).astype(int).tolist()}')

    print('\n判读:')
    print('  测试1 分布随 i 变化 → 风格控制在 DDIM z 上有效')
    print('  测试1 分布恒为少数吸引子 → DDIM z 上风格控制失效')
    print('  测试3 若分布随 i 变化而测试1 不变 → 失效特定于 DDIM z 分布')


if __name__ == '__main__':
    main()
