#!/usr/bin/env python3
"""
统一的数据加载工具
"""
import os
import numpy as np
import sys
from pathlib import Path

# 添加项目根目录到路径
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

# 尝试从项目根目录导入 config，如果不存在则从 experiments.paper_experiments 导入
try:
    from config import DATA_PATH, DATASET_CONFIG
except ImportError:
    from experiments.paper_experiments.config import DATA_PATH, DATASET_CONFIG

def load_bci2a_data():
    """
    加载BCI2a数据
    
    Returns:
        X: EEG数据 [N, 22, 1000]
        y: 标签 [N]
        subjects: 被试ID [N]
        sessions: 会话ID [N]
    """
    # 加载数据
    X_path = os.path.join(DATA_PATH, 'X.npy')
    y_path = os.path.join(DATA_PATH, 'y.npy')
    
    if not os.path.exists(X_path) or not os.path.exists(y_path):
        raise FileNotFoundError(f"数据文件不存在！\n  X: {X_path}\n  y: {y_path}")
    
    X = np.load(X_path).astype(np.float32)
    y = np.load(y_path)
    
    # 标准化标签
    y = y - y.min()
    mask = y < DATASET_CONFIG['n_classes']
    X, y = X[mask], y[mask].astype(np.int64)
    
    # 标准化数据
    X = (X - X.mean(axis=(0,2), keepdims=True)) / (X.std(axis=(0,2), keepdims=True) + 1e-8)
    
    # 创建被试和会话标识
    n_subjects = DATASET_CONFIG['n_subjects']
    n_sessions = DATASET_CONFIG['n_sessions']
    trials_per_session = len(X) // (n_subjects * n_sessions)
    
    subjects = []
    sessions = []
    for subj in range(n_subjects):
        for sess in range(n_sessions):
            subjects.extend([subj] * trials_per_session)
            sessions.extend([sess] * trials_per_session)
    
    subjects = np.array(subjects[:len(X)])
    sessions = np.array(sessions[:len(X)])
    
    print(f"数据加载成功")
    print(f"   总样本: {len(X)}")
    print(f"   数据形状: {X.shape}")
    print(f"   类别分布: {np.bincount(y)}")
    print(f"   被试数: {len(np.unique(subjects))}")
    print(f"   会话数: {len(np.unique(sessions))}")
    
    return X, y, subjects, sessions

def get_session1_data(X, y, subjects, sessions):
    """
    获取所有被试的Session 1数据（用于训练DDPM）
    
    Returns:
        X_session1: Session 1的EEG数据
        y_session1: Session 1的标签
    """
    session1_mask = sessions == 0
    return X[session1_mask], y[session1_mask]

def get_subject_data(X, y, subjects, subject_id):
    """
    获取特定被试的所有数据
    
    Args:
        subject_id: 被试ID (0-8)
    
    Returns:
        X_subj: 该被试的EEG数据
        y_subj: 该被试的标签
    """
    mask = subjects == subject_id
    return X[mask], y[mask]

def get_subject_session_data(X, y, subjects, sessions, subject_id, session_id):
    """
    获取特定被试特定会话的数据
    
    Args:
        subject_id: 被试ID (0-8)
        session_id: 会话ID (0-1)
    
    Returns:
        X_data: 该被试该会话的EEG数据
        y_data: 该被试该会话的标签
    """
    mask = (subjects == subject_id) & (sessions == session_id)
    return X[mask], y[mask]


def load_data(dataset="BCI2a", mode="train"):
    """
    统一的数据加载接口
    
    Args:
        dataset: 数据集名称，目前支持 "BCI2a"
        mode: 模式，目前支持 "train"（返回所有数据）
    
    Returns:
        X: EEG数据 [N, C, T]
        y: 标签 [N]
        subjects: 被试ID [N] (可选，如果不需要可以忽略)
        sessions: 会话ID [N] (可选，如果不需要可以忽略)
    """
    if dataset == "BCI2a":
        X, y, subjects, sessions = load_bci2a_data()
        if mode == "train":
            # 返回所有训练数据
            return X, y, subjects, sessions
        else:
            raise ValueError(f"不支持的 mode: {mode}，目前只支持 'train'")
    else:
        raise ValueError(f"不支持的数据集: {dataset}，目前只支持 'BCI2a'")

if __name__ == '__main__':
    # 测试数据加载
    print("="*70)
    print("测试数据加载")
    print("="*70)
    
    X, y, subjects, sessions = load_bci2a_data()
    
    print(f"\n测试Session 1数据:")
    X_s1, y_s1 = get_session1_data(X, y, subjects, sessions)
    print(f"  Session 1样本数: {len(X_s1)}")
    
    print(f"\n测试被试0数据:")
    X_subj, y_subj = get_subject_data(X, y, subjects, 0)
    print(f"  被试0样本数: {len(X_subj)}")
    
    print(f"\n测试被试0 Session 0数据:")
    X_data, y_data = get_subject_session_data(X, y, subjects, sessions, 0, 0)
    print(f"  被试0 Session 0样本数: {len(X_data)}")
    
    print("\n数据加载测试通过！")
