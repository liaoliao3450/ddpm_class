#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SB-SD-LDM P4 评估: StyleEncoder 两种生成策略的跨被试 LOSO
===============================================================
前置: P2 checkpoint + P4 StyleEncoder checkpoint

策略 (消融区分, 同一 StyleEncoder 不同 s 来源):
  prior   (方向2): s ~ N(e_i, sigma0^2 I), i 随机训练被试
                   — 高斯尾巴外插, 突破 Dirichlet 凸包 ("盲新被试")
  fewshot (方向1): s_test = mean(E_style(测试被试 N_few 个无标签 trial))
                   — 定向生成测试被试风格 (target-aware 协议)
  hybrid  (1+2 组合, 两种实现加以区分):
    --hybrid_mode mix    向量级: s = 0.5*s_prior + 0.5*s_test (每样本风格折中)
    --hybrid_mode concat 数据级: 一半样本 s_prior + 一半样本 s_test
                         (风格各留原位, 分类器同时见多样性+定向两类样本)

协议声明:
  fewshot/hybrid 使用测试被试的无标签 trial 估计风格 (unsupervised
  target-aware / transductive 协议, 与 CORAL 等域对齐方法同类), 生成样本
  的类标签来自 diffusion 条件, 不使用测试 trial 标签.
  prior 为严格 blind 协议 (不看测试被试任何数据).
  P2/StyleEncoder 训练见过全部 9 被试 (proof-of-concept, 严格版需 per-fold 重训).

对照锚点 (BCI2a LOSO, GEN_RATIO=1.0):
  real-only:        51.99% (Kappa 0.360)
  fix-SB-LDM:       46.26% (Kappa 0.283)  ← 域偏移毒性
  P3-dirichlet:     52.10% (Kappa 0.361)  ← 凸包内插上限
  P3-dirichlet 0.5: 49.92% / 1.5: 50.66%  ← 倒 U 型, 1.0 是甜点

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/evaluate_p4_cross_subject.py --strategy prior --norm none
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/evaluate_p4_cross_subject.py --strategy fewshot --norm none
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/evaluate_p4_cross_subject.py --strategy hybrid --hybrid_mode concat --norm none
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/evaluate_p4_cross_subject.py --strategy hybrid --hybrid_mode mix --norm none
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/evaluate_p4_cross_subject.py --quick  # 仅快检
"""
import sys
import json
import argparse
from pathlib import Path

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from core.models.latent_diffusion.model_shared import (
    SharedBackboneConfig, SharedVAEUNetLDM1D)

from style_vae import load_style_vae

import importlib.util


def _load_ev():
    spec = importlib.util.spec_from_file_location(
        'evaluate_sb_ldm_3datasets',
        str(PROJECT_ROOT / 'projects/tc_conf_ldm/scripts/SB-LDM/evaluate_sb_ldm_3datasets.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
SEED = 42

DDIM_STEPS = 50
GUIDANCE_SCALE = 2.0   # 可被 --cfg 覆盖 (CFG=1.0 时 z 统计与真实 mu_z 对齐)
GEN_RATIO = 1.0
N_ENSEMBLE = 3
N_FEWSHOT = 40          # fewshot 使用的测试被试无标签 trial 数
FEWSHOT_SIGMA = None    # fewshot 风格抖动宽度 (None -> 0.2*sigma0 历史默认)

# 多数据集 P4 评测配置 (journal Table III prior/few-shot 行)
P4_DS_CONFIG = {
    'bci2a': {
        'channels': 22, 'input_length': 1000, 'num_classes': 4,
        'teacher_ckpt': 'checkpoints/tc_conf_ldm/bci2a_shared_margin/pretrained_teacher_eegnet.pt',
        'p2_ckpt': 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p2/sb_sd_ldm_p2_epoch_500.pt',
        'p4_ckpt': 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p4/style_vae_final.pt',
    },
    'bci2b': {
        'channels': 3, 'input_length': 1000, 'num_classes': 2,
        'teacher_ckpt': 'checkpoints/tc_conf_ldm/bci2b_shared/pretrained_teacher_eegnet.pt',
        'p2_ckpt': 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2b_p2/sb_sd_ldm_p2_epoch_500.pt',
        'p4_ckpt': 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2b_p4/style_vae_final.pt',
    },
    'physionet': {
        'channels': 64, 'input_length': 640, 'num_classes': 4,
        'teacher_ckpt': 'checkpoints/tc_conf_ldm/physionet_mi4c_shared/pretrained_teacher_eegnet.pt',
        'p2_ckpt': 'checkpoints/tc_conf_ldm/sb_sd_ldm_physionet_p2/sb_sd_ldm_p2_epoch_500.pt',
        'p4_ckpt': 'checkpoints/tc_conf_ldm/sb_sd_ldm_physionet_p4/style_vae_final.pt',
    },
}


def load_p2_model_ds(ckpt_path, channels, input_length, num_classes):
    """数据集感知版模型加载 (原 load_p2_model 硬编码 BCI2a 维度)."""
    ckpt = torch.load(str(ckpt_path), map_location=DEVICE, weights_only=False)
    model_cfg = ckpt['config'].get('model', {})
    backbone = SharedBackboneConfig(
        base=int(model_cfg.get('backbone_base', 64)),
        levels=tuple(int(x) for x in model_cfg.get('backbone_levels', [1, 2, 4])),
        blocks_per_level=int(model_cfg.get('backbone_blocks_per_level', 2)),
    )
    model = SharedVAEUNetLDM1D(
        channels=channels,
        input_length=input_length,
        z_channels=int(model_cfg.get('z_channels', 64)),
        timesteps=int(model_cfg.get('timesteps', 1000)),
        t_dim=int(model_cfg.get('t_dim', 128)),
        cond_dim=int(model_cfg.get('cond_embed_dim', 64)),
        backbone=backbone,
        num_subjects=ckpt.get('num_subjects', 9),
        adv_alpha=0.0,
        subj_dim=ckpt.get('subj_dim', 32),
        disentangle=True,
    ).to(DEVICE)
    model.load_state_dict(ckpt['model_state_dict'])
    model.eval()

    cond_embed = torch.nn.Embedding(
        num_classes, int(model_cfg.get('cond_embed_dim', 64))).to(DEVICE)
    cond_embed.load_state_dict(ckpt['cond_embed_state_dict'])
    cond_embed.eval()
    return model, cond_embed


def set_seed(seed=SEED):
    import random
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)


def load_p2_model(ckpt_path):
    ckpt = torch.load(str(ckpt_path), map_location=DEVICE, weights_only=False)
    model_cfg = ckpt['config'].get('model', {})
    backbone = SharedBackboneConfig(
        base=int(model_cfg.get('backbone_base', 64)),
        levels=tuple(int(x) for x in model_cfg.get('backbone_levels', [1, 2, 4])),
        blocks_per_level=int(model_cfg.get('backbone_blocks_per_level', 2)),
    )
    model = SharedVAEUNetLDM1D(
        channels=22,
        input_length=1000,
        z_channels=int(model_cfg.get('z_channels', 64)),
        timesteps=int(model_cfg.get('timesteps', 1000)),
        t_dim=int(model_cfg.get('t_dim', 128)),
        cond_dim=int(model_cfg.get('cond_embed_dim', 64)),
        backbone=backbone,
        num_subjects=ckpt.get('num_subjects', 9),
        adv_alpha=0.0,
        subj_dim=ckpt.get('subj_dim', 32),
        disentangle=True,
    ).to(DEVICE)
    model.load_state_dict(ckpt['model_state_dict'])
    model.eval()

    cond_embed = torch.nn.Embedding(4, int(model_cfg.get('cond_embed_dim', 64))).to(DEVICE)
    cond_embed.load_state_dict(ckpt['cond_embed_state_dict'])
    cond_embed.eval()
    return model, cond_embed


def make_ddim_schedule(alpha_bar, steps):
    total = len(alpha_bar)
    step = total // steps
    return list(reversed(range(0, total, step)))[:steps]


def estimate_fewshot_style(style_enc, X_few, device=DEVICE, bs=40):
    """fewshot 风格估计: 测试被试少量无标签 trial -> 风格均值向量."""
    with torch.no_grad():
        mus = []
        for i in range(0, len(X_few), bs):
            xb = torch.FloatTensor(X_few[i:i + bs]).to(device)
            mu_s, _ = style_enc(xb)
            mus.append(mu_s.cpu())
        return torch.cat(mus).mean(0)     # (subj_dim,)


def generate_p4(model, cond_embed, style_enc, n_per_class, num_classes, strategy,
                train_subj_ids, X_few=None, prior_sigma=None, sigma0=0.5,
                device=DEVICE, hybrid_mode='concat'):
    """P4 DDIM 生成: z 被试不变 + StyleEncoder 风格来源注入.

    strategy:
      prior:   s ~ N(e_i, sigma^2 I), i 随机训练被试 (盲新被试)
      fewshot: s = s_test_hat + 0.2*sigma0*eps (定向测试被试)
      hybrid (1+2 组合):
        mix:    每样本 s = 0.5*(e_i + sigma*eps) + 0.5*s_test_hat (向量折中)
        concat: 一半样本用 s_prior, 一半用 s_fewshot (数据级组合)
    """
    model.eval()
    cond_embed.eval()
    style_enc.eval()
    e = 1e-8
    ddim_seq = make_ddim_schedule(model.alpha_bar, DDIM_STEPS)

    if prior_sigma is None:
        prior_sigma = sigma0

    with torch.no_grad():
        dummy = torch.zeros(1, model.channels, model.input_length, device=device)
        z_d, _, _ = model.encode(dummy, cond=torch.zeros(1, model.cond_dim, device=device))
        z_ch, latent_len = model.z_channels, z_d.shape[-1]

    W = model.subj_embed.weight.detach()  # (num_subjects, subj_dim)

    # fewshot 风格抖动宽度 (默认 0.2*sigma0; 可放宽到 sigma0 匹配被试内变异)
    if FEWSHOT_SIGMA is None:
        fewshot_sigma = 0.5 * sigma0
    else:
        fewshot_sigma = FEWSHOT_SIGMA

    # fewshot 风格估计 (若策略需要)
    s_test_hat = None
    if strategy in ('fewshot', 'hybrid'):
        assert X_few is not None, f'{strategy} 需要测试被试 fewshot trial'
        s_test_hat = estimate_fewshot_style(style_enc, X_few, device).to(device)

    all_X, all_y = [], []
    with torch.no_grad():
        for c in range(num_classes):
            generated = 0
            while generated < n_per_class:
                bs = min(32, n_per_class - generated)
                cl = torch.full((bs,), c, dtype=torch.long, device=device)
                cond = cond_embed(cl)

                # 风格向量
                style_vec = None
                if strategy == 'prior':
                    pick = np.random.choice(train_subj_ids, size=bs)
                    e_pick = W[torch.as_tensor(pick, device=device)]      # (bs, d)
                    style_vec = e_pick + prior_sigma * torch.randn_like(e_pick)
                elif strategy == 'fewshot':
                    s_rep = s_test_hat.unsqueeze(0).expand(bs, -1)
                    style_vec = s_rep + fewshot_sigma * torch.randn_like(s_rep)
                elif strategy == 'hybrid':
                    if hybrid_mode == 'mix':
                        # 向量级: 每样本风格 = prior 与 fewshot 的折中
                        pick = np.random.choice(train_subj_ids, size=bs)
                        e_pick = W[torch.as_tensor(pick, device=device)]
                        s_prior = e_pick + prior_sigma * torch.randn_like(e_pick)
                        s_rep = s_test_hat.unsqueeze(0).expand(bs, -1)
                        style_vec = 0.5 * s_prior + 0.5 * s_rep
                    else:
                        # 数据级: batch 内一半 prior 风格 + 一半 fewshot 风格
                        n_prior = max(1, bs // 2)
                        pick = np.random.choice(train_subj_ids, size=n_prior)
                        e_pick = W[torch.as_tensor(pick, device=device)]
                        s_prior = e_pick + prior_sigma * torch.randn_like(e_pick)
                        s_rep = s_test_hat.unsqueeze(0).expand(bs - n_prior, -1)
                        s_few = s_rep + fewshot_sigma * torch.randn_like(s_rep)
                        style_vec = torch.cat([s_prior, s_few], dim=0)

                z = torch.randn(bs, z_ch, latent_len, device=device)
                for i, t_idx in enumerate(ddim_seq):
                    t = torch.full((bs,), t_idx, device=device, dtype=torch.long)
                    ec = model.denoise_eps(z, t, cond=cond)
                    if GUIDANCE_SCALE > 1.0:
                        eu = model.denoise_eps(z, t, cond=None)
                        eps_pred = torch.clamp(eu + GUIDANCE_SCALE * (ec - eu), -100, 100)
                    else:
                        eps_pred = ec

                    ab = model.alpha_bar[t_idx]
                    ab_prev = model.alpha_bar[ddim_seq[i + 1]] if i + 1 < len(ddim_seq) else model.alpha_bar[0]
                    ab = ab.to(device) if isinstance(ab, torch.Tensor) else torch.tensor(ab, device=device)
                    ab_prev = ab_prev.to(device) if isinstance(ab_prev, torch.Tensor) else torch.tensor(ab_prev, device=device)

                    sab = torch.sqrt(ab.clamp(min=e))
                    s1mb = torch.sqrt((1 - ab).clamp(min=e))
                    sab_prev = torch.sqrt(ab_prev.clamp(min=e))
                    s1mb_prev = torch.sqrt((1 - ab_prev).clamp(min=e))

                    pred_x0 = ((z - s1mb * eps_pred) / sab).clamp(-5, 5)
                    z = sab_prev * pred_x0 + s1mb_prev * eps_pred

                x = model.decode(z, target_length=model.input_length,
                                 cond=cond, style_vec=style_vec)
                all_X.append(x.cpu().numpy())
                all_y.extend([c] * bs)
                generated += bs

    return np.concatenate(all_X), np.array(all_y)


def quick_gen_check(model, cond_embed, style_enc, ev, X, y, subjects, strategy,
                    sigma0, norm_mode='none', hybrid_mode='concat',
                    num_classes=4, teacher_ckpt=None):
    """生成质量快检: teacher 判类 + subj_head 风格分布."""
    hm = f', hybrid_mode={hybrid_mode}' if strategy == 'hybrid' else ''
    print('\n' + '=' * 70)
    print(f'[快检] 策略={strategy}{hm}, norm={norm_mode}: teacher 判类 + subj_head 风格分布')
    print('=' * 70)

    n_subj = len(np.unique(subjects))
    train_subj_ids = list(range(n_subj))
    set_seed()

    # fewshot 快检: 用最后一个被试的 N_FEWSHOT 个 trial 模拟
    X_few = X[subjects == n_subj - 1][:N_FEWSHOT] if strategy in ('fewshot', 'hybrid') else None

    gX, gy = generate_p4(model, cond_embed, style_enc, 50, num_classes, strategy,
                         train_subj_ids, X_few=X_few, sigma0=sigma0,
                         hybrid_mode=hybrid_mode)
    if norm_mode == 'global':
        gX = ev.normalize_to_real_stats(X, gX)
    else:
        gX = gX.astype(np.float32)
        gX = np.nan_to_num(gX, nan=0.0)

    # teacher 判类
    from core.classifiers.eegnet import EEGNet
    teacher = EEGNet(n_channels=X.shape[1], n_samples=X.shape[2],
                     n_classes=num_classes).to(DEVICE)
    state = torch.load(str(teacher_ckpt), map_location=DEVICE, weights_only=False)
    if isinstance(state, dict) and 'model_state_dict' in state:
        state = state['model_state_dict']
    teacher.load_state_dict(state, strict=False)
    teacher.eval()

    with torch.no_grad():
        xb = torch.FloatTensor(gX).unsqueeze(1).to(DEVICE)
        pred = teacher(xb).argmax(1).cpu().numpy()
    gen_cls_acc = float((pred == gy).mean())

    with torch.no_grad():
        xb = torch.FloatTensor(X[:400]).unsqueeze(1).to(DEVICE)
        pred_r = teacher(xb).argmax(1).cpu().numpy()
    real_cls_acc = float((pred_r == y[:400]).mean())

    # subj_head 风格分布
    with torch.no_grad():
        xb = torch.FloatTensor(gX).to(DEVICE)
        s_pred = model.subj_head(xb).argmax(1).cpu().numpy()
    style_dist = np.bincount(s_pred, minlength=n_subj) / len(s_pred)

    print(f'  teacher 判类 (生成): {gen_cls_acc*100:.1f}%  (真实数据: {real_cls_acc*100:.1f}%)')
    print(f'  subj_head 风格分布: {np.round(style_dist*100, 1).tolist()}%')
    if strategy == 'prior':
        print(f'  (期望: 类一致 + 风格分散; prior 高斯尾巴应比 dirichlet 更外扩)')
    elif strategy == 'fewshot':
        print(f'  (期望: 风格集中于被试 9 — fewshot 定向的证据)')

    return gen_cls_acc, real_cls_acc, style_dist


def loso_eval(model, cond_embed, style_enc, ev, X, y, subjects, sessions,
              strategy, sigma0, norm_mode='none', hybrid_mode='concat',
              num_classes=4):
    """跨被试 LOSO (协议与 evaluate_p3 对齐; fewshot 用测试被试无标签 trial)."""
    from sklearn.metrics import accuracy_score, cohen_kappa_score

    hm = f', hybrid_mode={hybrid_mode}' if strategy == 'hybrid' else ''
    print('\n' + '=' * 70)
    print(f'[LOSO] P4 策略={strategy}{hm}, GEN_RATIO={GEN_RATIO}, N_FEWSHOT={N_FEWSHOT}, norm={norm_mode}')
    print('=' * 70)

    results = []
    unique_subjects = np.unique(subjects)
    channels, input_length = X.shape[1], X.shape[2]

    ev.GEN_RATIO = GEN_RATIO
    ev.N_ENSEMBLE = N_ENSEMBLE

    for test_subj in unique_subjects:
        train_mask = subjects != test_subj
        test_mask = subjects == test_subj
        X_train, y_train = X[train_mask], y[train_mask]
        X_test, y_test = X[test_mask], y[test_mask]

        train_subj_ids = [int(s) for s in np.unique(subjects[train_mask])]

        # fewshot: 测试被试的无标签 trial (不用其标签)
        X_few = X_test[:N_FEWSHOT] if strategy in ('fewshot', 'hybrid') else None

        spc = max(1, int(GEN_RATIO * len(X_train)) // num_classes)
        set_seed()
        gen_X, gen_y = generate_p4(model, cond_embed, style_enc, spc, num_classes,
                                   strategy, train_subj_ids, X_few=X_few,
                                   sigma0=sigma0, hybrid_mode=hybrid_mode)
        if norm_mode == 'global':
            gen_X = ev.normalize_to_real_stats(X_train, gen_X)
        else:
            gen_X = gen_X.astype(np.float32)
            gen_X = np.nan_to_num(gen_X, nan=0.0)

        X_aug = np.concatenate([X_train, gen_X])
        y_aug = np.concatenate([y_train, gen_y])

        clf = ev.train_classifier(X_aug, y_aug, channels, input_length, num_classes)
        pred = ev.predict(clf, X_test)
        acc = float(accuracy_score(y_test, pred))
        kappa = float(cohen_kappa_score(y_test, pred))
        results.append({'acc': acc, 'kappa': kappa})
        print(f'  被试 {int(test_subj)+1}: Acc {acc*100:.2f}%, Kappa {kappa:.4f}')

    accs = [r['acc'] for r in results]
    kappas = [r['kappa'] for r in results]
    res = {'mean': float(np.mean(accs)), 'std': float(np.std(accs)),
           'per_subject': accs, 'mean_kappa': float(np.mean(kappas)),
           'std_kappa': float(np.std(kappas)), 'per_subject_kappa': kappas}
    print(f'\n>>> P4 ({strategy}) LOSO: {res["mean"]*100:.2f}% ± {res["std"]*100:.2f}% '
          f'(Kappa {res["mean_kappa"]:.4f})')
    return res


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', type=str, default='bci2a',
                        choices=['bci2a', 'bci2b', 'physionet'],
                        help='数据集 (bci2a 为原版默认, 向后兼容)')
    parser.add_argument('--strategy', type=str, default='fewshot',
                        choices=['prior', 'fewshot', 'hybrid'])
    parser.add_argument('--hybrid_mode', type=str, default='concat',
                        choices=['mix', 'concat'],
                        help='hybrid (1+2 组合) 实现方式: mix=向量级折中, '
                             'concat=数据级一半prior一半fewshot')
    parser.add_argument('--ratio', type=float, default=1.0)
    parser.add_argument('--n_fewshot', type=int, default=40)
    parser.add_argument('--fewshot_sigma', type=float, default=None,
                        help='fewshot 风格抖动宽度 (默认 0.2*sigma0; 放宽到 sigma0 '
                             '匹配 StyleEncoder 学到的被试内变异)')
    parser.add_argument('--prior_sigma', type=float, default=None,
                        help='prior 采样标准差 (默认 sigma0)')
    parser.add_argument('--norm', type=str, default='none', choices=['none', 'global'],
                        help='生成样本归一化: none=decode 原始输出 (保风格), '
                             'global=归一化到真实全局统计 (洗风格, 历史口径)')
    parser.add_argument('--cfg', type=float, default=2.0,
                        help='classifier-free guidance scale (1.0 = 无外推, z 统计对齐真实)')
    parser.add_argument('--quick', action='store_true', help='仅生成质量快检')
    parser.add_argument('--p2_ckpt', type=str, default=None)
    parser.add_argument('--p4_ckpt', type=str, default=None)
    args = parser.parse_args()

    global GEN_RATIO, N_FEWSHOT, GUIDANCE_SCALE, FEWSHOT_SIGMA
    GEN_RATIO = args.ratio
    N_FEWSHOT = args.n_fewshot
    GUIDANCE_SCALE = args.cfg
    FEWSHOT_SIGMA = args.fewshot_sigma

    ds = P4_DS_CONFIG[args.dataset]
    channels = ds['channels']
    input_length = ds['input_length']
    num_classes = ds['num_classes']
    p2_ckpt = args.p2_ckpt or ds['p2_ckpt']
    p4_ckpt = args.p4_ckpt or ds['p4_ckpt']

    set_seed()
    ev = _load_ev()

    print(f'加载 P2 checkpoint: {p2_ckpt}')
    model, cond_embed = load_p2_model_ds(
        PROJECT_ROOT / p2_ckpt, channels, input_length, num_classes)

    print(f'加载 P4 StyleEncoder: {p4_ckpt}')
    style_enc, class_disc, sigma0 = load_style_vae(
        PROJECT_ROOT / p4_ckpt, channels=channels, input_length=input_length,
        num_classes=num_classes, device=DEVICE)
    print(f'  sigma0 = {sigma0}')

    # 数据
    X, y, subjects, sessions = ev.load_dataset_data(args.dataset)
    subj_uniq = np.unique(subjects)
    if subj_uniq.max() != len(subj_uniq) - 1:
        remap = {s: i for i, s in enumerate(subj_uniq)}
        subjects = np.array([remap[s] for s in subjects])

    # [1] 生成质量快检
    gen_acc, real_acc, style_dist = quick_gen_check(
        model, cond_embed, style_enc, ev, X, y, subjects, args.strategy, sigma0,
        norm_mode=args.norm, hybrid_mode=args.hybrid_mode,
        num_classes=num_classes, teacher_ckpt=PROJECT_ROOT / ds['teacher_ckpt'])

    if args.quick:
        return

    # [2] LOSO
    res = loso_eval(model, cond_embed, style_enc, ev, X, y, subjects, sessions,
                    args.strategy, sigma0, norm_mode=args.norm,
                    hybrid_mode=args.hybrid_mode, num_classes=num_classes)

    # [3] 汇总
    hm_tag = f'-{args.hybrid_mode}' if args.strategy == 'hybrid' else ''
    print('\n' + '=' * 70)
    print(f'P4 结果汇总 ({args.dataset} 跨被试 LOSO)')
    print('=' * 70)
    if args.dataset == 'bci2a':
        print(f'  real-only:        51.99% (Kappa 0.360)  ← 天花板')
        print(f'  fix-SB-LDM 1.0:   46.26% (Kappa 0.283)  ← 域偏移毒性')
        print(f'  P3-dirichlet 1.0: 52.10% (Kappa 0.361)  ← 凸包内插')
        print(f'  P4-fewshot:       53.01% (Kappa 0.373)  ← 方向1 定向风格')
    print(f'  P4-{args.strategy}{hm_tag} ({args.ratio}, norm={args.norm}): {res["mean"]*100:.2f}% ± {res["std"]*100:.2f}% '
          f'(Kappa {res["mean_kappa"]:.4f})')

    fs_tag = f'_fs{FEWSHOT_SIGMA}' if FEWSHOT_SIGMA is not None else ''
    if args.dataset == 'bci2a':
        out = PROJECT_ROOT / f'outputs/results/sb_sd_ldm_p4_{args.strategy}{hm_tag}_r{args.ratio}_n{args.norm}_cfg{args.cfg}{fs_tag}.json'
    else:
        out = PROJECT_ROOT / f'outputs/results/sb_sd_ldm_p4_{args.dataset}_{args.strategy}{hm_tag}_r{args.ratio}_n{args.norm}_cfg{args.cfg}{fs_tag}.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, 'w', encoding='utf-8') as f:
        json.dump({'dataset': args.dataset, 'strategy': args.strategy,
                   'hybrid_mode': args.hybrid_mode,
                   'ratio': args.ratio, 'fewshot_sigma': FEWSHOT_SIGMA,
                   'n_fewshot': N_FEWSHOT, 'norm': args.norm, 'cfg': args.cfg,
                   'gen_cls_acc': gen_acc, 'real_cls_acc': real_acc,
                   'style_dist': style_dist.tolist(), 'loso': res},
                  f, indent=2, ensure_ascii=False)
    print(f'\n已保存: {out}')


if __name__ == '__main__':
    main()
