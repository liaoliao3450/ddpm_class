#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EA-only 基线 + 风格向量方差解释分析
===============================================================
定位坐标系 (route 1 的收尾):
  real-only:        51.99% (Kappa 0.360)  ← 无增强锚点
  P4-fewshot:       53.01% (Kappa 0.373)  ← 我们的方法
  fix-SB-LDM:       46.26% (Kappa 0.283)  ← 毒性锚点

[A] EA-only LOSO (协议与 evaluate_p4 逐字对齐: 同数据口径/同 EEGNet×3
    集成/同 200 epochs/batch 32/lr 1e-3/软投票):
    EA-full: 每个被试 (含测试被试) 用自己全部 trial 估计 R_s,
             x' = R_s^{-1/2} x  (文献标准, unsupervised transductive)
    EA-40:   测试被试只用前 40 个无标签 trial 估计 R_s
             (与 P4-fewshot N_FEWSHOT=40 访问量严格对齐), 训练被试不限
    判定: EA-full >= 55% -> 风格通路叙事改为 "互补";
          EA-only < fewshot -> 风格通路 "超越二阶几何对齐" 有底气.

[B] 风格向量方差解释 (双向冗余分析, LOO 交叉验证防 n=9 过拟合):
    style -> logm(R_s) PCA(6):  风格解释协方差几何的多少 ("包含")
    logm(R_s) PCA(6) -> style:  协方差解释风格的多少 ("子集?")
    不对称性 (前者高后者低) = "包含但超越" 的直接量化.

数据口径声明: 与模型训练一致的全局 per-channel z-norm 后再做 EA
    (保证与 real-only/fewshot 锚点可比; EA 论文的原始数据口径不同,
     但被试间相对协方差结构在统一线性变换下等价保留).

输出: outputs/results/ea_baseline_loso.json

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/ea_baseline_loso.py
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/ea_baseline_loso.py --skip_ea  # 仅 [B]
"""
import sys
import json
import argparse
from pathlib import Path

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from style_vae import load_style_vae
from diag_style_cov_cca import subject_covariances, logm_sym
from diag_cca_loo_robustness import pca_feats

import importlib.util


def _load_ev():
    spec = importlib.util.spec_from_file_location(
        'evaluate_sb_ldm_3datasets',
        str(PROJECT_ROOT / 'projects/tc_conf_ldm/scripts/SB-LDM/evaluate_sb_ldm_3datasets.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
SEED = 42
N_FEWSHOT = 40
ANCHORS = {'real-only': (0.5199, 0.360), 'P4-fewshot': (0.5301, 0.373),
           'fix-SB-LDM': (0.4626, 0.283)}


# ============================================================
# EA (Euclidean Alignment)
# ============================================================

def ea_transform(X_subj, R_s, eps=1e-8):
    """x' = R_s^{-1/2} x.  X_subj:(N,C,T) -> (N,C,T)."""
    R = (R_s + R_s.T) / 2.0
    w, V = np.linalg.eigh(R)
    w = np.clip(w, eps, None)
    R_inv_half = (V * (1.0 / np.sqrt(w))) @ V.T
    return np.einsum('ab,nbt->nat', R_inv_half.astype(np.float32),
                     X_subj.astype(np.float32))


def subject_Rs(X_subj):
    """R_s = mean_i x_i x_i^T / T (trial 不中心化, EA 标准口径)."""
    return subject_covariances(X_subj)


# ============================================================
# [B] 双向冗余分析 (LOO R²)
# ============================================================

def loo_r2(X, Y, lam=0.5):
    """留一被试交叉验证 R²: ridge 回归 Y~X, 预测留出被试.

    R² 相对 null (训练折均值) 计算; 负值 = 不比均值预测好.
    """
    n = len(X)
    y_true, y_pred, y_null = [], [], []
    for i in range(n):
        keep = [j for j in range(n) if j != i]
        Xk, Yk = X[keep], Y[keep]
        Xm, Ym = Xk.mean(0), Yk.mean(0)
        Xc, Yc = Xk - Xm, Yk - Ym
        A = Xc.T @ Xc / len(Xc) + lam * np.eye(X.shape[1])
        W = np.linalg.solve(A, Xc.T @ Yc / len(Xc))
        pred = (X[i] - Xm) @ W + Ym
        y_true.append(Y[i]); y_pred.append(pred); y_null.append(Ym)
    yt = np.stack(y_true); yp = np.stack(y_pred); yn = np.stack(y_null)
    ss_res = float(((yt - yp) ** 2).sum())
    ss_null = float(((yt - yn) ** 2).sum())
    r2 = 1.0 - ss_res / max(ss_null, 1e-12)
    # 逐维 R² (Y 每个主成分方向)
    r2_per_dim = 1.0 - ((yt - yp) ** 2).sum(0) / \
                 np.maximum(((yt - yn) ** 2).sum(0), 1e-12)
    return r2, r2_per_dim.tolist()


def full_r2(X, Y, lam=0.5):
    """全样本 (非交叉验证) R², 过拟合上限参考."""
    Xc, Yc = X - X.mean(0), Y - Y.mean(0)
    A = Xc.T @ Xc / len(Xc) + lam * np.eye(X.shape[1])
    W = np.linalg.solve(A, Xc.T @ Yc / len(Xc))
    pred = Xc @ W
    ss_res = float(((Yc - pred) ** 2).sum())
    ss_tot = float((Yc ** 2).sum())
    return 1.0 - ss_res / max(ss_tot, 1e-12)


# ============================================================
# 主流程
# ============================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--p4_ckpt', type=str,
                        default='checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p4/style_vae_final.pt')
    parser.add_argument('--skip_ea', action='store_true', help='跳过 [A] EA LOSO')
    parser.add_argument('--lam', type=float, default=0.5)
    args = parser.parse_args()

    ev = _load_ev()
    X, y, subjects, sessions = ev.load_dataset_data('bci2a')
    subj_uniq = np.unique(subjects)
    if subj_uniq.max() != len(subj_uniq) - 1:
        remap = {s: i for i, s in enumerate(subj_uniq)}
        subjects = np.array([remap[s] for s in subjects])
    n_subj = len(np.unique(subjects))
    channels, input_length, num_classes = X.shape[1], X.shape[2], 4

    results = {'n_subjects': int(n_subj), 'n_fewshot': N_FEWSHOT}

    # ==========================================================
    # [B] 风格向量方差解释 (CPU, 先出结果)
    # ==========================================================
    print('\n' + '=' * 72)
    print('[B] 风格向量 <-> 协方差几何 双向冗余分析 (LOO R², lam=%.1f)'
          % args.lam)
    print('=' * 72)

    style_enc, _, sigma0 = load_style_vae(
        PROJECT_ROOT / args.p4_ckpt, channels=22, input_length=1000,
        num_classes=4, device=torch.device('cpu'))
    enc_device = torch.device('cpu')

    s_all, logm_all = [], []
    with torch.no_grad():
        for s in range(n_subj):
            Xs = X[subjects == s]
            logm_all.append(logm_sym(subject_Rs(Xs)))
            mus = []
            for i in range(0, len(Xs), 64):
                xb = torch.FloatTensor(Xs[i:i + 64]).to(enc_device)
                mu_s, _ = style_enc(xb)
                mus.append(mu_s.cpu().numpy())
            s_all.append(np.concatenate(mus).mean(0))
    S = np.stack(s_all)                       # (9, 32)
    Ycov = pca_feats(logm_all, k=6)           # (9, 6)

    r2_style2cov, r2_style2cov_dim = loo_r2(S, Ycov, args.lam)
    r2_cov2style, r2_cov2style_dim = loo_r2(Ycov, S, args.lam)
    full_s2c = full_r2(S, Ycov, args.lam)
    full_c2s = full_r2(Ycov, S, args.lam)

    print(f'  style(32d) -> cov-PCA(6):  LOO R² = {r2_style2cov:+.3f}   '
          f'(全样本 R² = {full_s2c:+.3f})')
    print(f'  cov-PCA(6) -> style(32d):  LOO R² = {r2_cov2style:+.3f}   '
          f'(全样本 R² = {full_c2s:+.3f})')
    print(f'  逐维 (style->cov 前 3 个 PC): '
          f'{[round(v, 3) for v in r2_style2cov_dim[:3]]}')
    asym = r2_style2cov - r2_cov2style
    print(f'  不对称性 (style->cov 减 cov->style) = {asym:+.3f}')
    if r2_style2cov > 0.3 and asym > 0.15:
        print('  => 支持 "包含但超越": 风格线性编码协方差几何, 且包含更多')
    elif r2_style2cov < 0.1:
        print('  => 风格几乎不含协方差几何信息 (与 CCA 0.92 矛盾, 需检查)')
    else:
        print('  => 部分包含, 不对称性有限')

    results['variance_explanation'] = {
        'style_to_cov_loo_r2': r2_style2cov,
        'style_to_cov_full_r2': full_s2c,
        'style_to_cov_per_dim': r2_style2cov_dim,
        'cov_to_style_loo_r2': r2_cov2style,
        'cov_to_style_full_r2': full_c2s,
        'asymmetry': asym,
        'lam': args.lam,
    }

    # ==========================================================
    # [A] EA-only LOSO
    # ==========================================================
    if not args.skip_ea:
        from sklearn.metrics import accuracy_score, cohen_kappa_score

        ev.GEN_RATIO = 1.0
        ev.N_ENSEMBLE = 3

        for arm in ('ea_full', 'ea_40'):
            print('\n' + '=' * 72)
            use_few = (arm == 'ea_40')
            print(f'[A] EA-only LOSO ({arm}: 测试被试 R_s 用'
                  f'{"前 " + str(N_FEWSHOT) + " 个无标签 trial" if use_few else "全部 trial"}估计)')
            print('=' * 72)

            arm_results = []
            for test_subj in range(n_subj):
                np.random.seed(SEED)

                # 每个被试独立 EA (训练被试用全部 trial; 测试被试按 arm)
                X_train_parts, y_train_parts = [], []
                X_test, y_test = None, None
                for s in range(n_subj):
                    m = subjects == s
                    Xs, ys = X[m], y[m]
                    if s == test_subj:
                        R_est = subject_Rs(Xs[:N_FEWSHOT]) if use_few \
                            else subject_Rs(Xs)
                        X_test = ea_transform(Xs, R_est)
                        y_test = ys
                    else:
                        X_train_parts.append(ea_transform(Xs, subject_Rs(Xs)))
                        y_train_parts.append(ys)
                X_tr = np.concatenate(X_train_parts)
                y_tr = np.concatenate(y_train_parts)

                clf = ev.train_classifier(X_tr, y_tr, channels,
                                          input_length, num_classes)
                pred = ev.predict(clf, X_test)
                acc = float(accuracy_score(y_test, pred))
                kappa = float(cohen_kappa_score(y_test, pred))
                arm_results.append({'acc': acc, 'kappa': kappa})
                print(f'  被试 {test_subj + 1}: Acc {acc * 100:.2f}%, '
                      f'Kappa {kappa:.4f}')

            accs = [r['acc'] for r in arm_results]
            kappas = [r['kappa'] for r in arm_results]
            res = {'mean': float(np.mean(accs)), 'std': float(np.std(accs)),
                   'per_subject': accs,
                   'mean_kappa': float(np.mean(kappas)),
                   'std_kappa': float(np.std(kappas)),
                   'per_subject_kappa': kappas}
            results[arm] = res
            print(f'\n>>> EA-only ({arm}): {res["mean"] * 100:.2f}% '
                  f'± {res["std"] * 100:.2f}% (Kappa {res["mean_kappa"]:.4f})')

        # 定位汇总
        print('\n' + '=' * 72)
        print('坐标系定位 (BCI2a 跨被试 LOSO, 同协议):')
        print('=' * 72)
        rows = [('real-only (无增强)', *ANCHORS['real-only'])]
        if 'ea_40' in results:
            rows.append(('EA-40 (对齐 fewshot 访问量)',
                         results['ea_40']['mean'], results['ea_40']['mean_kappa']))
        if 'ea_full' in results:
            rows.append(('EA-full (文献标准)',
                         results['ea_full']['mean'], results['ea_full']['mean_kappa']))
        rows.append(('P4-fewshot (ours)', *ANCHORS['P4-fewshot']))
        for name, a, k in rows:
            print(f'  {name:32s} {a * 100:6.2f}%  (Kappa {k:.3f})')

        if 'ea_full' in results and 'ea_40' in results:
            ea_best = max(results['ea_full']['mean'], results['ea_40']['mean'])
            if ea_best >= 0.55:
                print('\n  判定: EA >= 55% -> 风格通路叙事应改为 "互补" (EA 主导)')
            elif ea_best < ANCHORS['P4-fewshot'][0]:
                print('\n  判定: EA-only < fewshot -> 风格通路超越二阶几何对齐, '
                      '"包含但超越" 成立')
            else:
                print('\n  判定: EA 与 fewshot 相当 -> 风格通路 ≈ 可学习 EA, '
                      '需靠 Mantel 零结果区分')

    out = PROJECT_ROOT / 'outputs/results/ea_baseline_loso.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f'\n结果已保存: {out}')


if __name__ == '__main__':
    main()
