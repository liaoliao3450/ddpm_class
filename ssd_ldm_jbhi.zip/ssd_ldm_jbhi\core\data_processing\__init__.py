#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EEG数据预处理模块

提供统一的数据预处理接口，支持不同的模型需求
"""

from .preprocess_for_test import (
    # 主要类和枚举
    EEGPreprocessor,
    PreprocessMode,
    
    # 统一接口
    preprocess_for_test,
    
    # 向后兼容函数
    preprocess_for_csp,
    preprocess_for_eegnet,
    preprocess_for_deep_learning,
    preprocess_for_shallow_convnet,
    preprocess_for_deep_convnet,
    preprocess_for_eeg_resnet
)

__version__ = "1.0.0"
__author__ = "DS-DDPM Project"

__all__ = [
    'EEGPreprocessor',
    'PreprocessMode', 
    'preprocess_for_test',
    'preprocess_for_csp',
    'preprocess_for_eegnet',
    'preprocess_for_deep_learning',
    'preprocess_for_shallow_convnet',
    'preprocess_for_deep_convnet',
    'preprocess_for_eeg_resnet'
]