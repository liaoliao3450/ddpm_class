#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CCA 离群被试稳健性检查 (leave-one-subject-out)
===============================================================
背景: diag_style_cov_cca.py 得到 CCA 第一典型相关 ~0.92 (p<0.01), 但 n=9.
担心: 高相关可能由单个离群被试驱动 (一个极端点就能造出高相关).

三重检查:
  [1] LOO 折: 逐个去掉被试 i (n=8, 协方差 PCA 每折重拟合防泄漏),
      重算 ridge CCA rho + 置换 p. 去掉某被试后 rho 崩塌 -> 该被试驱动相关.
  [2] 贡献分解: Pearson r = Σᵢ z_u,i·z_v,i/(n-1), 每被试贡献单独列出.
      单一被试贡献 > 40% 总相关 -> 离群驱动.
  [3] 超参敏感性: lam × PCA 维数网格上的 LOO rho 稳定性.
附加: Mantel LOO (点估计) — 检查 "距离层不相关" 是否也被离群被试掩盖
      (若去掉某被试后 Mantel r 跳到 0.4+, 原 n.s. 结论可能是离群假象).

判定:
  robust         : 所有 LOO 折 delta < 0.15 且 p < 0.05, 且无单被试贡献 > 40%
  outlier-driven : 存在折 delta >= 0.15, 或单被试贡献 > 40%

输出: outputs/results/diag_cca_loo_robustness.json

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/diag_cca_loo_robustness.py
"""
import sys
import json
import argparse
from pathlib import Path

import numpy as np
import torch
from scipy.stats import pearsonr

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from core.models.latent_diffusion.model_shared import (
    SharedBackboneConfig, SharedVAEUNetLDM1D)
from style_vae import load_style_vae
from diag_style_cov_cca import (
    subject_covariances, logm_sym, log_euclid_dist, euclid_dist, _offdiag)

import importlib.util


def _load_ev():
    spec = importlib.util.spec_from_file_location(
        'evaluate_sb_ldm_3datasets',
        str(PROJECT_ROOT / 'projects/tc_conf_ldm/scripts/SB-LDM/evaluate_sb_ldm_3datasets.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


DEVICE = torch.device('cpu')  # 诊断脚本用 CPU, 不与训练/评估抢 GPU


# ============================================================
# Ridge CCA (SVD 形式, 返回第一典型相关 + 两个方向向量)
# ============================================================

def ridge_cca(X, Y, lam):
    """X:(n,p) Y:(n,q) 需已中心化. 返回 (rho, a, b).

    Sxx = X'X/n + lam*I (SPD), A = Sxx^{-1/2}; 同理 B = Syy^{-1/2}
    K = A Sxy B, rho = K 的第一奇异值, a = A u1, b = B v1
    (lam->0 退化为标准 CCA)
    """
    n, p = X.shape
    q = Y.shape[1]
    Sxx = X.T @ X / n + lam * np.eye(p)
    Syy = Y.T @ Y / n + lam * np.eye(q)
    Sxy = X.T @ Y / n
    dx, Qx = np.linalg.eigh(Sxx)
    dy, Qy = np.linalg.eigh(Syy)
    A = (Qx * (1.0 / np.sqrt(dx))) @ Qx.T
    B = (Qy * (1.0 / np.sqrt(dy))) @ Qy.T
    U, S, Vt = np.linalg.svd(A @ Sxy @ B)
    return float(S[0]), A @ U[:, 0], B @ Vt[0]


def cca_perm_p(X, Y, lam, n_perm=1000, seed=42):
    """置换检验: 打乱 Y 的行 (被试级配对), rho >= 观测值的比例."""
    rng = np.random.RandomState(seed)
    rho_obs = ridge_cca(X, Y, lam)[0]
    cnt = 0
    for _ in range(n_perm):
        Yp = Y[rng.permutation(len(Y))]
        if ridge_cca(X, Yp, lam)[0] >= rho_obs - 1e-12:
            cnt += 1
    return rho_obs, cnt / n_perm


def pca_feats(logm_list, k):
    """logm 上三角展开 -> 中心化 -> PCA(k). 返回 (n, k)."""
    m = logm_list[0].shape[0]
    F = np.stack([m_[np.triu_indices(m)] for m_ in logm_list])
    Fc = F - F.mean(0)
    U, S, Vt = np.linalg.svd(Fc, full_matrices=False)
    k = min(k, Vt.shape[0])
    return Fc @ Vt[:k].T


# ============================================================
# 主流程
# ============================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--p2_ckpt', type=str,
                        default='checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p2/sb_sd_ldm_p2_epoch_500.pt')
    parser.add_argument('--p4_ckpt', type=str,
                        default='checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p4/style_vae_final.pt')
    parser.add_argument('--lam', type=float, default=0.5)
    parser.add_argument('--pca_k', type=int, default=6)
    parser.add_argument('--n_perm', type=int, default=1000)
    args = parser.parse_args()

    print('=' * 72)
    print(f'CCA LOO 稳健性检查 (lam={args.lam}, PCA k={args.pca_k}, '
          f'perm={args.n_perm})')
    print('=' * 72)

    # 1) 模型 (仅取 subj_embed / StyleEncoder)
    ckpt = torch.load(str(PROJECT_ROOT / args.p2_ckpt), map_location=DEVICE,
                      weights_only=False)
    model_cfg = ckpt['config'].get('model', {})
    backbone = SharedBackboneConfig(
        base=int(model_cfg.get('backbone_base', 64)),
        levels=tuple(int(x) for x in model_cfg.get('backbone_levels', [1, 2, 4])),
        blocks_per_level=int(model_cfg.get('backbone_blocks_per_level', 2)),
    )
    model = SharedVAEUNetLDM1D(
        channels=22, input_length=1000,
        z_channels=int(model_cfg.get('z_channels', 64)),
        timesteps=int(model_cfg.get('timesteps', 1000)),
        t_dim=int(model_cfg.get('t_dim', 128)),
        cond_dim=int(model_cfg.get('cond_embed_dim', 64)),
        backbone=backbone,
        num_subjects=ckpt.get('num_subjects', 9),
        adv_alpha=0.0, subj_dim=ckpt.get('subj_dim', 32), disentangle=True,
    ).to(DEVICE)
    model.load_state_dict(ckpt['model_state_dict'])
    model.eval()
    W_subj = model.subj_embed.weight.detach().cpu().numpy()  # (9, 32)

    style_enc, _, sigma0 = load_style_vae(
        PROJECT_ROOT / args.p4_ckpt, channels=22, input_length=1000,
        num_classes=4, device=DEVICE)

    # 2) 数据 (与模型训练同口径)
    ev = _load_ev()
    X, y, subjects, sessions = ev.load_dataset_data('bci2a')
    subj_uniq = np.unique(subjects)
    if subj_uniq.max() != len(subj_uniq) - 1:
        remap = {s: i for i, s in enumerate(subj_uniq)}
        subjects = np.array([remap[s] for s in subjects])
    n_subj = len(np.unique(subjects))
    print(f'被试数={n_subj}, W_subj={W_subj.shape}, sigma0={sigma0}')

    # 3) 被试级表示
    logm_all, s_all = [], []
    with torch.no_grad():
        for s in range(n_subj):
            m = subjects == s
            Xs = X[m]
            logm_all.append(logm_sym(subject_covariances(Xs)))
            mus = []
            for i in range(0, len(Xs), 64):
                xb = torch.FloatTensor(Xs[i:i + 64]).to(DEVICE)
                mu_s, _ = style_enc(xb)
                mus.append(mu_s.cpu().numpy())
            s_all.append(np.concatenate(mus).mean(0))
    W_subj = W_subj[:n_subj]
    s_all = np.stack(s_all)
    reps = {'W_subj': W_subj, 's_bar(all)': s_all}
    D_cov = log_euclid_dist(logm_all)

    # ==========================================================
    # [1]+[2] 全量 CCA + 贡献分解 + LOO 折
    # ==========================================================
    full, contrib_all, loo = {}, {}, {}
    for name, Fx in reps.items():
        Yp = pca_feats(logm_all, args.pca_k)
        Xc = Fx - Fx.mean(0)
        rho, a, b = ridge_cca(Xc, Yp, args.lam)
        u, v = Xc @ a, Yp @ b
        r_emp = float(pearsonr(u, v)[0])
        zu = (u - u.mean()) / (u.std() + 1e-12)
        zv = (v - v.mean()) / (v.std() + 1e-12)
        contrib = zu * zv / (len(u) - 1)      # Σ contrib = r_emp (Pearson 恒等式)

        print(f'\n--- [{name}] 全量 CCA: ridge rho={rho:.3f}, '
              f'score corr={r_emp:.3f} ---')
        print('  逐被试贡献 (Σ=r):')
        for i in range(n_subj):
            frac = contrib[i] / (r_emp + 1e-12)
            bar = '#' * int(max(frac, 0) * 50)
            print(f'    被试{i+1}: {contrib[i]:+.3f} ({frac * 100:5.1f}%) {bar}')
        contrib_all[name] = contrib.tolist()

        # LOO 折 (PCA 每折重拟合, 防止被丢被试的信息经 PCA 基泄漏)
        folds = []
        print(f'  LOO 折 (n=8):')
        for i in range(n_subj):
            keep = [j for j in range(n_subj) if j != i]
            Xk = Fx[keep] - Fx[keep].mean(0)
            Yk = pca_feats([logm_all[j] for j in keep], args.pca_k)
            rho_i, p_i = cca_perm_p(Xk, Yk, args.lam, n_perm=args.n_perm)
            delta = rho - rho_i
            folds.append({'dropped': i, 'rho': rho_i, 'p': p_i, 'delta': delta})
            flag = ' <-- 崩塌' if delta >= 0.15 else ''
            print(f'    去掉被试{i+1}: rho={rho_i:.3f} (p={p_i:.4f}) '
                  f'delta={delta:+.3f}{flag}')
        full[name] = {'rho': rho, 'score_corr': r_emp,
                      'scores_x': u.tolist(), 'scores_y': v.tolist()}
        loo[name] = folds

    # ==========================================================
    # [3] 超参敏感性 (lam × PCA k 网格, LOO 点估计)
    # ==========================================================
    print(f'\n--- [3] 超参敏感性 (LOO rho 的 mean/min, 网格扫描) ---')
    sens = {}
    for name, Fx in reps.items():
        for lam_s in (0.1, 0.5, 1.0):
            for k_s in (4, 6):
                rhos = []
                for i in range(n_subj):
                    keep = [j for j in range(n_subj) if j != i]
                    Xk = Fx[keep] - Fx[keep].mean(0)
                    Yk = pca_feats([logm_all[j] for j in keep], k_s)
                    rhos.append(ridge_cca(Xk, Yk, lam_s)[0])
                key = f'{name}|lam{lam_s}|k{k_s}'
                sens[key] = {'mean': float(np.mean(rhos)),
                             'min': float(np.min(rhos)),
                             'max': float(np.max(rhos))}
                print(f'  {key:28s} mean={np.mean(rhos):.3f} '
                      f'min={np.min(rhos):.3f} max={np.max(rhos):.3f}')

    # ==========================================================
    # 附加: Mantel LOO (距离层不相关是否被离群掩盖)
    # ==========================================================
    print(f'\n--- 附加: Mantel LOO (点估计, 检查掩盖效应) ---')
    mantel_loo = {}
    for name, Fx in reps.items():
        D_sty = euclid_dist(Fx)
        rows = []
        for i in range(n_subj):
            keep = [j for j in range(n_subj) if j != i]
            r_i = float(pearsonr(
                _offdiag(D_sty[np.ix_(keep, keep)]),
                _offdiag(D_cov[np.ix_(keep, keep)]))[0])
            rows.append({'dropped': i, 'r': r_i})
        best = max(rows, key=lambda r: r['r'])
        mantel_loo[name] = {'folds': rows, 'max_loo_r': best['r'],
                            'at_dropped': best['dropped'],
                            'possibly_masked': bool(best['r'] > 0.4)}
        print(f'  {name}: LOO r 范围 [{min(r["r"] for r in rows):+.3f}, '
              f'{max(r["r"] for r in rows):+.3f}], 最大值出现在去掉被试'
              f'{best["dropped"] + 1} (r={best["r"]:+.3f})'
              f'{" <-- 可能被离群掩盖!" if best["r"] > 0.4 else ""}')

    # ==========================================================
    # 判定
    # ==========================================================
    print('\n' + '=' * 72)
    verdict = {}
    for name in reps:
        deltas = [f['delta'] for f in loo[name]]
        r_emp = full[name]['score_corr']
        contrib = np.array(contrib_all[name])
        max_frac = float(contrib.max() / (r_emp + 1e-12))
        robust = (max(deltas) < 0.15) and (max_frac < 0.4) and \
                 all(f['p'] < 0.05 for f in loo[name])
        verdict[name] = {
            'delta_max': float(max(deltas)),
            'worst_fold_dropped': int(np.argmax(deltas)),
            'min_loo_rho': float(min(f['rho'] for f in loo[name])),
            'max_contrib_frac': max_frac,
            'top_contributor': int(np.argmax(contrib)),
            'all_loo_p_lt_005': bool(all(f['p'] < 0.05 for f in loo[name])),
            'robust': bool(robust)}
        v = verdict[name]
        print(f"[{name}] {'稳健 (非离群驱动)' if robust else '离群驱动嫌疑!'}: "
              f"max_delta={v['delta_max']:.3f} (去掉被试{v['worst_fold_dropped'] + 1}), "
              f"min_LOO_rho={v['min_loo_rho']:.3f}, "
              f"最大单被试贡献={v['max_contrib_frac'] * 100:.1f}% "
              f"(被试{v['top_contributor'] + 1})")
    print('=' * 72)

    out = PROJECT_ROOT / 'outputs/results/diag_cca_loo_robustness.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, 'w', encoding='utf-8') as f:
        json.dump({
            'n_subjects': int(n_subj),
            'lam': args.lam, 'pca_k': args.pca_k, 'n_perm': args.n_perm,
            'full_cca': full,
            'per_subject_contribution': contrib_all,
            'loo': loo,
            'sensitivity': sens,
            'mantel_loo': mantel_loo,
            'verdict': verdict,
        }, f, indent=2, ensure_ascii=False)
    print(f'结果已保存: {out}')


if __name__ == '__main__':
    main()
