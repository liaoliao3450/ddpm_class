#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
生成质量 5 指标评估 — SSD-LDM 期刊管线版 (BCI2a)
================================================
背景: outputs/results/gen_quality_evaluation_bci2a.json (2026-07-25) 的
sb_sd_ldm 行使用旧条件嵌入路径 (generate_mixed_difficulty, 无
StyleEncoder / CovChart / L1-L3 对齐融合), 不代表期刊 SSD-LDM 方法.

本脚本重算 SSD-LDM 行, 生成端与 Table III / fig_quality.py 完全一致:
  逐 LOSO 折 (9 折), few-shot 风格估计 (40 无标签 trials, teacher 伪标签),
  generate_p5(mode='cov_only', z_source='encoder', latent_match=True,
  amp_calib='full') = L1 潜空间矩匹配 + L2 CovChart 协方差条件风格
  + L3 白化-重着色. 每折 11 样本/类 -> 9 x 11 x 4 = 396 (baseline 为 400).

评估协议 (复用 2_gen_quality_evaluation_tc_conf_ldm.py, 与 ERD-DDPM /
SB-LDM 前作一致):
  真实数据 = BCI2a session-0 (2592 trials, 9 subjects pooled);
  初始 EEGNet 仅用真实数据训练, 再用 真实+全部方法生成数据 联合微调;
  特征 = 微调后 EEGNet 中间层; 指标 = Inter / Intra / Sep / FID / MMD.

SSD-LDM 样本不做 normalize_generated_data_to_real_stats:
  L3 已做二阶精确校准, 外部逐通道归一化会破坏协方差匹配;
  baseline 样本的归一化沿用前作协议.

Usage (NUMBA_CACHE_DIR 必须先设置, 否则 umap/numba 在沙箱下挂起):
  $env:NUMBA_CACHE_DIR='F:\DS-DDPM-main\outputs\numba_cache'
  $env:PYTHONUTF8='1'
  python -u projects/tc_conf_ldm/scripts/SB-SD-LDM/gen_quality_5metrics_journal.py
"""
import sys
import json
import importlib.machinery
from pathlib import Path

import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from core.classifiers.eegnet import EEGNet

# ---- 期刊管线组件 (与 fig_quality.py 一致) ----
from style_vae import load_style_vae
from style_vae_cov import load_p5
from evaluate_p4_cross_subject import load_p2_model, set_seed, DEVICE
from evaluate_p5_cross_subject import generate_p5

# ---- 复用 2_gen 质量评估协议 ----
_GEN2 = PROJECT_ROOT / 'projects/tc_conf_ldm/scripts/2_gen_quality_evaluation_tc_conf_ldm.py'
gen2 = importlib.machinery.SourceFileLoader(
    'gen2_protocol', str(_GEN2)).load_module()

DATASET = 'bci2a'
NUM_CLASSES = 4
N_FEWSHOT = 40
SPC_PER_FOLD = 11            # 9 折 x 11/类 = 396 ≈ baseline 400
BASELINE_KEYS = ['cvae', 'wavegan', 'cond_ddpm', 'braindiff',
                 'eegdiff', 'diffeegbooth']
N_PER_CLASS_BASELINE = 100

P2_CKPT = PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p2/sb_sd_ldm_p2_epoch_500.pt'
P4_CKPT = PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p4/style_vae_final.pt'
P5_CKPT = PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p5/cov_chart_final.pt'
TEACHER_CKPT = PROJECT_ROOT / 'checkpoints/tc_conf_ldm/bci2a_shared_margin/pretrained_teacher_eegnet.pt'

RESULTS_DIR = PROJECT_ROOT / 'outputs/results'
OUT_JSON = RESULTS_DIR / 'gen_quality_evaluation_bci2a_journal.json'


def load_teacher():
    teacher = EEGNet(n_channels=22, n_samples=1000, n_classes=4).to(DEVICE)
    state = torch.load(str(TEACHER_CKPT), map_location=DEVICE, weights_only=False)
    if isinstance(state, dict) and 'model_state_dict' in state:
        state = state['model_state_dict']
    teacher.load_state_dict(state, strict=False)
    teacher.eval()
    return teacher


def main():
    set_seed()

    # ---- 1. 真实数据: session-0, 2592 trials (与 2_gen 协议一致) ----
    X, y, subjects, sessions = gen2.load_dataset_data(DATASET)
    sessions = np.asarray(sessions)
    subjects = np.asarray(subjects)
    subj_uniq = np.unique(subjects)
    if subj_uniq.max() != len(subj_uniq) - 1:
        remap = {s: i for i, s in enumerate(subj_uniq)}
        subjects = np.array([remap[s] for s in subjects])
    sess0 = sessions == 0
    X_real, y_real = X[sess0], y[sess0]
    subjects_real = subjects[sess0]
    n_subj = len(np.unique(subjects_real))
    channels, input_length = X_real.shape[1], X_real.shape[2]
    print(f'真实数据 (session 0): {X_real.shape}, 被试数 {n_subj}, '
          f'类别分布 {np.bincount(y_real)}')

    # ---- 2. 期刊模型 (P2 主干 + P4 StyleEncoder + P5 CovChart) ----
    print('\n加载期刊管线模型...')
    model, cond_embed = load_p2_model(P2_CKPT)
    style_enc, _, _ = load_style_vae(P4_CKPT, channels=22, input_length=1000,
                                     num_classes=4, device=DEVICE)
    chart, covemb, sigma0_p5 = load_p5(P5_CKPT, device=DEVICE)
    teacher = load_teacher()
    W_subj = model.subj_embed.weight.detach()

    # ---- 3. SSD-LDM 期刊管线生成 (逐 LOSO 折, few-shot 40 无标签 trials) ----
    print(f'\nSSD-LDM 期刊管线生成: {n_subj} 折 x {SPC_PER_FOLD} 样本/类')
    parts_X, parts_y, fold_log = [], [], []
    for s in range(n_subj):
        m_test = subjects_real == s
        X_few = X_real[m_test][:N_FEWSHOT]
        with torch.no_grad():
            xb = torch.FloatTensor(X_few).unsqueeze(1).to(DEVICE)
            y_pl = teacher(xb).argmax(1).cpu().numpy()
        m_train = ~m_test
        X_pool, y_pool = X_real[m_train], y_real[m_train]
        train_ids = [i for i in range(n_subj) if i != s]
        set_seed()
        gX, gy = generate_p5(
            model, cond_embed, style_enc, chart, covemb,
            SPC_PER_FOLD, NUM_CLASSES, 'cov_only', train_ids, W_subj,
            X_few=X_few, sigma0=sigma0_p5,
            z_source='encoder', X_pool=X_pool, y_pool=y_pool,
            latent_match=True, X_few_pl=X_few, y_few_pl=y_pl,
            amp_calib='full')
        gX = np.nan_to_num(gX.astype(np.float32), nan=0.0)
        parts_X.append(gX)
        parts_y.append(np.asarray(gy))
        r_real = float(np.sqrt((X_real[m_test] ** 2).mean()))
        r_gen = float(np.sqrt((gX ** 2).mean()))
        fold_log.append({'subject': int(s), 'n': int(len(gX)),
                         'rms_ratio': r_gen / r_real})
        print(f'  折 S{s + 1}: {gX.shape}, RMS 比 {r_gen / r_real:.3f}')
    X_ours = np.concatenate(parts_X, axis=0)
    y_ours = np.concatenate(parts_y, axis=0)
    print(f'SSD-LDM 样本合计: {X_ours.shape} (不做外部归一化, L3 已校准)')

    # ---- 4. baseline 样本 (协议与 2_gen / 前作一致) ----
    gen_data_dict, gen_labels_dict = {}, {}
    X_g, y_g = gen2.generate_gaussian_samples(X_real, y_real, NUM_CLASSES,
                                              N_PER_CLASS_BASELINE)
    gen_data_dict['gaussian'] = (X_g, y_g)
    X_g, y_g = gen2.generate_smote_samples(X_real, y_real, NUM_CLASSES,
                                           N_PER_CLASS_BASELINE)
    gen_data_dict['smote'] = (X_g, y_g)
    for key in BASELINE_KEYS:
        X_g, y_g = gen2.load_precomputed_samples(DATASET, key)
        if X_g is None:
            print(f'  [警告] {key} 样本未找到, 跳过')
            continue
        if X_g.shape[1] != channels:
            print(f'  [警告] {key} 通道数不匹配, 跳过')
            continue
        if X_g.shape[2] > input_length:
            X_g = X_g[:, :, :input_length]
        elif X_g.shape[2] < input_length:
            pad = input_length - X_g.shape[2]
            X_g = np.pad(X_g, ((0, 0), (0, 0), (0, pad)), mode='constant')
        X_g = gen2.normalize_generated_data_to_real_stats(X_real, X_g)
        gen_data_dict[key] = (X_g, y_g)
    # ---- 4b. ERD-DDPM (前作, 预生成样本) + SB-LDM (会议版模型) ----
    # ERD-DDPM: outputs/samples/bci2a/ddpm_samples.npy (best_class_discriminative.pt
    # + ERD 引导生成), 与其他 baseline 同样归一化到真实统计
    X_g, y_g = gen2.load_precomputed_samples(DATASET, 'ddpm')
    if X_g is not None:
        if X_g.shape[2] > input_length:
            X_g = X_g[:, :, :input_length]
        elif X_g.shape[2] < input_length:
            pad = input_length - X_g.shape[2]
            X_g = np.pad(X_g, ((0, 0), (0, 0), (0, pad)), mode='constant')
        X_g = gen2.normalize_generated_data_to_real_stats(X_real, X_g)
        gen_data_dict['erd_ddpm'] = (X_g, y_g)
        print(f'  ERD-DDPM: {X_g.shape}')
    else:
        print('  [警告] ERD-DDPM 样本未找到, 跳过')

    # SB-LDM: 会议版模型生成 (会议全局 z-score 空间), 再归一化到 gen2 真实统计
    for _p in (str(PROJECT_ROOT / 'core' / 'models' / 'baselines'),
               str(PROJECT_ROOT / 'core' / 'models' / 'ddpm'),
               str(PROJECT_ROOT)):
        if _p not in sys.path:
            sys.path.insert(0, _p)
    _conf_path = (PROJECT_ROOT / 'projects/tc_conf_ldm/scripts/SB-LDM'
                  / 'SB_generate_quality_figures.py')
    _spec = importlib.machinery.SourceFileLoader(
        'sb_gen_quality_q5', str(_conf_path)).load_module()
    _spec.PROJECT_ROOT = PROJECT_ROOT
    _spec.BASELINE_CKPT_DIR = PROJECT_ROOT / 'checkpoints' / 'baselines'
    model_sbl, cond_sbl, ch_sbl, len_sbl, cd_sbl = _spec.load_sb_ldm_model()
    gX, gy = _spec.generate_samples(
        model_sbl, cond_sbl, n_per_class=N_PER_CLASS_BASELINE,
        cond_dim=cd_sbl, channels=ch_sbl, input_length=len_sbl)
    del model_sbl, cond_sbl
    torch.cuda.empty_cache()
    gX = gen2.normalize_generated_data_to_real_stats(X_real, gX)
    gen_data_dict['sb_ldm'] = (gX.astype(np.float32), gy)
    print(f'  SB-LDM: {gX.shape}')

    gen_data_dict['sb_sd_ldm'] = (X_ours, y_ours)

    # ---- 5. EEGNet 特征提取器: 初始训练 + 联合微调 ----
    clf = gen2.train_feature_extractor(X_real, y_real, NUM_CLASSES,
                                       channels, input_length)
    clf = gen2.finetune_classifier(
        clf, X_real, y_real,
        {k: v[0] for k, v in gen_data_dict.items()},
        {k: v[1] for k, v in gen_data_dict.items()})
    real_feat = gen2.extract_features(clf, X_real)

    # ---- 6. 指标 ----
    print('\n计算 5 指标...')
    metrics_dict = {}
    for key, (Xg, yg) in gen_data_dict.items():
        gf = gen2.extract_features(clf, Xg)
        metrics_dict[key] = gen2.evaluate_method(real_feat, y_real, gf, yg,
                                                 NUM_CLASSES)
        m = metrics_dict[key]
        print(f"  {key:14s} Inter={m['inter_class_distance']:.2f} "
              f"Intra={m['intra_class_distance']:.2f} "
              f"Sep={m['separation_ratio']:.3f} "
              f"FID={m['fid']:.2f} MMD={m['mmd']:.4f}")

    real_row = {
        'inter_class_distance': gen2.compute_inter_class_distance(
            real_feat, y_real, NUM_CLASSES),
        'intra_class_distance': gen2.compute_intra_class_distance(
            real_feat, y_real, NUM_CLASSES),
    }
    real_row['separation_ratio'] = (
        real_row['inter_class_distance']
        / (real_row['intra_class_distance'] + 1e-8))
    print(f"  {'real (ref.)':14s} Inter={real_row['inter_class_distance']:.2f} "
          f"Intra={real_row['intra_class_distance']:.2f} "
          f"Sep={real_row['separation_ratio']:.3f}")

    # ---- 7. 保存 ----
    out = {
        'dataset': DATASET,
        'protocol': ('期刊管线: SSD-LDM = generate_p5 cov_only + latent_match '
                     '(L1) + chart 风格 (L2) + amp_calib=full (L3), 逐 LOSO 折 '
                     'few-shot 40 无标签 trials; 其余协议与 '
                     'gen_quality_evaluation_bci2a.json (2026-07-25) 一致'),
        'ssd_ldm_generation': {
            'n_folds': n_subj, 'spc_per_fold': SPC_PER_FOLD,
            'total': int(len(X_ours)),
            'post_normalization': ('none (L3 二阶精确校准, '
                                   '外部归一化会破坏协方差匹配)'),
            'per_fold_rms_ratio': fold_log,
        },
        'real_reference': {'n': int(len(X_real)), 'session': 0,
                           'metrics': real_row},
        'methods': metrics_dict,
    }
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    with open(OUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    print(f'\n结果已保存: {OUT_JSON}')

    # ---- 8. LaTeX 表 ----
    name_map = {'gaussian': 'Gaussian Noise', 'smote': 'SMOTE', 'cvae': 'CVAE',
                'wavegan': 'WaveGAN', 'cond_ddpm': 'Cond-DDPM',
                'braindiff': 'BrainDiff', 'eegdiff': 'EEGDiffuser',
                'diffeegbooth': 'DiffEEGBooth', 'erd_ddpm': 'ERD-DDPM',
                'sb_ldm': 'SB-LDM',
                'sb_sd_ldm': r'\textbf{SSD-LDM (Ours)}'}
    print('\n% ---- LaTeX table ----')
    print(r'\begin{tabular}{lccccc}')
    print(r'\toprule')
    print(r'Method & Inter$\uparrow$ & Intra$\downarrow$ & Sep.$\uparrow$ '
          r'& FID$\downarrow$ & MMD$\downarrow$ \\')
    print(r'\midrule')
    print(f"Real (ref.) & {real_row['inter_class_distance']:.2f} & "
          f"{real_row['intra_class_distance']:.2f} & "
          f"{real_row['separation_ratio']:.2f} & --- & --- \\\\")
    for key in ['gaussian', 'smote', 'cvae', 'wavegan', 'cond_ddpm',
                'braindiff', 'eegdiff', 'diffeegbooth', 'erd_ddpm',
                'sb_ldm', 'sb_sd_ldm']:
        if key not in metrics_dict:
            continue
        m = metrics_dict[key]
        print(f"{name_map[key]} & {m['inter_class_distance']:.2f} & "
              f"{m['intra_class_distance']:.2f} & {m['separation_ratio']:.2f} & "
              f"{m['fid']:.2f} & {m['mmd']:.4f} \\\\")
    print(r'\bottomrule')
    print(r'\end{tabular}')


if __name__ == '__main__':
    main()
