#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
P5 诊断 3: amp_calib full 白化-重着色为何对部分被试失效
===============================================================
现象 (ea_latentEA_combo.log): 被试 4 d_gen=0.0046 (精确), 被试 1-3
  d_gen=5.5-8.5 (失效). 数学上 W R_gen W^T = R_tgt 是恒等式, 失效只能是:
  (a) decoder 输出含 NaN/Inf/巨大离群 trial -> R_gen_all 污染
  (b) float32 协方差精度 x 病态条件数放大
  (c) nan_to_num 在校准后改写数据

插桩 (复现 combo 第 1 折, spc=1152):
  1. 原始生成批: NaN/Inf 计数, 逐 trial 幅度分布 (离群识别)
  2. R_gen_all: 特征值谱, 条件数
  3. float32 vs float64 协方差路径对比
  4. 手工 full 校准: W 谱, 校准后 d_logEuclid (float64 全程)
  5. 修复候选: 离群 trial 裁剪后再校准

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/diag_p5_calib.py
"""
import sys
from pathlib import Path

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from style_vae import load_style_vae
from style_vae_cov import load_p5, compute_subject_R
from evaluate_p4_cross_subject import load_p2_model, set_seed, DEVICE
from evaluate_p5_cross_subject import generate_p5
from diag_style_cov_cca import logm_sym

import importlib.util


def _load_ev():
    spec = importlib.util.spec_from_file_location(
        'evaluate_sb_ldm_3datasets',
        str(PROJECT_ROOT / 'projects/tc_conf_ldm/scripts/SB-LDM/evaluate_sb_ldm_3datasets.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def log_euclid(Ra, Rb):
    return float(np.linalg.norm(logm_sym(Ra) - logm_sym(Rb)))


def sqrtm_sym(R, eps=1e-8):
    R = (R + R.T) / 2.0
    w, V = np.linalg.eigh(R)
    w = np.clip(w, eps, None)
    return (V * np.sqrt(w)) @ V.T


def main():
    set_seed()
    ev = _load_ev()

    model, cond_embed = load_p2_model(
        PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p2/sb_sd_ldm_p2_epoch_500.pt')
    W_subj = model.subj_embed.weight.detach()
    style_enc, _, sigma0_p4 = load_style_vae(
        PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p4/style_vae_final.pt',
        channels=22, input_length=1000, num_classes=4, device=DEVICE)
    chart, covemb, sigma0_p5 = load_p5(
        PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p5/cov_chart_final.pt',
        device=DEVICE)

    from core.classifiers.eegnet import EEGNet
    teacher_ckpt = PROJECT_ROOT / 'checkpoints/tc_conf_ldm/bci2a_shared_margin/pretrained_teacher_eegnet.pt'
    teacher = EEGNet(n_channels=22, n_samples=1000, n_classes=4).to(DEVICE)
    state = torch.load(str(teacher_ckpt), map_location=DEVICE, weights_only=False)
    if isinstance(state, dict) and 'model_state_dict' in state:
        state = state['model_state_dict']
    teacher.load_state_dict(state, strict=False)
    teacher.eval()

    X, y, subjects, sessions = ev.load_dataset_data('bci2a')
    subj_uniq = np.unique(subjects)
    if subj_uniq.max() != len(subj_uniq) - 1:
        remap = {s: i for i, s in enumerate(subj_uniq)}
        subjects = np.array([remap[s] for s in subjects])
    n_subj = len(np.unique(subjects))

    for test_subj in [0, 3]:        # 被试 1 (失效) vs 被试 4 (正常)
        m_test = subjects == test_subj
        X_few = X[m_test][:40]
        with torch.no_grad():
            xb = torch.FloatTensor(X_few).unsqueeze(1).to(DEVICE)
            y_few_pl = teacher(xb).argmax(1).cpu().numpy()
        R_test = compute_subject_R(X_few)

        m_train = subjects != test_subj
        X_pool, y_pool = X[m_train], y[m_train]
        train_subj_ids = [int(s) for s in np.unique(subjects[m_train])]

        spc = max(1, int(1.0 * len(X_pool)) // 4)
        set_seed()
        gen_X, gen_y = generate_p5(
            model, cond_embed, style_enc, chart, covemb,
            spc, 4, 'cov_only', train_subj_ids, W_subj,
            X_few=X_few, sigma0=sigma0_p5,
            z_source='encoder', X_pool=X_pool, y_pool=y_pool,
            latent_match=True, X_few_pl=X_few, y_few_pl=y_few_pl,
            amp_calib='none')           # 关校准, 拿原始批
        gen_X = gen_X.astype(np.float32)

        print('\n' + '=' * 70)
        print(f'被试 {test_subj+1} (combo d_gen: '
              f'{"5.50 失效" if test_subj == 0 else "0.0046 正常"})')
        print('=' * 70)

        # 1. 原始生成批健康检查
        n_nan = int(np.isnan(gen_X).sum())
        n_inf = int(np.isinf(gen_X).sum())
        amps = np.sqrt((gen_X ** 2).mean(axis=(1, 2)))
        med, p99, mx = np.median(amps), np.percentile(amps, 99), amps.max()
        print(f'[1] 生成批: shape={gen_X.shape}, NaN={n_nan}, Inf={n_inf}')
        print(f'    逐 trial RMS幅度: median={med:.3f}, p99={p99:.3f}, '
              f'max={mx:.3f} (max/median={mx/max(med,1e-9):.1f}x)')

        # 2. R_gen_all 谱
        R_gen32 = compute_subject_R(gen_X)
        R_gen64 = compute_subject_R(gen_X.astype(np.float64))
        for tag, R in [('float32', R_gen32), ('float64', R_gen64)]:
            w = np.linalg.eigvalsh((R + R.T) / 2)
            w_c = np.clip(w, 1e-12, None)
            print(f'[2] R_gen({tag}): eig [{w_c.min():.3e}, {w_c.max():.3e}], '
                  f'cond={w_c.max()/w_c.min():.2e}')
        print(f'    R_test eig: [{np.linalg.eigvalsh(R_test).min():.3e}, '
              f'{np.linalg.eigvalsh(R_test).max():.3e}]')

        # 3. float64 全程校准 (排除精度因素)
        W64 = sqrtm_sym(R_test) @ np.linalg.inv(sqrtm_sym(R_gen64))
        out64 = np.einsum('cd,ndt->nct', W64,
                          gen_X.astype(np.float64)).astype(np.float32)
        d64 = log_euclid(compute_subject_R(out64), R_test)
        print(f'[3] float64 校准: d_logEuclid={d64:.4f}')

        # 4. float32 路径 (复现 combo 现象)
        W32 = sqrtm_sym(R_test) @ np.linalg.inv(sqrtm_sym(R_gen32))
        out32 = np.einsum('cd,ndt->nct', W32, gen_X).astype(np.float32)
        d32 = log_euclid(compute_subject_R(out32), R_test)
        print(f'[4] float32 校准 (combo 路径): d_logEuclid={d32:.4f}')

        # 5. 离群裁剪修复: RMS > 5x median 的 trial 幅度缩到 5x
        thr = 5.0 * med
        n_out = int((amps > thr).sum())
        if n_out > 0:
            fix = gen_X.copy()
            scale = np.minimum(1.0, thr / np.maximum(amps, 1e-9))
            fix = fix * scale[:, None, None]
            R_fix = compute_subject_R(fix.astype(np.float64))
            W_fix = sqrtm_sym(R_test) @ np.linalg.inv(sqrtm_sym(R_fix))
            out_fix = np.einsum('cd,ndt->nct', W_fix,
                                fix.astype(np.float64)).astype(np.float32)
            d_fix = log_euclid(compute_subject_R(out_fix), R_test)
            print(f'[5] 离群裁剪: {n_out}/{len(amps)} trial 超 5x median; '
                  f'裁剪后校准 d={d_fix:.4f}')

        # 6. nan_to_num 影响检查
        n_nan_out = int(np.isnan(out32).sum())
        n_inf_out = int(np.isinf(out32).sum())
        print(f'[6] 校准后输出: NaN={n_nan_out}, Inf={n_inf_out} '
              f'(nan_to_num 会改写它们)')


if __name__ == '__main__':
    main()
