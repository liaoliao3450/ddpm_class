# PhysioNet Table III 评测看守: 等训练链产出 P5 checkpoint 后自动执行评测
# 等待: checkpoints/tc_conf_ldm/sb_sd_ldm_physionet_p5/cov_chart_final.pt
# 然后依次: journal_table3_arms.py --dataset physionet -> ea_latentEA_combo.py --dataset physionet
$ErrorActionPreference = 'Continue'
$env:PYTHONUTF8 = '1'
Set-Location F:\DS-DDPM-main
$logdir = 'F:\DS-DDPM-main\outputs\logs'
$scripts = 'F:\DS-DDPM-main\projects\tc_conf_ldm\scripts\SB-SD-LDM'
$status = "$logdir\journal_physionet_eval_status.txt"
$p5 = 'F:\DS-DDPM-main\checkpoints\tc_conf_ldm\sb_sd_ldm_physionet_p5\cov_chart_final.pt'

function Write-Status($msg) {
    $ts = Get-Date -Format 'HH:mm:ss'
    "[$ts] $msg" | Tee-Object -FilePath $status -Append
}

function Run-Step($name, $argList, $log) {
    Write-Status "$name START -> $log"
    $p = Start-Process -FilePath python -ArgumentList $argList `
        -RedirectStandardOutput "$logdir\$log" -RedirectStandardError "$logdir\$log.err" `
        -NoNewWindow -PassThru -Wait
    if ($p.ExitCode -ne 0) {
        Write-Status "$name FAILED (exit=$($p.ExitCode)), see $logdir\$log.err"
        return $false
    }
    Write-Status "$name DONE"
    return $true
}

Write-Status '===== PhysioNet eval watcher START ====='

# 等待 P5 产品 (最长 24h, 每 5 分钟检查)
$deadline = (Get-Date).AddHours(24)
while (-not (Test-Path $p5)) {
    if ((Get-Date) -gt $deadline) {
        Write-Status 'TIMEOUT waiting for P5 checkpoint - watcher exit'
        exit 1
    }
    Start-Sleep -Seconds 300
}
Write-Status "P5 checkpoint detected: $p5"
# 再等 2 分钟让链写完验收日志
Start-Sleep -Seconds 120

$ok = Run-Step 'physionet-arms' @('-u', "$scripts\journal_table3_arms.py", '--dataset', 'physionet') 'journal_physionet_arms.log'
if ($ok) {
    $ok = Run-Step 'physionet-ours' @('-u', "$scripts\ea_latentEA_combo.py", '--dataset', 'physionet') 'journal_physionet_ours.log'
}

if ($ok) {
    Write-Status '===== PhysioNet Table III eval COMPLETE ====='
} else {
    Write-Status '===== PhysioNet Table III eval STOPPED (failure) ====='
}
