#!/usr/bin/env python3
"""
将已经预处理好的 BCI2b .mat 文件转换为项目统一的 processed 结构。

假设每个 .mat 文件形如:
- 文件名: B01T.mat / B01E.mat / B02T.mat / ...
- 变量:
  - data: [N_trials, C, T]
  - label: [N_trials, 1] 或 [N_trials]

输出目录结构示例 (--output_dir data/processed/BCI2b):
- data/processed/BCI2b/X.npy
- data/processed/BCI2b/y.npy
- data/processed/BCI2b/B01T/X.npy
- data/processed/BCI2b/B01T/y.npy
- ...

这样即可与 `utils/data_loader_bci2b.py` 完全兼容。
"""

import os
import argparse
from pathlib import Path
from typing import List

import numpy as np
from scipy.io import loadmat


def convert_bci2b_mat(mat_dir: str, output_root: str) -> None:
    print(f"[BCI2b-mat] 输入 .mat 目录: {mat_dir}")
    print(f"[BCI2b-mat] 输出 processed 目录: {output_root}")

    if not os.path.isdir(mat_dir):
        raise FileNotFoundError(f"[BCI2b-mat] 错误: .mat 目录不存在: {mat_dir}")

    mat_files = sorted(
        f for f in os.listdir(mat_dir) if f.lower().endswith(".mat")
    )
    if not mat_files:
        raise RuntimeError(f"[BCI2b-mat] 错误: 在 {mat_dir} 下未找到任何 .mat 文件")

    print(f"[BCI2b-mat] 共找到 {len(mat_files)} 个 .mat 文件: {mat_files}")

    out_root = Path(output_root)
    out_root.mkdir(parents=True, exist_ok=True)

    all_X: List[np.ndarray] = []
    all_y: List[np.ndarray] = []

    for fname in mat_files:
        fpath = os.path.join(mat_dir, fname)
        print(f"\n[BCI2b-mat] 处理文件: {fname}")
        d = loadmat(fpath)

        if "data" not in d or "label" not in d:
            raise KeyError(f"[BCI2b-mat] {fname} 中未找到 'data' 或 'label' 变量")

        X = np.asarray(d["data"], dtype=np.float32)
        y = np.asarray(d["label"])

        if y.ndim > 1:
            y = y.squeeze()
        y = y.astype(np.int64)

        # 标签统一从 0 开始
        y = y - y.min()

        print(f"  data 形状: {X.shape}, dtype={X.dtype}")
        print(f"  label 形状: {y.shape}, 唯一值={np.unique(y).tolist()}")

        sub_name = os.path.splitext(fname)[0]  # 如 B01T / B01E
        sub_dir = out_root / sub_name
        sub_dir.mkdir(parents=True, exist_ok=True)

        np.save(sub_dir / "X.npy", X)
        np.save(sub_dir / "y.npy", y)
        print(f"  已保存: {sub_dir / 'X.npy'}, {sub_dir / 'y.npy'}")

        all_X.append(X)
        all_y.append(y)

    # 汇总保存整体 X/y 方便快速检查
    X_all = np.concatenate(all_X, axis=0)
    y_all = np.concatenate(all_y, axis=0)
    np.save(out_root / "X.npy", X_all)
    np.save(out_root / "y.npy", y_all)

    print("\n[BCI2b-mat] 汇总数据:")
    print(f"  X_all: {X_all.shape}, y_all: {y_all.shape}")
    print(f"  类别分布: {np.bincount(y_all).tolist()}")
    print(f"[BCI2b-mat] 转换完成，已写入: {out_root}")


def main() -> None:
    parser = argparse.ArgumentParser(description="将 BCI2b .mat 转换为 processed/BCI2b 结构")
    parser.add_argument("--mat_dir", type=str, required=True, help="原始 BCI2b .mat 文件目录 (例如 E:\\data\\BCI2b)")
    parser.add_argument(
        "--output_dir",
        type=str,
        default="data/processed/BCI2b",
        help="输出 processed/BCI2b 目录",
    )
    args = parser.parse_args()

    convert_bci2b_mat(args.mat_dir, args.output_dir)


if __name__ == "__main__":
    main()


