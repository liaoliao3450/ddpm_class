# SSD-LDM: Subject–Style Disentangled Latent Diffusion for Cross-Subject EEG Motor Imagery Augmentation

Reference implementation of the paper submitted to *IEEE Journal of Biomedical and Health
Informatics* (JBHI).

The model couples a **shared-backbone** VAE + latent diffusion model with three coupled
alignment levels:

- **L1 — latent moment matching** in the class-content latent `z`;
- **L2 — CovChart style rendering**, i.e. an SPD-constrained chart that maps a target
  covariance estimate to a style vector `s` injected only through FiLM at the decoder;
- **L3 — output calibration**, a closed-form whitening–recoloring operator applied at the
  generator output.

A gradient-reversal subject discriminator removes subject identity from `z`, and
class-conditional labels are injected through FiLM in the denoiser.

> **Note on L3.** The exact covariance match reported in the paper is a property of the
> closed-form whitening–recoloring operator, not something learned by the diffusion model.
> L1/L2 are the learned alignment components.

---

## Repository layout

```
.
├── core/
│   ├── classifiers/eegnet.py                  # EEGNet classifier used in every experiment
│   ├── models/latent_diffusion/model_shared.py# shared backbone: VAE + latent UNet + FiLM + GRL
│   ├── models/baselines/                      # CVAE / conditional-DDPM style baselines
│   ├── models/ddpm/                           # DDPM building blocks and classifier pretraining
│   └── data_processing/                       # raw → processed .npy preprocessing
├── utils/
│   ├── data_loader.py                         # BCI2a loader
│   ├── data_loader_bci2b.py                   # BCI2b loader
│   └── data_loader_physionet_mi4c.py          # PhysioNet MI (4-class) loader
├── experiments/paper_experiments/config.py    # dataset paths and label mapping
├── projects/tc_conf_ldm/
│   ├── configs/                               # model / training YAML files
│   ├── core/                                  # task-conditioning modules
│   └── scripts/
│       ├── SB-SD-LDM/                         # ★ paper code: training, evaluation, figures
│       └── SB-LDM/                            # shared-backbone baseline pipeline reused by figures
└── paper/                                     # LaTeX source of the manuscript
```

`projects/tc_conf_ldm/scripts/SB-SD-LDM/` is the code that produces the paper results.

`paper/` holds the LaTeX source of the manuscript. Rendering it also requires the figure
files produced by the `fig_*.py` scripts plus the two architecture images
(`sb-ldm-1`, `SSD-LDM`), which are not part of this repository.

| Stage | Script |
|---|---|
| Train (subject-style path, P1) | `train_sb_sd_ldm.py` |
| Train (disentanglement, P2) | `train_sb_sd_ldm_p2.py` |
| Train (align-fused, P4) | `train_sb_sd_ldm_p4.py` |
| Train (few-shot style, P5) | `train_sb_sd_ldm_p5.py` |
| Sanity checks | `validate_p1_style.py`, `validate_p2_decisive.py`, `validate_p2_disentangle.py` |
| Main 3-scenario table | `evaluate_sbsdldm_3scenarios.py` |
| Cross-subject evaluation | `evaluate_p3_cross_subject.py`, `evaluate_p4_cross_subject.py`, `evaluate_p5_cross_subject.py` |
| EA / alignment controls | `ea_baseline_loso.py`, `ea_gen_combo.py`, `ea_latentEA_combo.py` |
| Generation-quality metrics | `gen_quality_5metrics_journal.py` |
| Figures | `fig_framework_matplotlib.py`, `fig_protocol.py`, `fig_umap_methods.py`, `fig_erd_combined.py`, `fig_quality.py`, `fig_budget.py` |
| Ablation table | `journal_table3_arms.py` |

---

## Environment

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate      Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
```

The experiments were run with Python 3.10+ and PyTorch 2.x on a single NVIDIA RTX 3090.

## Data

Raw datasets are **not** redistributed here. Download them from their official sources and
follow their licences:

- **BCI Competition IV 2a** — 4-class motor imagery, 9 subjects, 22 channels, 250 Hz.
- **BCI Competition IV 2b** — 2-class motor imagery, 9 subjects, 3 channels, 250 Hz.
- **PhysioNet EEG Motor Movement/Imagery** — 4-class subset, 109 subjects.

Preprocess with the scripts in `core/data_processing/`, e.g.

```bash
python core/data_processing/process_bci2a.py
```

The loaders expect the processed arrays at:

```
data/processed/BCI2a/X.npy            # float32 [N, 22, 1000]
data/processed/BCI2a/y.npy            # integer labels
data/processed/BCI2b/...
data/processed/PhysioNetMI4C/...
```

Adjust paths in `experiments/paper_experiments/config.py` if your layout differs.

## Training and evaluation

Run from the repository root.

```bash
# 1) pretrain the EEGNet teacher on source subjects (run from the repository root)
PYTHONPATH=. python experiments/paper_experiments/pretrain_classifier_train.py

# 2) train the subject–style pathway, then disentanglement / alignment stages
python projects/tc_conf_ldm/scripts/SB-SD-LDM/train_sb_sd_ldm.py    --dataset bci2a
python projects/tc_conf_ldm/scripts/SB-SD-LDM/train_sb_sd_ldm_p2.py --dataset bci2a
python projects/tc_conf_ldm/scripts/SB-SD-LDM/train_sb_sd_ldm_p4.py --dataset bci2a

# 3) few-shot style estimation on the target subject and evaluation
python projects/tc_conf_ldm/scripts/SB-SD-LDM/train_sb_sd_ldm_p5.py --dataset bci2a
python projects/tc_conf_ldm/scripts/SB-SD-LDM/evaluate_sbsdldm_3scenarios.py

# 4) figures and quality metrics
python projects/tc_conf_ldm/scripts/SB-SD-LDM/gen_quality_5metrics_journal.py
python projects/tc_conf_ldm/scripts/SB-SD-LDM/fig_umap_methods.py
```

`--dataset` accepts `bci2a`, `bci2b`, and `physionet`. Checkpoints are written to
`checkpoints/tc_conf_ldm/` and figures to `outputs/figures/`. Trained weights are not
included in the repository because of their size; please contact the authors if you need
the exact checkpoints used in the paper.

Evaluation protocol: leave-one-subject-out for cross-subject columns, session-wise splits
for cross-session columns, and the same EEGNet classifier, training schedule, and per-fold
seed across all methods.

## Results reported in the paper

Classification accuracy (%) with Cohen's κ in parentheses.

| Method | BCI2a Within | BCI2a C-Sess. | BCI2a C-Subj. | BCI2b C-Subj. | PhysioNet C-Subj. |
|---|---|---|---|---|---|
| No Aug. | 73.85 (0.65) | 63.38 (0.49) | 49.88 (0.33) | 71.55 (0.43) | 55.89 (0.41) |
| SSD-LDM (Ours) | **80.84 (0.74)** | **72.15 (0.63)** | **59.24 (0.46)** | **77.67 (0.55)** | **60.81 (0.48)** |

## Citation

```bibtex
@article{liao2026ssdldm,
  title   = {Subject--Style Disentangled Latent Diffusion for Cross-Subject
             EEG Motor Imagery Augmentation},
  author  = {Liao, C. and others},
  journal = {IEEE Journal of Biomedical and Health Informatics},
  year    = {2026}
}
```

Please update the entry once the manuscript is accepted.

## Licence

No licence is granted yet. The code is released for review and reproducibility purposes;
contact the authors before reuse.
