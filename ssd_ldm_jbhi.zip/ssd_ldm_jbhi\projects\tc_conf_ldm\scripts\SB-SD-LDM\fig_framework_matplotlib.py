#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SSD-LDM framework figure (English, simplified v2)
==================================================
Panel (a) Training: content lane (top) / style lane (bottom), merge at Decoder.
Panel (b) Generation: top-down pipeline, dual inputs at top.

Output: outputs/figures/fig_SSDLDM_framework.pdf (+ PNG 300dpi)
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial"]
plt.rcParams["axes.unicode_minus"] = False

OUT_DIR = Path(__file__).resolve().parents[4] / "outputs" / "figures"
OUT_DIR.mkdir(parents=True, exist_ok=True)

# ---- palette ----
C_DATA = ("#ECECEC", "#555555")   # data / statistics
C_ENC  = ("#D6E4F5", "#3A6EA5")   # content pathway
C_DEC  = ("#D9F0D9", "#3B7A3B")   # decoder
C_DISC = ("#FDE8D0", "#C87A2A")   # GRL adversarial
C_ALN  = ("#F9DDDD", "#B34040")   # alignment L1-L3
C_DIF  = ("#D8F0F5", "#2A7A8A")   # diffusion component
C_STY  = ("#E8DDF5", "#7A4BA0")   # style pathway

fig, ax = plt.subplots(figsize=(17, 8.65))
ax.set_xlim(0, 29.5)
ax.set_ylim(-1.8, 13.2)
ax.axis("off")


def box(x, y, w, h, text, pal, fs=10, ls="-", lw=1.1, bold=False):
    fc, ec = pal
    ax.add_patch(FancyBboxPatch((x - w / 2, y - h / 2), w, h,
                                boxstyle="round,pad=0.02,rounding_size=0.10",
                                facecolor=fc, edgecolor=ec, linewidth=lw,
                                linestyle=ls))
    ax.text(x, y, text, ha="center", va="center", fontsize=fs,
            fontweight="bold" if bold else "normal", linespacing=1.4)


def arrow(x1, y1, x2, y2, color="#333333", ls="-", lw=1.6, rad=0.0):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>",
                                 mutation_scale=16, linewidth=lw, color=color,
                                 linestyle=ls, shrinkA=0, shrinkB=0,
                                 connectionstyle=f"arc3,rad={rad}"))


def lab(x, y, text, color="#333333", fs=8.8, ha="center"):
    ax.text(x, y, text, fontsize=fs, ha=ha, va="center", color=color,
            style="italic")


# ================= panel divider =================
ax.plot([15.5, 15.5], [-1.0, 13.0], ls="--", lw=0.8, color="#BBBBBB")

# ================= (a) Training =================
ax.text(7.6, 12.85, "(a) Training: style--content disentangling",
        fontsize=14, fontweight="bold", ha="center")

# --- content lane (top) ---
box(1.5, 7.4, 2.4, 1.15, "Source trial\n$\\mathbf{X}$", C_DATA)
box(4.4, 10.4, 2.1, 0.78, "Encoder $q_\\phi$", C_ENC)
box(7.1, 10.4, 2.0, 0.78, "class latent $z$", C_DATA)
box(10.9, 10.4, 2.5, 1.05, "Decoder $D_\\theta$\n(FiLM cond.)", C_DEC)
box(13.9, 10.4, 2.2, 1.05, "Recon $\\hat{\\mathbf{X}}$\n(style-swap)", C_DATA)
box(7.1, 12.05, 3.4, 0.90,
    "Subj.\ discriminator + GRL\n(erase $s$ from $z$)", C_DISC, fs=8.8)
box(7.1, 8.5, 3.8, 0.98,
    "Diffusion UNet $\\epsilon_\\theta$\n(noise--denoise in $z$)",
    C_DIF, fs=9.2)

# shared-backbone dashed frame
ax.add_patch(FancyBboxPatch((2.9, 7.75), 9.6, 3.4,
                            boxstyle="round,pad=0.02,rounding_size=0.12",
                            facecolor="none", edgecolor="#3A6EA5",
                            linewidth=1.0, linestyle="--", alpha=0.6))
lab(7.7, 7.42, "Shared backbone (Enc / Dec / UNet)", "#2E5A86", 8.5)

# --- style lane (bottom) ---
box(4.4, 4.6, 2.9, 1.0, "StyleEncoder $q_\\psi$\n(trial-level)", C_STY, fs=9.3)
box(7.1, 4.6, 2.0, 0.75, "style $\\mathbf{s}$", C_DATA, fs=9.3)
box(10.9, 4.6, 2.9, 1.0, "Style anchor space\n$\\{e_1,\\dots,e_S\\}$",
    C_STY, fs=9.8, lw=1.9)
box(7.1, 2.7, 3.4, 0.90,
    "Class disc.\ + GRL\n(erase $y$ from $\\mathbf{s}$)", C_DISC, fs=8.8)
box(10.9, 2.7, 3.2, 0.98,
    "CovChart $g$\n$\\varphi(R_s)\\mapsto\\mathbf{s}$", C_STY, fs=9.3)

# --- arrows ---
arrow(2.45, 7.9, 3.5, 10.0)                      # X -> Encoder
arrow(2.45, 6.9, 3.5, 5.15)                      # X -> StyleEncoder
arrow(5.45, 10.4, 6.1, 10.4)                     # Enc -> z
arrow(8.1, 10.4, 9.65, 10.4)                     # z -> Dec
arrow(12.15, 10.4, 12.8, 10.4)                   # Dec -> Xhat
arrow(7.1, 10.79, 7.1, 11.60)                    # z -> subj disc
arrow(5.40, 12.05, 4.45, 10.85, "#C87A2A", "--", rad=0.2)   # GRL back
arrow(7.1, 10.01, 7.1, 8.99)                     # z -> UNet
lab(7.95, 9.5, "noise--denoise", ha="left")
arrow(5.85, 4.6, 6.1, 4.6)                       # StyEnc -> s
arrow(7.1, 4.22, 7.1, 3.15)                      # s -> class disc
arrow(5.40, 2.7, 4.45, 4.10, "#C87A2A", "--", rad=-0.2)    # GRL back
arrow(8.1, 4.6, 9.45, 4.6)                       # s -> style space
lab(8.78, 4.98, "KL anchor", "#7A4BA0")
arrow(10.9, 3.19, 10.9, 4.10)                    # CovChart -> style space
lab(11.6, 3.66, "exact anchor", "#7A4BA0", ha="left")
arrow(10.9, 5.1, 10.9, 9.87)                     # style space -> Decoder
lab(11.3, 7.4, "FiLM: $\\mathbf{s}$", "#7A4BA0", ha="left")

# ================= (b) Generation =================
ax.text(22.9, 12.85,
        "(b) Generation: alignment-fused (40 unlabeled trials)",
        fontsize=14, fontweight="bold", ha="center")

# --- top dual inputs ---
box(20.6, 11.0, 2.7, 1.05, "Source trials\n(class $c$)", C_DATA, fs=9.5)
box(26.6, 11.0, 3.1, 1.05, "Unseen subject:\n40 unlabeled trials",
    C_DATA, fs=9.5)
box(20.6, 9.1, 2.3, 0.78, "Encoder $\\mu_\\phi$", C_ENC, fs=9.5)
box(26.6, 9.1, 3.4, 1.05,
    "$R_{\\mathrm{test}}$, $\\varphi(R_{\\mathrm{test}})$\n"
    "$m_t, s_t$ (pseudo-lab.)", C_DATA, fs=9.0)

# --- middle: z sources + L1/L2 ---
box(16.9, 6.9, 2.5, 1.0, "Diffusion prior\n$z\\sim$DDIM (alt.)",
    C_DIF, fs=9.2, ls="--", lw=1.7)
box(20.6, 6.9, 2.8, 1.0, "L1: latent moment\nmatching $\\to\\tilde{z}$",
    C_ALN, fs=9.5)
box(26.2, 6.9, 3.3, 1.0,
    "L2: style rendering\n$\\mathbf{s}=g(\\varphi(R_{\\mathrm{test}}))$",
    C_ALN, fs=9.2)

# --- lower pipeline ---
box(23.3, 4.9, 4.3, 0.84,
    "Decoder $D_\\theta(\\tilde{z},\\,c,\\,\\mathbf{s})$", C_DEC, fs=10)
box(23.3, 3.1, 4.1, 1.0,
    "L3: whiten--recolor\n$W=R_{\\mathrm{test}}^{1/2}R_{\\mathrm{gen}}^{-1/2}$",
    C_ALN, fs=9.3)
box(23.3, 1.5, 3.9, 1.02,
    "Aligned samples $\\tilde{\\mathbf{X}}$\n"
    "$\\mathrm{cov}(\\tilde{\\mathbf{X}})=R_{\\mathrm{test}}$",
    C_DATA, fs=9.5)

# --- arrows ---
arrow(20.6, 10.47, 20.6, 9.49)                   # pool -> Enc2
arrow(20.6, 8.71, 20.6, 7.40)                    # Enc2 -> L1 (vertical)
lab(21.05, 8.30, "content transport (default)", ha="left")
arrow(18.15, 6.9, 19.20, 6.9, "#2A7A8A", "--")   # prior -> L1
lab(18.65, 7.42, "composite affine", "#2A7A8A", 8.2)
arrow(26.6, 10.47, 26.6, 9.63)                   # few -> stat
arrow(25.30, 8.60, 21.70, 7.45)                  # stat -> L1 (m_t, s_t)
lab(23.70, 8.10, "$m_t, s_t$")
arrow(26.40, 8.57, 26.30, 7.42)                  # stat -> L2
lab(27.00, 8.00, "$\\varphi(R_{\\mathrm{test}})$", ha="left")
arrow(20.60, 6.40, 21.70, 5.33)                  # L1 -> Dec2
arrow(26.20, 6.40, 24.90, 5.33)                  # L2 -> Dec2
arrow(23.3, 4.48, 23.3, 3.61)                    # Dec2 -> L3
arrow(23.3, 2.60, 23.3, 2.02)                    # L3 -> out

ax.text(23.3, 0.40,
        "L1--L3 (red): alignment fused inside generation, not post-hoc",
        fontsize=10.5, ha="center", color="#B34040", fontweight="bold")
ax.text(23.3, -0.50,
        "Generated pool + real trials $\\to$ EEGNet$\\times$3 ensemble; "
        "training-side EA whitening under large domain shift",
        fontsize=9, ha="center", color="#555555", style="italic")

# ================= legend =================
legend_items = [
    (C_DATA, "Data / statistics"),
    (C_ENC,  "Content pathway"),
    (C_STY,  "Style pathway"),
    (C_DEC,  "Decoder"),
    (C_DISC, "GRL adversarial"),
    (C_ALN,  "Alignment L1--L3"),
    (C_DIF,  "Diffusion"),
]
lx = 2.0
for pal, name in legend_items:
    fc, ec = pal
    ax.add_patch(FancyBboxPatch((lx, -1.42), 0.8, 0.32,
                                boxstyle="round,pad=0.01,rounding_size=0.05",
                                facecolor=fc, edgecolor=ec, linewidth=1.0))
    ax.text(lx + 0.95, -1.26, name, fontsize=9, ha="left", va="center")
    lx += 0.95 + 0.24 * len(name) + 0.70

pdf_path = OUT_DIR / "fig_SSDLDM_framework.pdf"
png_path = OUT_DIR / "fig_SSDLDM_framework.png"
fig.savefig(pdf_path, bbox_inches="tight", pad_inches=0.15)
fig.savefig(png_path, dpi=300, bbox_inches="tight", pad_inches=0.15)
plt.close(fig)
print(f"saved: {pdf_path}")
print(f"saved: {png_path}")
