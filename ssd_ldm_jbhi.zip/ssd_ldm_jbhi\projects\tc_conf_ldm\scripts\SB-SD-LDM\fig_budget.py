#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
论文图 F7: few-shot 预算扫描 (BCI2a LOSO)
===============================================================
数据来源 (全部真实结果, 无模拟):
  N=10/20/60/80: outputs/results/ea_latentEA_combo_full_nf{10,20,60,80}.json
  N=40:          outputs/results/ea_latentEA_combo_full.json (主结果)
  参考线: real-only 51.99%

双轴: 左轴 Acc (实线 + 圆点), 右轴 Kappa (虚线 + 方点).
参考线以灰色水平点线标注, 突出 "N=10 已超过 real-only, N>=40 曲线变平" 的信息.

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/fig_budget.py
"""
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
FIGDIR = PROJECT_ROOT / 'outputs/figures'
FIGDIR.mkdir(parents=True, exist_ok=True)

# 真实结果 (budget sweep + 主结果 + 锚点)
BUDGET = {10: None, 20: None, 40: None, 60: None, 80: None}
ANCHORS = {'real-only': (0.5199, 0.360)}


def _load_result(tag):
    p = PROJECT_ROOT / f'outputs/results/ea_latentEA_combo_full_{tag}.json'
    if tag == 'main':
        p = PROJECT_ROOT / 'outputs/results/ea_latentEA_combo_full.json'
    with open(p, 'r', encoding='utf-8') as f:
        r = json.load(f)
    # bci2a 多数据集改造后结果在 loso 键下; 旧版为顶层
    blob = r.get('loso', r)
    return float(blob['mean']), float(blob['mean_kappa']), \
        [float(x) for x in blob['per_subject']]


def main():
    for nf in BUDGET:
        tag = 'main' if nf == 40 else f'nf{nf}'
        BUDGET[nf] = _load_result(tag)
        acc, kappa, _ = BUDGET[nf]
        print(f'N={nf:3d}: Acc {acc * 100:.2f}%  Kappa {kappa:.4f}')

    ns = sorted(BUDGET)
    accs = [BUDGET[n][0] * 100 for n in ns]
    kappas = [BUDGET[n][1] for n in ns]
    acc_stds = [BUDGET[n][2] and (BUDGET[n][0] * 0) for n in ns]  # 无 per-subject std 需求, 画均值点即可

    fig, ax1 = plt.subplots(figsize=(7, 4.2))
    c_acc, c_kap = '#C0392B', '#2C3E50'

    # 参考线
    ax1.axhline(ANCHORS['real-only'][0] * 100, color='#95A5A6', ls=':',
                lw=1.2, zorder=1)
    ax1.text(10.3, ANCHORS['real-only'][0] * 100 + 0.12, 'Real-only (51.99%)',
             fontsize=9, color='#7F8C8D')

    # Acc (左轴)
    l1, = ax1.plot(ns, accs, '-o', color=c_acc, lw=2, ms=7, zorder=3,
                   label='Accuracy (left)')
    ax1.set_xlabel('Unlabeled budget $N_f$', fontsize=12)
    ax1.set_ylabel('Accuracy (%)', fontsize=12, color=c_acc)
    ax1.tick_params(axis='y', labelcolor=c_acc)
    ax1.set_xticks(ns)
    ax1.set_ylim(51, 62)
    ax1.grid(True, ls=':', alpha=0.4)

    # Kappa (右轴)
    ax2 = ax1.twinx()
    l2, = ax2.plot(ns, kappas, '--s', color=c_kap, lw=2, ms=6, zorder=3,
                   label='Kappa (right)')
    ax2.set_ylabel(r'$\kappa$', fontsize=12, color=c_kap)
    ax2.tick_params(axis='y', labelcolor=c_kap)
    ax2.set_ylim(0.34, 0.49)

    # 数值标注 (Acc)
    for n, a in zip(ns, accs):
        ax1.annotate(f'{a:.2f}', (n, a), textcoords='offset points',
                     xytext=(0, 9), ha='center', fontsize=9, color=c_acc)

    ax1.legend(handles=[l1, l2], loc='lower right', fontsize=10,
               framealpha=0.9)
    ax1.set_title('Few-shot budget sweep (BCI2a LOSO)', fontsize=13)

    fig.tight_layout()
    out = FIGDIR / 'fig_budget_bci2a.pdf'
    fig.savefig(out, dpi=300, bbox_inches='tight')
    fig.savefig(out.with_suffix('.png'), dpi=300, bbox_inches='tight')
    print(f'已保存: {out}')


if __name__ == '__main__':
    main()
