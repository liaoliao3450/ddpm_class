#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EA-40 + Latent-EA-full 生成组合 (互补假设的第二轮检验)
===============================================================
前情 (ea_gen_combo.py, 已否定): fewshot-gen 白化后 +0.18pp 噪声级,
  根因是 fewshot 风格不复现 R_test (d_logEuclid 13.3), gen_ea=test 灾难.

本轮改动: 生成源换成 Latent-EA full (53.80% 那一版):
  encoder mu_z (零标签噪声) + 潜空间矩匹配 (方向) + chart(cov_test) 风格
  + 白化-重着色 (生成批协方差 == R_test, 机器精度 d_rel~1e-6)
=> 生成样本与真实数据在同一个 EA 白化空间 (cov→I), 前提成立:
   "精确对齐的多样化生成数据" 能否在 EA 之上叠加增益?

协议 (与 ea_baseline_loso.py / ea_gen_combo.py 逐字对齐):
  真实训练数据: 每训练被试独立 EA (R_s^{-1/2})
  测试数据:     R_test (40 无标签 trial) 白化, 与 EA-40 同预算
  生成数据:     Latent-EA full (协方差==R_test), 再按 R_test 白化 (→I)
  分类器: EEGNet x3 集成, 200 epochs, batch 32, 软投票

诊断: 每折记录 d_logEuclid(gen_cov, R_test) — 预期 ~0 (对比上轮 13.3)

锚点: real-only 51.99 / Latent-EA-full 53.80 / EA-40 59.68 / 上轮组合 59.86

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/ea_latentEA_combo.py
"""
import sys
import json
import argparse
from pathlib import Path

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from style_vae import load_style_vae
from style_vae_cov import load_p5
from ea_baseline_loso import ea_transform, subject_Rs
from diag_style_cov_cca import logm_sym
from evaluate_p4_cross_subject import set_seed, DEVICE, N_ENSEMBLE
from evaluate_p5_cross_subject import generate_p5

import importlib.util


def _load_ev():
    spec = importlib.util.spec_from_file_location(
        'evaluate_sb_ldm_3datasets',
        str(PROJECT_ROOT / 'projects/tc_conf_ldm/scripts/SB-LDM/evaluate_sb_ldm_3datasets.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


SEED = 42
N_FEWSHOT = 40
GEN_RATIO = 1.0

# 多数据集配置 (journal Table III "Ours" 行): 维度 / checkpoint / 协议模式
DS_CONFIG = {
    'bci2a': {
        'channels': 22, 'input_length': 1000, 'num_classes': 4, 'mode': 'loso',
        'teacher_ckpt': 'checkpoints/tc_conf_ldm/bci2a_shared_margin/pretrained_teacher_eegnet.pt',
        'p2_ckpt': 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p2/sb_sd_ldm_p2_epoch_500.pt',
        'p4_ckpt': 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p4/style_vae_final.pt',
        'p5_ckpt': 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p5/cov_chart_final.pt',
    },
    'bci2b': {
        'channels': 3, 'input_length': 1000, 'num_classes': 2, 'mode': 'loso',
        'teacher_ckpt': 'checkpoints/tc_conf_ldm/bci2b_shared/pretrained_teacher_eegnet.pt',
        'p2_ckpt': 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2b_p2/sb_sd_ldm_p2_epoch_500.pt',
        'p4_ckpt': 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2b_p4/style_vae_final.pt',
        'p5_ckpt': 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2b_p5/cov_chart_final.pt',
    },
    'physionet': {
        'channels': 64, 'input_length': 640, 'num_classes': 4, 'mode': 'lmso_10fold',
        'teacher_ckpt': 'checkpoints/tc_conf_ldm/physionet_mi4c_shared/pretrained_teacher_eegnet.pt',
        'p2_ckpt': 'checkpoints/tc_conf_ldm/sb_sd_ldm_physionet_p2/sb_sd_ldm_p2_epoch_500.pt',
        'p4_ckpt': 'checkpoints/tc_conf_ldm/sb_sd_ldm_physionet_p4/style_vae_final.pt',
        'p5_ckpt': 'checkpoints/tc_conf_ldm/sb_sd_ldm_physionet_p5/cov_chart_final.pt',
    },
}

ANCHORS = {'real-only': (0.5199, 0.360), 'Latent-EA-full': (0.5380, 0.384),
           'EA-40': (0.5968, 0.462), 'prev-combo': (0.5986, 0.465)}


def log_euclid(Ra, Rb):
    return float(np.linalg.norm(logm_sym(Ra) - logm_sym(Rb)))


def load_p2_model_ds(ckpt_path, channels, input_length, num_classes):
    """数据集感知版 load_p2_model (evaluate_p4_cross_subject 版硬编码 BCI2a 维度)."""
    from core.models.latent_diffusion.model_shared import (
        SharedBackboneConfig, SharedVAEUNetLDM1D)
    ckpt = torch.load(str(ckpt_path), map_location=DEVICE, weights_only=False)
    model_cfg = ckpt['config'].get('model', {})
    backbone = SharedBackboneConfig(
        base=int(model_cfg.get('backbone_base', 64)),
        levels=tuple(int(x) for x in model_cfg.get('backbone_levels', [1, 2, 4])),
        blocks_per_level=int(model_cfg.get('backbone_blocks_per_level', 2)),
    )
    model = SharedVAEUNetLDM1D(
        channels=channels,
        input_length=input_length,
        z_channels=int(model_cfg.get('z_channels', 64)),
        timesteps=int(model_cfg.get('timesteps', 1000)),
        t_dim=int(model_cfg.get('t_dim', 128)),
        cond_dim=int(model_cfg.get('cond_embed_dim', 64)),
        backbone=backbone,
        num_subjects=ckpt.get('num_subjects', 9),
        adv_alpha=0.0,
        subj_dim=ckpt.get('subj_dim', 32),
        disentangle=True,
    ).to(DEVICE)
    model.load_state_dict(ckpt['model_state_dict'])
    model.eval()

    cond_embed = torch.nn.Embedding(
        num_classes, int(model_cfg.get('cond_embed_dim', 64))).to(DEVICE)
    cond_embed.load_state_dict(ckpt['cond_embed_state_dict'])
    cond_embed.eval()
    return model, cond_embed


def make_folds(subjects, mode):
    """LOSO: 每被试一折; lmso_10fold: 与 ev.cross_subject_test 一致的折叠."""
    uniq = np.unique(subjects)
    if mode == 'loso':
        return [[int(s)] for s in uniq]
    rng = np.random.RandomState(42)
    shuffled = rng.permutation(uniq).tolist()
    n_folds = 10
    fs = len(shuffled) // n_folds
    rem = len(shuffled) % n_folds
    folds, start = [], 0
    for i in range(n_folds):
        sz = fs + (1 if i < rem else 0)
        folds.append([int(s) for s in shuffled[start:start + sz]])
        start += sz
    return folds


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', type=str, default='bci2a',
                        choices=['bci2a', 'bci2b', 'physionet'],
                        help='数据集 (bci2a 为原版默认, 向后兼容)')
    parser.add_argument('--ratio', type=float, default=1.0)
    parser.add_argument('--gen_mode', type=str, default='cov_only',
                        choices=['cov_only', 'full', 'orth_only'],
                        help='生成端风格模式: cov_only=图表风格(L2) / '
                             'orth_only=fewshot正交风格(无L2) / full=正交+协方差位移')
    parser.add_argument('--amp_calib', type=str, default='full',
                        choices=['none', 'global', 'diag', 'full'],
                        help='生成端幅度校准 (L3): none=关闭 / full=白化-重着色')
    parser.add_argument('--no_latent_match', action='store_true',
                        help='关闭 L1 潜空间矩匹配 (消融用)')
    parser.add_argument('--n_fewshot', type=int, default=40,
                        help='无标签 few-shot 预算 (trial 数, budget sweep 用)')
    parser.add_argument('--tag', type=str, default='',
                        help='输出文件名后缀 (如 L1 / L1L2)')
    parser.add_argument('--p2_ckpt', type=str, default=None)
    parser.add_argument('--p4_ckpt', type=str, default=None)
    parser.add_argument('--p5_ckpt', type=str, default=None)
    args = parser.parse_args()

    ds = DS_CONFIG[args.dataset]
    channels = ds['channels']
    input_length = ds['input_length']
    num_classes = ds['num_classes']
    mode = ds['mode']
    p2_ckpt = args.p2_ckpt or ds['p2_ckpt']
    p4_ckpt = args.p4_ckpt or ds['p4_ckpt']
    p5_ckpt = args.p5_ckpt or ds['p5_ckpt']

    lm = not args.no_latent_match
    print('=' * 72)
    print(f'EA-40 + Latent-EA 生成组合 ({args.dataset}, {mode.upper()}): '
          f'ratio={args.ratio}, gen_mode={args.gen_mode}, latent_match={lm}, '
          f'amp_calib={args.amp_calib}')
    if args.dataset == 'bci2a':
        print('锚点: real-only 51.99 / Latent-EA-full 53.80 / EA-40 59.68 / 上轮组合 59.86')
    print('=' * 72)

    # 1) 模型
    model, cond_embed = load_p2_model_ds(
        PROJECT_ROOT / p2_ckpt, channels, input_length, num_classes)
    W_subj = model.subj_embed.weight.detach()
    style_enc, _, sigma0_p4 = load_style_vae(
        PROJECT_ROOT / p4_ckpt, channels=channels, input_length=input_length,
        num_classes=num_classes, device=DEVICE)
    chart, covemb, sigma0_p5 = load_p5(
        PROJECT_ROOT / p5_ckpt, device=DEVICE)
    print(f'sigma0_p4={sigma0_p4}, sigma0_p5={sigma0_p5}, '
          f'cov_dim={covemb.k}')

    # teacher (latent_match 伪标签)
    from core.classifiers.eegnet import EEGNet
    teacher_ckpt = PROJECT_ROOT / ds['teacher_ckpt']
    teacher = EEGNet(n_channels=channels, n_samples=input_length,
                     n_classes=num_classes).to(DEVICE)
    state = torch.load(str(teacher_ckpt), map_location=DEVICE, weights_only=False)
    if isinstance(state, dict) and 'model_state_dict' in state:
        state = state['model_state_dict']
    teacher.load_state_dict(state, strict=False)
    teacher.eval()

    def pseudo_label(Xf):
        with torch.no_grad():
            xb = torch.FloatTensor(np.asarray(Xf)).unsqueeze(1).to(DEVICE)
            return teacher(xb).argmax(1).cpu().numpy()

    # 2) 数据
    ev = _load_ev()
    X, y, subjects, sessions = ev.load_dataset_data(args.dataset)
    subj_uniq = np.unique(subjects)
    if subj_uniq.max() != len(subj_uniq) - 1:
        remap = {s: i for i, s in enumerate(subj_uniq)}
        subjects = np.array([remap[s] for s in subjects])
    n_subj = len(np.unique(subjects))
    channels, input_length = X.shape[1], X.shape[2]

    ev.GEN_RATIO = GEN_RATIO
    ev.N_ENSEMBLE = N_ENSEMBLE

    from sklearn.metrics import accuracy_score, cohen_kappa_score

    folds = make_folds(subjects, mode)
    results, dists = [], []
    for fold_idx, test_group in enumerate(folds):
        # 真实训练数据: 每源被试独立 EA
        X_train_parts, y_train_parts = [], []
        train_subj_ids = []
        for s in range(n_subj):
            if s in test_group:
                continue
            m = subjects == s
            X_train_parts.append(ea_transform(X[m], subject_Rs(X[m])))
            y_train_parts.append(y[m])
            train_subj_ids.append(s)
        X_tr = np.concatenate(X_train_parts)      # EA 白化空间
        y_tr = np.concatenate(y_train_parts)
        # 原始空间训练池 (encoder mu_z 来源, 模型训练分布)
        m_train = ~np.isin(subjects, test_group)
        X_pool, y_pool = X[m_train], y[m_train]

        # 每个测试被试: R_test (前 n_fewshot 无标签 trial) + 协方差精确匹配生成
        # (LMSO 模式: 生成总量按 GEN_RATIO*len(X_tr) 均分到各测试被试)
        spc = max(1, int(GEN_RATIO * len(X_tr)) // (len(test_group) * num_classes))
        gen_parts_X, gen_parts_y = [], []
        X_te_parts, y_te_parts = [], []
        fold_dists = []
        for s in test_group:
            m_test = subjects == s
            X_test_raw, y_test_s = X[m_test], y[m_test]
            n_use = min(args.n_fewshot, len(X_test_raw))
            X_few = X_test_raw[:n_use]  # 无标签 trial: 协方差 + z 统计双用途
            R_test = subject_Rs(X_few)
            y_few_pl = pseudo_label(X_few)

            # 生成: 生成端对齐配置由参数决定 (消融: L1 / L1+L2 / L1+L2+L3)
            set_seed()
            gen_X, gen_y = generate_p5(
                model, cond_embed, style_enc, chart, covemb,
                spc, num_classes, args.gen_mode, train_subj_ids, W_subj,
                X_few=X_few, sigma0=sigma0_p5,
                z_source='encoder', X_pool=X_pool, y_pool=y_pool,
                latent_match=lm, X_few_pl=X_few, y_few_pl=y_few_pl,
                amp_calib=args.amp_calib)
            gen_X = np.nan_to_num(gen_X.astype(np.float32), nan=0.0)

            # 诊断: 生成批协方差 vs R_test (上轮 fewshot-gen 是 13.3)
            d_gen = log_euclid(subject_Rs(gen_X), R_test)
            fold_dists.append(d_gen)

            # 白化到与测试/真实训练一致的 EA 空间 (cov → I)
            gen_parts_X.append(ea_transform(gen_X, R_test))
            gen_parts_y.append(gen_y)

            # 测试数据 EA (R_test, 40-trial 预算, 与 EA-40 一致)
            X_te_parts.append(ea_transform(X_test_raw, R_test))
            y_te_parts.append(y_test_s)

        gen_X = np.concatenate(gen_parts_X)
        gen_y = np.concatenate(gen_parts_y)
        X_test = np.concatenate(X_te_parts)
        y_test = np.concatenate(y_te_parts)
        d_gen = float(np.mean(fold_dists))
        dists.append(d_gen)

        X_aug = np.concatenate([X_tr, gen_X])
        y_aug = np.concatenate([y_tr, gen_y])

        clf = ev.train_classifier(X_aug, y_aug, channels, input_length, num_classes)
        pred = ev.predict(clf, X_test)
        acc = float(accuracy_score(y_test, pred))
        kappa = float(cohen_kappa_score(y_test, pred))
        results.append({'acc': acc, 'kappa': kappa})
        print(f'  折 {fold_idx + 1}/{len(folds)} (测试被试 {test_group}): '
              f'Acc {acc * 100:.2f}%, Kappa {kappa:.4f} '
              f'(d_gen-Rtest={d_gen:.4f})')

    accs = [r['acc'] for r in results]
    kappas = [r['kappa'] for r in results]
    res = {'mean': float(np.mean(accs)), 'std': float(np.std(accs)),
           'per_subject': accs, 'mean_kappa': float(np.mean(kappas)),
           'std_kappa': float(np.std(kappas)), 'per_subject_kappa': kappas,
           'gen_cov_dist_to_Rtest': dists}

    print('\n' + '=' * 72)
    print(f'>>> EA-40 + Latent-EA ({args.dataset}, {args.gen_mode}, '
          f'amp={args.amp_calib}, lm={lm}): '
          f'{res["mean"] * 100:.2f}% ± {res["std"] * 100:.2f}% '
          f'(Kappa {res["mean_kappa"]:.4f})')
    print(f'    生成协方差与 R_test 的 log-Euclid 距离: '
          f'mean={np.mean(dists):.4f} (上轮 fewshot-gen: 13.3)')
    if args.dataset == 'bci2a':
        print(f'    锚点: EA-40 59.68 / 上轮组合 59.86 / Latent-EA-full 单独 53.80')
        combo_gain = res['mean'] - ANCHORS['EA-40'][0]
        print(f'    组合相对 EA-40: {"+" if combo_gain >= 0 else ""}'
              f'{combo_gain * 100:.2f}pp -> '
              f'{"生成数据在 EA 之上有叠加增益" if combo_gain > 0.005 else "无增益 (rewrite tax 最终确认)"}')
    print('=' * 72)

    tag = ('_' + args.tag) if args.tag else ''
    if args.dataset == 'bci2a':
        out = PROJECT_ROOT / f'outputs/results/ea_latentEA_combo_full{tag}.json'
    else:
        out = PROJECT_ROOT / f'outputs/results/ea_latentEA_combo_full_{args.dataset}{tag}.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, 'w', encoding='utf-8') as f:
        json.dump({'strategy': 'latent_ea_full', 'gen_ea': 'test',
                   'dataset': args.dataset, 'mode': mode,
                   'gen_mode': args.gen_mode, 'amp_calib': args.amp_calib,
                   'latent_match': lm, 'ratio': args.ratio,
                   'n_fewshot': args.n_fewshot, 'loso': res},
                  f, indent=2, ensure_ascii=False)
    print(f'结果已保存: {out}')


if __name__ == '__main__':
    main()
