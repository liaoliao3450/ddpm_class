#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
StyleEncoder (P4): trial 级被试风格编码器
===============================================================
前置: P2 checkpoint (z 已解耦只含类内容, 风格经 subj_embed 通路注入 decode)

设计 (内容-风格解耦的连续化升级):
  P1/P2 的风格空间 = 9 个离散嵌入点 (subj_embed 查找表)
  P4 StyleEncoder: 任意 trial x -> 连续风格向量 s 的分布 N(mu_s, sigma_s)

损失 (训练时 P2 主干冻结, 只训 StyleEncoder):
  L_recon  = MSE(decode(z_x, s), x)          s 补足 z 缺失的全部(被试)信息
  L_subj   = CE(subj_head(decode(z_x, s)), i) 风格真实到达输出 (判回正确被试)
  L_anchor = KL(N(mu_s, sig_s) || N(e_i, s0^2 I))
             锚定到 subj_embed 空间 — 保证 decode 对 s 可用, 且被试内
             风格宽度由 s0 控制 (生成时先验采样的外插半径)
  L_cls    = CE(class_disc(GRL(s)), y)       s 不含类信息 (对抗)

两种生成用法 (消融区分):
  prior   (方向2): s ~ N(e_i, s0^2 I), i 随机训练被试  — 盲生成"新被试"
  fewshot (方向1): s = mean(E(x_test_fewshot))          — 定向测试被试风格
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

import sys
from pathlib import Path

_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from core.models.latent_diffusion.model_shared import GradientReversalFn


class StyleEncoder(nn.Module):
    """x (B, C, T) -> (mu_s, logvar_s), 每个 trial 一个 32 维风格向量."""

    def __init__(self, channels: int = 22, input_length: int = 1000, subj_dim: int = 32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(channels, 64, kernel_size=7, padding=3),
            nn.SiLU(),
            nn.AvgPool1d(4),
            nn.Conv1d(64, 128, kernel_size=5, padding=2),
            nn.SiLU(),
            nn.AvgPool1d(4),
            nn.Conv1d(128, 128, kernel_size=3, padding=1),
            nn.SiLU(),
            nn.AdaptiveAvgPool1d(1),
            nn.Flatten(),
            nn.Linear(128, 128),
            nn.SiLU(),
        )
        self.head = nn.Linear(128, 2 * subj_dim)
        self.subj_dim = subj_dim

    def forward(self, x: torch.Tensor):
        h = self.net(x)
        out = self.head(h)
        mu_s, logvar_s = out.chunk(2, dim=1)
        logvar_s = torch.clamp(logvar_s, min=-6.0, max=4.0)
        return mu_s, logvar_s

    @torch.no_grad()
    def encode_style(self, x: torch.Tensor, sample: bool = False) -> torch.Tensor:
        """便捷接口: 返回风格向量 (均值或重参数化采样)."""
        mu_s, logvar_s = self.forward(x)
        if sample:
            std = torch.exp(0.5 * logvar_s)
            return mu_s + torch.randn_like(std) * std
        return mu_s


class StyleClassDisc(nn.Module):
    """s 上的类别判别器 (GRL 对抗用: s 必须不含类信息)."""

    def __init__(self, subj_dim: int = 32, num_classes: int = 4):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(subj_dim, 128), nn.SiLU(),
            nn.Linear(128, 64), nn.SiLU(),
            nn.Linear(64, num_classes),
        )

    def forward(self, s: torch.Tensor):
        return self.net(s)


def anchor_kl(mu_s: torch.Tensor, logvar_s: torch.Tensor,
              e_target: torch.Tensor, sigma0: float) -> torch.Tensor:
    """KL( N(mu_s, sig_s) || N(e_target, sigma0^2 I) ), 逐样本求和后取均值.

    e_target: (B, subj_dim) 该 batch 每个 trial 所属被试的嵌入 (冻结).
    """
    var_s = logvar_s.exp()
    var0 = float(sigma0) ** 2
    kl = 0.5 * (
        (var_s / var0)
        + ((mu_s - e_target) ** 2 / var0)
        - 1.0
        - torch.log(var_s / var0 + 1e-8)
    )
    return kl.sum(dim=1).mean()


@torch.no_grad()
def probe_subject_accuracy(probe_net, s_vec: torch.Tensor, subj: torch.Tensor) -> float:
    """已训练探针在 s 上的被试判别准确率 (诊断用)."""
    pred = probe_net(s_vec).argmax(1)
    return float((pred == subj).float().mean().item())


def save_style_vae(path, style_enc: StyleEncoder, class_disc: StyleClassDisc,
                   sigma0: float, meta: dict = None):
    torch.save({
        'style_encoder_state_dict': style_enc.state_dict(),
        'class_disc_state_dict': class_disc.state_dict(),
        'sigma0': sigma0,
        'subj_dim': style_enc.subj_dim,
        'meta': meta or {},
    }, path)


def load_style_vae(path, channels: int = 22, input_length: int = 1000,
                   num_classes: int = 4, device=torch.device('cpu')):
    ckpt = torch.load(str(path), map_location=device, weights_only=False)
    subj_dim = int(ckpt.get('subj_dim', 32))
    style_enc = StyleEncoder(channels, input_length, subj_dim).to(device)
    style_enc.load_state_dict(ckpt['style_encoder_state_dict'])
    style_enc.eval()
    class_disc = StyleClassDisc(subj_dim, num_classes).to(device)
    if 'class_disc_state_dict' in ckpt:
        class_disc.load_state_dict(ckpt['class_disc_state_dict'])
    class_disc.eval()
    sigma0 = float(ckpt.get('sigma0', 0.5))
    return style_enc, class_disc, sigma0
