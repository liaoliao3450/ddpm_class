#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
P4 诊断 II: CFG 外推是否是 DDIM z 身份错乱的根因
===============================================================
已知 (diag_p4_style_control.py):
  真实 mu_z + e_i 解码 → 100% 身份对齐 (完美)
  DDIM z (CFG=2.0) + e_i 解码 → 身份错乱 (e_0→4, e_2→6, ...)

假设: CFG=2.0 外推使 z 超出真实后验流形 → decoder 对 OOD z 响应漂移.
验证: CFG 扫描 (1.0 / 1.5 / 2.0) 下同一批噪声的 DDIM z + e_i 解码,
      看身份映射是否随 CFG 变化, CFG=1.0 时是否恢复对齐.

附加: DDIM z vs 真实 mu_z 的统计对比 (范数/逐维方差).

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/diag_p4_cfg.py
"""
import sys
from pathlib import Path

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

import importlib.util


def _load_ev():
    spec = importlib.util.spec_from_file_location(
        'evaluate_sb_ldm_3datasets',
        str(PROJECT_ROOT / 'projects/tc_conf_ldm/scripts/SB-LDM/evaluate_sb_ldm_3datasets.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


from evaluate_p4_cross_subject import load_p2_model, make_ddim_schedule, DDIM_STEPS

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def ddim_sample_z(model, cond_embed, n, guidance_scale, num_classes=4, seed=42):
    """DDIM 采样 (固定噪声种子, 可控 CFG). 返回 (z, y)."""
    g = torch.Generator(device='cpu').manual_seed(seed)
    e = 1e-8
    ddim_seq = make_ddim_schedule(model.alpha_bar, DDIM_STEPS)
    with torch.no_grad():
        dummy = torch.zeros(1, model.channels, model.input_length, device=DEVICE)
        z_d, _, _ = model.encode(dummy, cond=torch.zeros(1, model.cond_dim, device=DEVICE))
        z_ch, latent_len = model.z_channels, z_d.shape[-1]

    zs, ys = [], []
    with torch.no_grad():
        for c in range(num_classes):
            generated = 0
            while generated < n // num_classes:
                bs = min(32, n // num_classes - generated)
                cl = torch.full((bs,), c, dtype=torch.long, device=DEVICE)
                cond = cond_embed(cl)
                noise = torch.randn(bs, z_ch, latent_len, generator=g).to(DEVICE)
                z = noise.clone()
                for i, t_idx in enumerate(ddim_seq):
                    t = torch.full((bs,), t_idx, device=DEVICE, dtype=torch.long)
                    ec = model.denoise_eps(z, t, cond=cond)
                    if guidance_scale > 1.0:
                        eu = model.denoise_eps(z, t, cond=None)
                        eps_pred = torch.clamp(eu + guidance_scale * (ec - eu), -100, 100)
                    else:
                        eps_pred = ec
                    ab = model.alpha_bar[t_idx]
                    ab_prev = model.alpha_bar[ddim_seq[i + 1]] if i + 1 < len(ddim_seq) else model.alpha_bar[0]
                    sab = torch.sqrt(ab.clamp(min=e))
                    s1mb = torch.sqrt((1 - ab).clamp(min=e))
                    sab_prev = torch.sqrt(ab_prev.clamp(min=e))
                    s1mb_prev = torch.sqrt((1 - ab_prev).clamp(min=e))
                    pred_x0 = ((z - s1mb * eps_pred) / sab).clamp(-5, 5)
                    z = sab_prev * pred_x0 + s1mb_prev * eps_pred
                zs.append(z)
                ys.extend([c] * bs)
                generated += bs
    return torch.cat(zs, dim=0), torch.LongTensor(ys).to(DEVICE)


def identity_map_test(model, cond_embed, z_batch, y_batch, label=''):
    """同批 z + 9 个嵌入解码 (带正确类条件), 返回身份对齐率."""
    W = model.subj_embed.weight.detach()
    n = len(z_batch)
    correct = 0
    maps = []
    with torch.no_grad():
        cond = cond_embed(y_batch)
        for i in range(9):
            s_vec = W[i].unsqueeze(0).expand(n, -1)
            x_i = model.decode(z_batch, target_length=model.input_length,
                               cond=cond, style_vec=s_vec)
            pred = model.subj_head(x_i).argmax(1).cpu().numpy()
            dist = np.bincount(pred, minlength=9) / len(pred)
            maps.append((i, int(np.argmax(dist)), dist.max()))
            if np.argmax(dist) == i:
                correct += 1
    print(f'  {label}: 身份对齐 {correct}/9')
    for i, j, p in maps:
        mark = 'OK' if i == j else f'-> {j}'
        print(f'    e_{i} 判为 {j} ({p*100:.0f}%)  {mark}')
    return correct


def main():
    torch.manual_seed(42)
    np.random.seed(42)

    ev = _load_ev()
    model, cond_embed = load_p2_model(
        PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p2/sb_sd_ldm_p2_epoch_500.pt')

    X, y, subjects, sessions = ev.load_dataset_data('bci2a')
    subj_uniq = np.unique(subjects)
    if subj_uniq.max() != len(subj_uniq) - 1:
        remap = {s: i for i, s in enumerate(subj_uniq)}
        subjects = np.array([remap[s] for s in subjects])

    n = 72

    # ============================================================
    # [1] CFG 扫描: 身份对齐率
    # ============================================================
    print('\n' + '=' * 70)
    print('[1] CFG 扫描: 同噪声种子, 不同 CFG 的 DDIM z 身份对齐')
    print('=' * 70)
    for cfg in [1.0, 1.5, 2.0]:
        z_batch, y_batch = ddim_sample_z(model, cond_embed, n, guidance_scale=cfg)
        identity_map_test(model, cond_embed, z_batch, y_batch, label=f'CFG={cfg}')

    # ============================================================
    # [2] z 统计对比: DDIM z vs 真实 mu_z
    # ============================================================
    print('\n' + '=' * 70)
    print('[2] z 统计对比 (范数 / 逐维 std)')
    print('=' * 70)
    # 真实 mu_z (session 0 全部, 与扩散训练分布一致)
    mask_s0 = (subjects >= 0)  # 全部
    X_all = torch.FloatTensor(X[mask_s0]).to(DEVICE)
    y_all = torch.LongTensor(y[mask_s0]).to(DEVICE)
    mus = []
    with torch.no_grad():
        for i in range(0, len(X_all), 128):
            _, mu, _ = model.encode(X_all[i:i+128], cond=cond_embed(y_all[i:i+128]))
            mus.append(mu)
    mu_real = torch.cat(mus)

    for cfg in [1.0, 2.0]:
        z_ddim, _ = ddim_sample_z(model, cond_embed, n, guidance_scale=cfg)
        print(f'  CFG={cfg}: DDIM z 范数 mean={z_ddim.norm(dim=(1,2)).mean():.2f} | '
              f'逐维 std mean={z_ddim.flatten(1).std(0).mean():.3f} | '
              f'逐维 |mean| mean={z_ddim.flatten(1).mean(0).abs().mean():.3f}')
    print(f'  真实 mu_z: 范数 mean={mu_real.norm(dim=(1,2)).mean():.2f} | '
          f'逐维 std mean={mu_real.flatten(1).std(0).mean():.3f} | '
          f'逐维 |mean| mean={mu_real.flatten(1).mean(0).abs().mean():.3f}')

    # ============================================================
    # [3] 直接用真实 mu_z 生成 (跳过扩散): 风格混合 + 身份对齐
    # ============================================================
    print('\n' + '=' * 70)
    print('[3] 真实 mu_z 直通生成 (skip diffusion): 类条件采样真实 z + 换风格')
    print('=' * 70)
    # 每类抽真实 mu_z, 用不同被试风格解码 — 检查"真实z+定向风格"的身份对齐
    # (模拟: 若生成管线改为"真实 z 库 + 风格重解码", 风格是否可控)
    per_class = 18
    idx_by_class = {c: np.where(y == c)[0] for c in range(4)}
    sel = np.concatenate([np.random.RandomState(0).choice(idx_by_class[c], per_class,
                                                          replace=False) for c in range(4)])
    X_sel = torch.FloatTensor(X[sel]).to(DEVICE)
    y_sel = torch.LongTensor(y[sel]).to(DEVICE)
    with torch.no_grad():
        _, mu_sel, _ = model.encode(X_sel, cond=cond_embed(y_sel))
    identity_map_test(model, cond_embed, mu_sel, y_sel, label='真实 mu_z (4类×18)')

    # ============================================================
    # [4] 归一化破坏假设验证: decode 输出 (身份完美) 经
    #     normalize_to_real_stats 后身份是否被冲散
    # ============================================================
    print('\n' + '=' * 70)
    print('[4] 归一化破坏测试: 原始 decode (9/9 对齐) -> normalize 后身份')
    print('=' * 70)
    W = model.subj_embed.weight.detach()
    z_batch, y_batch = ddim_sample_z(model, cond_embed, n, guidance_scale=2.0)
    with torch.no_grad():
        cond = cond_embed(y_batch)
        for i in [0, 4, 8]:
            s_vec = W[i].unsqueeze(0).expand(n, -1)
            x_raw = model.decode(z_batch, target_length=model.input_length,
                                 cond=cond, style_vec=s_vec)
            # 原始
            pred_raw = model.subj_head(x_raw).argmax(1).cpu().numpy()
            # 全局归一化 (quick check 口径)
            x_np = x_raw.cpu().numpy()
            x_norm = ev.normalize_to_real_stats(X, x_np)
            pred_norm = model.subj_head(torch.FloatTensor(x_norm).to(DEVICE)).argmax(1).cpu().numpy()
            d_raw = np.bincount(pred_raw, minlength=9) / n
            d_norm = np.bincount(pred_norm, minlength=9) / n
            print(f'  s=e_{i}: 原始 判为 {np.argmax(d_raw)} ({d_raw.max()*100:.0f}%) | '
                  f'归一化后 判为 {np.argmax(d_norm)} ({d_norm.max()*100:.0f}%) | '
                  f'归一化后仍判为 {i} 的比例: {d_norm[i]*100:.0f}%')

    # [4b] 归一化到"目标被试统计" (修复方案: 用 e_i 对应被试的真实数据统计)
    print('\n  [4b] 修复方案: 归一化到目标被试自身统计 (而非全局)')
    for i in [0, 4, 8]:
        X_subj_i = X[subjects == i]
        s_vec = W[i].unsqueeze(0).expand(n, -1)
        with torch.no_grad():
            x_raw = model.decode(z_batch, target_length=model.input_length,
                                 cond=cond, style_vec=s_vec)
        x_np = x_raw.cpu().numpy()
        x_norm_t = ev.normalize_to_real_stats(X_subj_i, x_np)
        with torch.no_grad():
            pred_t = model.subj_head(torch.FloatTensor(x_norm_t).to(DEVICE)).argmax(1).cpu().numpy()
        d_t = np.bincount(pred_t, minlength=9) / n
        print(f'  s=e_{i}: 目标被试归一化后 判为 {np.argmax(d_t)} ({d_t.max()*100:.0f}%) | '
              f'仍判为 {i}: {d_t[i]*100:.0f}%')


if __name__ == '__main__':
    main()
