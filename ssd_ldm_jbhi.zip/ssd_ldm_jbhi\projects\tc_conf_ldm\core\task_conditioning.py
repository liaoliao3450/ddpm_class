"""
Class / difficulty / subject conditioning for TC-Conf-LDM.

条件: 类别 + 难度(置信度) + 被试编号
场景条件 (num_scenarios > 0) 保留向后兼容, 默认不使用。
"""

from typing import Optional

import torch
import torch.nn as nn


class TaskConditionEmbedding(nn.Module):
    def __init__(
        self,
        num_classes: int,
        num_scenarios: int = 0,  # 0=不使用场景条件 (向后兼容)
        embed_dim: int = 64,
        num_subjects: int = 0,
        difficulty_gain: float = 1.0,
    ) -> None:
        super().__init__()
        self.class_emb = nn.Embedding(num_classes, embed_dim)
        # 难度使用连续标量, 经 2 层 MLP 映射到 embed_dim
        self.difficulty_mlp = nn.Sequential(
            nn.Linear(1, embed_dim),
            nn.ReLU(inplace=True),
            nn.Linear(embed_dim, embed_dim),
            nn.ReLU(inplace=True),
        )
        self.difficulty_gain = difficulty_gain
        # 被试嵌入 (num_subjects=0 时不创建)
        self.num_subjects = num_subjects
        if num_subjects > 0:
            self.subject_emb = nn.Embedding(num_subjects, embed_dim)
        # 场景嵌入 (num_scenarios=0 时不创建, 向后兼容)
        self.num_scenarios = num_scenarios
        if num_scenarios > 0:
            self.scenario_emb = nn.Embedding(num_scenarios, embed_dim)

    def forward(
        self,
        class_labels: torch.Tensor,
        scenario_labels: Optional[torch.Tensor] = None,
        difficulty: Optional[torch.Tensor] = None,
        subject_labels: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Args:
            class_labels: (B,)
            scenario_labels: (B,) 或 None (向后兼容, 可传任意值)
            difficulty: (B,) in [0,1] 或 None
            subject_labels: (B,) 被试编号 或 None
        Returns:
            cond: (B, D)
        """
        cond = self.class_emb(class_labels)
        if difficulty is not None:
            d = difficulty.view(-1, 1)
            d_emb = self.difficulty_mlp(d) * self.difficulty_gain
            cond = cond + d_emb
        if subject_labels is not None and self.num_subjects > 0:
            cond = cond + self.subject_emb(subject_labels)
        if scenario_labels is not None and self.num_scenarios > 0:
            cond = cond + self.scenario_emb(scenario_labels)
        return cond


__all__ = ["TaskConditionEmbedding"]
