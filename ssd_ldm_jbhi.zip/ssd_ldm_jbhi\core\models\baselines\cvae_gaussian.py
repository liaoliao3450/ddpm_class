#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CVAE implementation for EEG generation"""
import torch
import torch.nn as nn
import torch.nn.functional as F

class CVAEEncoder(nn.Module):
    """Encoder: x -> z_mean, z_logvar"""
    def __init__(self, channels=22, latent_dim=32, num_classes=4):
        super().__init__()
        self.class_embed = nn.Embedding(num_classes, 32)
        
        self.net = nn.Sequential(
            nn.Conv1d(channels + 32, 64, kernel_size=5, stride=2, padding=2),
            nn.BatchNorm1d(64), nn.ReLU(),
            nn.Conv1d(64, 128, kernel_size=5, stride=2, padding=2),
            nn.BatchNorm1d(128), nn.ReLU(),
            nn.Conv1d(128, 256, kernel_size=5, stride=2, padding=2),
            nn.BatchNorm1d(256), nn.ReLU(),
            nn.AdaptiveAvgPool1d(1)
        )
        
        self.fc_mean = nn.Linear(256, latent_dim)
        self.fc_logvar = nn.Linear(256, latent_dim)
    
    def forward(self, x, y):
        c = self.class_embed(y).unsqueeze(-1).expand(-1, -1, x.size(2))  # [B, 32, T]
        x = torch.cat([x, c], dim=1)  # [B, C+32, T]
        h = self.net(x).squeeze(-1)
        return self.fc_mean(h), self.fc_logvar(h)


class CVAEDecoder(nn.Module):
    """Decoder: z + y -> x (deeper with residual refinement)"""
    def __init__(self, channels=22, latent_dim=64, out_length=1000, num_classes=4):
        super().__init__()
        self.class_embed = nn.Embedding(num_classes, 32)
        self.out_length = out_length
        self.init_length = out_length // 16  # More upsampling steps

        self.fc = nn.Linear(latent_dim + 32, 256 * self.init_length)

        self.net = nn.Sequential(
            # [256, T/16] -> [128, T/8]
            nn.ConvTranspose1d(256, 128, kernel_size=5, stride=2, padding=2, output_padding=1),
            nn.BatchNorm1d(128), nn.GELU(),
            # Residual refinement
            nn.Conv1d(128, 128, kernel_size=3, padding=1),
            nn.BatchNorm1d(128), nn.GELU(),
            nn.Conv1d(128, 128, kernel_size=3, padding=1),
            nn.BatchNorm1d(128), nn.GELU(),
            # [128, T/8] -> [64, T/4]
            nn.ConvTranspose1d(128, 64, kernel_size=5, stride=2, padding=2, output_padding=1),
            nn.BatchNorm1d(64), nn.GELU(),
            # Residual refinement
            nn.Conv1d(64, 64, kernel_size=3, padding=1),
            nn.BatchNorm1d(64), nn.GELU(),
            nn.Conv1d(64, 64, kernel_size=3, padding=1),
            nn.BatchNorm1d(64), nn.GELU(),
            # [64, T/4] -> [32, T/2]
            nn.ConvTranspose1d(64, 32, kernel_size=5, stride=2, padding=2, output_padding=1),
            nn.BatchNorm1d(32), nn.GELU(),
            # [32, T/2] -> [channels, T]
            nn.ConvTranspose1d(32, channels, kernel_size=5, stride=2, padding=2, output_padding=1),
        )

    def forward(self, z, y):
        c = self.class_embed(y)
        h = torch.cat([z, c], dim=-1)
        h = self.fc(h)
        h = h.view(h.size(0), 256, self.init_length)
        out = self.net(h)
        # Trim or pad to exact output length
        if out.size(2) > self.out_length:
            out = out[:, :, :self.out_length]
        elif out.size(2) < self.out_length:
            out = F.pad(out, (0, self.out_length - out.size(2)))
        return out


class CVAE(nn.Module):
    """Conditional Variational Autoencoder for EEG generation"""
    def __init__(self, channels=22, latent_dim=64, out_length=1000, num_classes=4, beta=0.01):
        super().__init__()
        self.encoder = CVAEEncoder(channels, latent_dim, num_classes)
        self.decoder = CVAEDecoder(channels, latent_dim, out_length, num_classes)
        self.latent_dim = latent_dim
        self.beta = beta  # KL weight (low beta to prevent posterior collapse)
    
    def reparameterize(self, mean, logvar):
        std = torch.exp(0.5 * logvar)
        return torch.randn_like(std) * std + mean
    
    def forward(self, x, y):
        z_mean, z_logvar = self.encoder(x, y)
        z = self.reparameterize(z_mean, z_logvar)
        x_recon = self.decoder(z, y)
        return x_recon, z_mean, z_logvar
    
    def loss(self, x, y):
        x_recon, z_mean, z_logvar = self(x, y)
        # Per-element MSE (interpretable, data is standardized so target ~1.0)
        recon_loss = F.mse_loss(x_recon, x, reduction='mean')
        # KL divergence per latent dimension
        kl_loss = -0.5 * torch.mean(1 + z_logvar - z_mean.pow(2) - z_logvar.exp())
        # Total: recon + beta * KL
        total = recon_loss + self.beta * kl_loss
        return total
    
    @torch.no_grad()
    def generate(self, n, y, device):
        """Generate samples"""
        z = torch.randn(n, self.latent_dim, device=device)
        return self.decoder(z, y.to(device))


class GaussianNoiseAugmentation:
    """Simple Gaussian noise augmentation for baseline"""
    def __init__(self, noise_std=0.1):
        self.noise_std = noise_std
    
    def generate(self, X, y, n_samples=None, device='cpu'):
        """Add Gaussian noise to existing samples"""
        if n_samples is None:
            n_samples = len(X)
        idx = torch.randint(0, len(X), (n_samples,))
        x_base = torch.FloatTensor(X[idx]).to(device)
        noise = torch.randn_like(x_base) * self.noise_std
        return x_base + noise