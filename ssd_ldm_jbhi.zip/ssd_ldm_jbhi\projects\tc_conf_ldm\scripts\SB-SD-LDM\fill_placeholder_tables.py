#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
填充 SB_SD_LDM_JBHI.tex 中 Table I / Table III 的 TODO 占位数据
================================================================
目的: 让论文可以完整编译, 预览双栏排版效果 (图表位置/宽度/分页).

规则:
  1. 只填 TODO 单元格; BCI2a 真实数据一律不动.
  2. 所有占位值用 \textcolor{gray}{\emph{...}} 包裹 (灰色斜体),
     表标题脚注声明 "gray italic = placeholder".
  3. 假数据模式自洽:
       - BCI2b (2类, chance 50%): 绝对值高于 BCI2a, Kappa = 2*(acc-0.5)
       - PhysioNet (4类, 64ch, S=97): 跨被试更难, Acc 低于 BCI2a,
         Kappa = (acc-0.25)/0.75; 97 折 std 更小
       - 方法间排序复刻 BCI2a 模式: SB-LDM 毒性 < real-only <
         prior < fewshot; fused ~= EA-40
  4. 备份原文件为 .tex.bak; --restore 一键还原.

Usage:
    python projects/tc_conf_ldm/scripts/SB-SD-LDM/fill_placeholder_tables.py
    python ... --restore          # 从 .tex.bak 还原
"""
import argparse
import shutil
import sys
from pathlib import Path

TEX = Path(r'F:\DS-DDPM-main\paper\SB_SD_LDM_JBHI.tex')
BAK = TEX.with_suffix('.tex.bak')


def _g(s: str) -> str:
    """占位单元格: 灰色斜体."""
    return r'\textcolor{gray}{\emph{%s}}' % s


# ------------------------------------------------------------
# Table I: datasets summary (只替换 trials 行的 TODO)
# ------------------------------------------------------------
T1_OLD = r"""Trials (total) & 5776 & 6520 & TODO \\"""
T1_NEW = r"""Trials (total) & 5776 & """ + _g('6480') + r""" & """ + _g('3780') + r""" \\"""

# ------------------------------------------------------------
# Table III: main results (整表替换, BCI2a 列真实值保留并补 std)
# ------------------------------------------------------------
# 方法行: (name, bci2a_acc, bci2a_k, bci2b_acc, bci2b_std, bci2b_k,
#          phys_acc, phys_std, phys_k, bold_fused)
ROWS = [
    ('Real-only',            '51.99', '(0.360)', 57.2, 10.4, 0.144, 44.8, 6.9, 0.264, False),
    ('SB-LDM (fixed-VAE)',   '46.26', '(0.283)', 53.9,  9.8, 0.078, 41.3, 6.2, 0.217, False),
    ('EA-40',                '59.68', '(0.462)', 66.1, 11.2, 0.322, 52.4, 7.1, 0.365, False),
    ('SB-SD-LDM (prior)',    '52.85', '(0.371)', 58.0, 10.1, 0.160, 45.7, 6.8, 0.276, False),
    ('SB-SD-LDM (few-shot)', '53.01', '(0.373)', 58.6, 10.2, 0.172, 46.1, 6.8, 0.281, False),
    ('SB-SD-LDM (fused)',    '59.24', '(0.457)', 65.8, 11.0, 0.316, 51.9, 7.3, 0.359, True),
]

T3_OLD_CAPTION = r"""\caption{Cross-subject LOSO performance on three datasets (accuracy \%,
mean $\pm$ std over subjects; $\kappa$ in parentheses). Best generative
result in \textbf{bold}. TODO = pending training chains.}"""

T3_NEW_CAPTION = r"""\caption{Cross-subject LOSO performance on three datasets (accuracy \%,
mean $\pm$ std over subjects; $\kappa$ in parentheses). Best generative
result per dataset in \textbf{bold}. \emph{Gray italic values are
placeholders pending ongoing experiments and will be replaced by final
results.}}"""

T3_OLD_BODY = r"""\begin{tabular}{@{}lcccccc@{}}
\toprule
 & \multicolumn{2}{c}{BCI2a} & \multicolumn{2}{c}{BCI2b} & \multicolumn{2}{c}{PhysioNet} \\
\cmidrule(lr){2-3}\cmidrule(lr){4-5}\cmidrule(lr){6-7}
Method & Acc & $\kappa$ & Acc & $\kappa$ & Acc & $\kappa$ \\
\midrule
Real-only            & 51.99 & (0.360) & TODO & () & TODO & () \\
SB-LDM (fixed-VAE)   & 46.26 & (0.283) & TODO & () & TODO & () \\
EA-40                & 59.68 & (0.462) & TODO & () & TODO & () \\
\midrule
SB-SD-LDM (prior)    & 52.85 & (0.371) & TODO & () & TODO & () \\
SB-SD-LDM (few-shot) & 53.01 & (0.373) & TODO & () & TODO & () \\
SB-SD-LDM (fused)    & \textbf{59.24} & (0.457) & TODO & () & TODO & () \\
\bottomrule
\end{tabular}"""


def _fmt_row(name, a2a, k2a, b_acc, b_std, b_k, p_acc, p_std, p_k, bold):
    b_cell = _g('%.1f\\,$\\pm$\\,%.1f' % (b_acc, b_std))
    p_cell = _g('%.1f\\,$\\pm$\\,%.1f' % (p_acc, p_std))
    b_k_cell = _g('(%.3f)' % b_k)
    p_k_cell = _g('(%.3f)' % p_k)
    a_cell = a2a if not bold else r'\textbf{%s}' % a2a
    return ('%-20s & %s & %s & %s & %s & %s & %s \\\\'
            % (name, a_cell, k2a, b_cell, b_k_cell, p_cell, p_k_cell))


def build_t3_new():
    lines = [r'\begin{tabular}{@{}lcccccc@{}}',
             r'\toprule',
             r' & \multicolumn{2}{c}{BCI2a} & \multicolumn{2}{c}{BCI2b} & \multicolumn{2}{c}{PhysioNet} \\',
             r'\cmidrule(lr){2-3}\cmidrule(lr){4-5}\cmidrule(lr){6-7}',
             r'Method & Acc & $\kappa$ & Acc & $\kappa$ & Acc & $\kappa$ \\',
             r'\midrule']
    for i, row in enumerate(ROWS):
        if i == 3:
            lines.append(r'\midrule')
        lines.append(_fmt_row(*row))
    lines += [r'\bottomrule', r'\end{tabular}']
    return '\n'.join(lines)


XCOLOR_OLD = r'\usepackage{booktabs}'
XCOLOR_NEW = r'\usepackage{booktabs}' + '\n' + r'\usepackage{xcolor}'


def restore():
    if not BAK.exists():
        print('no backup found: %s' % BAK)
        sys.exit(1)
    shutil.copy(BAK, TEX)
    print('restored %s from backup' % TEX.name)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--restore', action='store_true',
                    help='restore tex from .tex.bak')
    args = ap.parse_args()
    if args.restore:
        restore()
        return

    if not TEX.exists():
        print('tex not found: %s' % TEX)
        sys.exit(1)

    text = TEX.read_text(encoding='utf-8')

    # 0) 备份
    shutil.copy(TEX, BAK)

    # 1) 确保加载 xcolor
    if r'\usepackage{xcolor}' not in text:
        if XCOLOR_OLD in text:
            text = text.replace(XCOLOR_OLD, XCOLOR_NEW, 1)
        else:
            print('WARN: booktabs line not found, xcolor NOT inserted')

    # 2) Table I trials TODO
    if T1_OLD in text:
        text = text.replace(T1_OLD, T1_NEW, 1)
        print('[Table I   ] trials placeholders filled (gray italic)')
    else:
        print('[Table I   ] pattern not found (already filled?)')

    # 3) Table III caption + body
    if T3_OLD_CAPTION in text:
        text = text.replace(T3_OLD_CAPTION, T3_NEW_CAPTION, 1)
        print('[Table III ] caption updated (placeholder footnote)')
    else:
        print('[Table III ] caption pattern not found (already filled?)')

    if T3_OLD_BODY in text:
        text = text.replace(T3_OLD_BODY, build_t3_new(), 1)
        print('[Table III ] body placeholders filled: '
              'BCI2b/PhysioNet Acc+-std + Kappa (gray italic)')
    else:
        print('[Table III ] body pattern not found (already filled?)')

    TEX.write_text(text, encoding='utf-8')
    print('done. backup at %s (restore: --restore)' % BAK)


if __name__ == '__main__':
    main()
