# -*- coding: utf-8 -*-
"""对照实验: 修复版 SB-LDM (无风格通路) 的 z 被试探针.

目的: 验证 probe 方法学的效度.
  - 若 fix-SB-LDM z 被试探针高 (如 >50%): probe 有效, 且证明 P1/P2 的 z 解耦是真实的
    (P1 引入风格通路 + 交换训练后, z 的被试信息确实被移到了 s 通路)
  - 若 fix-SB-LDM z 被试探针也 ~chance: probe 太弱, P2 验收结论不可信
"""
import sys
from pathlib import Path

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from core.models.latent_diffusion.model_shared import (
    SharedBackboneConfig, SharedVAEUNetLDM1D)

from train_sb_sd_ldm import DATASET_CONFIG, load_dataset

from validate_p2_disentangle import train_probe, encode_all

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def main():
    dataset = 'bci2a'
    cfg = DATASET_CONFIG[dataset]

    ckpt_path = PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_ldm_bci2a_fix/sb_ldm_epoch_500.pt'
    print(f'加载修复版 SB-LDM: {ckpt_path}')
    ckpt = torch.load(str(ckpt_path), map_location=DEVICE, weights_only=False)

    model_cfg = ckpt['config'].get('model', {})
    backbone = SharedBackboneConfig(
        base=int(model_cfg.get('backbone_base', 64)),
        levels=tuple(int(x) for x in model_cfg.get('backbone_levels', [1, 2, 4])),
        blocks_per_level=int(model_cfg.get('backbone_blocks_per_level', 2)),
    )
    # 修复版无风格通路 (num_subjects=0)
    model = SharedVAEUNetLDM1D(
        channels=cfg['channels'],
        input_length=cfg['input_length'],
        z_channels=int(model_cfg.get('z_channels', 64)),
        timesteps=int(model_cfg.get('timesteps', 1000)),
        t_dim=int(model_cfg.get('t_dim', 128)),
        cond_dim=int(model_cfg.get('cond_embed_dim', 64)),
        backbone=backbone,
        num_subjects=0,
        adv_alpha=0.0,
    ).to(DEVICE)
    model.load_state_dict(ckpt['model_state_dict'])

    cond_embed = torch.nn.Embedding(cfg['num_classes'],
                                    int(model_cfg.get('cond_embed_dim', 64))).to(DEVICE)
    cond_embed.load_state_dict(ckpt['cond_embed_state_dict'])
    cond_embed.eval()

    X, y, subjects = load_dataset(dataset)
    X_t = torch.FloatTensor(X)
    y_t = torch.LongTensor(y)

    z = encode_all(model, cond_embed, X_t, y_t)
    print(f'z 形状: {z.shape}')

    subj_acc = train_probe(z, subjects, cfg['num_subjects'])
    cls_acc = train_probe(z, y, cfg['num_classes'])
    print(f'\n修复版 SB-LDM z 探针 (对照):')
    print(f'  被试探针: {subj_acc*100:.1f}% (chance={100/cfg["num_subjects"]:.1f}%)')
    print(f'  类别探针: {cls_acc*100:.1f}%')
    print(f'\n结论: probe {"有效 — z 含可读被试信息, P1/P2 解耦是真实成就" if subj_acc > 0.5 else "存疑 — 需更强探针复核"}')


if __name__ == '__main__':
    main()
