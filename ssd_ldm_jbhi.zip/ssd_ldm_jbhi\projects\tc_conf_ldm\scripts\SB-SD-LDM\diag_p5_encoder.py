#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
P5 诊断: encoder 重渲染幅度塌缩的根源隔离
===============================================================
现象: decode(mu_z, chart(cov_test_40)) 幅度比仅 0.293, 但
      G1 门 decode(mu_z, chart(cov_t_full)) d_correct=0.393 (通过).
隔离变量 (固定 mu_z 批, 只换 style):
  [A] chart(cov_t)  t=0..8  全量锚点 (训练流形内, G1 复现)
  [B] chart(cov_9 的 40-trial 估计)           <- 快检塌缩配置
  [C] chart(cov_9 的 40-trial 收缩估计)       <- 收缩修复: (1-w)*R40 + w*R_bar
  [D] e_9 直接锚点 (跳过 chart)
  [E] chart(cov_9 session1 全量 / session2 全量)  <- 会话组成效应

每配置输出: ||R_gen||/||R_target|| 幅度比 + d_rel + 风格向量到各锚点距离.

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/diag_p5_encoder.py
"""
import sys
from pathlib import Path

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from style_vae_cov import load_p5, compute_subject_R
from evaluate_p4_cross_subject import load_p2_model, set_seed, DEVICE

import importlib.util


def _load_ev():
    spec = importlib.util.spec_from_file_location(
        'evaluate_sb_ldm_3datasets',
        str(PROJECT_ROOT / 'projects/tc_conf_ldm/scripts/SB-LDM/evaluate_sb_ldm_3datasets.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


@torch.no_grad()
def render_R(model, cond_embed, chart, mu_z_fixed, y_fixed, style_vec, device):
    """decode(mu_z, style) -> 批协方差."""
    cond = cond_embed(y_fixed)
    x = model.decode(mu_z_fixed, target_length=model.input_length,
                     cond=cond, style_vec=style_vec)
    return compute_subject_R(x.cpu().numpy())


def main():
    set_seed()
    ev = _load_ev()

    model, cond_embed = load_p2_model(
        PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p2/sb_sd_ldm_p2_epoch_500.pt')
    W_subj = model.subj_embed.weight.detach()
    chart, covemb, sigma0 = load_p5(
        PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p5/cov_chart_final.pt',
        device=DEVICE)

    X, y, subjects, sessions = ev.load_dataset_data('bci2a')
    subj_uniq = np.unique(subjects)
    if subj_uniq.max() != len(subj_uniq) - 1:
        remap = {s: i for i, s in enumerate(subj_uniq)}
        subjects = np.array([remap[s] for s in subjects])
    n_subj = len(np.unique(subjects))
    T = n_subj - 1                      # 测试被试 = 9 (0-based: 8)

    # 固定 mu_z 批: 混合被试/类别 72 trial (与 G1 诊断同构)
    rs = np.random.RandomState(0)
    idx_fix = rs.choice(len(X), size=72, replace=False)
    xb = torch.FloatTensor(X[idx_fix]).to(DEVICE)
    yb = torch.LongTensor(y[idx_fix]).to(DEVICE)
    _, mu_z_fixed, _ = model.encode(xb, cond=cond_embed(yb))
    y_fixed = yb

    # 协方差锚点
    R_full = [compute_subject_R(X[subjects == s]) for s in range(n_subj)]
    R_bar = np.mean(np.stack(R_full), axis=0)          # 全体均值 (收缩目标)
    X_T = X[subjects == T]
    sess_T = sessions[subjects == T]
    R_40 = compute_subject_R(X_T[:40])
    w_shrink = 0.3
    R_40s = (1 - w_shrink) * R_40 + w_shrink * R_bar
    R_s1 = compute_subject_R(X_T[sess_T == np.unique(sess_T)[0]])
    R_s2 = compute_subject_R(X_T[sess_T == np.unique(sess_T)[1]])
    R_target = R_full[T]
    nR_t = np.linalg.norm(R_target)

    def emb(R):
        return torch.FloatTensor(covemb.embed(R)).to(DEVICE)

    def chartv(R):
        return chart(emb(R).unsqueeze(0))

    # 风格空间距离: chart(cov) 到各锚点 e_s
    e_all = W_subj.to(DEVICE)

    def style_report(name, s_vec):
        d = (e_all - s_vec).norm(dim=1)
        d_raw = (e_all - e_all[T]).norm(dim=1)
        near = int(d.argmin())
        print(f'    到 e_{near+1} 最近 (d={d.min():.3f}); '
              f'到 e_{T+1} 距离 {d[T]:.3f} '
              f'(全量锚点自身到 e_{T+1}: {d_raw[T]:.1e}, '
              f'次近邻锚距 {sorted(d_raw.tolist())[:2][1]:.3f})')

    cfgs = []
    # [A] 全量锚点 (G1 复现, 含被试 9)
    for t in [0, 3, T]:
        cfgs.append((f'A chart(cov_full_{t+1})', chartv(R_full[t]), R_full[t]))
    # [B] 40-trial 估计 (快检塌缩配置)
    cfgs.append(('B chart(cov_40trial)', chartv(R_40), R_target))
    # [C] 40-trial + 收缩 0.3
    cfgs.append((f'C chart(cov_40 shrink w={w_shrink})', chartv(R_40s), R_target))
    # [D] e_9 直接锚点
    cfgs.append(('D e_9 (chart 绕过)', e_all[T].unsqueeze(0), R_target))
    # [E] session 组成
    cfgs.append(('E chart(cov_s1_full)', chartv(R_s1), R_target))
    cfgs.append(('E chart(cov_s2_full)', chartv(R_s2), R_target))

    print('=' * 72)
    print(f'P5 encoder 重渲染诊断 (测试被试 = {T+1}, 固定 72 trial mu_z 批)')
    print('=' * 72)

    # 锚点嵌入空间几何: cov_40 离 cov_full_9 多远?
    c_all = np.stack([covemb.embed(R) for R in R_full])
    c_40 = covemb.embed(R_40)
    d_anchor = np.linalg.norm(c_all - c_all[T], axis=1)
    d_40 = np.linalg.norm(c_all - c_40, axis=1)
    print(f'\n[嵌入空间] 锚点间最大距离 {d_anchor.max():.3f}, '
          f'cov_40 到最近锚点 (subj{int(np.argmin(d_40))+1}) 距离 {d_40.min():.3f}, '
          f'到 cov_full_{T+1} 距离 {d_40[T]:.3f}')

    print(f'\n{"配置":<28s}{"幅度比":>8s}{"d_rel":>8s}')
    print('-' * 48)
    for name, s_vec, R_tgt in cfgs:
        R_gen = render_R(model, cond_embed, chart, mu_z_fixed, y_fixed,
                         s_vec.expand(mu_z_fixed.size(0), -1), DEVICE)
        amp = np.linalg.norm(R_gen) / nR_t
        d_rel = np.linalg.norm(R_gen - R_tgt) / (np.linalg.norm(R_tgt) + 1e-8)
        print(f'{name:<28s}{amp:>8.3f}{d_rel:>8.3f}')
        if name.startswith(('B', 'C', 'D', 'E')):
            style_report(name, s_vec.squeeze(0))

    print('\n判读: A 行应复现 G1 (幅度 ~0.6-0.9); 若 B 塌缩而 A 正常,'
          '\n      根因 = 40-trial 嵌入偏离流形; 若 C 恢复 -> 收缩可修复;'
          '\n      若 D 也塌缩 -> chart 无关, mu_z 本身问题.')


if __name__ == '__main__':
    main()
