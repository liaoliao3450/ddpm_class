# -*- coding: utf-8 -*-
"""SB-SD-LDM P2 独立验收: z 解耦效果 (fresh probe 协议).

为什么用 fresh probe: 训练中的 subject_disc 是"同营对抗者", 它读不准可能是
判别器太弱而非 z 真的干净 (低估泄漏). 诚实协议 = 冻结编码器, 独立训练一个
新探针从 z 预测被试/类别, 测试集准确率才是 z 信息含量的无偏估计.

验收门:
  G1 fresh 被试探针 (z) <= 25%   (chance=11.1%; P1 泄漏基线预期 ~100%)
  G2 fresh 类别探针 (z) >= 90%   (类信息保留)
  G3 重建判类 (teacher, 正确 s) >= 95%  (对抗不毁重建)
  G4 交换控制 (subj_head 判 s_other) >= 70%  (风格通路仍因果)

Usage:
    python projects/tc_conf_ldm/scripts/SB-SD-LDM/validate_p2_disentangle.py
    python projects/tc_conf_ldm/scripts/SB-SD-LDM/validate_p2_disentangle.py --epoch 500
"""
import sys
import json
import argparse
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.model_selection import train_test_split

# 项目根路径 + 同目录
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from core.models.latent_diffusion.model_shared import (
    SharedBackboneConfig, SharedVAEUNetLDM1D)

from train_sb_sd_ldm import (
    DATASET_CONFIG, load_config, load_dataset, load_teacher, eval_style_quality)

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


# ---------------------------------------------------------------------------
# Fresh probe: 冻结 z, 独立训练探针
# conv 探针 (正对照: 原始波形被试识别 99%, 上限可信;
#           MLP 探针对被试信息无效力 — fix/P1/P2 的 z 均读出 chance)
# ---------------------------------------------------------------------------
class ConvProbe(torch.nn.Module):
    def __init__(self, c_in, n_out):
        super().__init__()
        self.net = torch.nn.Sequential(
            torch.nn.Conv1d(c_in, 64, kernel_size=7, padding=3), torch.nn.ReLU(),
            torch.nn.Conv1d(64, 64, kernel_size=5, padding=2), torch.nn.ReLU(),
            torch.nn.AdaptiveAvgPool1d(1), torch.nn.Flatten(),
            torch.nn.Linear(64, n_out),
        )

    def forward(self, x):
        return self.net(x)


def train_probe(z, labels, n_classes, epochs=150, bs=256, lr=1e-3, seed=0):
    """80/20 分层划分, 训练 fresh conv 探针, 返回测试集准确率. z: (N, C, L)."""
    torch.manual_seed(seed)
    np.random.seed(seed)

    idx = np.arange(len(z))
    tr_idx, te_idx = train_test_split(idx, test_size=0.2, random_state=0,
                                      stratify=labels)
    z_tr = torch.FloatTensor(z[tr_idx]).to(DEVICE)
    y_tr = torch.LongTensor(labels[tr_idx]).to(DEVICE)
    z_te = torch.FloatTensor(z[te_idx]).to(DEVICE)
    y_te = torch.LongTensor(labels[te_idx]).to(DEVICE)

    probe = ConvProbe(z.shape[1], n_classes).to(DEVICE)
    optim = torch.optim.Adam(probe.parameters(), lr=lr)
    n = len(z_tr)
    for ep in range(epochs):
        probe.train()
        perm = torch.randperm(n, device=DEVICE)
        for i in range(0, n, bs):
            p = perm[i:i + bs]
            loss = F.cross_entropy(probe(z_tr[p]), y_tr[p])
            optim.zero_grad()
            loss.backward()
            optim.step()
    probe.eval()
    with torch.no_grad():
        pred = probe(z_te).argmax(1)
    return float((pred == y_te).float().mean().item())


@torch.no_grad()
def encode_all(model, cond_embed, X_t, y_t, bs=100):
    """全量编码 -> mu 张量 (N, C, L), 不展平 (conv 探针需要结构)."""
    model.eval()
    mus = []
    for i in range(0, len(X_t), bs):
        xb = X_t[i:i + bs].to(DEVICE)
        yb = y_t[i:i + bs].to(DEVICE)
        mu, _, _ = model.encode(xb, cond=cond_embed(yb))
        mus.append(mu.cpu())
    return torch.cat(mus).numpy()


def build_model(yaml_cfg, dataset, disentangle, subj_dim, num_subjects):
    cfg = DATASET_CONFIG[dataset]
    model_cfg = yaml_cfg.get('model', {})
    backbone = SharedBackboneConfig(
        base=int(model_cfg.get('backbone_base', 64)),
        levels=tuple(int(x) for x in model_cfg.get('backbone_levels', [1, 2, 4])),
        blocks_per_level=int(model_cfg.get('backbone_blocks_per_level', 2)),
    )
    model = SharedVAEUNetLDM1D(
        channels=cfg['channels'],
        input_length=cfg['input_length'],
        z_channels=int(model_cfg.get('z_channels', 64)),
        timesteps=int(model_cfg.get('timesteps', 1000)),
        t_dim=int(model_cfg.get('t_dim', 128)),
        cond_dim=int(model_cfg.get('cond_embed_dim', 64)),
        backbone=backbone,
        num_subjects=num_subjects,
        adv_alpha=0.0,
        subj_dim=subj_dim,
        disentangle=disentangle,
    ).to(DEVICE)
    return model


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--epoch', type=int, default=500)
    parser.add_argument('--p2_dir', type=str, default='checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p2')
    parser.add_argument('--p1_dir', type=str, default='checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a')
    args = parser.parse_args()

    dataset = 'bci2a'
    cfg = DATASET_CONFIG[dataset]
    num_subjects = cfg['num_subjects']

    # ------------------------------------------------------------------
    # [1/4] 加载 P2 / P1 checkpoints
    # ------------------------------------------------------------------
    p2_path = PROJECT_ROOT / args.p2_dir / f'sb_sd_ldm_p2_epoch_{args.epoch}.pt'
    p1_path = PROJECT_ROOT / args.p1_dir / 'sb_sd_ldm_epoch_500.pt'
    print(f'[1/4] 加载 P2: {p2_path}')
    print(f'      加载 P1: {p1_path}')
    p2_ckpt = torch.load(str(p2_path), map_location=DEVICE, weights_only=False)
    p1_ckpt = torch.load(str(p1_path), map_location=DEVICE, weights_only=False)
    assert p2_ckpt.get('disentangle', False), 'P2 checkpoint 应含 subject_disc'

    subj_dim = p2_ckpt.get('subj_dim', 32)

    model_p2 = build_model(p2_ckpt['config'], dataset, True, subj_dim, num_subjects)
    model_p2.load_state_dict(p2_ckpt['model_state_dict'])

    model_p1 = build_model(p1_ckpt['config'], dataset, False,
                           p1_ckpt.get('subj_dim', 32), num_subjects)
    model_p1.load_state_dict(p1_ckpt['model_state_dict'])

    cond_embed = torch.nn.Embedding(cfg['num_classes'],
                                    int(p2_ckpt['config'].get('model', {}).get('cond_embed_dim', 64))).to(DEVICE)
    cond_embed.load_state_dict(p2_ckpt['cond_embed_state_dict'])
    cond_embed.eval()

    # ------------------------------------------------------------------
    # [2/4] 数据 + 编码
    # ------------------------------------------------------------------
    X, y, subjects = load_dataset(dataset)
    X_t = torch.FloatTensor(X)
    y_t = torch.LongTensor(y)
    subj_t = torch.LongTensor(subjects)

    print('\n[2/4] 编码全量训练集 (P1 / P2)...')
    z_p1 = encode_all(model_p1, cond_embed, X_t, y_t)
    z_p2 = encode_all(model_p2, cond_embed, X_t, y_t)
    print(f'  z 形状: P1 {z_p1.shape}, P2 {z_p2.shape}')

    # ------------------------------------------------------------------
    # [3/4] Fresh probes: 被试泄漏 + 类别保留
    # ------------------------------------------------------------------
    print('\n[3/4] Fresh probe 训练 (被试探针 x2 + 类别探针 x2)...')
    subj_p1 = train_probe(z_p1, subjects, num_subjects)
    subj_p2 = train_probe(z_p2, subjects, num_subjects)
    cls_p1 = train_probe(z_p1, y, cfg['num_classes'])
    cls_p2 = train_probe(z_p2, y, cfg['num_classes'])
    chance_subj = 1.0 / num_subjects
    chance_cls = 1.0 / cfg['num_classes']

    # ------------------------------------------------------------------
    # [4/4] 重建/风格 (P2 模型, 复用 P1 的 eval_style_quality)
    # ------------------------------------------------------------------
    teacher = load_teacher(dataset, cfg['channels'], cfg['input_length'], cfg['num_classes'])
    m = eval_style_quality(model_p2, cond_embed, teacher, X_t, y_t, subj_t,
                           num_subjects, n=1000)

    # ------------------------------------------------------------------
    # 报告
    # ------------------------------------------------------------------
    print('\n' + '=' * 70)
    print(f'P2 验收报告 (epoch {args.epoch})')
    print('=' * 70)
    print(f'  G1 被试探针 (z):  P1 {subj_p1*100:.1f}% -> P2 {subj_p2*100:.1f}%  '
          f'[{"通过" if subj_p2 <= 0.25 else "失败"}] (门: <=25%, chance={chance_subj*100:.1f}%)')
    print(f'  G2 类别探针 (z):  P1 {cls_p1*100:.1f}% -> P2 {cls_p2*100:.1f}%  '
          f'[{"通过" if cls_p2 >= 0.90 else "失败"}] (门: >=90%)')
    print(f'  G3 重建判类:      {m["recon_class_acc"]*100:.1f}%  '
          f'[{"通过" if m["recon_class_acc"] >= 0.95 else "失败"}] (门: >=95%)')
    print(f'  G4 交换控制:      {m["swap_acc"]*100:.1f}%  '
          f'[{"通过" if m["swap_acc"] >= 0.70 else "失败"}] (门: >=70%, backfire={m["swap_backfire"]*100:.1f}%)')
    print(f'  附: 风格判回 {m["style_acc"]*100:.1f}% | '
          f'mse_true={m["mse_true"]:.4f} mse_swap={m["mse_swap"]:.4f} '
          f'(比值 {m["mse_swap"]/max(m["mse_true"],1e-9):.2f}x)')

    leakage_removed = (subj_p1 - subj_p2) * 100
    print('-' * 70)
    print(f'  泄漏移除量: {leakage_removed:.1f} 个百分点 (P1 -> P2)')

    all_pass = (subj_p2 <= 0.25 and cls_p2 >= 0.90
                and m['recon_class_acc'] >= 0.95 and m['swap_acc'] >= 0.70)
    print('=' * 70)
    if all_pass:
        print('  P2 总体验收: 全部通过 — z 已解耦, 可进入 P3 (跨被试生成)')
    elif subj_p2 > 0.25 and cls_p2 >= 0.90 and m['recon_class_acc'] >= 0.95:
        print('  P2 总体验收: 部分通过 — 解耦不彻底, 建议 lambda_inv 0.3->0.5 重训或延长 alpha_ramp')
    else:
        print('  P2 总体验收: 未通过 — 类信息/重建受损, 建议 lambda_inv 减半重训')
    print('=' * 70)

    out = PROJECT_ROOT / 'outputs/results/sb_sd_ldm_bci2a_p2_validation.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, 'w', encoding='utf-8') as f:
        json.dump({
            'epoch': args.epoch,
            'subject_probe': {'p1': subj_p1, 'p2': subj_p2, 'chance': chance_subj},
            'class_probe': {'p1': cls_p1, 'p2': cls_p2, 'chance': chance_cls},
            'recon_swap_metrics': m,
            'leakage_removed_pp': leakage_removed,
            'all_pass': all_pass,
        }, f, indent=2, ensure_ascii=False)
    print(f'\n已保存: {out}')


if __name__ == '__main__':
    main()
