# 接力链: BCI2a ours 完成 -> BCI2b ours -> PhysioNet ours (+ PhysioNet real_only)
# 用途: 三场景统一协议评测过夜自动执行 (2026-08-23)
$ErrorActionPreference = 'Continue'
$logdir = 'F:\DS-DDPM-main\outputs\logs'
$py = 'F:\DS-DDPM-main\projects\tc_conf_ldm\scripts\SB-SD-LDM\evaluate_sbsdldm_3scenarios.py'
New-Item -ItemType Directory -Force -Path $logdir | Out-Null

function Log($msg) {
    "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg" | Add-Content "$logdir\chain_rest.log"
}

function Run-Py($argList, $log) {
    $p = Start-Process -FilePath python -ArgumentList $argList -NoNewWindow -PassThru -Wait `
        -RedirectStandardOutput "$logdir\$log" -RedirectStandardError "$logdir\$log.err"
    if ($p.ExitCode -ne 0) { Log "FAILED ($($p.ExitCode)): $log" }
    else { Log "DONE: $log" }
    return $p.ExitCode
}

$env:PYTHONUTF8 = '1'

Log 'watcher started: waiting for bci2a ours to finish'
while (Get-CimInstance Win32_Process -Filter "Name='python.exe'" |
       Where-Object { $_.CommandLine -like '*evaluate_sbsdldm_3scenarios.py*--dataset bci2a*--method ours*' }) {
    Start-Sleep -Seconds 60
}
Log 'bci2a ours finished -> starting bci2b ours + bci2b real_only (parallel)'
$proc_2b_rl = Start-Process -FilePath python -ArgumentList @('-u', $py, '--dataset', 'bci2b', '--method', 'real_only', '--scenario', 'all') `
    -NoNewWindow -PassThru -RedirectStandardOutput "$logdir\sbsdldm_bci2b_real_only.log" -RedirectStandardError "$logdir\sbsdldm_bci2b_real_only.log.err"
Run-Py @('-u', $py, '--dataset', 'bci2b', '--method', 'ours', '--scenario', 'all') 'sbsdldm_bci2b_ours.log'
if ($proc_2b_rl -and -not $proc_2b_rl.HasExited) { Wait-Process -Id $proc_2b_rl.Id -ErrorAction SilentlyContinue }

Log 'bci2b ours finished -> starting physionet ours + physionet real_only (parallel)'
Run-Py @('-u', $py, '--dataset', 'physionet', '--method', 'ours', '--scenario', 'cross_subject') 'sbsdldm_physionet_ours.log'
$proc_rl = Start-Process -FilePath python -ArgumentList @('-u', $py, '--dataset', 'physionet', '--method', 'real_only', '--scenario', 'cross_subject') `
    -NoNewWindow -PassThru -RedirectStandardOutput "$logdir\sbsdldm_physionet_real_only.log" -RedirectStandardError "$logdir\sbsdldm_physionet_real_only.log.err"

Log 'physionet ours finished -> waiting for physionet real_only'
if ($proc_rl -and -not $proc_rl.HasExited) { Wait-Process -Id $proc_rl.Id -ErrorAction SilentlyContinue }
Log 'chain complete'
