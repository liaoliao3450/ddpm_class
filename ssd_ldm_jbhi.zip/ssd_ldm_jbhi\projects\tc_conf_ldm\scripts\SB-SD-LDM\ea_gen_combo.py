#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EA + fewshot 生成组合 (互补假设的直接检验)
===============================================================
三块证据链:
  1. Mantel n.s. + LOO R2(style->cov)=0.055: 风格与协方差几何基本正交
  2. EA-40 (纯协方差对齐): 59.68%  >>  fewshot 生成 53.01%
  3. fewshot 定向增益 (+1.0pp) 稳定存在
=> 假设: EA 对齐协方差 (大头), 生成补非协方差风格变异 (小头), 组合应 > EA-only.

协议 (与 ea_baseline_loso.py / evaluate_p4 逐字对齐):
  真实训练数据: 每个训练被试用自己全部 trial 估计 R_s -> x' = R_s^{-1/2} x
  测试数据:     测试被试前 40 个无标签 trial 估计 R_test (与 EA-40 同预算)
  生成数据:     fewshot 风格 (同 40 trial 估计, jitter=0.2*sigma0), DDIM50/CFG2.0,
                然后按 --gen_ea 白化:
                  test:  用 R_test 白化 (风格蕴含协方差的假设)
                  batch: 用生成批自身协方差白化 (EA 哲学: 各源按自身统计白化)
                  none:  不白化 (对照, 预期分布失配)
  分类器: EEGNet x3 集成, 200 epochs, batch 32, lr 1e-3, 软投票

诊断: 每折记录 d(gen_cov, R_test) log-Euclid 距离
  (风格定向是否真的复现了测试被试协方差 -> 解释组合增益来源)

锚点: real-only 51.99 / fewshot 53.01 / EA-40 59.68

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/ea_gen_combo.py --gen_ea test
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/ea_gen_combo.py --gen_ea batch
"""
import sys
import json
import argparse
from pathlib import Path

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from style_vae import load_style_vae
from ea_baseline_loso import ea_transform, subject_Rs
from diag_style_cov_cca import logm_sym
from evaluate_p4_cross_subject import (
    load_p2_model, generate_p4, set_seed, DEVICE,
    DDIM_STEPS, N_ENSEMBLE)

import importlib.util


def _load_ev():
    spec = importlib.util.spec_from_file_location(
        'evaluate_sb_ldm_3datasets',
        str(PROJECT_ROOT / 'projects/tc_conf_ldm/scripts/SB-LDM/evaluate_sb_ldm_3datasets.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# 组合脚本固定 fewshot 最佳配置 (jitter=0.2*sigma0, 即 53.01% 那一版)
import evaluate_p4_cross_subject as ev_p4

SEED = 42
N_FEWSHOT = 40
GEN_RATIO = 1.0
NUM_CLASSES = 4

ANCHORS = {'real-only': (0.5199, 0.360), 'fewshot-gen': (0.5301, 0.373),
           'EA-40': (0.5968, 0.462)}


def log_euclid(Ra, Rb):
    return float(np.linalg.norm(logm_sym(Ra) - logm_sym(Rb)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--gen_ea', type=str, default='test',
                        choices=['test', 'batch', 'none'],
                        help='生成样本白化方式')
    parser.add_argument('--strategy', type=str, default='fewshot',
                        choices=['fewshot', 'prior'],
                        help='生成风格来源 (fewshot=定向 / prior=盲)')
    parser.add_argument('--ratio', type=float, default=1.0)
    parser.add_argument('--jitter', type=float, default=None,
                        help='fewshot 风格抖动宽度 (默认 0.2*sigma0, 53.01% 版配置)')
    parser.add_argument('--p2_ckpt', type=str,
                        default='checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p2/sb_sd_ldm_p2_epoch_500.pt')
    parser.add_argument('--p4_ckpt', type=str,
                        default='checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p4/style_vae_final.pt')
    args = parser.parse_args()

    print('=' * 72)
    print(f'EA + 生成组合 LOSO: strategy={args.strategy}, gen_ea={args.gen_ea}, '
          f'ratio={args.ratio}')
    print(f'锚点: real-only 51.99 / fewshot-gen 53.01 / EA-40 59.68')
    print('=' * 72)

    # 1) 模型
    model, cond_embed = load_p2_model(PROJECT_ROOT / args.p2_ckpt)
    style_enc, _, sigma0 = load_style_vae(
        PROJECT_ROOT / args.p4_ckpt, channels=22, input_length=1000,
        num_classes=4, device=DEVICE)
    jitter = args.jitter if args.jitter is not None else 0.2 * sigma0
    ev_p4.FEWSHOT_SIGMA = jitter
    ev_p4.GUIDANCE_SCALE = 2.0
    ev_p4.DDIM_STEPS = DDIM_STEPS
    print(f'sigma0={sigma0}, jitter={jitter:.3f}')

    # 2) 数据
    ev = _load_ev()
    X, y, subjects, sessions = ev.load_dataset_data('bci2a')
    subj_uniq = np.unique(subjects)
    if subj_uniq.max() != len(subj_uniq) - 1:
        remap = {s: i for i, s in enumerate(subj_uniq)}
        subjects = np.array([remap[s] for s in subjects])
    n_subj = len(np.unique(subjects))
    channels, input_length = X.shape[1], X.shape[2]

    ev.GEN_RATIO = GEN_RATIO
    ev.N_ENSEMBLE = N_ENSEMBLE

    from sklearn.metrics import accuracy_score, cohen_kappa_score

    results, dists = [], []
    for test_subj in range(n_subj):
        m_test = subjects == test_subj
        X_test_raw, y_test = X[m_test], y[m_test]
        X_few = X_test_raw[:N_FEWSHOT]      # 40 无标签 trial: 风格 + R_test 双用途
        R_test = subject_Rs(X_few)

        # 真实训练数据: 每被试独立 EA
        X_train_parts, y_train_parts = [], []
        train_subj_ids = []
        for s in range(n_subj):
            if s == test_subj:
                continue
            m = subjects == s
            X_train_parts.append(ea_transform(X[m], subject_Rs(X[m])))
            y_train_parts.append(y[m])
            train_subj_ids.append(s)
        X_tr = np.concatenate(X_train_parts)
        y_tr = np.concatenate(y_train_parts)

        # 生成 (fewshot 定向 / prior 盲)
        spc = max(1, int(GEN_RATIO * len(X_tr)) // NUM_CLASSES)
        set_seed()
        gen_X, gen_y = generate_p4(
            model, cond_embed, style_enc, spc, NUM_CLASSES, args.strategy,
            train_subj_ids, X_few=X_few, sigma0=sigma0)
        gen_X = np.nan_to_num(gen_X.astype(np.float32), nan=0.0)

        # 诊断: 生成批协方差 vs R_test (风格是否复现测试协方差)
        d_gen = log_euclid(subject_Rs(gen_X), R_test)
        dists.append(d_gen)

        # 生成样本白化
        if args.gen_ea == 'test':
            gen_X = ea_transform(gen_X, R_test)
        elif args.gen_ea == 'batch':
            gen_X = ea_transform(gen_X, subject_Rs(gen_X))

        X_aug = np.concatenate([X_tr, gen_X])
        y_aug = np.concatenate([y_tr, gen_y])

        # 测试数据 EA (R_test, 40-trial 预算, 与 EA-40 一致)
        X_test = ea_transform(X_test_raw, R_test)

        clf = ev.train_classifier(X_aug, y_aug, channels, input_length, NUM_CLASSES)
        pred = ev.predict(clf, X_test)
        acc = float(accuracy_score(y_test, pred))
        kappa = float(cohen_kappa_score(y_test, pred))
        results.append({'acc': acc, 'kappa': kappa})
        print(f'  被试 {test_subj + 1}: Acc {acc * 100:.2f}%, Kappa {kappa:.4f} '
              f'(d_gen-Rtest={d_gen:.2f})')

    accs = [r['acc'] for r in results]
    kappas = [r['kappa'] for r in results]
    res = {'mean': float(np.mean(accs)), 'std': float(np.std(accs)),
           'per_subject': accs, 'mean_kappa': float(np.mean(kappas)),
           'std_kappa': float(np.std(kappas)), 'per_subject_kappa': kappas,
           'gen_cov_dist_to_Rtest': dists}

    print('\n' + '=' * 72)
    print(f'>>> EA+{args.strategy}-gen (gen_ea={args.gen_ea}): '
          f'{res["mean"] * 100:.2f}% ± {res["std"] * 100:.2f}% '
          f'(Kappa {res["mean_kappa"]:.4f})')
    print(f'    生成协方差与 R_test 的 log-Euclid 距离: '
          f'mean={np.mean(dists):.2f}')
    print(f'    锚点: EA-40 59.68 (Kappa 0.462) / fewshot-gen 53.01 / real-only 51.99')
    combo_gain = res['mean'] - ANCHORS['EA-40'][0]
    print(f'    组合相对 EA-40: {"+" if combo_gain >= 0 else ""}'
          f'{combo_gain * 100:.2f}pp -> '
          f'{"互补假设成立" if combo_gain > 0.005 else "无增益/冲突"}')
    print('=' * 72)

    out = PROJECT_ROOT / f'outputs/results/ea_gen_combo_{args.strategy}_{args.gen_ea}.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, 'w', encoding='utf-8') as f:
        json.dump({'strategy': args.strategy, 'gen_ea': args.gen_ea,
                   'ratio': args.ratio, 'jitter': jitter,
                   'loso': res}, f, indent=2, ensure_ascii=False)
    print(f'结果已保存: {out}')


if __name__ == '__main__':
    main()
