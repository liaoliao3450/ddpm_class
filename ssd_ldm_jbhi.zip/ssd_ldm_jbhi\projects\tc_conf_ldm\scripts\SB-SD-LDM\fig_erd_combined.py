#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
期刊补充图: ERD 时频图 + 脑地形图组合 (ERD-DDPM 旧版风格, 2 个代表被试)
======================================================================
镜像 4_generate_erd_tfr_plots_tc_conf_ldm.py / ERD-DDPM 11_ 的布局:
  Row 0: 4 个时频图 (Real-Left-C4 | Real-Right-C3 | SSD-LDM-Left-C4 | SSD-LDM-Right-C3)
  Row 1: 4 个地形图 (Real-Left | Real-Right | SSD-LDM-Left | SSD-LDM-Right)
  figsize=(16,11), height_ratios=[1.0,1.1], hspace=0.45, 独立 colorbar

区别于 4_ (旧会议模型 + AdaIN): 生成端换成期刊主方法 SSD-LDM
  L1 latent_match + L2 chart(cov_test) + L3 amp_calib full (evaluate_p5 融合管线),
  LOSO 折 (pool = 其余 8 被试), few-shot 40 trial (teacher 伪标签) 定目标域.

Real 端与旧版完全一致: GDF raw (-1.5..2.5s, cue@375) + 基线 z-score.
Gen 端: ev 空间生成 -> X.npy 原尺度 -> 被试 session-0 逐通道 z (与旧版
normalize_generated_data_to_real_stats 同构), clip[-5,5].

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/fig_erd_combined.py
"""
import sys
import importlib.util
from pathlib import Path

import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from style_vae import load_style_vae
from style_vae_cov import load_p5
from evaluate_p4_cross_subject import load_p2_model, set_seed, DEVICE
from fig_quality import _gen_ours

NUM_CLASSES = 4
N_FEWSHOT = 40
N_PER_CLASS = 72
FS = 250
FIGDIR = PROJECT_ROOT / 'outputs/figures'
FIGDIR.mkdir(parents=True, exist_ok=True)

# ---- 复用 4_ 脚本的 ERD-DDPM 辅助函数 (通道位置/数据加载/标准化) ----
_P4 = PROJECT_ROOT / 'projects' / 'tc_conf_ldm' / 'scripts' / '4_generate_erd_tfr_plots_tc_conf_ldm.py'
_spec = importlib.util.spec_from_file_location('erd_p4', str(_P4))
p4 = importlib.util.module_from_spec(_spec)
sys.modules['erd_p4'] = p4
_spec.loader.exec_module(p4)

C3_IDX, C4_IDX = p4.C3_IDX, p4.C4_IDX
load_raw_bci2a_subject = p4.load_raw_bci2a_subject
standardize_data_with_baseline = p4.standardize_data_with_baseline
compute_alpha_power_mne = p4.compute_alpha_power_mne
create_mne_info = p4.create_mne_info


def _load_ev():
    spec = importlib.util.spec_from_file_location(
        'evaluate_sb_ldm_3datasets',
        str(PROJECT_ROOT / 'projects/tc_conf_ldm/scripts/SB-LDM/evaluate_sb_ldm_3datasets.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def ev_gen_to_subject_space(gX_ev, mu_c, sd_c, X_subj_raw):
    """ev 空间生成样本 -> X.npy 原尺度 -> 被试 session-0 逐通道 z, clip[-5,5]."""
    x_np = gX_ev * (sd_c + 1e-8) + mu_c
    mu_s = X_subj_raw.mean(axis=(0, 2), keepdims=True)
    sd_s = X_subj_raw.std(axis=(0, 2), keepdims=True)
    out = (x_np - mu_s) / (sd_s + 1e-8)
    return np.clip(out.astype(np.float32), -5.0, 5.0)


def generate_combined_tfr_topo(real_data, gen_data, labels_real, labels_gen, fs,
                               save_path, subject_id,
                               baseline_start=0, baseline_end=375,
                               task_start=375):
    """与 4_/11_ 的 generate_combined_tfr_topo 一致, 'SB-SD-LDM' 标签换为 'SSD-LDM'."""
    from mne.time_frequency import tfr_array_morlet, AverageTFR
    import mne

    fig = plt.figure(figsize=(16, 11))
    gs = GridSpec(2, 4, figure=fig,
                  height_ratios=[1.0, 1.1],
                  hspace=0.45, wspace=0.28)

    show_classes = [0, 1]
    class_labels = ['Left', 'Right']
    data_labels = {'real': 'Real', 'gen': 'SSD-LDM'}
    contralateral_ch = {0: (C4_IDX, 'C4'), 1: (C3_IDX, 'C3')}

    # ---------- 时频图 (MNE Morlet + ERD%) ----------
    freqs = np.linspace(4, 30, 50)
    n_cycles = np.array([max(6.0, f / 2.0) for f in freqs])
    ref_samples = int(0.5 * fs)
    N_PER_CLASS = 50

    all_tfr_objs = {}
    for class_id in show_classes:
        # Real
        ch_idx, ch_name = contralateral_ch[class_id]
        info_ch = mne.create_info([ch_name], sfreq=fs, ch_types='eeg')
        real_class = real_data[labels_real == class_id][:N_PER_CLASS]
        real_epochs = real_class[:, ch_idx:ch_idx + 1, :].astype(np.float64)
        tfr_real = tfr_array_morlet(
            real_epochs, sfreq=fs, freqs=freqs, n_cycles=n_cycles,
            output='power', use_fft=True, decim=1).squeeze(1)
        tfr_avg = tfr_real.mean(axis=0)
        times_real = (np.arange(real_data.shape[2]) / fs) - (baseline_end / fs)
        all_tfr_objs[('real', class_id)] = AverageTFR(
            inst={'data': tfr_avg[None, :, :],
                  'info': info_ch, 'times': times_real, 'freqs': freqs},
            comment=f'real_{ch_name}')

        # Gen
        gen_class = gen_data[labels_gen == class_id][:N_PER_CLASS]
        gen_epochs = gen_class[:, ch_idx:ch_idx + 1, :].astype(np.float64)
        tfr_gen = tfr_array_morlet(
            gen_epochs, sfreq=fs, freqs=freqs, n_cycles=n_cycles,
            output='power', use_fft=True, decim=1).squeeze(1)
        tfr_avg_g = tfr_gen.mean(axis=0)
        times_gen = np.linspace(0, tfr_avg_g.shape[1] / fs, tfr_avg_g.shape[1])
        all_tfr_objs[('gen', class_id)] = AverageTFR(
            inst={'data': tfr_avg_g[None, :, :],
                  'info': info_ch, 'times': times_gen, 'freqs': freqs},
            comment=f'ssd_ldm_{ch_name}')

    vmin_tf, vmax_tf = -50, 50
    from mne.baseline import rescale
    last_im = None
    col_order = [('real', 0), ('real', 1), ('gen', 0), ('gen', 1)]

    for col, (data_key, class_id) in enumerate(col_order):
        ax = fig.add_subplot(gs[0, col])
        key = (data_key, class_id)
        if key not in all_tfr_objs:
            ax.axis('off')
            continue

        tfr_obj = all_tfr_objs[key]
        ch_name = contralateral_ch[class_id][1]

        if data_key == 'real':
            bl = (-baseline_end / fs, 0)      # pre-cue (-1.5, 0)
        else:
            bl = (0, ref_samples / fs)        # early-task (0, 0.5)

        data = tfr_obj.data[0]
        times = tfr_obj.times
        data_pct = rescale(data, times=times, baseline=bl,
                           mode='percent', copy=True) * 100

        im = ax.pcolormesh(times, freqs, data_pct, cmap='RdBu_r',
                           vmin=vmin_tf, vmax=vmax_tf, shading='auto')
        last_im = im

        ax.axhline(y=8, color='black', linestyle='--', linewidth=0.6, alpha=0.5)
        ax.axhline(y=13, color='black', linestyle='--', linewidth=0.6, alpha=0.5)
        ax.axvline(x=0, color='black', linestyle='--', linewidth=1.0, alpha=0.7)

        ax.set_ylim(4, 30)
        ax.set_ylabel('Frequency (Hz)', fontsize=14)
        ax.set_xlabel('Time (s)', fontsize=14)
        ax.tick_params(labelsize=12)

        ax.set_title(f'{data_labels[data_key]} - {class_labels[class_id]} ({ch_name})',
                     fontsize=18, fontweight='bold')

    cbar_ax1 = fig.add_axes([0.92, 0.58, 0.015, 0.30])
    if last_im is not None:
        cbar1 = fig.colorbar(last_im, cax=cbar_ax1)
        cbar1.set_label('ERD/ERS (%)', fontsize=18)
        cbar1.ax.tick_params(labelsize=18)

    # ---------- 拓扑图 (alpha 功率 z-score) ----------
    info = create_mne_info(fs)

    all_zscore = {}
    for class_id in show_classes:
        mask_r = labels_real == class_id
        mask_g = labels_gen == class_id
        if mask_r.sum() > 0:
            p = compute_alpha_power_mne(real_data[mask_r][:N_PER_CLASS], fs,
                                        task_start=task_start)
            all_zscore[('real', class_id)] = (p - p.mean()) / (p.std() + 1e-8)
        if mask_g.sum() > 0:
            p = compute_alpha_power_mne(gen_data[mask_g][:N_PER_CLASS], fs, task_start=None)
            all_zscore[('gen', class_id)] = (p - p.mean()) / (p.std() + 1e-8)

    if all_zscore:
        all_vals_z = np.concatenate([v for v in all_zscore.values()])
        abs_max_z = max(abs(all_vals_z.min()), abs(all_vals_z.max()))
    else:
        abs_max_z = 1.0

    topo_im = None
    for col, (data_key, class_id) in enumerate(col_order):
        ax = fig.add_subplot(gs[1, col])
        key = (data_key, class_id)
        if key not in all_zscore:
            ax.axis('off')
            continue

        z = all_zscore[key]
        topo_im, _ = mne.viz.plot_topomap(
            z, info, axes=ax, cmap='RdBu_r',
            vlim=(-abs_max_z, abs_max_z),
            show=False, contours=6, sphere=None)

        ax.set_title(f'{data_labels[data_key]} - {class_labels[class_id]}',
                     fontsize=18, fontweight='bold')

    cbar_ax2 = fig.add_axes([0.92, 0.10, 0.015, 0.28])
    cbar2 = fig.colorbar(topo_im, cax=cbar_ax2)
    cbar2.set_label('Alpha Power (z-score)', fontsize=18)
    cbar2.ax.tick_params(labelsize=18)

    plt.savefig(str(save_path), dpi=300, bbox_inches='tight')
    plt.close(fig)


def main():
    set_seed()
    ev = _load_ev()

    # ---- 期刊模型 + ev 数据 ----
    model, cond_embed = load_p2_model(
        PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p2/sb_sd_ldm_p2_epoch_500.pt')
    style_enc, _, _ = load_style_vae(
        PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p4/style_vae_final.pt',
        channels=22, input_length=1000, num_classes=4, device=DEVICE)
    chart, covemb, sigma0_p5 = load_p5(
        PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p5/cov_chart_final.pt',
        device=DEVICE)

    from core.classifiers.eegnet import EEGNet
    teacher = EEGNet(n_channels=22, n_samples=1000, n_classes=4).to(DEVICE)
    state = torch.load(str(
        PROJECT_ROOT / 'checkpoints/tc_conf_ldm/bci2a_shared_margin/pretrained_teacher_eegnet.pt'),
        map_location=DEVICE, weights_only=False)
    if isinstance(state, dict) and 'model_state_dict' in state:
        state = state['model_state_dict']
    teacher.load_state_dict(state, strict=False)
    teacher.eval()

    X, y, subjects, sessions = ev.load_dataset_data('bci2a')
    subj_uniq = np.unique(subjects)
    if subj_uniq.max() != len(subj_uniq) - 1:
        remap = {s: i for i, s in enumerate(subj_uniq)}
        subjects = np.array([remap[s] for s in subjects])

    # ev 逆变换统计 (X.npy 原尺度)
    d = PROJECT_ROOT / 'data' / 'processed' / 'BCI2a'
    X_np = np.load(str(d / 'X.npy')).astype(np.float32)
    y_np = np.load(str(d / 'y.npy')).astype(np.int64)
    y_ev = y_np - y_np.min()
    mask = y_ev < NUM_CLASSES
    mu_c = X_np[mask].mean(axis=(0, 2), keepdims=True)
    sd_c = X_np[mask].std(axis=(0, 2), keepdims=True)

    # ---- 两个代表被试 (与 ERD-DDPM 论文一致: 被试 1 和 3) ----
    for subject_id in (1, 3):
        print(f'\n========== Subject {subject_id} ==========')
        # Real: GDF raw + 基线标准化 (与旧版一致)
        X_train, y_train = load_raw_bci2a_subject(subject_id=subject_id, session=0)
        X_train_std = standardize_data_with_baseline(X_train, 375)

        # Gen: LOSO 折 + few-shot 融合生成
        test_subj = subject_id - 1
        m_test = subjects == test_subj
        X_few = X[m_test][:N_FEWSHOT]
        with torch.no_grad():
            xb = torch.FloatTensor(X_few).unsqueeze(1).to(DEVICE)
            y_pl = teacher(xb).argmax(1).cpu().numpy()
        X_pool, y_pool = X[~m_test], y[~m_test]

        set_seed()
        gX_ev, gy = _gen_ours(model, cond_embed, style_enc, chart, covemb,
                              sigma0_p5, X_few, y_pl, X_pool, y_pool, N_PER_CLASS)

        # 被试 session-0 原始统计 (A0XT)
        subj_dir = d / f'A{subject_id:02d}T'
        if subj_dir.exists():
            X_subj_raw = np.load(str(subj_dir / 'X.npy')).astype(np.float32)
        else:
            X_subj_raw = X_np[mask]  # 兜底: 全体统计

        gen_samples = ev_gen_to_subject_space(gX_ev, mu_c, sd_c, X_subj_raw)
        print(f'  real {X_train_std.shape}, gen {gen_samples.shape}, '
              f'gen range [{gen_samples.min():.2f}, {gen_samples.max():.2f}]')

        for ext in ['pdf', 'png']:
            out = FIGDIR / f'fig_erd_combined_subj{subject_id}_bci2a.{ext}'
            generate_combined_tfr_topo(
                X_train_std, gen_samples, y_train, gy.astype(int), FS,
                out, subject_id=subject_id,
                baseline_start=0, baseline_end=375, task_start=375)
            print(f'  saved {out}')

    del model, cond_embed, style_enc, chart, covemb
    torch.cuda.empty_cache()
    print('\nAll combined ERD figures done ->', FIGDIR)


if __name__ == '__main__':
    main()
