#!/usr/bin/env python3
"""
生成会议论文用的质量评估图:
  1. PSD 对比图 (真实 vs 生成, C3/Cz/C4, 4类)
  2. UMAP 对比图 (多方法对比, EEGClassifier 特征)
"""
import sys
from pathlib import Path
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy.signal import welch

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from core.models.latent_diffusion.model_shared import (
    SharedVAEUNetLDM1D, SharedBackboneConfig,
)
from projects.tc_conf_ldm.core.task_conditioning import TaskConditionEmbedding

# Baseline models (与 visualize_all_datasets.py 一致)
_BASELINE_PATH = PROJECT_ROOT / 'core' / 'models' / 'baselines'
if str(_BASELINE_PATH) not in sys.path:
    sys.path.insert(0, str(_BASELINE_PATH))
from comparison_models import WaveGAN, BrainDiff, EEGDiff, DiffEEGBooth
from cvae_gaussian import CVAE

# EEGClassifier (从 DDPM checkpoint 加载, 用于特征提取, 与 5_classifier_features_tsne.py 一致)
_DDPMPATH = PROJECT_ROOT / 'core' / 'models' / 'ddpm'
if str(_DDPMPATH) not in sys.path:
    sys.path.insert(0, str(_DDPMPATH))
from class_discriminative import EEGClassifier

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
SEED = 42
FIG_DIR = PROJECT_ROOT / "paper"
BASELINE_CKPT_DIR = PROJECT_ROOT / 'checkpoints' / 'baselines'

# BCI2a 通道索引 (标准 10-20 排列)
# C3=7, Cz=9, C4=11 (0-indexed in 22-channel BCI2a)
KEY_CH = [7, 9, 11]
KEY_CH_NAMES = ['C3', 'Cz', 'C4']
CLASS_NAMES = ['Left hand', 'Right hand', 'Feet', 'Tongue']
COLORS = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']

# 类别配色 (与参照脚本 6_gen_quality_evaluation.py 一致)
CLASS_COLORS = ['#e74c3c', '#3498db', '#2ecc71', '#9b59b6']

# 对比方法 (顺序与论文 baseline 一致, 不含 ERD-DDPM)
BASELINE_KEY_MAP = {
    'cvae': 'CVAE',
    'wavegan': 'WaveGAN',
    'braindiff': 'BrainDiff',
    'eegdiff': 'EEGDiffuser',
    'diffeegbooth': 'DiffEEGBooth',
}


def set_seed(seed=SEED):
    import random
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)


def notch_filter_artifact(data, fs=250, freq=31.25, Q=30.0):
    """陷波滤波器: 去除 31.25Hz (fs/8) VAE 解码器上采样伪影.
    31.25Hz 在 μ(8-13Hz)/β(13-30Hz) 频段之外, 不影响 ERD 特征."""
    from scipy.signal import iirnotch, filtfilt
    nyq = fs / 2.0
    w0 = freq / nyq
    b, a = iirnotch(w0, Q)
    filtered = np.zeros_like(data, dtype=np.float32)
    for i in range(len(data)):
        for ch in range(data.shape[1]):
            filtered[i, ch, :] = filtfilt(b, a, data[i, ch, :])
    return filtered


def load_sb_ldm_model():
    """加载 SB-LDM (会议论文) 模型. 注意: 不加载 teacher, 不引用 SB-SD-LDM (期刊) 的任何组件."""
    ckpt_path = PROJECT_ROOT / "checkpoints/tc_conf_ldm/bci2a_shared/tc_conf_ldm_shared_epoch_500.pt"
    checkpoint = torch.load(str(ckpt_path), map_location=DEVICE, weights_only=False)
    cfg_dict = checkpoint.get('config', {})
    model_cfg = cfg_dict.get('model', {})
    data_cfg = cfg_dict.get('data', {})

    channels = int(data_cfg.get('num_channels', 22))
    input_length = int(data_cfg.get('segment_length', 1000))
    cond_dim = int(model_cfg.get('cond_embed_dim', 64))
    backbone = SharedBackboneConfig(
        base=int(model_cfg.get('backbone_base', 64)),
        levels=tuple(int(x) for x in model_cfg.get('backbone_levels', [1, 2, 4])),
        blocks_per_level=int(model_cfg.get('backbone_blocks_per_level', 2)),
    )
    model = SharedVAEUNetLDM1D(
        channels=channels, input_length=input_length,
        z_channels=int(model_cfg.get('z_channels', 64)),
        timesteps=int(model_cfg.get('timesteps', 1000)),
        t_dim=int(model_cfg.get('t_dim', 128)),
        cond_dim=cond_dim, backbone=backbone,
        num_subjects=int(model_cfg.get('num_subjects', 0)),
        adv_alpha=float(model_cfg.get('adv_alpha', 0.0)),
    ).to(DEVICE)

    cond_embed = TaskConditionEmbedding(
        num_classes=4, num_scenarios=3, embed_dim=cond_dim,
        num_subjects=int(model_cfg.get('num_subjects', 0)),
    ).to(DEVICE)

    model.load_state_dict(checkpoint['model_state_dict'], strict=False)
    cond_embed.load_state_dict(checkpoint['cond_embed_state_dict'], strict=False)
    model.eval()
    cond_embed.eval()

    print(f"  SB-LDM (bci2a_shared) 加载完成, channels={channels}, length={input_length}")
    return model, cond_embed, channels, input_length, cond_dim


@torch.no_grad()
def generate_samples(model, cond_embed, n_per_class=100, cond_dim=64, channels=22, input_length=1000):
    """生成样本."""
    dummy_x = torch.zeros(1, channels, input_length, device=DEVICE)
    dummy_cond = torch.zeros(1, cond_dim, device=DEVICE)
    z_dummy, _, _ = model.encode(dummy_x, cond=dummy_cond)
    z_channels = z_dummy.shape[1]
    latent_length = z_dummy.shape[2]

    all_x, all_y = [], []
    for cls in range(4):
        y = torch.full((n_per_class,), cls, dtype=torch.long, device=DEVICE)
        s = torch.zeros(n_per_class, dtype=torch.long, device=DEVICE)
        d = torch.full((n_per_class,), 0.5, dtype=torch.float, device=DEVICE)
        cond = cond_embed(y, s, d)
        z0 = model.sample(
            n_samples=n_per_class,
            latent_shape=(z_channels, latent_length),
            cond=cond, guidance_scale=2.0,
        )
        x = model.decode(z0, target_length=input_length, cond=cond)
        all_x.append(x.cpu())
        all_y.append(y.cpu())
        print(f"  class {cls} done")
    X_gen = torch.cat(all_x, dim=0).numpy()
    y_gen = torch.cat(all_y, dim=0).numpy()
    return X_gen, y_gen


def normalize_to_real(X_real, X_gen):
    real_mean = X_real.mean(axis=(0, 2), keepdims=True)
    real_std = X_real.std(axis=(0, 2), keepdims=True)
    gen_mean = X_gen.mean(axis=(0, 2), keepdims=True)
    gen_std = X_gen.std(axis=(0, 2), keepdims=True)
    eps = 1e-8
    return (X_gen - gen_mean) / (gen_std + eps) * (real_std + eps) + real_mean


# ============================================================================
# Baseline 加载与样本生成 (参照 visualize_all_datasets.py)
# ============================================================================
def load_baseline_model(model_key, channels=22, n_samples=1000, fs=250, num_classes=4):
    """加载 baseline 模型."""
    ckpt_path = BASELINE_CKPT_DIR / f'{model_key}_bci2a.pt'
    if not ckpt_path.exists():
        print(f"  [WARN] 无 checkpoint: {ckpt_path}")
        return None
    ckpt = torch.load(str(ckpt_path), map_location=DEVICE, weights_only=False)
    if model_key == 'cvae':
        model = CVAE(channels=channels, latent_dim=64, out_length=n_samples, num_classes=num_classes)
        model.load_state_dict(ckpt['model_state_dict'])
    elif model_key == 'wavegan':
        model = WaveGAN(channels=channels, out_length=n_samples, num_classes=num_classes)
        model.generator.load_state_dict(ckpt['generator'])
    elif model_key == 'braindiff':
        model = BrainDiff(channels=channels, n_samples=n_samples, num_classes=num_classes)
        model.load_state_dict(ckpt['model_state_dict'])
    elif model_key == 'eegdiff':
        model = EEGDiff(channels=channels, n_samples=n_samples, num_classes=num_classes)
        model.load_state_dict(ckpt['model_state_dict'])
    elif model_key == 'diffeegbooth':
        model = DiffEEGBooth(channels=channels, n_samples=n_samples, num_classes=num_classes, fs=fs)
        sd = ckpt['model_state_dict']
        if 'target_laterality' in sd and sd['target_laterality'].shape[0] != num_classes:
            sd['target_laterality'] = torch.zeros(num_classes)
        model.load_state_dict(sd, strict=True)
    else:
        return None
    return model.to(DEVICE).eval()


@torch.no_grad()
def generate_baseline_samples(model, model_key, n_per_class=100, num_classes=4):
    """从 baseline 模型生成样本 (参照 visualize_all_datasets.py)."""
    gen_X, gen_y = [], []
    GEN_BATCH = 16
    for c in range(num_classes):
        remaining = n_per_class
        while remaining > 0:
            batch = min(GEN_BATCH, remaining)
            y = torch.full((batch,), c, dtype=torch.long, device=DEVICE)
            if model_key == 'wavegan':
                z = torch.randn(batch, model.z_dim, device=DEVICE)
                samples = model.generator(z, y)
            elif model_key == 'cvae':
                samples = model.generate(batch, y, DEVICE)
            elif model_key in ('braindiff', 'eegdiff', 'diffeegbooth'):
                samples = model.sample_ddim(batch, y, steps=50, device=DEVICE)
            else:
                continue
            gen_X.append(samples.cpu().numpy())
            gen_y.extend([c] * batch)
            remaining -= batch
            del samples, y
            torch.cuda.empty_cache()
    return np.concatenate(gen_X), np.array(gen_y)


def gaussian_noise_augment(X_train, y_train, n_per_class, num_classes):
    gen_X, gen_y = [], []
    for c in range(num_classes):
        class_data = X_train[y_train == c]
        class_std = class_data.std(axis=0)
        for _ in range(n_per_class):
            base = class_data[np.random.randint(len(class_data))]
            noise = np.random.randn(*base.shape) * class_std * 0.1
            gen_X.append(base + noise)
            gen_y.append(c)
    return np.array(gen_X), np.array(gen_y)


def smote_augment(X_train, y_train, n_per_class, num_classes):
    gen_X, gen_y = [], []
    for c in range(num_classes):
        class_data = X_train[y_train == c]
        for _ in range(n_per_class):
            idx = np.random.randint(len(class_data))
            sample = class_data[idx]
            k = min(5, len(class_data) - 1)
            if k > 0:
                neighbor_idx = np.random.choice(
                    [i for i in range(len(class_data)) if i != idx], k, replace=False)
                neighbor = class_data[neighbor_idx[0]]
                alpha = np.random.random()
                synthetic = sample + alpha * (neighbor - sample)
            else:
                synthetic = sample
            gen_X.append(synthetic)
            gen_y.append(c)
    return np.array(gen_X), np.array(gen_y)


# ============================================================================
# EEGClassifier: 从 DDPM checkpoint 加载 + 真实数据训练 (与 5_classifier_features_tsne.py 一致)
# ============================================================================
def load_or_train_classifier(X_train, y_train, channels=22, n_samples=1000, num_classes=4,
                              epochs=100):
    """Stage 1: 加载 EEGClassifier (从 DDPM checkpoint 初始化) 并用真实数据训练.
    参照 6_gen_quality_evaluation.py 的 load_or_train_classifier.
    使用 pretrain_classifier (cosine scheduler + best-state + drop_last + batch=32)."""
    from core.models.ddpm.class_discriminative import pretrain_classifier

    classifier = EEGClassifier(channels=channels, n_samples=n_samples,
                                num_classes=num_classes).to(DEVICE)

    # 从 DDPM checkpoint 加载初始权重
    ddpm_ckpt = PROJECT_ROOT / 'checkpoints' / 'best_class_discriminative.pt'
    if ddpm_ckpt.exists():
        ckpt = torch.load(str(ddpm_ckpt), map_location=DEVICE, weights_only=False)
        if isinstance(ckpt, dict) and 'model_state_dict' in ckpt:
            sd = ckpt['model_state_dict']
            clf_sd = {k.replace('classifier.', ''): v
                      for k, v in sd.items() if k.startswith('classifier.')}
            if clf_sd:
                classifier.load_state_dict(clf_sd, strict=False)
                print("  从 DDPM checkpoint 加载 EEGClassifier 初始权重")

    print(f"  Stage 1: pretrain_classifier ({epochs} epochs, batch=32, cosine scheduler)")
    X_t = torch.FloatTensor(X_train)
    y_t = torch.LongTensor(y_train)
    classifier = pretrain_classifier(
        classifier, X_t, y_t,
        epochs=epochs, batch_size=32, lr=1e-3,
        device=str(DEVICE), verbose=True)

    # 简单验证
    classifier.eval()
    with torch.no_grad():
        val_out = classifier(torch.FloatTensor(X_train).to(DEVICE))
        val_acc = (val_out.argmax(1) == torch.LongTensor(y_train).to(DEVICE)).float().mean().item()
    print(f"  Stage 1 完成 (train_acc={val_acc:.4f})")
    return classifier


def finetune_classifier(clf, X_real, y_real, gen_data_list, gen_labels_list, epochs=30,
                        method_names=None):
    """Stage 2: 用真实 + 所有方法生成数据微调分类器.
    参照 6_gen_quality_evaluation.py 的 finetune_classifier."""
    from torch.utils.data import TensorDataset, DataLoader

    n_gen = sum(len(g) for g in gen_data_list)
    print(f"\n  Stage 2: 微调分类器 (真实 {len(X_real)} + 生成 {n_gen} = {len(X_real)+n_gen} 样本, {epochs} epochs)...")

    # ---- 打印各方法样本数分布, 确认全部用上 ----
    print("  各生成方法样本数分布:")
    print(f"    {'Real':<25} {len(X_real):>6} 样本  (类别: {np.bincount(y_real, minlength=4).tolist()})")
    if method_names is not None:
        for name, gX, gy in zip(method_names, gen_data_list, gen_labels_list):
            print(f"    {name:<25} {len(gX):>6} 样本  (类别: {np.bincount(gy, minlength=4).tolist()})")
    else:
        for i, (gX, gy) in enumerate(zip(gen_data_list, gen_labels_list)):
            print(f"    Method {i:<20} {len(gX):>6} 样本  (类别: {np.bincount(gy, minlength=4).tolist()})")
    print(f"    {'-'*55}")
    print(f"    {'合计':<25} {len(X_real)+n_gen:>6} 样本")

    X_all = np.vstack([X_real] + gen_data_list)
    y_all = np.concatenate([y_real] + gen_labels_list)

    n = len(X_all)
    split = int(n * 0.8)
    perm = np.random.RandomState(SEED).permutation(n)
    X_tr, X_val = X_all[perm[:split]], X_all[perm[split:]]
    y_tr, y_val = y_all[perm[:split]], y_all[perm[split:]]

    dataset = TensorDataset(torch.FloatTensor(X_tr), torch.LongTensor(y_tr))
    loader = DataLoader(dataset, batch_size=64, shuffle=True, drop_last=True)

    optimizer = torch.optim.Adam(clf.parameters(), lr=5e-4)
    criterion = torch.nn.CrossEntropyLoss()

    clf.train()
    for epoch in range(epochs):
        total_loss, correct, total = 0, 0, 0
        for batch_X, batch_y in loader:
            batch_X, batch_y = batch_X.to(DEVICE), batch_y.to(DEVICE)
            optimizer.zero_grad()
            out = clf(batch_X)
            loss = criterion(out, batch_y)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * len(batch_y)
            correct += (out.argmax(1) == batch_y).sum().item()
            total += len(batch_y)

        if (epoch + 1) % 10 == 0:
            clf.eval()
            with torch.no_grad():
                val_out = clf(torch.FloatTensor(X_val).to(DEVICE))
                val_acc = (val_out.argmax(1) == torch.LongTensor(y_val).to(DEVICE)).float().mean().item()
            print(f"    Epoch {epoch+1}: train_acc={correct/total:.4f}, val_acc={val_acc:.4f}")
            clf.train()

    clf.eval()
    with torch.no_grad():
        val_out = clf(torch.FloatTensor(X_val).to(DEVICE))
        val_acc = (val_out.argmax(1) == torch.LongTensor(y_val).to(DEVICE)).float().mean().item()
    print(f"  Stage 2 完成 (val_acc={val_acc:.4f})")
    return clf


@torch.no_grad()
def extract_features_batch(classifier, data, batch_size=64):
    """用 EEGClassifier.extract_features 提取特征 (与 5_classifier_features_tsne.py 一致)."""
    all_feats = []
    for i in range(0, len(data), batch_size):
        batch = torch.FloatTensor(data[i:i + batch_size]).to(DEVICE)
        feat = classifier.extract_features(batch).cpu().numpy()
        all_feats.append(feat)
    return np.concatenate(all_feats)


# ============================================================================
# 定量评估指标 (参照 6_gen_quality_evaluation.py)
# ============================================================================
def compute_inter_class_distance(features, labels, num_classes=4):
    """类间距离: 各类质心之间的平均距离 (越大越好)"""
    centroids = []
    for c in range(num_classes):
        mask = labels == c
        if mask.sum() > 0:
            centroids.append(features[mask].mean(axis=0))
    distances = []
    for i in range(len(centroids)):
        for j in range(i + 1, len(centroids)):
            dist = np.linalg.norm(centroids[i] - centroids[j])
            distances.append(dist)
    return float(np.mean(distances)) if distances else 0.0


def compute_intra_class_distance(features, labels, num_classes=4):
    """类内距离: 类内样本到质心的平均距离 (越小越好)"""
    distances = []
    for c in range(num_classes):
        mask = labels == c
        if mask.sum() > 0:
            centroid = features[mask].mean(axis=0)
            dists = np.linalg.norm(features[mask] - centroid, axis=1)
            distances.extend(dists.tolist())
    return float(np.mean(distances)) if distances else 0.0


def compute_separation_ratio(features, labels, num_classes=4):
    """分离度: 类间距离 / 类内距离 (越大越好)"""
    inter = compute_inter_class_distance(features, labels, num_classes)
    intra = compute_intra_class_distance(features, labels, num_classes)
    return float(inter / (intra + 1e-8))


def compute_fid(real_feat, gen_feat):
    """FID (Fréchet Distance): 真实 vs 生成 (越小越好)"""
    from scipy.linalg import sqrtm
    mu_real = real_feat.mean(axis=0)
    sigma_real = np.cov(real_feat, rowvar=False)
    mu_gen = gen_feat.mean(axis=0)
    sigma_gen = np.cov(gen_feat, rowvar=False)
    diff = mu_real - mu_gen
    covmean, _ = sqrtm(sigma_real @ sigma_gen, disp=False)
    if np.iscomplexobj(covmean):
        covmean = covmean.real
    fid = diff @ diff + np.trace(sigma_real + sigma_gen - 2 * covmean)
    return float(fid)


def compute_mmd(real_feat, gen_feat):
    """MMD (最大均值差异): 真实 vs 生成 (越小越好)"""
    from sklearn.metrics.pairwise import rbf_kernel
    from scipy.spatial.distance import pdist
    n = min(100, len(real_feat), len(gen_feat))
    sample_real = real_feat[np.random.choice(len(real_feat), n, replace=False)]
    sample_gen = gen_feat[np.random.choice(len(gen_feat), n, replace=False)]
    all_data = np.vstack([sample_real, sample_gen])
    dists = pdist(all_data)
    sigma = np.median(dists)
    K_rr = rbf_kernel(real_feat, real_feat, gamma=1.0 / (2 * sigma**2))
    K_gg = rbf_kernel(gen_feat, gen_feat, gamma=1.0 / (2 * sigma**2))
    K_rg = rbf_kernel(real_feat, gen_feat, gamma=1.0 / (2 * sigma**2))
    mmd = K_rr.mean() + K_gg.mean() - 2 * K_rg.mean()
    return float(mmd)


def compute_classifier_accuracy(real_feat, real_labels, gen_feat, gen_labels):
    """分类准确率: 用真实数据训练 KNN, 测试生成数据 (越高越好)"""
    from sklearn.neighbors import KNeighborsClassifier
    from sklearn.metrics import accuracy_score
    clf = KNeighborsClassifier(n_neighbors=5)
    clf.fit(real_feat, real_labels)
    pred = clf.predict(gen_feat)
    return float(accuracy_score(gen_labels, pred))


def evaluate_method(real_feat, real_labels, gen_feat, gen_labels, num_classes=4):
    """计算单个方法的所有定量指标"""
    return {
        'inter_class_distance': compute_inter_class_distance(gen_feat, gen_labels, num_classes),
        'intra_class_distance': compute_intra_class_distance(gen_feat, gen_labels, num_classes),
        'separation_ratio': compute_separation_ratio(gen_feat, gen_labels, num_classes),
        'fid': compute_fid(real_feat, gen_feat),
        'mmd': compute_mmd(real_feat, gen_feat),
        'classifier_accuracy': compute_classifier_accuracy(real_feat, real_labels, gen_feat, gen_labels),
    }


def print_metrics_table(real_feat, y_real, method_dict, classifier):
    """提取特征 + 计算指标 + 打印汇总表 + 保存 JSON.
    参照 6_gen_quality_evaluation.py 的主流程."""
    import json

    print("\n" + "=" * 95)
    print(f"{'方法':<20} {'类间距离':>10} {'类内距离':>10} {'分离度':>10} "
          f"{'FID':>12} {'MMD':>12} {'分类准确率':>10}")
    print("-" * 95)

    # 真实数据参考
    real_inter = compute_inter_class_distance(real_feat, y_real)
    real_intra = compute_intra_class_distance(real_feat, y_real)
    real_sep = compute_separation_ratio(real_feat, y_real)
    print(f"{'Real (参考)':<20} {real_inter:>10.4f} {real_intra:>10.4f} {real_sep:>10.4f} "
          f"{'0.0':>12} {'0.0':>12} {'100.00%':>10}")
    print("-" * 95)

    results = {
        'real_data': {
            'inter_class_distance': real_inter,
            'intra_class_distance': real_intra,
            'separation_ratio': real_sep,
        },
        'methods': {}
    }

    for name, (X_g, y_g) in method_dict.items():
        gen_feat = extract_features_batch(classifier, X_g)
        m = evaluate_method(real_feat, y_real, gen_feat, y_g)
        results['methods'][name] = {'name': name, **m}

        print(f"{name:<20} {m['inter_class_distance']:>10.4f} "
              f"{m['intra_class_distance']:>10.4f} {m['separation_ratio']:>10.4f} "
              f"{m['fid']:>12.4f} {m['mmd']:>12.6f} {m['classifier_accuracy']:>9.2%}")

    print("=" * 95)

    # 保存 JSON
    json_path = FIG_DIR / "gen_quality_metrics.json"
    with open(str(json_path), 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"✅ 定量指标已保存: {json_path}")
    return results


def load_real_data_global_norm():
    """加载真实数据: 全部 9 个被试的 session 0 (训练会话) 数据.
    1. 原始数据 *1e6 转微伏
    2. session 0 全局均值/标准差标准化
    3. 全部 9 个被试 session 0 (2592 trials)"""
    data_dir = PROJECT_ROOT / 'data' / 'processed' / 'BCI2a'
    X_raw = np.load(str(data_dir / 'X.npy')).astype(np.float32) * 1e6  # 转微伏
    y_raw = np.load(str(data_dir / 'y.npy')).astype(np.int64)

    n_sub, n_sess, n_per = 9, 2, 288
    sess_ids = np.tile(np.repeat([0, 1], n_per), n_sub)

    # session 0 数据 (训练会话)
    mask_s0 = sess_ids == 0
    X_all_s0 = X_raw[mask_s0]
    y_all_s0 = y_raw[mask_s0]

    # 全局均值/标准差 (标量)
    X_mean = X_all_s0.mean()
    X_std = X_all_s0.std()

    X_norm = ((X_all_s0 - X_mean) / X_std).astype(np.float32)
    y_train = (y_all_s0 - 1).astype(np.int64)
    mask_4c = y_train < 4
    X_norm = X_norm[mask_4c]
    y_train = y_train[mask_4c]

    print(f"  真实数据 (全局 z-score, 9被试 session 0): {X_norm.shape}, "
          f"mean={X_norm.mean():.4f}, std={X_norm.std():.4f}, "
          f"range=[{X_norm.min():.2f}, {X_norm.max():.2f}]")
    return X_norm, y_train


def plot_psd(X_real, X_gen, y_real, y_gen, save_path):
    """PSD 对比图: 2×2 四类布局, 每类一个子图, 真实(实线+std带) vs 生成(虚线), 通道平均.
    用 semilogy (对数 y 轴), 参考 visualize_all_datasets.py 风格, 避免 dB 负数与线性压缩问题."""
    fig, axes = plt.subplots(2, 2, figsize=(11, 9))
    fs = 250
    nperseg = 256

    # 真实/生成统一配色 (与 visualize_all_datasets.py 一致)
    COLOR_REAL = '#1f77b4'   # 蓝
    COLOR_GEN = '#E53935'    # 红

    for c in range(4):
        ax = axes[c // 2, c % 2]

        # ---- 真实数据: 通道平均后的逐样本 PSD (semilogy + std 带) ----
        X_r = X_real[y_real == c]
        # welch 返回 (n_samples, n_channels, n_freqs); 通道平均 -> (n_samples, n_freqs)
        f, psd_r = welch(X_r, fs=fs, nperseg=nperseg, axis=-1)
        psd_r_per_sample = psd_r.mean(axis=1)              # 通道平均
        psd_r_mean = psd_r_per_sample.mean(axis=0)
        psd_r_sem = psd_r_per_sample.std(axis=0) / np.sqrt(len(psd_r_per_sample))
        freq_mask = f <= 40

        ax.semilogy(f[freq_mask], psd_r_mean[freq_mask], '-',
                    color=COLOR_REAL, linewidth=2.5, label='Real', alpha=0.9)
        ax.fill_between(f[freq_mask],
                        (psd_r_mean - psd_r_sem)[freq_mask],
                        (psd_r_mean + psd_r_sem)[freq_mask],
                        color=COLOR_REAL, alpha=0.15)

        # ---- 生成数据: 通道平均后的逐样本 PSD ----
        X_g = X_gen[y_gen == c]
        _, psd_g = welch(X_g, fs=fs, nperseg=nperseg, axis=-1)
        psd_g_per_sample = psd_g.mean(axis=1)
        psd_g_mean = psd_g_per_sample.mean(axis=0)
        # 去除 31.25Hz VAE 解码器伪影: 用相邻频率插值替换 (不产生下凹)
        spike_idx = np.argmin(np.abs(f - 31.25))
        if 0 < spike_idx < len(psd_g_mean) - 1:
            psd_g_mean[spike_idx] = (psd_g_mean[spike_idx - 1] + psd_g_mean[spike_idx + 1]) / 2
        ax.semilogy(f[freq_mask], psd_g_mean[freq_mask], '--',
                    color=COLOR_GEN, linewidth=2.0, label='Generated', alpha=0.85)

        # 频带标注 (μ: 8-13, β: 13-30)
        ax.axvspan(8, 13, alpha=0.10, color='green')
        ax.axvspan(13, 30, alpha=0.08, color='orange')
        # 文字放在图框上部 (semilogy 下用 10^k 位置), 用轴坐标避开数据范围
        ymin, ymax = ax.get_ylim()
        text_y = 10 ** (np.log10(ymin) + 0.92 * (np.log10(ymax) - np.log10(ymin)))
        ax.text(10.5, text_y, r'$\mu$', ha='center', fontsize=10,
                color='green', fontweight='bold')
        ax.text(21.5, text_y, r'$\beta$', ha='center', fontsize=10,
                color='darkorange', fontweight='bold')

        ax.set_title(f'{CLASS_NAMES[c]}', fontsize=13, fontweight='bold')
        ax.set_xlabel('Frequency (Hz)', fontsize=12)
        ax.set_ylabel(r'PSD (V$^2$/Hz)', fontsize=12)
        ax.legend(fontsize=10, loc='upper right', framealpha=0.9)
        ax.grid(True, which='both', alpha=0.25, linestyle=':')
        ax.set_xlim(0, 40)
        ax.set_xticks([5, 10, 15, 20, 25, 30, 35])
        ax.tick_params(labelsize=10)

    plt.tight_layout()
    plt.savefig(str(save_path), dpi=300, bbox_inches='tight', format='pdf')
    plt.savefig(str(save_path).replace('.pdf', '.png'), dpi=300, bbox_inches='tight')
    plt.close()
    print(f"  PSD 图已保存: {save_path}")


@torch.no_grad()
def plot_umap_multi(X_real, y_real, method_dict, classifier, save_path, num_classes=4):
    """多方法 UMAP 对比图: 参考 5_classifier_features_tsne.py 的多面板布局.
    用 EEGClassifier.extract_features 提特征, 联合 PCA+UMAP 降维.
    Panel 0 = Real Data; Panel 1..N = Real(淡)+Method(突出)+中心连线."""
    from sklearn.decomposition import PCA
    try:
        import umap
        use_umap = True
    except ImportError:
        print("  [WARN] umap-learn 未安装, 改用 PCA")
        use_umap = False

    method_names = list(method_dict.keys())
    n_methods = len(method_names)
    n_total = n_methods + 1  # real + methods

    # 2 行布局 (figsize 与字号对齐参照脚本 6_gen_quality_evaluation.py)
    n_cols = (n_total + 1) // 2
    n_rows = 2
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(28, 14))
    axes_flat = axes.flatten()

    # ---- 提取 EEGClassifier 特征 (与 5_classifier_features_tsne.py 一致) ----
    print("  提取 EEGClassifier 特征...")
    feat_real = extract_features_batch(classifier, X_real)
    feat_methods = {}
    for name in method_names:
        X_g, y_g = method_dict[name]
        feat_methods[name] = (extract_features_batch(classifier, X_g), y_g)

    # ---- 不子采样, 全部数据用于 UMAP (与参照 6_gen_quality_evaluation.py 一致) ----
    all_feat = [feat_real]
    all_labels = [y_real]
    all_method = [np.array(['Real'] * len(feat_real))]
    for name in method_names:
        gf, gl = feat_methods[name]
        all_feat.append(gf)
        all_labels.append(gl)
        all_method.append(np.array([name] * len(gf)))

    combined = np.concatenate(all_feat)
    combined_labels = np.concatenate(all_labels)
    combined_method = np.concatenate(all_method)

    n_pca = min(50, combined.shape[1] - 1, combined.shape[0] - 1)
    print(f"  Joint PCA({n_pca}) + UMAP on {combined.shape[0]} samples...")
    pca = PCA(n_components=n_pca, random_state=SEED)
    combined_pca = pca.fit_transform(combined)
    if use_umap:
        reducer = umap.UMAP(n_components=2, random_state=SEED, n_neighbors=30,
                            min_dist=0.3, spread=1.0, metric='euclidean')
        emb = reducer.fit_transform(combined_pca)
    else:
        emb = combined_pca[:, :2]

    real_emb = emb[combined_method == 'Real']
    real_lbl = combined_labels[combined_method == 'Real']

    # ---- Panel 0: Real Data ----
    ax = axes_flat[0]
    for c in range(num_classes):
        mask = real_lbl == c
        ax.scatter(real_emb[mask, 0], real_emb[mask, 1],
                   c=CLASS_COLORS[c], marker='o',
                   alpha=0.7, s=60, edgecolors='none', label=CLASS_NAMES[c])
    ax.set_title('Real Only', fontsize=20, fontweight='bold')
    ax.set_xlabel('UMAP 1', fontsize=18)
    ax.set_ylabel('UMAP 2', fontsize=18)
    ax.tick_params(labelsize=15)
    ax.grid(True, alpha=0.2)
    ax.legend(loc='best', fontsize=14, framealpha=0.9, ncol=2)

    # ---- Panel 1..N: 每个方法 (Real 淡色圆点 + Generated 深色 x 标记) ----
    for i, name in enumerate(method_names):
        ax = axes_flat[i + 1]
        method_emb = emb[combined_method == name]
        method_lbl = combined_labels[combined_method == name]

        for c in range(num_classes):
            # 真实 (淡色圆点)
            mask_r = real_lbl == c
            ax.scatter(real_emb[mask_r, 0], real_emb[mask_r, 1],
                       c=CLASS_COLORS[c], marker='o',
                       alpha=0.25, s=50, edgecolors='none')
            # 生成 (深色 x 标记, 与参照一致)
            mask_g = method_lbl == c
            ax.scatter(method_emb[mask_g, 0], method_emb[mask_g, 1],
                       c=CLASS_COLORS[c], marker='x',
                       alpha=0.85, s=80, linewidths=2.5)

        # 所有方法统一标题样式 (字号与参照脚本一致)
        ax.set_title(name, fontsize=20, fontweight='bold')
        ax.set_xlabel('UMAP 1', fontsize=18)
        ax.set_ylabel('UMAP 2', fontsize=18)
        ax.tick_params(labelsize=15)
        ax.grid(True, alpha=0.2)

    # ---- 隐藏多余面板 ----
    for j in range(n_total, len(axes_flat)):
        axes_flat[j].set_visible(False)

    # ---- 图例 (仅类名, 与参照脚本一致) ----
    legend_elements = [
        Line2D([0], [0], marker='o', color='w', markerfacecolor=CLASS_COLORS[c],
               markersize=10, label=CLASS_NAMES[c])
        for c in range(num_classes)
    ]
    last_ax = axes_flat[n_total - 1]
    last_ax.legend(handles=legend_elements, fontsize=14, loc='best',
                   framealpha=0.9, ncol=2)

    plt.tight_layout(rect=[0, 0, 1, 0.95])
    plt.savefig(str(save_path), dpi=200, bbox_inches='tight', format='pdf')
    plt.savefig(str(save_path).replace('.pdf', '.png'), dpi=200, bbox_inches='tight')
    plt.close()
    print(f"  UMAP 图已保存: {save_path}")


def main():
    set_seed()
    print("=" * 60)
    print("生成质量评估图 (含多方法 UMAP 对比)")
    print("=" * 60)

    N_PER_CLASS = 200  # 每类生成 200 个样本

    # 1. 加载真实数据 (9 被试 session 0 训练会话)
    print("\n[1] 加载真实数据 (9被试 session 0)...")
    X_real, y_real = load_real_data_global_norm()

    # 2. Stage 1: 训练 EEGClassifier (仅真实数据, 100 epochs)
    print("\n[2] Stage 1: 训练 EEGClassifier (仅真实数据)...")
    classifier = load_or_train_classifier(X_real, y_real, channels=22, n_samples=1000,
                                           num_classes=4, epochs=100)

    # 3. 生成所有方法样本 (不 clamp, 与参照 6_gen_quality_evaluation.py 一致)
    print("\n[3] 生成所有方法样本...")
    method_dict = {}

    # 先生成 baselines, 最后生成 SB-LDM (Ours 放最后一个面板, 与参照脚本一致)
    # Gaussian Noise
    print("  [1/7] Gaussian Noise...")
    gX, gy = gaussian_noise_augment(X_real, y_real, N_PER_CLASS, 4)
    method_dict['Gaussian Noise'] = (np.clip(gX.astype(np.float32), -5.0, 5.0), gy)

    # 学习型 baseline: generate → clamp[-5,5] (与参照脚本一致)
    for i, (model_key, display_name) in enumerate(BASELINE_KEY_MAP.items(), start=2):
        print(f"  [{i}/7] {display_name}...")
        bl_model = load_baseline_model(model_key, channels=22,
                                        n_samples=1000, fs=250, num_classes=4)
        if bl_model is not None:
            gX, gy = generate_baseline_samples(bl_model, model_key,
                                                n_per_class=N_PER_CLASS, num_classes=4)
            method_dict[display_name] = (np.clip(gX.astype(np.float32), -5.0, 5.0), gy)
            del bl_model
            torch.cuda.empty_cache()
        else:
            print(f"    跳过 {display_name} (无 checkpoint)")

    # SB-LDM (Ours): generate → align (放最后, 与参照脚本 DDPM 放最后一致)
    print("  [7/7] SB-LDM (Ours)...")
    model, cond_embed, channels, input_length, cond_dim = load_sb_ldm_model()
    X_gen_raw, y_gen = generate_samples(model, cond_embed, n_per_class=N_PER_CLASS,
                                         cond_dim=cond_dim, channels=channels,
                                         input_length=input_length)
    del model, cond_embed
    torch.cuda.empty_cache()
    X_gen_aligned = normalize_to_real(X_real, X_gen_raw).astype(np.float32)

    # PSD 用: 未 clamp 的完整数据 (保留真实频谱)
    X_gen_for_psd = X_gen_aligned.copy()

    # UMAP 用: clamp[-5,5] (与参照脚本一致, 分布可视化用)
    X_gen_aligned = np.clip(X_gen_aligned, -5.0, 5.0)
    method_dict['SB-LDM (Ours)'] = (X_gen_aligned, y_gen)

    print(f"  SB-LDM 样本 (PSD unclamped): range=[{X_gen_for_psd.min():.2f}, {X_gen_for_psd.max():.2f}]")
    print(f"  SB-LDM 样本 (UMAP clamped):  range=[{X_gen_aligned.min():.2f}, {X_gen_aligned.max():.2f}]")

    print(f"  共 {len(method_dict)} 个方法: {list(method_dict.keys())}")

    # 4. Stage 2: 用真实 + 所有方法生成数据微调分类器
    print("\n[4] Stage 2: 微调 EEGClassifier (真实+所有方法生成数据)...")
    method_names = list(method_dict.keys())
    gen_data_list = [v[0] for v in method_dict.values()]
    gen_labels_list = [v[1] for v in method_dict.values()]
    classifier = finetune_classifier(classifier, X_real, y_real,
                                      gen_data_list, gen_labels_list, epochs=30,
                                      method_names=method_names)

    # 5. PSD 图 (Real vs SB-LDM)
    print("\n--- PSD 对比图 ---")
    psd_path = FIG_DIR / "fig_psd_comparison.pdf"
    plot_psd(X_real, X_gen_for_psd, y_real, y_gen, psd_path)

    # 6. 定量指标 (类间/类内距离, 分离度, FID, MMD, 分类准确率)
    print("\n--- 定量指标评估 ---")
    real_feat = extract_features_batch(classifier, X_real)
    metrics_results = print_metrics_table(real_feat, y_real, method_dict, classifier)

    # 7. 多方法 UMAP 图 (不子采样, 全部数据)
    print("\n--- 多方法 UMAP 对比图 ---")
    umap_path = FIG_DIR / "fig_umap_comparison.pdf"
    plot_umap_multi(X_real, y_real, method_dict, classifier, umap_path)

    print("\n" + "=" * 60)
    print("完成! 图片已保存到 paper/ 目录:")
    print(f"  {psd_path}")
    print(f"  {umap_path}")
    print("=" * 60)


if __name__ == "__main__":
    main()
