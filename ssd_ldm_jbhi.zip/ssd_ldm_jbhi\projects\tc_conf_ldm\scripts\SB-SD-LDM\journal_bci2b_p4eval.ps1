# BCI2b P4 prior/few-shot 评测 (journal Table III 第4/5行 BCI2b 列)
# 顺序执行: prior -> fewshot, 与 BCI2a 已有结果同协议 (norm none, GEN_RATIO 1.0, CFG 2.0)
$ErrorActionPreference = 'Continue'
$scripts = 'F:\DS-DDPM-main\projects\tc_conf_ldm\scripts\SB-SD-LDM'
$logdir  = 'F:\DS-DDPM-main\outputs\logs'
$status  = "$logdir\journal_bci2b_p4eval_status.txt"
$env:PYTHONUTF8 = '1'

function Write-Status($msg) {
    $line = "[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $msg
    Add-Content -Path $status -Value $line
}

function Run-Step($name, $argList, $log) {
    Write-Status "$name START -> $log"
    $p = Start-Process -FilePath python -ArgumentList $argList `
        -RedirectStandardOutput "$logdir\$log" -RedirectStandardError "$logdir\$log.err" `
        -NoNewWindow -PassThru -Wait
    if ($p.ExitCode -ne 0) {
        Write-Status "$name FAILED (exit=$($p.ExitCode)), see $logdir\$log.err"
        return $false
    }
    Write-Status "$name DONE"
    return $true
}

Write-Status '===== BCI2b P4 prior/fewshot eval START ====='
$ok = Run-Step 'bci2b-prior' @('-u', "$scripts\evaluate_p4_cross_subject.py", '--dataset', 'bci2b', '--strategy', 'prior', '--norm', 'none') 'journal_bci2b_prior.log'
if ($ok) {
    $ok = Run-Step 'bci2b-fewshot' @('-u', "$scripts\evaluate_p4_cross_subject.py", '--dataset', 'bci2b', '--strategy', 'fewshot', '--norm', 'none') 'journal_bci2b_fewshot.log'
}
if ($ok) { Write-Status '===== BCI2b P4 prior/fewshot eval COMPLETE =====' }
else     { Write-Status '===== BCI2b P4 prior/fewshot eval STOPPED (error) =====' }
