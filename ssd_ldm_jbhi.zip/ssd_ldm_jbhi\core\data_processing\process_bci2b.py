"""
BCI Competition IV Dataset 2b 数据处理器
专门处理BCI2b数据集
"""

import os
import argparse
from pathlib import Path
import numpy as np
import mne
from scipy.io import loadmat
from typing import List, Tuple
import warnings
warnings.filterwarnings('ignore')

try:
    from .common import (
        DEFAULT_PATHS, get_default_paths, save_processed_dataset,
        extract_segment_trial, apply_preprocessing
    )
except ImportError:
    # 当直接运行模块时，使用绝对导入
    from common import (
        DEFAULT_PATHS, get_default_paths, save_processed_dataset,
        extract_segment_trial, apply_preprocessing
    )

class BCICompetition4Set2B:
    """BCI Competition IV Dataset 2b 数据加载器"""
    
    def __init__(self, filename: str, labels_filename: str = None) -> None:
        self.filename = filename
        self.labels_filename = labels_filename

    def load(self) -> mne.io.BaseRaw:
        """加载GDF文件"""
        cnt = self.extract_data()
        events, artifact_trial_mask = self.extract_events(cnt)
        cnt.info['temp'] = {'events': events, 'artifact_trial_mask': artifact_trial_mask}
        return cnt

    def extract_data(self) -> mne.io.BaseRaw:
        """提取原始数据"""
        raw_gdf = mne.io.read_raw_gdf(
            self.filename,
            stim_channel="auto",
            verbose='ERROR',
            exclude=(['EOG-left', 'EOG-central', 'EOG-right'])
        )
        
        # 重命名通道
        raw_gdf.rename_channels({
            'EEG-Fz': 'Fz', 'EEG-0': 'FC3', 'EEG-1': 'FC1', 'EEG-2': 'FCz', 'EEG-3': 'FC2', 'EEG-4': 'FC4',
            'EEG-5': 'C5', 'EEG-C3': 'C3', 'EEG-6': 'C1', 'EEG-Cz': 'Cz', 'EEG-7': 'C2', 'EEG-C4': 'C4',
            'EEG-8': 'C6', 'EEG-9': 'CP3', 'EEG-10': 'CP1', 'EEG-11': 'CPz', 'EEG-12': 'CP2', 'EEG-13': 'CP4',
            'EEG-14': 'P1', 'EEG-15': 'Pz', 'EEG-16': 'P2', 'EEG-Pz': 'POz'
        })
        
        raw_gdf.load_data()
        
        # 处理异常值
        data = raw_gdf.get_data()
        for i_chan in range(data.shape[0]):
            this_chan = data[i_chan]
            data[i_chan] = np.where(this_chan == np.min(this_chan), np.nan, this_chan)
            mask = np.isnan(data[i_chan])
            chan_mean = np.nanmean(data[i_chan])
            data[i_chan, mask] = chan_mean

        gdf_events = mne.events_from_annotations(raw_gdf)
        raw_gdf = mne.io.RawArray(data, raw_gdf.info, verbose='ERROR')
        raw_gdf.info['temp'] = {'gdf_events': gdf_events}
        return raw_gdf

    def extract_events(self, raw_gdf: mne.io.BaseRaw) -> Tuple[np.ndarray, np.ndarray]:
        """提取事件信息"""
        events, name_to_code = raw_gdf.info['temp']['gdf_events']

        # 判断是否为训练集
        if '769' and '770' in name_to_code:
            train_set = True
        else:
            train_set = False
            assert '783' in name_to_code

        # 确定试验代码
        if train_set:
            if self.filename[-10:] == 'B0102T.gdf':
                trial_codes = [4, 5]
            else:
                trial_codes = [10, 11]
            trial_mask = [ev_code in trial_codes for ev_code in events[:, 2]]
            trial_events = events[trial_mask]
        else:
            if self.filename[-10:] == 'B0504E.gdf':
                trial_codes = [5]
            else:
                trial_codes = [11]
            trial_mask = [ev_code in trial_codes for ev_code in events[:, 2]]
            trial_events = events[trial_mask]

        # 调整标签
        if train_set:
            if self.filename[-10:] == 'B0102T.gdf':
                trial_events[:, 2] = trial_events[:, 2] - 3
            else:
                trial_events[:, 2] = trial_events[:, 2] - 9
        else:
            if self.filename[-10:] == 'B0504E.gdf':
                trial_events[:, 2] = trial_events[:, 2] - 4
            else:
                trial_events[:, 2] = trial_events[:, 2] - 10

        # 加载标签文件
        if self.labels_filename is not None and os.path.exists(self.labels_filename):
            classes = loadmat(self.labels_filename)["classlabel"].squeeze()
            if train_set:
                np.testing.assert_array_equal(trial_events[:, 2], classes)
            trial_events[:, 2] = classes

        # 验证标签
        unique_classes = np.unique(trial_events[:, 2])
        assert np.array_equal([1, 2], unique_classes), f'期望标签为1,2，实际得到: {str(unique_classes)}'

        # 提取试验开始事件
        if train_set:
            if self.filename[-10:] == 'B0102T.gdf':
                trial_start_events = events[events[:, 2] == 3]
            else:
                trial_start_events = events[events[:, 2] == 9]
        else:
            if self.filename[-10:] == 'B0504E.gdf':
                trial_start_events = events[events[:, 2] == 3]
            else:
                trial_start_events = events[events[:, 2] == 9]
        assert len(trial_start_events) == len(trial_events)

        # 标记伪影试验
        artifact_trial_mask = np.zeros(len(trial_events), dtype=np.uint8)
        artifact_events = events[events[:, 2] == 1]
        for artifact_time in artifact_events[:, 0]:
            i_trial = trial_start_events[:, 0].tolist().index(artifact_time)
            artifact_trial_mask[i_trial] = 1

        return trial_events, artifact_trial_mask

def process_bci2b_dataset(data_dir: str, label_dir: str, output_dir: str, 
                         subject: str = None, l_freq: float = 4.0, h_freq: float = 30.0,
                         notch_freq: float = 50.0, car: bool = True, resample_freq: float = 250.0,
                         tmin: float = 0.0, tmax: float = 4.0):
    """处理BCI2b数据集"""
    print('[BCI2b] 开始处理数据集...')
    
    # 检查原始数据目录
    if not os.path.exists(data_dir):
        print(f'[BCI2b] 错误: 原始数据目录不存在: {data_dir}')
        return False
    
    # 获取所有GDF文件
    gdf_files = []
    for root, _, files in os.walk(data_dir):
        for f in files:
            if f.lower().endswith('.gdf'):
                gdf_files.append(os.path.join(root, f))
    gdf_files.sort()
    
    # 如果指定了特定被试，只处理该被试
    if subject:
        want = subject.strip().lower()
        gdf_files = [p for p in gdf_files if os.path.basename(p).lower() == f"{want}.gdf"]
        print(f"[BCI2b] 仅处理: {subject}, 匹配到 {len(gdf_files)} 个文件")
    
    if len(gdf_files) == 0:
        print(f'[BCI2b] 错误: 未找到任何GDF文件')
        return False
    
    all_X: List[np.ndarray] = []
    all_y: List[np.ndarray] = []
    used_files: List[str] = []
    per_file_data: List[Tuple[str, np.ndarray, np.ndarray]] = []
    
    for gdf_path in gdf_files:
        base = os.path.basename(gdf_path)
        print(f'[BCI2b] 处理文件: {base}')
        
        # 查找对应的标签文件
        lab = None
        if label_dir is not None:
            cand = os.path.join(label_dir, base.replace('.gdf', '.mat'))
            if os.path.exists(cand):
                lab = cand
        
        try:
            # 加载数据
            cnt = BCICompetition4Set2B(gdf_path, labels_filename=lab).load()
            
            # 应用预处理
            cnt = apply_preprocessing(cnt, l_freq=l_freq, h_freq=h_freq, 
                                    notch_freq=notch_freq, car=car, resample_freq=resample_freq)
            
            # 提取试验数据
            X, y = extract_segment_trial(cnt, tmin=tmin, tmax=tmax)
            
            # 打印标签信息
            uniq = sorted(set(y.tolist()))
            counts = {int(k): int((y == k).sum()) for k in uniq}
            print(f"[BCI2b] 标签唯一值: {uniq}, 计数: {counts}")
            
            # 保存每个文件的数据
            sub_name = os.path.splitext(base)[0]
            dir2b_sub = os.path.join(output_dir, 'BCI2b', sub_name)
            Path(dir2b_sub).mkdir(parents=True, exist_ok=True)
            np.save(os.path.join(dir2b_sub, 'X.npy'), X)
            np.save(os.path.join(dir2b_sub, 'y.npy'), y)
            
            all_X.append(X)
            all_y.append(y)
            used_files.append(gdf_path)
            per_file_data.append((gdf_path, X, y))
            
            print(f'[BCI2b] 成功处理: {base}, X={X.shape}, y={y.shape}')
            
        except Exception as e:
            print(f'[BCI2b] 跳过 {base}: {e}')
            import traceback
            traceback.print_exc()
    
    if len(all_X) == 0:
        print('[BCI2b] 错误: 未成功读取任何数据')
        return False
    
    # 合并所有数据
    X_cat = np.concatenate(all_X, axis=0)
    y_cat = np.concatenate(all_y, axis=0)
    
    # 保存数据集
    metadata = {
        'files': used_files,
        'preprocessing': {
            'l_freq': l_freq,
            'h_freq': h_freq,
            'notch_freq': notch_freq,
            'car': car,
            'resample_freq': resample_freq,
            'tmin': tmin,
            'tmax': tmax
        }
    }
    
    save_processed_dataset(output_dir, 'BCI2b', X_cat, y_cat, metadata, per_file_data)
    
    print('[BCI2b] 处理完成!')
    return True

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='处理BCI Competition IV Dataset 2b')
    parser.add_argument('--data_dir', type=str, default=None, help='原始数据目录')
    parser.add_argument('--label_dir', type=str, default=None, help='标签文件目录')
    parser.add_argument('--output_dir', type=str, default='processed', help='输出目录')
    parser.add_argument('--subject', type=str, default=None, help='仅处理指定被试 (如: B0102T)')
    parser.add_argument('--l_freq', type=float, default=4.0, help='低通滤波频率')
    parser.add_argument('--h_freq', type=float, default=30.0, help='高通滤波频率')
    parser.add_argument('--notch', type=float, default=50.0, help='陷波频率(Hz)，0禁用')
    parser.add_argument('--car', type=int, default=1, help='1=使用CAR，0=不使用')
    parser.add_argument('--resample', type=float, default=250.0, help='重采样频率')
    parser.add_argument('--tmin', type=float, default=0.0, help='试验开始时间(秒)')
    parser.add_argument('--tmax', type=float, default=4.0, help='试验结束时间(秒)')
    
    args = parser.parse_args()
    
    # 使用默认路径（如果未指定）
    if args.data_dir is None:
        args.data_dir = get_default_paths('2b')['data_dir']
    if args.label_dir is None:
        args.label_dir = get_default_paths('2b')['label_dir']
    
    print(f'[BCI2b] 数据目录: {args.data_dir}')
    print(f'[BCI2b] 标签目录: {args.label_dir}')
    print(f'[BCI2b] 输出目录: {args.output_dir}')
    
    # 处理数据集
    success = process_bci2b_dataset(
        data_dir=args.data_dir,
        label_dir=args.label_dir,
        output_dir=args.output_dir,
        subject=args.subject,
        l_freq=args.l_freq,
        h_freq=args.h_freq,
        notch_freq=args.notch,
        car=bool(args.car),
        resample_freq=args.resample,
        tmin=args.tmin,
        tmax=args.tmax
    )
    
    if success:
        print('[BCI2b] 处理成功完成!')
    else:
        print('[BCI2b] 处理失败!')
        exit(1)

if __name__ == '__main__':
    main()