#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
统一的EEG数据预处理模块
整合所有模型的预处理需求，提供一致的数据处理接口

Created: 2025年
Author: DS-DDPM Project
"""

import numpy as np
from scipy import signal
from typing import Tuple, Optional, Dict, Any
from enum import Enum


class PreprocessMode(Enum):
    """预处理模式枚举"""
    CSP_LDA = "csp_lda"           # CSP+LDA预处理
    EEGNET = "eegnet"             # EEGNet预处理
    SHALLOW_CONVNET = "shallow_convnet"  # ShallowConvNet预处理  
    DEEP_CONVNET = "deep_convnet" # DeepConvNet预处理
    EEG_RESNET = "eeg_resnet"     # EEGResNet预处理
    FBCSP = "fbcsp"               # FBCSP预处理
    DEEP_LEARNING = "deep_learning"  # 通用深度学习预处理
    MINIMAL = "minimal"           # 最小预处理（仅标签映射）
    CROSS_SESSION = "cross_session"  # 跨会话预处理


class EEGPreprocessor:
    """EEG数据预处理器"""
    
    def __init__(self, mode: PreprocessMode = PreprocessMode.MINIMAL, 
                 fs: float = 250.0, verbose: bool = True):
        """
        初始化预处理器
        
        Args:
            mode: 预处理模式
            fs: 采样频率 (Hz)
            verbose: 是否显示详细信息
        """
        self.mode = mode
        self.fs = fs
        self.verbose = verbose
        
        # 预处理配置
        self.config = self._get_preprocessing_config()
    
    def _get_preprocessing_config(self) -> Dict[str, Any]:
        """获取不同模式的预处理配置"""
        configs = {
            PreprocessMode.CSP_LDA: {
                'scale_factor': 1e6,  # 放大到伏特级别
                'remove_dc': True,
                'detrend': True,
                'filter_type': 'simple_highpass',
                'standardize': False,
                'output_dtype': np.float64
            },
            
            PreprocessMode.EEGNET: {
                'scale_factor': 1e6,  # 放大到伏特级别
                'remove_dc': True,
                'detrend': True,
                'filter_type': 'simple_highpass',
                'standardize': False,
                'output_dtype': np.float32,
                'add_channel_dim': True  # 添加通道维度用于CNN
            },
            
            PreprocessMode.SHALLOW_CONVNET: {
                'scale_factor': 1e6,
                'remove_dc': True,
                'detrend': True,
                'filter_type': 'simple_highpass',
                'standardize': False,
                'output_dtype': np.float32,
                'add_channel_dim': True
            },
            
            PreprocessMode.DEEP_CONVNET: {
                'scale_factor': 1e6,
                'remove_dc': True,
                'detrend': True,
                'filter_type': 'simple_highpass',
                'standardize': False,
                'output_dtype': np.float32,
                'add_channel_dim': True
            },
            
            PreprocessMode.EEG_RESNET: {
                'scale_factor': 1e6,
                'remove_dc': True,
                'detrend': True,
                'filter_type': 'simple_highpass',
                'standardize': False,
                'output_dtype': np.float32,
                'add_channel_dim': True
            },
            
            PreprocessMode.DEEP_LEARNING: {
                'scale_factor': 1e-6,  # 注意：这里是缩小，与其他不同
                'remove_dc': True,
                'detrend': True,
                'filter_type': 'butter_highpass',
                'standardize': 'trial_wise',  # 试验级标准化
                'output_dtype': np.float32
            },
            
            PreprocessMode.FBCSP: {
                'scale_factor': 1e6,
                'remove_dc': True,
                'detrend': True,
                'filter_type': 'simple_highpass',
                'standardize': False,
                'output_dtype': np.float64
            },
            
            PreprocessMode.CROSS_SESSION: {
                'scale_factor': 1e6,
                'remove_dc': True,
                'detrend': True,
                'filter_type': 'simple_highpass',
                'standardize': False,
                'output_dtype': np.float64,
                'preserve_session_info': True
            },
            
            PreprocessMode.MINIMAL: {
                'scale_factor': 1.0,  # 不缩放
                'remove_dc': False,
                'detrend': False,
                'filter_type': None,
                'standardize': False,
                'output_dtype': np.float32
            }
        }
        return configs.get(self.mode, configs[PreprocessMode.MINIMAL])
    
    def preprocess(self, X: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        统一的预处理接口
        
        Args:
            X: EEG数据，形状 (n_trials, n_channels, n_samples)
            y: 标签，形状 (n_trials,)
            
        Returns:
            预处理后的 (X_processed, y_mapped)
        """
        if self.verbose:
            print(f"    🔧 使用 {self.mode.value} 模式预处理数据")
            print(f"    📊 输入数据形状: X={X.shape}, y={y.shape}")
            print(f"    📈 原始数据范围: [{X.min():.2e}, {X.max():.2e}]")
        
        # 1. 标签映射（所有模式都需要）
        y_mapped = self._map_labels(y)
        
        # 2. 数据类型转换
        X_processed = X.astype(self.config['output_dtype'])
        
        # 3. 数据缩放
        if self.config['scale_factor'] != 1.0:
            X_processed = X_processed * self.config['scale_factor']
            if self.verbose:
                print(f"    📏 缩放后数据范围: [{X_processed.min():.2f}, {X_processed.max():.2f}]")
        
        # 4. 信号处理步骤
        if self.config['remove_dc']:
            X_processed = self._remove_dc(X_processed)
        
        if self.config['detrend']:
            X_processed = self._detrend(X_processed)
        
        if self.config['filter_type']:
            X_processed = self._apply_filter(X_processed)
        
        if self.config['standardize']:
            X_processed = self._standardize(X_processed)
        
        # 5. 特殊处理
        if self.config.get('add_channel_dim', False):
            # 为CNN模型添加通道维度 (N, C, H, W) -> (N, 1, C, W)
            X_processed = X_processed[:, np.newaxis, :, :]
            if self.verbose:
                print(f"    🔄 添加通道维度: {X_processed.shape}")
        
        if self.verbose:
            print(f"    ✅ 预处理完成: X={X_processed.shape}, y={y_mapped.shape}")
            print(f"    📊 标签分布: {np.bincount(y_mapped)}")
        
        return X_processed, y_mapped
    
    def _map_labels(self, y: np.ndarray) -> np.ndarray:
        """标签映射：确保从0开始"""
        unique_labels = np.unique(y)
        if min(unique_labels) != 0:
            y_mapped = y - min(unique_labels)
        else:
            y_mapped = y.copy()
        
        if self.verbose:
            print(f"    🏷️  标签映射: {unique_labels} -> {np.unique(y_mapped)}")
        
        return y_mapped
    
    def _remove_dc(self, X: np.ndarray) -> np.ndarray:
        """去除直流分量"""
        return X - np.mean(X, axis=-1, keepdims=True)
    
    def _detrend(self, X: np.ndarray) -> np.ndarray:
        """去趋势处理"""
        X_detrended = X.copy()
        
        for i in range(X.shape[0]):
            for ch in range(X.shape[1]):
                signal_data = X_detrended[i, ch, :]
                
                # 线性去趋势
                t = np.arange(len(signal_data))
                if len(signal_data) > 1:
                    coeffs = np.polyfit(t, signal_data, 1)
                    trend = np.polyval(coeffs, t)
                    X_detrended[i, ch, :] = signal_data - trend
        
        return X_detrended
    
    def _apply_filter(self, X: np.ndarray) -> np.ndarray:
        """应用滤波"""
        filter_type = self.config['filter_type']
        X_filtered = X.copy()
        
        if filter_type == 'simple_highpass':
            # 简单高通滤波：减去低频成分
            for i in range(X.shape[0]):
                for ch in range(X.shape[1]):
                    signal_data = X_filtered[i, ch, :]
                    window_size = min(50, len(signal_data)//4)
                    if window_size > 0:
                        moving_avg = np.convolve(signal_data, np.ones(window_size)/window_size, mode='same')
                        X_filtered[i, ch, :] = signal_data - moving_avg
        
        elif filter_type == 'butter_highpass':
            # Butterworth高通滤波
            try:
                sos = signal.butter(4, 0.5, btype='high', fs=self.fs, output='sos')
                for i in range(X.shape[0]):
                    for ch in range(X.shape[1]):
                        X_filtered[i, ch, :] = signal.sosfilt(sos, X_filtered[i, ch, :])
            except Exception as e:
                if self.verbose:
                    print(f"    ⚠️  Butterworth滤波失败，跳过: {e}")
        
        return X_filtered
    
    def _standardize(self, X: np.ndarray) -> np.ndarray:
        """标准化处理"""
        standardize_type = self.config['standardize']
        
        if standardize_type == 'trial_wise':
            # 试验级标准化
            X_std = X.copy()
            for i in range(X.shape[0]):
                trial_mean = np.mean(X_std[i])
                trial_std = np.std(X_std[i])
                if trial_std > 0:
                    X_std[i] = (X_std[i] - trial_mean) / trial_std
            return X_std
        
        elif standardize_type == 'global':
            # 全局标准化
            return (X - np.mean(X)) / np.std(X)
        
        elif standardize_type == 'channel_wise':
            # 通道级标准化
            X_std = X.copy()
            for ch in range(X.shape[1]):
                channel_data = X_std[:, ch, :].flatten()
                mean_val = np.mean(channel_data)
                std_val = np.std(channel_data)
                if std_val > 0:
                    X_std[:, ch, :] = (X_std[:, ch, :] - mean_val) / std_val
            return X_std
        
        return X


# 便利函数
def preprocess_for_test(X: np.ndarray, y: np.ndarray, 
                       model_type: str = "minimal", 
                       verbose: bool = True) -> Tuple[np.ndarray, np.ndarray]:
    """
    统一的测试预处理函数
    
    Args:
        X: EEG数据，形状 (n_trials, n_channels, n_samples)
        y: 标签，形状 (n_trials,)
        model_type: 模型类型字符串
        verbose: 是否显示详细信息
        
    Returns:
        预处理后的 (X_processed, y_mapped)
    """
    # 映射模型类型到预处理模式
    mode_mapping = {
        'csp_lda': PreprocessMode.CSP_LDA,
        'fbcsp': PreprocessMode.FBCSP,
        'eegnet': PreprocessMode.EEGNET,
        'shallow_convnet': PreprocessMode.SHALLOW_CONVNET,
        'deep_convnet': PreprocessMode.DEEP_CONVNET,
        'eeg_resnet': PreprocessMode.EEG_RESNET,
        'deep_learning': PreprocessMode.DEEP_LEARNING,
        'cross_session': PreprocessMode.CROSS_SESSION,
        'minimal': PreprocessMode.MINIMAL
    }
    
    mode = mode_mapping.get(model_type.lower(), PreprocessMode.MINIMAL)
    
    # 创建预处理器并处理数据
    preprocessor = EEGPreprocessor(mode=mode, verbose=verbose)
    return preprocessor.preprocess(X, y)


# 向后兼容的独立函数
def preprocess_for_csp(X: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """CSP+LDA预处理（向后兼容）"""
    return preprocess_for_test(X, y, model_type="csp_lda", verbose=True)


def preprocess_for_eegnet(X: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """EEGNet预处理（向后兼容）"""
    return preprocess_for_test(X, y, model_type="eegnet", verbose=True)


def preprocess_for_deep_learning(X: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """深度学习预处理（向后兼容）"""
    return preprocess_for_test(X, y, model_type="deep_learning", verbose=True)


def preprocess_for_shallow_convnet(X: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """ShallowConvNet预处理（向后兼容）"""
    return preprocess_for_test(X, y, model_type="shallow_convnet", verbose=True)


def preprocess_for_deep_convnet(X: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """DeepConvNet预处理（向后兼容）"""
    return preprocess_for_test(X, y, model_type="deep_convnet", verbose=True)


def preprocess_for_eeg_resnet(X: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """EEGResNet预处理（向后兼容）"""
    return preprocess_for_test(X, y, model_type="eeg_resnet", verbose=True)


if __name__ == "__main__":
    # 测试代码
    print("EEG预处理模块测试")
    print("=" * 50)
    
    # 创建模拟数据
    np.random.seed(42)
    X_test = np.random.randn(100, 22, 1000) * 1e-5  # 模拟微伏特级别数据
    y_test = np.random.randint(1, 5, 100)  # 标签1-4
    
    # 测试不同模式
    modes_to_test = ['minimal', 'csp_lda', 'eegnet', 'deep_learning']
    
    for mode in modes_to_test:
        print(f"\n测试 {mode.upper()} 模式:")
        X_proc, y_proc = preprocess_for_test(X_test, y_test, model_type=mode, verbose=True)
        print(f"输出形状: X={X_proc.shape}, y={y_proc.shape}")
        print(f"输出数据类型: {X_proc.dtype}")
        print("-" * 30)