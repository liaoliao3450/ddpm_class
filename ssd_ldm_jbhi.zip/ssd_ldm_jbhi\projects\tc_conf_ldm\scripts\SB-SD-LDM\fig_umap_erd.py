#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
论文图 F4/F5: UMAP 分布对比 / ERD 脑地形图 (BCI2a)
===============================================================
F4: UMAP — real vs SSD-LDM(fused) vs SB-LDM 三面板, 类名着色
    (Flat UI 红蓝绿紫; 图例只显示类名, 不显示 Real/Generated;
     SB-LDM 面板置最后)
F5: ERD 地形图 — 8-30Hz 带功率 (cue 期), real vs generated 上下排,
    4 类; BCI2a 22ch 标准位置

生成端与论文主方法一致 (L1+L2+L3), 被试 1 折, 200 样本/类.
SB-LDM 对照: prior 被试嵌入风格 (源分布回放).

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/fig_umap_erd.py
"""
import sys
from pathlib import Path

import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from style_vae import load_style_vae
from style_vae_cov import load_p5
from evaluate_p4_cross_subject import load_p2_model, set_seed, DEVICE
from evaluate_p5_cross_subject import generate_p5
from fig_quality import (_load_ev, _gen_ours, _gen_sbmldm,
                         N_FEWSHOT, NUM_CLASSES, CLASS_NAMES)

FIGDIR = PROJECT_ROOT / 'outputs/figures'
FIGDIR.mkdir(parents=True, exist_ok=True)

# Flat UI 四色 (项目约定: 红蓝绿紫)
FLAT = ['#e74c3c', '#3498db', '#2ecc71', '#9b59b6']

# BCI2a 22 通道 10-20 坐标 (归一化 x,y, 用于 topomap)
CH_POS = {
    'Fz': (0.0, 0.8), 'FC3': (-0.5, 0.5), 'FC1': (-0.18, 0.5),
    'FCz': (0.0, 0.5), 'FC2': (0.18, 0.5), 'FC4': (0.5, 0.5),
    'C5': (-0.68, 0.18), 'C3': (-0.4, 0.2), 'C1': (-0.14, 0.2),
    'Cz': (0.0, 0.2), 'C2': (0.14, 0.2), 'C4': (0.4, 0.2), 'C6': (0.68, 0.18),
    'CP3': (-0.5, -0.1), 'CP1': (-0.18, -0.1), 'CPz': (0.0, -0.1),
    'CP2': (0.18, -0.1), 'CP4': (0.5, -0.1),
    'P1': (-0.14, -0.42), 'Pz': (0.0, -0.4), 'P2': (0.14, -0.42),
    'POz': (0.0, -0.68),
}
CH_NAMES = list(CH_POS.keys())
FS = 250


def _topomap(ax, values, vmin, vmax, title):
    """简易 topomap: 通道位置圆点 + 最近邻插值填充背景."""
    from scipy.interpolate import Rbf
    xs = np.array([CH_POS[c][0] for c in CH_NAMES])
    ys = np.array([CH_POS[c][1] for c in CH_NAMES])
    # 插值网格
    gx, gy = np.meshgrid(np.linspace(-0.85, 0.85, 120),
                         np.linspace(-0.85, 0.85, 120))
    rbf = Rbf(xs, ys, values, function='linear')
    zg = rbf(gx, gy)
    # 头外区域遮罩
    mask = (gx ** 2 + gy ** 2) > 0.72
    zg = np.ma.masked_array(zg, mask)
    im = ax.pcolormesh(gx, gy, zg, cmap='RdBu_r', vmin=vmin, vmax=vmax,
                       shading='auto')
    ax.scatter(xs, ys, s=4, c='k', zorder=3)
    # 头轮廓
    circ = plt.Circle((0, 0), 0.85, fill=False, color='k', lw=1)
    ax.add_patch(circ)
    ax.set_xlim(-0.95, 0.95); ax.set_ylim(-0.95, 0.95)
    ax.set_aspect('equal'); ax.axis('off')
    ax.set_title(title, fontsize=10)
    return im


def band_power_erp(X):
    """8-30Hz 带功率 (每 trial 全通道, Welch) -> (n, C)."""
    from scipy.signal import welch
    f, p = welch(X, fs=FS, nperseg=250, axis=-1)   # (n, C, f)
    band = p[..., (f >= 8) & (f <= 30)].mean(axis=-1)
    return band  # (n, C)


def main():
    set_seed()
    ev = _load_ev()

    model, cond_embed = load_p2_model(
        PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p2/sb_sd_ldm_p2_epoch_500.pt')
    style_enc, _, sigma0_p4 = load_style_vae(
        PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p4/style_vae_final.pt',
        channels=22, input_length=1000, num_classes=4, device=DEVICE)
    chart, covemb, sigma0_p5 = load_p5(
        PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p5/cov_chart_final.pt',
        device=DEVICE)

    from core.classifiers.eegnet import EEGNet
    teacher_ckpt = PROJECT_ROOT / 'checkpoints/tc_conf_ldm/bci2a_shared_margin/pretrained_teacher_eegnet.pt'
    teacher = EEGNet(n_channels=22, n_samples=1000, n_classes=4).to(DEVICE)
    state = torch.load(str(teacher_ckpt), map_location=DEVICE, weights_only=False)
    if isinstance(state, dict) and 'model_state_dict' in state:
        state = state['model_state_dict']
    teacher.load_state_dict(state, strict=False)
    teacher.eval()

    X, y, subjects, sessions = ev.load_dataset_data('bci2a')
    subj_uniq = np.unique(subjects)
    if subj_uniq.max() != len(subj_uniq) - 1:
        remap = {s: i for i, s in enumerate(subj_uniq)}
        subjects = np.array([remap[s] for s in subjects])
    n_subj = len(np.unique(subjects))

    # ---- 被试 1 折生成 ----
    test_subj = 0
    m_test = subjects == test_subj
    X_real, y_real = X[m_test], y[m_test]
    X_few = X_real[:N_FEWSHOT]
    with torch.no_grad():
        xb = torch.FloatTensor(X_few).unsqueeze(1).to(DEVICE)
        y_pl = teacher(xb).argmax(1).cpu().numpy()
    m_train = ~m_test
    X_pool, y_pool = X[m_train], y[m_train]

    set_seed()
    gX_ours, gy_ours = _gen_ours(model, cond_embed, style_enc, chart, covemb,
                                 sigma0_p5, X_few, y_pl, X_pool, y_pool, 200)
    set_seed()
    gX_sb, gy_sb = _gen_sbmldm(model, cond_embed, sigma0_p5, X_pool, y_pool, 200)
    print(f'generated: ours {gX_ours.shape}, sb-ldm {gX_sb.shape}')

    # ================= F4: UMAP =================
    import umap
    n_real = 400   # 每类 100 real
    rs = np.random.RandomState(0)
    idx_r = np.concatenate([rs.choice(np.where(y_real == c)[0], 100, replace=False)
                            for c in range(NUM_CLASSES)])
    X_r = X_real[idx_r]
    y_r = y_real[idx_r]

    feats = np.concatenate([X_r, gX_ours, gX_sb], axis=0)
    labels = np.concatenate([y_r, gy_ours, gy_sb])
    src = np.array([0] * len(X_r) + [1] * len(gX_ours) + [2] * len(gX_sb))

    # 特征: 通道 x 频带功率 (8-30Hz Welch) + 协方差上三角 log — 轻量且保留域结构
    def _feat(Xs):
        bp = band_power_erp(Xs)
        bp = np.log10(bp + 1e-8)
        # 逐通道归一 (域内标准化, 去幅度主导)
        bp = (bp - bp.mean(1, keepdims=True)) / (bp.std(1, keepdims=True) + 1e-8)
        covs = [np.cov(x) for x in Xs]
        tri = np.array([c[np.triu_indices(22)] for c in covs])
        return np.concatenate([bp, np.log10(np.abs(tri) + 1e-8)], axis=1)

    F = _feat(feats)
    print('[F4] UMAP fitting ...')
    emb = umap.UMAP(n_neighbors=30, min_dist=0.3, random_state=42).fit_transform(F)

    fig, axes = plt.subplots(1, 3, figsize=(21, 7))
    panels = [('Real', 0), ('SSD-LDM (fused)', 1), ('SB-LDM (fixed-VAE)', 2)]
    for ax, (name, s) in zip(axes, panels):
        for c in range(NUM_CLASSES):
            m = (src == s) & (labels == c)
            ax.scatter(emb[m, 0], emb[m, 1], s=6, c=FLAT[c],
                       label=CLASS_NAMES[c], alpha=0.6, linewidths=0)
        ax.set_title(name, fontsize=18)
        ax.set_xticks([]); ax.set_yticks([])
        ax.legend(fontsize=15, markerscale=2.0)
    fig.suptitle('UMAP: real vs. generated (BCI2a, subject 1 held out)',
                 fontsize=20)
    out = FIGDIR / 'fig_umap_bci2a.pdf'
    fig.savefig(out, dpi=200, bbox_inches='tight')
    plt.close(fig)
    print(f'[F4] saved {out}')

    # ================= F5: ERD topomap =================
    # 带功率相对基线 (cue 前 0.5s) 的 ERD%: (base-band)/base
    def _erd(Xs):
        base = band_power_erp(Xs[:, :, :125])   # 0-0.5s
        act = band_power_erp(Xs[:, :, 250:])    # 1s-3s (cue 期)
        return (base - act) / (base + 1e-8)     # >0 = ERD

    erd_r = _erd(X_real)
    erd_g = _erd(gX_ours)

    vmin = min(erd_r.mean(0).min(), erd_g.mean(0).min())
    vmax = max(erd_r.mean(0).max(), erd_g.mean(0).max())

    fig, axes = plt.subplots(2, 4, figsize=(15, 7.2))
    for c in range(NUM_CLASSES):
        im = _topomap(axes[0, c], erd_r[y_real == c].mean(0), vmin, vmax,
                      f'Real: {CLASS_NAMES[c]}')
        _topomap(axes[1, c], erd_g[gy_ours == c].mean(0), vmin, vmax,
                 f'Generated: {CLASS_NAMES[c]}')
    cb = fig.colorbar(im, ax=axes, fraction=0.02, pad=0.02)
    cb.set_label('ERD%  (8–30 Hz, positive = desync)', fontsize=11)
    fig.suptitle('ERD topographies: real (top) vs. generated (bottom)', fontsize=15)
    out = FIGDIR / 'fig_erd_topomap_bci2a.pdf'
    fig.savefig(out, dpi=200, bbox_inches='tight')
    plt.close(fig)
    print(f'[F5] saved {out}')

    print('\nAll figures done ->', FIGDIR)


if __name__ == '__main__':
    main()
