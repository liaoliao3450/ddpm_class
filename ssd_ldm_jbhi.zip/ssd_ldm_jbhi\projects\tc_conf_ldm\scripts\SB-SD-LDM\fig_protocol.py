"""Data-partitioning protocol figure for the SSD-LDM journal paper
(adapted from ERD-DDPM's fig_protocol.py; replaces its method-specific chips).

Visual language follows the lock-box reference diagram: per-scenario striped data
bars (four class colors) split into a training portion and a held-out portion; all
adaptive estimation consumes the training portion only; the held-out portion is
evaluated exactly once. SSD-LDM specifics: few-shot budget of 40 unlabeled target
trials per fold (style + covariance, no labels); final EEGNet retrained from
scratch on real + synthetic.

Output: outputs/figures/fig_protocol.pdf (+ .png preview, 300 dpi).
Run from the repository root.
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, FancyArrowPatch, Arc

plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial"]
plt.rcParams["axes.unicode_minus"] = False

# ---- palette ----
CLASS_C = ["#C9403A", "#3A6EA5", "#4E9C5B", "#E09B3D"]  # schematic 4-class colors
BOX_FC, BOX_EC = "#F1F1F1", "#8A8A8A"    # data boxes
HO_EC = "#555555"                         # held-out box edge (darker)
CHIP_FC, CHIP_EC = "#FFFFFF", "#999999"
GRP_FC, GRP_EC = "#E7E7E7", "#666666"
ARROW_C = "#3A3A3A"
GRAY = "#666666"

OUT_PDF = Path("outputs/figures/fig_protocol.pdf")
OUT_PNG = Path("outputs/figures/fig_protocol.png")
OUT_PNG.parent.mkdir(parents=True, exist_ok=True)

fig, ax = plt.subplots(figsize=(7.1, 7.0))
ax.set_xlim(0, 100)
ax.set_ylim(0, 100)
ax.axis("off")


def rbox(x, y, w, h, fc, ec, lw=1.0, ls="-", z=2):
    ax.add_patch(FancyBboxPatch((x, y), w, h,
                                boxstyle="round,pad=0,rounding_size=1.1",
                                fc=fc, ec=ec, lw=lw, ls=ls, zorder=z))


def _stripe_run(x0, x1, y0, y1, sw, alpha):
    i, x = 0, x0
    while x < x1 - 1e-6:
        w = min(sw, x1 - x)
        ax.add_patch(Rectangle((x, y0), w, y1 - y0,
                               fc=CLASS_C[i % 4], ec="none",
                               alpha=alpha, zorder=3))
        x += w
        i += 1


def stripes(x0, x1, y0, y1, sw=1.5, blocks=1, alpha=0.9):
    """Vertical class stripes (4-class cycle); blocks>1 inserts white gaps (e.g. per-subject blocks)."""
    if blocks > 1:
        gap = 0.4
        bw = ((x1 - x0) - gap * (blocks - 1)) / blocks
        for b in range(blocks):
            bx0 = x0 + b * (bw + gap)
            _stripe_run(bx0, bx0 + bw, y0, y1, bw / 4, alpha)  # 4 stripes per block
    else:
        _stripe_run(x0, x1, y0, y1, sw, alpha)


def padlock(cx, cy, s=1.0):
    # white halo so the lock stays readable over stripes
    ax.add_patch(FancyBboxPatch((cx - 1.5 * s, cy - 2.1 * s), 3.0 * s, 3.4 * s,
                                boxstyle="round,pad=0,rounding_size=0.5",
                                fc="white", ec="none", alpha=0.88, zorder=5))
    ax.add_patch(Arc((cx, cy - 0.55 * s), 1.5 * s, 1.9 * s,
                     theta1=0, theta2=180, lw=1.3, ec="#3A3A3A", zorder=6))
    ax.add_patch(Rectangle((cx - 1.05 * s, cy - 1.75 * s), 2.1 * s, 1.3 * s,
                           fc="#4A4A4A", ec="#3A3A3A", lw=0.5, zorder=6))
    ax.add_patch(plt.Circle((cx, cy - 1.1 * s), 0.22 * s, fc="white", ec="none", zorder=7))


def arrow(x1, y1, x2, y2, lw=1.7, ls="-"):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>",
                                 mutation_scale=15, lw=lw, color=ARROW_C,
                                 linestyle=ls, shrinkA=0, shrinkB=0, zorder=5))


def txt(x, y, s, fs=8, bold=False, italic=False, color="#222222",
        ha="center", va="center", z=8, rot=0, bbox=False, linespacing=1.15):
    ax.text(x, y, s, fontsize=fs, ha=ha, va=va, color=color, zorder=z,
            fontweight="bold" if bold else "normal",
            fontstyle="italic" if italic else "normal",
            rotation=rot, linespacing=linespacing,
            bbox=dict(fc="white", ec="none", pad=0.6) if bbox else None)


# =====================================================================
# Top: legend (4 classes) + column headers + split annotation
# =====================================================================
for k in range(4):
    lx = 3 if k % 2 == 0 else 17
    ly = 97.0 if k < 2 else 93.6
    ax.add_patch(Rectangle((lx, ly), 3.2, 2.2, fc=CLASS_C[k], ec="none", zorder=6))
    txt(lx + 4.6, ly + 1.1, f"class {k + 1}", fs=8.8, ha="left")

txt(44, 96.3, "Training portion", fs=11, bold=True)
txt(85, 96.3, "Held-out portion", fs=11, bold=True)
txt(57, 91.6, "one fixed split per scenario", fs=8.5, italic=True, color=GRAY)

# =====================================================================
# Grid: 3 scenario rows x (training | held-out) striped boxes
# =====================================================================
TRAIN_L = 30.0   # left edge of training boxes
HO_L = 76.0      # left edge of held-out boxes
BH = 8.6         # box height

rows = [
    dict(cy=86.0, name="Within-subject", sub="pooled sessions",
         tw=26.0, tl="training split (80%)", hw=10.0, hl="held-out 20%",
         tb=1, hb=1),
    dict(cy=70.5, name="Cross-session", sub="session-wise transfer",
         tw=18.0, tl="training session", hw=18.0, hl="held-out session",
         tb=1, hb=1),
    dict(cy=55.0, name="Cross-subject", sub="leave-one-subject-out",
         tw=28.0, tl="8 training subjects", hw=9.0, hl="1 held-out subject",
         tb=8, hb=1),
]

for r in rows:
    cy = r["cy"]
    y0, y1 = cy - BH / 2, cy + BH / 2
    # scenario label (left column)
    txt(3, cy + 2.0, r["name"], fs=10.5, bold=True, ha="left")
    txt(3, cy - 2.8, r["sub"], fs=8.5, color=GRAY, ha="left")
    # training box
    rbox(TRAIN_L, y0, r["tw"], BH, BOX_FC, BOX_EC, lw=1.0)
    stripes(TRAIN_L + 0.7, TRAIN_L + r["tw"] - 0.7, y0 + 0.7, y1 - 0.7, blocks=r["tb"])
    txt(TRAIN_L + r["tw"] / 2, cy - 7.2, r["tl"], fs=9)
    # held-out box (+ lock)
    rbox(HO_L, y0, r["hw"], BH, BOX_FC, HO_EC, lw=1.3)
    stripes(HO_L + 0.7, HO_L + r["hw"] - 0.7, y0 + 0.7, y1 - 0.7, blocks=r["hb"])
    padlock(HO_L + r["hw"] - 2.7, y1 - 2.7, s=1.0)
    txt(HO_L + r["hw"] / 2, cy - 7.2, r["hl"], fs=9)

# =====================================================================
# Brackets + arrows:
#   training bracket -> estimation box (direct, x=44)
#   held-out bracket -> down along right margin (x=95) -> test box
# =====================================================================
def bracket(x0, x1, y=45.0, tick=1.5):
    ax.plot([x0, x1], [y, y], color=ARROW_C, lw=1.1, zorder=4)
    ax.plot([x0, x0], [y, y + tick], color=ARROW_C, lw=1.1, zorder=4)
    ax.plot([x1, x1], [y, y + tick], color=ARROW_C, lw=1.1, zorder=4)

bracket(28, 59)
arrow(44, 44.4, 44, 42.9)          # training -> estimation box top
bracket(75, 95)
arrow(94.4, 44.4, 94.4, 16.9)      # held-out -> test box top (right margin)
txt(96.9, 30, "never seen by the final classifier", fs=8.5, italic=True,
    color=GRAY, rot=90)

# =====================================================================
# Row 1 of bottom section: estimation stages (full width)
# =====================================================================
rbox(20, 21.2, 72, 21.3, GRP_FC, GRP_EC, lw=1.2)
txt(56, 39.3, "Estimation stages (training portion only)", fs=11.5, bold=True)

chips = [
    (38.25, 33.9, "Shared-backbone generator\n(subject-style disentangled)"),
    (73.75, 33.9, "Few-shot statistics\n(40 unlabeled target trials)"),
    (38.25, 25.7, "Alignment operators\nL1-L3 (at generation)"),
    (73.75, 25.7, "Final classifier\n(real + synthetic)"),
]
for cx, cy, s in chips:
    rbox(cx - 16.75, cy - 3.6, 33.5, 7.2, CHIP_FC, CHIP_EC, lw=0.9, z=4)
    txt(cx, cy, s, fs=9.5, z=6)

# =====================================================================
# Row 2 of bottom section: few-shot note (left) + test (right)
# =====================================================================
# --- note (dashed), linked to estimation box ---
rbox(20, 3.0, 50, 13.5, "#FFFFFF", "#777777", lw=1.0, ls=(0, (4, 3)))
ax.plot([45, 45], [21.1, 16.7], color="#999999", lw=0.9, ls=(0, (2, 2)), zorder=4)
txt(45, 12.5, "Few-shot budget: $N_f{=}40$ unlabeled trials", fs=9.5)
txt(45, 9.6, "estimate target style and covariance", fs=9.5)
txt(45, 6.7, "per fold; no target labels", fs=9.5)

# --- test evaluation box ---
rbox(74, 3.0, 23, 13.5, GRP_FC, GRP_EC, lw=1.2)
txt(85.5, 13.8, "Test evaluation", fs=10.5, bold=True)
txt(85.5, 10.6, "final classifier,", fs=9)
txt(85.5, 8.3, "evaluated exactly once", fs=9, italic=True)
txt(85.5, 6.0, "on the held-out portion", fs=9)
arrow(85, 21.0, 85, 16.9)          # estimation box bottom -> test box top

fig.savefig(OUT_PDF, bbox_inches="tight", pad_inches=0.02)
fig.savefig(OUT_PNG, dpi=300, bbox_inches="tight", pad_inches=0.02)
print(f"saved: {OUT_PDF}")
print(f"saved: {OUT_PNG}")
