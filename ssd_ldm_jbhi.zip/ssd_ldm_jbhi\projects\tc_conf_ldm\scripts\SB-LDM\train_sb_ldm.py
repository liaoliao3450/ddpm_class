#!/usr/bin/env python3
"""
SB-LDM (Shared-Backbone Latent Diffusion Model) — 纯会议版训练脚本

与期刊版 SB-SD-LDM 的区别:
  - 不使用 difficulty (难度) 条件化
  - 不使用 boundary (边界) 监督 loss
  - 不使用 margin-aware 采样 → 普通 shuffle
  - 不使用 scenario (场景) 条件化 → 仅类别条件化
  - 保留: 共享骨干 + 多目标训练 + ERD 正则化

三个数据集: BCI2a / BCI2b / PhysioNet MI4C

Usage:
    python projects/tc_conf_ldm/scripts/train_sb_ldm.py --dataset bci2a
    python projects/tc_conf_ldm/scripts/train_sb_ldm.py --dataset bci2b
    python projects/tc_conf_ldm/scripts/train_sb_ldm.py --dataset physionet
"""
import sys
import json
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
import yaml
from torch.utils.data import DataLoader, TensorDataset

# 项目根路径
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from core.classifiers.eegnet import EEGNet
from core.models.latent_diffusion.model_shared import SharedBackboneConfig, SharedVAEUNetLDM1D

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ============================================================================
# 数据集配置 (纯 SB-LDM, 无 difficulty/boundary)
# ============================================================================
DATASET_CONFIG = {
    'bci2a': {
        'channels': 22,
        'input_length': 1000,
        'num_classes': 4,
        'fs': 250,
        'erd_c3': 7,       # C3 通道索引
        'erd_c4': 11,      # C4 通道索引
        'num_subjects': 9,
        'yaml': 'projects/tc_conf_ldm/configs/bci2a_tc_conf_ldm_shared.yaml',
        'teacher_ckpt': 'checkpoints/tc_conf_ldm/bci2a_shared/pretrained_teacher_eegnet.pt',
        'teacher_fallback': 'checkpoints/tc_conf_ldm/bci2a_v2/pretrained_teacher_eegnet.pt',
        'ckpt_dir': 'checkpoints/tc_conf_ldm/sb_ldm_bci2a',
    },
    'bci2b': {
        'channels': 3,
        'input_length': 1000,
        'num_classes': 2,
        'fs': 250,
        'erd_c3': 0,       # C3 (3通道: C3, Cz, C4)
        'erd_c4': 2,       # C4
        'num_subjects': 9,
        'yaml': 'projects/tc_conf_ldm/configs/bci2b_tc_conf_ldm_shared.yaml',
        'teacher_ckpt': 'checkpoints/tc_conf_ldm/bci2b_shared/pretrained_teacher_eegnet.pt',
        'teacher_fallback': None,
        'ckpt_dir': 'checkpoints/tc_conf_ldm/sb_ldm_bci2b',
    },
    'physionet': {
        'channels': 64,
        'input_length': 640,
        'num_classes': 4,
        'fs': 160,
        'erd_c3': 17,      # C3 近似通道
        'erd_c4': 48,      # C4 近似通道
        'num_subjects': 97,
        'yaml': 'projects/tc_conf_ldm/configs/physionet_mi4c_tc_conf_ldm_shared.yaml',
        'teacher_ckpt': 'checkpoints/tc_conf_ldm/physionet_mi4c_shared/pretrained_teacher_eegnet.pt',
        'teacher_fallback': None,
        'ckpt_dir': 'checkpoints/tc_conf_ldm/sb_ldm_physionet',
    },
}


def load_config(yaml_path: str) -> dict:
    full_path = PROJECT_ROOT / yaml_path
    if full_path.exists():
        with open(full_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    return {}


def load_dataset(dataset: str):
    """加载数据, 只用 session 0 训练, 按通道 z-score。"""
    print(f'加载 {dataset} 数据...')
    if dataset == 'bci2a':
        from utils.data_loader import load_bci2a_data
        X, y, subjects, sessions = load_bci2a_data()
    elif dataset == 'bci2b':
        from utils.data_loader_bci2b import load_bci2b_data
        X, y, subjects, sessions, _ = load_bci2b_data()
    elif dataset == 'physionet':
        from utils.data_loader_physionet_mi4c import load_physionet_mi4c_data
        X, y, subjects, sessions, _ = load_physionet_mi4c_data()
    else:
        raise ValueError(f'未知数据集: {dataset}')

    X = X.astype(np.float32)
    y = y.astype(np.int64)
    subjects = np.asarray(subjects)
    sessions = np.asarray(sessions)

    cfg = DATASET_CONFIG[dataset]
    num_classes = cfg['num_classes']
    y = y - y.min()
    mask = y < num_classes
    X, y = X[mask], y[mask]
    subjects = subjects[mask]
    sessions = sessions[mask]

    # 只用 session 0
    train_mask = sessions == 0
    X_train = X[train_mask]
    y_train = y[train_mask]
    subjects_train = subjects[train_mask]

    # 按通道 z-score
    X_train = (X_train - X_train.mean(axis=(0, 2), keepdims=True)) / (X_train.std(axis=(0, 2), keepdims=True) + 1e-8)

    print(f'  训练数据: {X_train.shape}, 类别分布: {np.bincount(y_train)}')
    print(f'  被试数: {len(np.unique(subjects_train))}')
    return X_train, y_train, subjects_train


def load_teacher(dataset: str, channels: int, input_length: int, num_classes: int):
    """加载 EEGNet teacher (用于 feat/logit/conf 蒸馏)。"""
    cfg = DATASET_CONFIG[dataset]
    teacher = EEGNet(n_channels=channels, n_samples=input_length, n_classes=num_classes).to(DEVICE)

    ckpt_path = PROJECT_ROOT / cfg['teacher_ckpt']
    if not ckpt_path.exists() and cfg['teacher_fallback']:
        ckpt_path = PROJECT_ROOT / cfg['teacher_fallback']

    if ckpt_path.exists():
        print(f'  加载 teacher: {ckpt_path}')
        state = torch.load(str(ckpt_path), map_location=DEVICE, weights_only=False)
        if isinstance(state, dict) and 'model_state_dict' in state:
            state = state['model_state_dict']
        teacher.load_state_dict(state, strict=False)
        print('  teacher 加载成功')
    else:
        print(f'  ⚠️  未找到 teacher: {ckpt_path}, 跳过蒸馏损失')

    for p in teacher.parameters():
        p.requires_grad = False
    teacher.eval()
    return teacher


def train(dataset: str, num_epochs: int = 500, batch_size: int = 64, lr: float = 1e-4):
    cfg = DATASET_CONFIG[dataset]
    yaml_cfg = load_config(cfg['yaml'])

    print('=' * 70)
    print(f'SB-LDM 训练 (纯会议版, 无 difficulty/boundary)')
    print(f'数据集: {dataset}, 设备: {DEVICE}')
    print('=' * 70)

    # 1) 加载数据
    X_train, y_train, subjects_train = load_dataset(dataset)
    channels = cfg['channels']
    input_length = cfg['input_length']
    num_classes = cfg['num_classes']
    fs = cfg['fs']

    X_t = torch.FloatTensor(X_train)
    y_t = torch.LongTensor(y_train)
    subj_t = torch.LongTensor(subjects_train)

    # 普通 shuffle (无 margin-aware 采样, 无 scenario 标签)
    dataset_t = TensorDataset(X_t, y_t, subj_t)
    loader = DataLoader(dataset_t, batch_size=batch_size, shuffle=True, num_workers=0, drop_last=False)

    # 2) 条件嵌入 (仅类别条件化, 无 scenario/difficulty/subject)
    model_cfg = yaml_cfg.get('model', {})
    cond_dim = int(model_cfg.get('cond_embed_dim', 64))
    cond_embed = torch.nn.Embedding(num_classes, cond_dim).to(DEVICE)

    # 3) 共享骨干模型
    backbone = SharedBackboneConfig(
        base=int(model_cfg.get('backbone_base', 64)),
        levels=tuple(int(x) for x in model_cfg.get('backbone_levels', [1, 2, 4])),
        blocks_per_level=int(model_cfg.get('backbone_blocks_per_level', 2)),
    )
    model = SharedVAEUNetLDM1D(
        channels=channels,
        input_length=input_length,
        z_channels=int(model_cfg.get('z_channels', 64)),
        timesteps=int(model_cfg.get('timesteps', 1000)),
        t_dim=int(model_cfg.get('t_dim', 128)),
        cond_dim=cond_dim,
        backbone=backbone,
        num_subjects=cfg['num_subjects'],
        adv_alpha=0.0,  # 不用域对抗
    ).to(DEVICE)

    print(f'\n模型参数: {sum(p.numel() for p in model.parameters()):,}')

    # 4) 潜空间分类头
    with torch.no_grad():
        dummy_x = torch.zeros(1, channels, input_length, device=DEVICE)
        dummy_cond = torch.zeros(1, cond_dim, device=DEVICE)
        z_dummy, _, _ = model.encode(dummy_x, cond=dummy_cond)
        latent_dim = z_dummy.shape[1] * z_dummy.shape[2]
    classifier_head = torch.nn.Linear(latent_dim, num_classes).to(DEVICE)

    # 5) Teacher
    teacher = load_teacher(dataset, channels, input_length, num_classes)

    # 6) 优化器
    optim = torch.optim.AdamW(
        list(model.parameters()) + list(cond_embed.parameters()) + list(classifier_head.parameters()),
        lr=lr, weight_decay=1e-5,
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optim, T_max=num_epochs, eta_min=1e-6)

    # 7) Checkpoint 目录
    ckpt_dir = PROJECT_ROOT / cfg['ckpt_dir']
    ckpt_dir.mkdir(parents=True, exist_ok=True)

    # 8) 训练循环
    print(f'\n开始训练 ({num_epochs} epochs)...')
    print('-' * 70)

    # Loss 权重
    beta_kl_base = float(model_cfg.get('beta_kl', 1e-3))
    lambda_cls = float(model_cfg.get('lambda_cls', 1.0))
    lambda_feat = float(model_cfg.get('lambda_feat', 0.4))
    lambda_logit_base = float(model_cfg.get('lambda_logit', 0.8))
    lambda_conf = float(model_cfg.get('lambda_conf', 0.15))
    lambda_erd = float(model_cfg.get('lambda_erd', 2.0))

    c3, c4 = cfg['erd_c3'], cfg['erd_c4']

    for epoch in range(1, num_epochs + 1):
        model.train()
        cond_embed.train()
        classifier_head.train()

        ep_loss, ep_eps, ep_kl, ep_cls, ep_recon = 0.0, 0.0, 0.0, 0.0, 0.0
        ep_feat, ep_logit, ep_conf, ep_erd = 0.0, 0.0, 0.0, 0.0

        for X_batch, y_batch, subj_batch in loader:
            X_batch = X_batch.to(DEVICE)
            y_batch = y_batch.to(DEVICE)
            subj_batch = subj_batch.to(DEVICE)

            B = X_batch.size(0)

            # SB-LDM: cond_embed 仅类别条件化 (无 scenario/difficulty)
            cond = cond_embed(y_batch)

            t = torch.randint(0, int(model.timesteps), (B,), device=DEVICE, dtype=torch.long)
            eps_pred, noise, mu, logvar, subj_logits = model(X_batch, t, cond=cond, subject_id=subj_batch)

            # 1. Diffusion loss
            loss_eps = F.mse_loss(eps_pred, noise)

            # 2. KL loss
            logvar_clamped = torch.clamp(logvar, min=-10, max=10)
            kl_per = -0.5 * (1 + logvar_clamped - mu.pow(2) - logvar_clamped.exp())
            kl_loss = torch.mean(kl_per)

            # 3. Reconstruction
            x_recon = model.decode(mu, target_length=X_batch.shape[-1], cond=cond)
            loss_recon = F.mse_loss(x_recon, X_batch)
            if epoch <= num_epochs * 0.2:
                loss_recon_w = 0.1 * (1 - epoch / (num_epochs * 0.2))
            else:
                loss_recon_w = 0.0

            # 4. Latent classification
            z0_flat = mu.view(B, -1)
            loss_cls = F.cross_entropy(classifier_head(z0_flat), y_batch)

            # 5. Teacher distillation (feat + logit + conf)
            X_real_t = X_batch.unsqueeze(1)
            X_recon_t = x_recon.unsqueeze(1)
            with torch.no_grad():
                feat_real = teacher._forward_features(X_real_t)
                logits_real = teacher(X_real_t)
            feat_recon = teacher._forward_features(X_recon_t)
            logits_recon = teacher(X_recon_t)

            loss_feat = F.mse_loss(feat_recon, feat_real)
            loss_logit = F.cross_entropy(logits_recon, y_batch)
            prob_real = F.softmax(logits_real, dim=1)
            prob_recon = F.softmax(logits_recon, dim=1)
            loss_conf = F.kl_div(prob_recon.log(), prob_real, reduction="batchmean")

            # 6. ERD regularization (mu/beta band lateralization)
            loss_erd = torch.tensor(0.0, device=DEVICE)
            if epoch > int(num_epochs * 0.1):
                eps_fft = 1e-8

                def band_power(x_sig, low, high):
                    T_len = x_sig.shape[-1]
                    freqs = torch.fft.rfftfreq(T_len, d=1.0 / fs).to(x_sig.device)
                    spec = torch.fft.rfft(x_sig, dim=-1).abs().pow(2)
                    mask = (freqs >= low) & (freqs <= high)
                    return spec[..., mask].mean(dim=-1).clamp(min=eps_fft)

                mu_recon = band_power(x_recon, 8, 13)
                beta_recon = band_power(x_recon, 13, 30)
                mu_real = band_power(X_batch, 8, 13).detach()
                beta_real = band_power(X_batch, 13, 30).detach()

                lat_mu_recon = (mu_recon[:, c4] - mu_recon[:, c3]) / (mu_recon[:, c4] + mu_recon[:, c3] + eps_fft)
                lat_mu_real = (mu_real[:, c4] - mu_real[:, c3]) / (mu_real[:, c4] + mu_real[:, c3] + eps_fft)
                lat_beta_recon = (beta_recon[:, c4] - beta_recon[:, c3]) / (beta_recon[:, c4] + beta_recon[:, c3] + eps_fft)
                lat_beta_real = (beta_real[:, c4] - beta_real[:, c3]) / (beta_real[:, c4] + beta_real[:, c3] + eps_fft)

                loss_erd = F.mse_loss(lat_mu_recon, lat_mu_real) + F.mse_loss(lat_beta_recon, lat_beta_real)

            # KL anneal
            if epoch <= num_epochs * 0.2:
                kl_w = (epoch / (num_epochs * 0.2)) * 0.3
            elif epoch <= num_epochs * 0.5:
                kl_w = 0.3 + ((epoch - num_epochs * 0.2) / (num_epochs * 0.3)) * 0.4
            elif epoch <= num_epochs * 0.8:
                kl_w = 0.7 + ((epoch - num_epochs * 0.5) / (num_epochs * 0.3)) * 0.3
            else:
                kl_w = 1.0

            beta_kl = beta_kl_base * kl_w
            lambda_logit = lambda_logit_base * (1.0 + epoch / num_epochs)

            # Total loss (无 boundary loss)
            loss = (
                loss_eps
                + beta_kl * kl_loss
                + lambda_cls * loss_cls
                + loss_recon_w * loss_recon
                + lambda_feat * loss_feat
                + lambda_logit * loss_logit
                + lambda_conf * loss_conf
                + lambda_erd * loss_erd
            )

            optim.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                list(model.parameters()) + list(cond_embed.parameters()), 1.0)
            optim.step()

            bs = float(B)
            ep_loss += loss.item() * bs
            ep_eps += loss_eps.item() * bs
            ep_kl += kl_loss.item() * bs
            ep_cls += loss_cls.item() * bs
            ep_recon += loss_recon.item() * bs
            ep_feat += loss_feat.item() * bs
            ep_logit += loss_logit.item() * bs
            ep_conf += loss_conf.item() * bs
            ep_erd += loss_erd.item() * bs

        n = float(len(dataset_t))
        ep_loss /= n; ep_eps /= n; ep_kl /= n; ep_cls /= n; ep_recon /= n
        ep_feat /= n; ep_logit /= n; ep_conf /= n; ep_erd /= n

        scheduler.step()
        lr_now = scheduler.get_last_lr()[0]

        if epoch % 10 == 0 or epoch == 1:
            print(
                f'[Ep {epoch:3d}/{num_epochs}] '
                f'Loss:{ep_loss:.4f} | Diff:{ep_eps:.4f} | KL:{ep_kl:.4f}(w:{beta_kl:.1e}) | '
                f'Cls:{ep_cls:.4f} | Recon:{ep_recon:.4f} | Feat:{ep_feat:.4f} | '
                f'Logit:{ep_logit:.4f} | Conf:{ep_conf:.4f} | ERD:{ep_erd:.4f} | LR:{lr_now:.1e}'
            )

        if epoch % 50 == 0 or epoch == num_epochs:
            ckpt_path = ckpt_dir / f'sb_ldm_epoch_{epoch}.pt'
            torch.save({
                'epoch': epoch,
                'config': yaml_cfg,
                'model_state_dict': model.state_dict(),
                'cond_embed_state_dict': cond_embed.state_dict(),
                'classifier_head_state_dict': classifier_head.state_dict(),
            }, ckpt_path)
            print(f'  保存: {ckpt_path}')

    # 训练摘要
    summary = {
        'config': yaml_cfg,
        'dataset': dataset,
        'model_type': 'SB-LDM (conference, no difficulty/boundary)',
        'num_epochs': num_epochs,
    }
    summary_path = ckpt_dir / 'train_summary.json'
    with open(summary_path, 'w', encoding='utf-8') as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print(f'\n训练完成: {summary_path}')


def main():
    import argparse
    parser = argparse.ArgumentParser(description='SB-LDM 训练 (纯会议版)')
    parser.add_argument('--dataset', type=str, required=True,
                        choices=['bci2a', 'bci2b', 'physionet'])
    parser.add_argument('--epochs', type=int, default=500)
    parser.add_argument('--batch_size', type=int, default=64)
    parser.add_argument('--lr', type=float, default=1e-4)
    args = parser.parse_args()

    torch.manual_seed(42)
    np.random.seed(42)

    train(args.dataset, num_epochs=args.epochs, batch_size=args.batch_size, lr=args.lr)


if __name__ == '__main__':
    main()
