#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SB-SD-LDM P3: Dirichlet 风格混合的跨被试 LOSO 增强
===============================================================
前置: P2 checkpoint (z 已解耦, 风格全部经 s 通路)

核心思想 (P3):
  fix-SB-LDM 跨被试失败的根因: 生成样本重演训练被试分布 (风格住 z).
  P2 解耦后: z 只含类内容 (被试不变), 风格全部由 s 控制.
  P3 生成: z ~ DDIM (被试不变的类内容) + s_mix = Σ αᵢ·subj_embed[i]
           (α ~ Dirichlet(1.0), 只在训练被试嵌入上采样)
  => 生成"新被试"风格的类一致样本, 覆盖被试间变异而非重演训练被试.

对照锚点 (BCI2a LOSO, GEN_RATIO=1.0):
  real-only:        51.99% (Kappa 0.360)  ← 天花板
  fix-SB-LDM:       46.26% (Kappa 0.283)  ← 域偏移毒性
  v1 (随机标签):    53.38% (噪声正则假象)

已知泄漏声明 (论文严谨版需每折重训):
  P2 的 subj_embed 训练时见过全部 9 被试 session 0 (含测试被试).
  LOSO 混合只用 8 个训练被试嵌入, 但 z/decode 参数仍受过测试被试影响.
  本脚本为方向验证 (proof of concept); 严格 LOSO 版本需 per-fold 重训.

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/evaluate_p3_cross_subject.py --quick   # 仅生成质量快检
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/evaluate_p3_cross_subject.py           # 快检 + LOSO
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/evaluate_p3_cross_subject.py --strategy none  # s=None 对照
"""
import sys
import json
import argparse
from pathlib import Path

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from core.models.latent_diffusion.model_shared import (
    SharedBackboneConfig, SharedVAEUNetLDM1D)

import importlib.util


def _load_ev():
    spec = importlib.util.spec_from_file_location(
        'evaluate_sb_ldm_3datasets',
        str(PROJECT_ROOT / 'projects/tc_conf_ldm/scripts/SB-LDM/evaluate_sb_ldm_3datasets.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
SEED = 42

DDIM_STEPS = 50
GUIDANCE_SCALE = 2.0
GEN_RATIO = 1.0
N_ENSEMBLE = 3


def set_seed(seed=SEED):
    import random
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)


def load_p2_model(ckpt_path):
    ckpt = torch.load(str(ckpt_path), map_location=DEVICE, weights_only=False)
    model_cfg = ckpt['config'].get('model', {})
    backbone = SharedBackboneConfig(
        base=int(model_cfg.get('backbone_base', 64)),
        levels=tuple(int(x) for x in model_cfg.get('backbone_levels', [1, 2, 4])),
        blocks_per_level=int(model_cfg.get('backbone_blocks_per_level', 2)),
    )
    model = SharedVAEUNetLDM1D(
        channels=22,
        input_length=1000,
        z_channels=int(model_cfg.get('z_channels', 64)),
        timesteps=int(model_cfg.get('timesteps', 1000)),
        t_dim=int(model_cfg.get('t_dim', 128)),
        cond_dim=int(model_cfg.get('cond_embed_dim', 64)),
        backbone=backbone,
        num_subjects=ckpt.get('num_subjects', 9),
        adv_alpha=0.0,
        subj_dim=ckpt.get('subj_dim', 32),
        disentangle=True,
    ).to(DEVICE)
    model.load_state_dict(ckpt['model_state_dict'])
    model.eval()

    cond_embed = torch.nn.Embedding(4, int(model_cfg.get('cond_embed_dim', 64))).to(DEVICE)
    cond_embed.load_state_dict(ckpt['cond_embed_state_dict'])
    cond_embed.eval()
    return model, cond_embed


def make_ddim_schedule(alpha_bar, steps):
    total = len(alpha_bar)
    step = total // steps
    return list(reversed(range(0, total, step)))[:steps]


def generate_p3(model, cond_embed, n_per_class, num_classes, strategy,
                train_subj_ids, dirichlet_conc=1.0, device=DEVICE):
    """P3 DDIM 生成: z 被试不变 + 风格策略注入.

    strategy:
      dirichlet: s_mix = Σ αᵢ·eᵢ, α ~ Dir(conc) 在训练被试嵌入上 (新被试风格)
      none:      s=None (通用风格)
      true_s:    随机选训练被试的真实嵌入 (fix-SB-LDM 行为对照)
    """
    model.eval()
    cond_embed.eval()
    e = 1e-8
    ddim_seq = make_ddim_schedule(model.alpha_bar, DDIM_STEPS)
    num_subjects = model.num_subjects

    with torch.no_grad():
        dummy = torch.zeros(1, model.channels, model.input_length, device=device)
        z_d, _, _ = model.encode(dummy, cond=torch.zeros(1, model.cond_dim, device=device))
        z_ch, latent_len = model.z_channels, z_d.shape[-1]

    W = model.subj_embed.weight.detach()  # (num_subjects, subj_dim)

    all_X, all_y = [], []
    with torch.no_grad():
        for c in range(num_classes):
            generated = 0
            while generated < n_per_class:
                bs = min(32, n_per_class - generated)
                cl = torch.full((bs,), c, dtype=torch.long, device=device)
                cond = cond_embed(cl)

                # 风格向量
                style_vec = None
                if strategy == 'dirichlet':
                    alpha = np.random.dirichlet(
                        np.full(len(train_subj_ids), dirichlet_conc), size=bs)
                    alpha_t = torch.FloatTensor(alpha).to(device)          # (bs, n_train)
                    W_train = W[torch.as_tensor(train_subj_ids, device=device)]  # (n_train, d)
                    style_vec = alpha_t @ W_train                           # (bs, d)
                elif strategy == 'true_s':
                    pick = np.random.choice(train_subj_ids, size=bs)
                    style_vec = W[torch.as_tensor(pick, device=device)]

                z = torch.randn(bs, z_ch, latent_len, device=device)
                for i, t_idx in enumerate(ddim_seq):
                    t = torch.full((bs,), t_idx, device=device, dtype=torch.long)
                    ec = model.denoise_eps(z, t, cond=cond)
                    if GUIDANCE_SCALE > 1.0:
                        eu = model.denoise_eps(z, t, cond=None)
                        eps_pred = torch.clamp(eu + GUIDANCE_SCALE * (ec - eu), -100, 100)
                    else:
                        eps_pred = ec

                    ab = model.alpha_bar[t_idx]
                    ab_prev = model.alpha_bar[ddim_seq[i + 1]] if i + 1 < len(ddim_seq) else model.alpha_bar[0]
                    ab = ab.to(device) if isinstance(ab, torch.Tensor) else torch.tensor(ab, device=device)
                    ab_prev = ab_prev.to(device) if isinstance(ab_prev, torch.Tensor) else torch.tensor(ab_prev, device=device)

                    sab = torch.sqrt(ab.clamp(min=e))
                    s1mb = torch.sqrt((1 - ab).clamp(min=e))
                    sab_prev = torch.sqrt(ab_prev.clamp(min=e))
                    s1mb_prev = torch.sqrt((1 - ab_prev).clamp(min=e))

                    pred_x0 = ((z - s1mb * eps_pred) / sab).clamp(-5, 5)
                    z = sab_prev * pred_x0 + s1mb_prev * eps_pred

                x = model.decode(z, target_length=model.input_length,
                                 cond=cond, style_vec=style_vec)
                all_X.append(x.cpu().numpy())
                all_y.extend([c] * bs)
                generated += bs

    return np.concatenate(all_X), np.array(all_y)


def quick_gen_check(model, cond_embed, ev, X, y, subjects, strategy):
    """生成质量快检: teacher 判类 + subj_head 风格分布 (第一折训练被试)."""
    print('\n' + '=' * 70)
    print(f'[快检] 策略={strategy}: teacher 判类 + subj_head 风格分布')
    print('=' * 70)

    train_subj_ids = list(range(9))  # 快检用全部 (不涉及 LOSO 泄漏判断)
    set_seed()
    gX, gy = generate_p3(model, cond_embed, 50, 4, strategy, train_subj_ids)
    gX = ev.normalize_to_real_stats(X, gX)

    # teacher 判类
    teacher_ckpt = PROJECT_ROOT / 'checkpoints/tc_conf_ldm/bci2a_shared_margin/pretrained_teacher_eegnet.pt'
    from core.classifiers.eegnet import EEGNet
    teacher = EEGNet(n_channels=22, n_samples=1000, n_classes=4).to(DEVICE)
    state = torch.load(str(teacher_ckpt), map_location=DEVICE, weights_only=False)
    if isinstance(state, dict) and 'model_state_dict' in state:
        state = state['model_state_dict']
    teacher.load_state_dict(state, strict=False)
    teacher.eval()

    with torch.no_grad():
        xb = torch.FloatTensor(gX).unsqueeze(1).to(DEVICE)
        pred = teacher(xb).argmax(1).cpu().numpy()
    gen_cls_acc = float((pred == gy).mean())

    # 真实数据 teacher 判类对照
    with torch.no_grad():
        xb = torch.FloatTensor(X[:400]).unsqueeze(1).to(DEVICE)
        pred_r = teacher(xb).argmax(1).cpu().numpy()
    real_cls_acc = float((pred_r == y[:400]).mean())

    # subj_head 风格分布 (生成样本被判成哪个被试)
    with torch.no_grad():
        xb = torch.FloatTensor(gX).to(DEVICE)
        s_pred = model.subj_head(xb).argmax(1).cpu().numpy()
    style_dist = np.bincount(s_pred, minlength=9) / len(s_pred)

    print(f'  teacher 判类 (生成): {gen_cls_acc*100:.1f}%  (真实数据: {real_cls_acc*100:.1f}%)')
    print(f'  subj_head 风格分布: {np.round(style_dist*100, 1).tolist()}%')
    print(f'  (期望: 类一致 + 风格分散; fix 版对照是 100% 集中训练被试)')

    return gen_cls_acc, real_cls_acc, style_dist


def loso_eval(model, cond_embed, ev, X, y, subjects, sessions, strategy):
    """跨被试 LOSO (协议与 evaluate_sb_ldm_3datasets.cross_subject_test 对齐)."""
    from sklearn.metrics import accuracy_score, cohen_kappa_score

    print('\n' + '=' * 70)
    print(f'[LOSO] P3 策略={strategy}, GEN_RATIO={GEN_RATIO}')
    print('=' * 70)

    results = []
    unique_subjects = np.unique(subjects)
    channels, input_length = X.shape[1], X.shape[2]
    num_classes = 4

    ev.GEN_RATIO = GEN_RATIO
    ev.N_ENSEMBLE = N_ENSEMBLE

    for test_subj in unique_subjects:
        train_mask = subjects != test_subj
        test_mask = subjects == test_subj
        X_train, y_train = X[train_mask], y[train_mask]
        X_test, y_test = X[test_mask], y[test_mask]

        # 训练被试 ID (0..8, load_dataset_data 已重映射)
        train_subj_ids = [int(s) for s in np.unique(subjects[train_mask])]

        spc = max(1, int(GEN_RATIO * len(X_train)) // num_classes)
        set_seed()
        gen_X, gen_y = generate_p3(model, cond_embed, spc, num_classes,
                                   strategy, train_subj_ids)
        gen_X = ev.normalize_to_real_stats(X_train, gen_X)

        X_aug = np.concatenate([X_train, gen_X])
        y_aug = np.concatenate([y_train, gen_y])

        clf = ev.train_classifier(X_aug, y_aug, channels, input_length, num_classes)
        pred = ev.predict(clf, X_test)
        acc = float(accuracy_score(y_test, pred))
        kappa = float(cohen_kappa_score(y_test, pred))
        results.append({'acc': acc, 'kappa': kappa})
        print(f'  被试 {int(test_subj)+1}: Acc {acc*100:.2f}%, Kappa {kappa:.4f}')

    accs = [r['acc'] for r in results]
    kappas = [r['kappa'] for r in results]
    res = {'mean': float(np.mean(accs)), 'std': float(np.std(accs)),
           'per_subject': accs, 'mean_kappa': float(np.mean(kappas)),
           'std_kappa': float(np.std(kappas)), 'per_subject_kappa': kappas}
    print(f'\n>>> P3 ({strategy}) LOSO: {res["mean"]*100:.2f}% ± {res["std"]*100:.2f}% '
          f'(Kappa {res["mean_kappa"]:.4f})')
    return res


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--strategy', type=str, default='dirichlet',
                        choices=['dirichlet', 'none', 'true_s'])
    parser.add_argument('--conc', type=float, default=1.0,
                        help='Dirichlet 浓度参数 (越小混合越极端)')
    parser.add_argument('--ratio', type=float, default=1.0)
    parser.add_argument('--quick', action='store_true', help='仅生成质量快检')
    parser.add_argument('--ckpt', type=str,
                        default='checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p2/sb_sd_ldm_p2_epoch_500.pt')
    args = parser.parse_args()

    global GEN_RATIO
    GEN_RATIO = args.ratio

    set_seed()
    ev = _load_ev()

    print(f'加载 P2 checkpoint: {args.ckpt}')
    model, cond_embed = load_p2_model(PROJECT_ROOT / args.ckpt)

    # 数据 (与 evaluate_sb_ldm_3datasets 相同的加载口径)
    X, y, subjects, sessions = ev.load_dataset_data('bci2a')
    # subjects 重映射 0..8 (load_dataset_data 返回原始 ID; 检查)
    subj_uniq = np.unique(subjects)
    if subj_uniq.max() != len(subj_uniq) - 1:
        remap = {s: i for i, s in enumerate(subj_uniq)}
        subjects = np.array([remap[s] for s in subjects])

    # [1] 生成质量快检
    gen_acc, real_acc, style_dist = quick_gen_check(
        model, cond_embed, ev, X, y, subjects, args.strategy)

    if args.quick:
        return

    # [2] LOSO
    res = loso_eval(model, cond_embed, ev, X, y, subjects, sessions, args.strategy)

    # [3] 汇总
    print('\n' + '=' * 70)
    print('P3 结果汇总 (BCI2a 跨被试 LOSO)')
    print('=' * 70)
    print(f'  real-only:      51.99% (Kappa 0.360)  ← 天花板')
    print(f'  fix-SB-LDM 1.0: 46.26% (Kappa 0.283)  ← 域偏移毒性')
    print(f'  v1 随机标签:    53.38% (噪声正则假象)')
    print(f'  P3-{args.strategy} ({args.ratio}): {res["mean"]*100:.2f}% ± {res["std"]*100:.2f}% '
          f'(Kappa {res["mean_kappa"]:.4f})')

    out = PROJECT_ROOT / f'outputs/results/sb_sd_ldm_p3_{args.strategy}_r{args.ratio}.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, 'w', encoding='utf-8') as f:
        json.dump({'strategy': args.strategy, 'ratio': args.ratio,
                   'gen_cls_acc': gen_acc, 'real_cls_acc': real_acc,
                   'style_dist': style_dist.tolist(), 'loso': res},
                  f, indent=2, ensure_ascii=False)
    print(f'\n已保存: {out}')


if __name__ == '__main__':
    main()
