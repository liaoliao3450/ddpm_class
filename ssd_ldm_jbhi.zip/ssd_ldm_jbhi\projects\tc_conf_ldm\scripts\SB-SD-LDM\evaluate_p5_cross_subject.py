#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SB-SD-LDM P5 v3 评估: 协方差图表生成的跨被试 LOSO (P1 协议, 全程原始空间)
===============================================================
前置: P2 + P4 + P5 (cov_chart_final.pt)

生成模式 (同一 chart, 不同 style 构造):
  cov_only : style = g(cov_test)                      纯生成式 EA (决定性实验)
             cov_test = R_test(40 trial) 的 PCA 嵌入
  full     : style = mu_s_fewshot + (g(cov_test) - g_center)
             正交定向 + 协方差位移 (g_center = 训练锚点图表均值)
  orth_only: style = mu_s_fewshot + jitter            P4 复刻对照 (~53%)
  prior    : style = e_i + sigma0*eps                 P4 prior 复刻 (盲)

协议: 真实训练数据(原始) + 生成数据(原始) -> EEGNet x3 -> 测试数据(原始).
  无任何白化 — 生成模型自己完成域对齐 (模型即对齐器).

判决: cov_only/full > EA-40 (59.68%) => 生成式对齐方法成立;
      ~= P4 (53%) => 图表未生效, 回退机制解剖叙事.

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/evaluate_p5_cross_subject.py --mode cov_only
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/evaluate_p5_cross_subject.py --mode full
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/evaluate_p5_cross_subject.py --quick  # 生成质量快检
"""
import sys
import json
import argparse
from pathlib import Path

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from style_vae import load_style_vae
from style_vae_cov import load_p5, compute_subject_R
from evaluate_p4_cross_subject import (
    load_p2_model, make_ddim_schedule, estimate_fewshot_style,
    set_seed, DEVICE, N_ENSEMBLE)

import importlib.util


def _load_ev():
    spec = importlib.util.spec_from_file_location(
        'evaluate_sb_ldm_3datasets',
        str(PROJECT_ROOT / 'projects/tc_conf_ldm/scripts/SB-LDM/evaluate_sb_ldm_3datasets.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


SEED = 42
DDIM_STEPS = 50
GUIDANCE_SCALE = 2.0
GEN_RATIO = 1.0
N_FEWSHOT = 40
NUM_CLASSES = 4

ANCHORS = {'real-only': 0.5199, 'P4-fewshot': 0.5301, 'EA-40': 0.5968}


def generate_p5(model, cond_embed, style_enc, chart, covemb, n_per_class,
                num_classes, mode, train_subj_ids, W_subj, X_few=None,
                sigma0=0.5, device=DEVICE, z_rescale=False,
                X_ref=None, y_ref=None, z_source='ddim',
                X_pool=None, y_pool=None, latent_match=False,
                X_few_pl=None, y_few_pl=None, amp_calib='none'):
    """P5 v3 DDIM 生成: z ~ DDIM (类条件) + chart 风格."""
    model.eval()
    cond_embed.eval()
    if chart is not None:
        chart.eval()
    if style_enc is not None:
        style_enc.eval()
    e = 1e-8
    ddim_seq = make_ddim_schedule(model.alpha_bar, DDIM_STEPS)

    with torch.no_grad():
        dummy = torch.zeros(1, model.channels, model.input_length, device=device)
        z_d, _, _ = model.encode(dummy, cond=torch.zeros(1, model.cond_dim, device=device))
        z_ch, latent_len = model.z_channels, z_d.shape[-1]

    S = W_subj.size(0)

    # fewshot 正交风格 + 测试被试协方差嵌入
    s_test_hat = None
    cov_test = None
    if mode in ('full', 'orth_only'):
        assert X_few is not None
        s_test_hat = estimate_fewshot_style(style_enc, X_few, device).to(device)
    if mode in ('full', 'cov_only'):
        assert X_few is not None
        R_test = compute_subject_R(np.asarray(X_few))
        cov_test = torch.FloatTensor(covemb.embed(R_test)).to(device)

    jitter = 0.2 * sigma0

    def _ddim_sample(bs, cond):
        z = torch.randn(bs, z_ch, latent_len, device=device)
        for i, t_idx in enumerate(ddim_seq):
            t = torch.full((bs,), t_idx, device=device, dtype=torch.long)
            ec = model.denoise_eps(z, t, cond=cond)
            if GUIDANCE_SCALE > 1.0:
                eu = model.denoise_eps(z, t, cond=None)
                eps_pred = torch.clamp(eu + GUIDANCE_SCALE * (ec - eu), -100, 100)
            else:
                eps_pred = ec

            ab = model.alpha_bar[t_idx]
            ab_prev = model.alpha_bar[ddim_seq[i + 1]] if i + 1 < len(ddim_seq) else model.alpha_bar[0]
            ab = ab.to(device) if isinstance(ab, torch.Tensor) else torch.tensor(ab, device=device)
            ab_prev = ab_prev.to(device) if isinstance(ab_prev, torch.Tensor) else torch.tensor(ab_prev, device=device)

            sab = torch.sqrt(ab.clamp(min=e))
            s1mb = torch.sqrt((1 - ab).clamp(min=e))
            sab_prev = torch.sqrt(ab_prev.clamp(min=e))
            s1mb_prev = torch.sqrt((1 - ab_prev).clamp(min=e))

            pred_x0 = ((z - s1mb * eps_pred) / sab).clamp(-5, 5)
            z = sab_prev * pred_x0 + s1mb_prev * eps_pred
        return z

    # z 统计再校准: CFG>1 时 DDIM z 偏离 encoder z 分布 (输出幅度塌缩 ~0.23x),
    # 逐位置一阶矩/二阶矩匹配回 encoder z 分布 (decoder 的训练输入分布).
    def _identity(z):
        return z

    rescale_fn = _identity
    if z_rescale:
        assert X_ref is not None and y_ref is not None
        with torch.no_grad():
            zs = [_ddim_sample(32, cond_embed(torch.full(
                (32,), c, dtype=torch.long, device=device)))
                for c in range(num_classes)]
            z_pilot = torch.cat(zs, dim=0)
            m_d = z_pilot.mean(dim=0, keepdim=True)
            s_d = z_pilot.std(dim=0, keepdim=True).clamp(min=1e-4)

            X_ref_a = np.asarray(X_ref)[:1024]
            y_ref_a = np.asarray(y_ref)[:1024]
            enc_zs = []
            for i in range(0, len(X_ref_a), 256):
                xb = torch.FloatTensor(X_ref_a[i:i + 256]).to(device)
                yb = torch.LongTensor(y_ref_a[i:i + 256]).to(device)
                z_enc, _, _ = model.encode(xb, cond=cond_embed(yb))
                enc_zs.append(z_enc)
            z_enc_all = torch.cat(enc_zs, dim=0)
            m_e = z_enc_all.mean(dim=0, keepdim=True)
            s_e = z_enc_all.std(dim=0, keepdim=True).clamp(min=1e-4)
            print(f'  [z_rescale] 逐位置矩匹配: '
                  f'encoder/DDIM 平均 std 比 = {(s_e.mean() / s_d.mean()).item():.3f}')

        def _rescale(z):
            return (z - m_d) / s_d * s_e + m_e
        rescale_fn = _rescale

    all_X, all_y = [], []
    # encoder 模式: 逐类预索引真实 trial (mu_z 池, 零标签噪声)
    cls_idx = None
    if z_source == 'encoder':
        assert X_pool is not None and y_pool is not None
        y_pool = np.asarray(y_pool)
        cls_idx = {c: np.where(y_pool == c)[0] for c in range(num_classes)}

    # 潜空间对齐 (Latent EA): z 逐位置矩匹配到测试被试统计.
    # 依据: 幅度信息在 z 不在 style (recon 幅度 0.90-1.06 全被试, chart 幅度
    # 恒 ~池均值); 匹配 z 统计后由 decoder 渲染 -> 对齐发生在模型内部.
    def _lm(mu):
        return mu

    _lm_ddim = None
    if latent_match:
        assert X_few_pl is not None and y_few_pl is not None
        assert X_pool is not None and y_pool is not None
        with torch.no_grad():
            xb = torch.FloatTensor(np.asarray(X_few_pl)).to(device)
            yb = torch.LongTensor(np.asarray(y_few_pl)).to(device)
            _, mu_t, _ = model.encode(xb, cond=cond_embed(yb))
            m_t = mu_t.mean(dim=0, keepdim=True)
            s_t = mu_t.std(dim=0, keepdim=True).clamp(min=1e-4)

            rs_lm = np.random.RandomState(0)
            idx_p = rs_lm.choice(len(X_pool),
                                 size=min(512, len(X_pool)), replace=False)
            xb = torch.FloatTensor(np.asarray(X_pool)[idx_p]).to(device)
            yb = torch.LongTensor(np.asarray(y_pool)[idx_p]).to(device)
            _, mu_p, _ = model.encode(xb, cond=cond_embed(yb))
            m_p = mu_p.mean(dim=0, keepdim=True)
            s_p = mu_p.std(dim=0, keepdim=True).clamp(min=1e-4)

            # 测试 z std 钳制在池 std 的 [0.25, 4] 倍 (40 样本估计噪声防护)
            s_t_safe = torch.clamp(s_t, 0.25 * s_p, 4.0 * s_p)
            print(f'  [latent_match] z 逐位置矩匹配: 测试/池 std 比 '
                  f'(位置均值) = {(s_t_safe.mean() / s_p.mean()).item():.3f}')

        if z_source == 'encoder':
            def _lm(mu):
                return (mu - m_p) / s_p * s_t_safe + m_t
        else:
            # ddim 路径 (真扩散先验采样): DDIM z 先白化到先验自身统计,
            # 再重着色到测试被试统计. 两步仿射复合后池统计相消:
            #   (z - m_p)/s_p*s_t + m_t  ∘  (z - m_d)/s_d*s_p + m_p
            # = (z - m_d)/s_d * s_t_safe + m_t
            # 同时修复 CFG>1 导致的 z 幅度塌缩 (原 z_rescale 的作用被包含).
            with torch.no_grad():
                zs = [_ddim_sample(32, cond_embed(torch.full(
                    (32,), c, dtype=torch.long, device=device)))
                    for c in range(num_classes)]
                z_pilot = torch.cat(zs, dim=0)
                m_d = z_pilot.mean(dim=0, keepdim=True)
                s_d = z_pilot.std(dim=0, keepdim=True).clamp(min=1e-4)
            print(f'  [latent_match ddim] DDIM z -> 测试统计复合仿射 '
                  f'(pilot {z_pilot.size(0)} 样本)')

            def _lm_ddim(z):
                return (z - m_d) / s_d * s_t_safe + m_t

    with torch.no_grad():
        for c in range(num_classes):
            generated = 0
            while generated < n_per_class:
                bs = min(32, n_per_class - generated)
                cl = torch.full((bs,), c, dtype=torch.long, device=device)
                cond = cond_embed(cl)

                if mode == 'cov_only':
                    # 图表点直接作为风格 (训练测同构)
                    style_vec = chart(cov_test.unsqueeze(0).expand(bs, -1))
                elif mode == 'full':
                    # 正交风格 + 协方差位移 (位移 = 图表点 - 图表中心)
                    base = s_test_hat.unsqueeze(0).expand(bs, -1)
                    base = base + jitter * torch.randn_like(base)
                    g_test = chart(cov_test.unsqueeze(0).expand(bs, -1))
                    g_center = chart.center.expand(bs, -1)
                    style_vec = base + (g_test - g_center)
                elif mode == 'orth_only':
                    base = s_test_hat.unsqueeze(0).expand(bs, -1)
                    style_vec = base + jitter * torch.randn_like(base)
                elif mode == 'prior':
                    pick = np.asarray(train_subj_ids)[np.random.choice(
                        len(train_subj_ids), size=bs)]
                    e_pick = W_subj[torch.as_tensor(pick, device=device)]
                    style_vec = e_pick + sigma0 * torch.randn_like(e_pick)
                else:
                    raise ValueError(mode)

                if z_source == 'encoder':
                    # 真实 trial 重渲染: mu_z 来自 encoder (零标签噪声, decoder 训练分布内),
                    # chart 风格渲染目标协方差 — decoder 即非线性对齐算子
                    idx_c = cls_idx[c]
                    pick = np.random.choice(
                        idx_c, size=bs, replace=(len(idx_c) < bs))
                    xb = torch.FloatTensor(
                        np.asarray(X_pool)[pick]).to(device)
                    _, mu, _ = model.encode(xb, cond=cond)
                    z = _lm(mu)
                else:
                    # 扩散先验采样: z ~ DDIM(类条件), 复合仿射对齐到测试被试统计
                    z = _ddim_sample(bs, cond)
                    z = _lm_ddim(z) if _lm_ddim is not None else rescale_fn(z)
                x = model.decode(z, target_length=model.input_length,
                                 cond=cond, style_vec=style_vec)
                all_X.append(x.cpu().numpy())
                all_y.extend([c] * bs)
                generated += bs

    allX = np.concatenate(all_X).astype(np.float32)
    ally = np.array(all_y)

    # 幅度校准: decoder 渲染的协方差方向误差已小 (~0.16), 幅度是唯一缺口
    # (z 幅度 ≠ x 幅度, 非线性 decoder 响应). 对角匹配 = 每通道方差对齐.
    if amp_calib != 'none':
        assert X_few is not None, 'amp_calib 需要 fewshot (cov_only/full 模式)'
        R_tgt = compute_subject_R(np.asarray(X_few)[:N_FEWSHOT])
        R_gen_all = compute_subject_R(allX)
        if amp_calib == 'global':
            alpha = float(np.sqrt(np.trace(R_tgt)
                                  / max(np.trace(R_gen_all), 1e-8)))
            alpha = float(np.clip(alpha, 0.25, 4.0))
            allX = allX * alpha
            print(f'  [amp_calib global] alpha={alpha:.3f}')
        elif amp_calib == 'diag':
            scale = np.sqrt(np.clip(np.diag(R_tgt), 1e-8, None)
                            / np.clip(np.diag(R_gen_all), 1e-8, None))
            scale = np.clip(scale, 0.25, 4.0)
            allX = allX * scale[None, :, None]
            print(f'  [amp_calib diag] 通道 scale 范围 '
                  f'[{scale.min():.3f}, {scale.max():.3f}]')
        elif amp_calib == 'full':
            def _sqrtm(R):
                w, V = np.linalg.eigh((R + R.T) / 2.0)
                w = np.clip(w, 1e-8, None)
                return (V * np.sqrt(w)) @ V.T
            W = _sqrtm(R_tgt) @ np.linalg.inv(_sqrtm(R_gen_all))
            allX = np.einsum('cd,ndt->nct', W, allX).astype(np.float32)
            print('  [amp_calib full] 白化-重着色完成 (二阶精确匹配)')
    return allX, ally


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', type=str, default='cov_only',
                        choices=['full', 'cov_only', 'orth_only', 'prior'])
    parser.add_argument('--ratio', type=float, default=1.0)
    parser.add_argument('--n_fewshot', type=int, default=40)
    parser.add_argument('--cfg', type=float, default=2.0,
                        help='CFG 强度 (1.0 时 z 统计与 encoder mu_z 对齐)')
    parser.add_argument('--z_rescale', action='store_true',
                        help='DDIM z 逐位置矩匹配到 encoder z 分布 (修复 CFG 失配)')
    parser.add_argument('--z_source', type=str, default='ddim',
                        choices=['ddim', 'encoder'],
                        help='z 来源: ddim=扩散采样 (生成式) / encoder=真实 trial mu_z 重渲染 (零标签噪声)')
    parser.add_argument('--latent_match', action='store_true',
                        help='潜空间对齐: 训练 trial mu_z 逐位置矩匹配到测试被试 z 统计 (Latent EA)')
    parser.add_argument('--amp_calib', type=str, default='none',
                        choices=['none', 'global', 'diag', 'full'],
                        help='幅度校准: global=全局标量 / diag=对角(每通道方差) / full=白化-重着色(二阶精确)')
    parser.add_argument('--quick', action='store_true', help='仅生成质量快检')
    parser.add_argument('--p2_ckpt', type=str,
                        default='checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p2/sb_sd_ldm_p2_epoch_500.pt')
    parser.add_argument('--p4_ckpt', type=str,
                        default='checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p4/style_vae_final.pt')
    parser.add_argument('--p5_ckpt', type=str,
                        default='checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p5/cov_chart_final.pt')
    args = parser.parse_args()

    global GEN_RATIO, N_FEWSHOT, GUIDANCE_SCALE
    GEN_RATIO = args.ratio
    N_FEWSHOT = args.n_fewshot
    GUIDANCE_SCALE = args.cfg

    set_seed()
    ev = _load_ev()

    print(f'加载 P2 checkpoint: {args.p2_ckpt}')
    model, cond_embed = load_p2_model(PROJECT_ROOT / args.p2_ckpt)
    W_subj = model.subj_embed.weight.detach()

    print(f'加载 P4 StyleEncoder: {args.p4_ckpt}')
    style_enc, _, sigma0 = load_style_vae(
        PROJECT_ROOT / args.p4_ckpt, channels=22, input_length=1000,
        num_classes=4, device=DEVICE)

    print(f'加载 P5 CovChart: {args.p5_ckpt}')
    chart, covemb, sigma0_p5 = load_p5(PROJECT_ROOT / args.p5_ckpt, device=DEVICE)
    print(f'  sigma0={sigma0_p5}, cov_dim={covemb.k}, '
          f'PCA 解释方差={covemb.explained_ratio*100:.1f}%')

    # 数据
    X, y, subjects, sessions = ev.load_dataset_data('bci2a')
    subj_uniq = np.unique(subjects)
    if subj_uniq.max() != len(subj_uniq) - 1:
        remap = {s: i for i, s in enumerate(subj_uniq)}
        subjects = np.array([remap[s] for s in subjects])
    n_subj = len(np.unique(subjects))
    channels, input_length = X.shape[1], X.shape[2]

    # 训练被试协方差查表 + 图表中心 (full 模式位移参考)
    cov_lookup = torch.FloatTensor(np.stack([
        covemb.embed(compute_subject_R(X[subjects == s]))
        for s in range(n_subj)])).to(DEVICE)
    with torch.no_grad():
        chart.center = chart(cov_lookup).mean(dim=0, keepdim=True)  # (1, 32)

    # teacher (快检判类 + latent_match 伪标签)
    from core.classifiers.eegnet import EEGNet
    teacher_ckpt = PROJECT_ROOT / 'checkpoints/tc_conf_ldm/bci2a_shared_margin/pretrained_teacher_eegnet.pt'
    teacher = EEGNet(n_channels=22, n_samples=1000, n_classes=4).to(DEVICE)
    state = torch.load(str(teacher_ckpt), map_location=DEVICE, weights_only=False)
    if isinstance(state, dict) and 'model_state_dict' in state:
        state = state['model_state_dict']
    teacher.load_state_dict(state, strict=False)
    teacher.eval()

    def pseudo_label(Xf):
        with torch.no_grad():
            xb = torch.FloatTensor(np.asarray(Xf)).unsqueeze(1).to(DEVICE)
            return teacher(xb).argmax(1).cpu().numpy()

    # [快检] teacher 判类 + 协方差定向性
    print('\n' + '=' * 70)
    print(f'[快检] mode={args.mode}, cfg={GUIDANCE_SCALE}, '
          f'z_rescale={args.z_rescale}, z_source={args.z_source}, '
          f'latent_match={args.latent_match}, amp_calib={args.amp_calib} '
          f'(用被试 {n_subj} 模拟测试被试)')
    print('=' * 70)
    X_few_q = X[subjects == n_subj - 1][:N_FEWSHOT]
    y_few_q_pl = pseudo_label(X_few_q)
    pl_acc = float((y_few_q_pl == y[subjects == n_subj - 1][:N_FEWSHOT]).mean())
    print(f'  fewshot 伪标签准确率: {pl_acc*100:.1f}%')
    train_ids_q = [s for s in range(n_subj) if s != n_subj - 1]
    X_ref_q = X[subjects != n_subj - 1]
    y_ref_q = y[subjects != n_subj - 1]
    gX, gy = generate_p5(model, cond_embed, style_enc, chart, covemb,
                         50, NUM_CLASSES, args.mode, train_ids_q, W_subj,
                         X_few=X_few_q, sigma0=sigma0_p5,
                         z_rescale=args.z_rescale,
                         X_ref=X_ref_q, y_ref=y_ref_q,
                         z_source=args.z_source,
                         X_pool=X_ref_q, y_pool=y_ref_q,
                         latent_match=args.latent_match,
                         X_few_pl=X_few_q, y_few_pl=y_few_q_pl,
                         amp_calib=args.amp_calib)
    gX = np.nan_to_num(gX.astype(np.float32), nan=0.0)

    with torch.no_grad():
        xb = torch.FloatTensor(gX).unsqueeze(1).to(DEVICE)
        pred = teacher(xb).argmax(1).cpu().numpy()
    gen_acc = float((pred == gy).mean())
    print(f'  teacher 判类 (生成): {gen_acc*100:.1f}%  (真实数据: 85.5%)')

    R_gen = compute_subject_R(gX)
    R_test_q = compute_subject_R(X_few_q)
    d_rel = np.linalg.norm(R_gen - R_test_q) / (np.linalg.norm(R_test_q) + 1e-8)
    d_rand = np.mean([np.linalg.norm(R_gen - compute_subject_R(X[subjects == s]))
                      / (np.linalg.norm(compute_subject_R(X[subjects == s])) + 1e-8)
                      for s in range(n_subj - 1)])
    print(f'  生成批协方差 vs R_test: d_rel={d_rel:.3f} (训练被试平均 d={d_rand:.3f}, '
          f'{"协方差定向生效" if d_rel < d_rand * 0.8 else "未定向"})')
    print(f'  幅度: ||R_gen||={np.linalg.norm(R_gen):.3f} vs '
          f'||R_test||={np.linalg.norm(R_test_q):.3f} '
          f'(比值 {np.linalg.norm(R_gen) / (np.linalg.norm(R_test_q) + 1e-8):.3f})')

    if args.quick:
        return

    # [LOSO]
    from sklearn.metrics import accuracy_score, cohen_kappa_score
    ev.GEN_RATIO = GEN_RATIO
    ev.N_ENSEMBLE = N_ENSEMBLE

    print('\n' + '=' * 70)
    print(f'[LOSO] P5 mode={args.mode}, ratio={GEN_RATIO}, cfg={GUIDANCE_SCALE}, '
          f'z_rescale={args.z_rescale}, z_source={args.z_source}, '
          f'latent_match={args.latent_match}, amp_calib={args.amp_calib} '
          f'(原始空间, 无白化)')
    print('=' * 70)

    results = []
    for test_subj in range(n_subj):
        train_mask = subjects != test_subj
        test_mask = subjects == test_subj
        X_train, y_train = X[train_mask], y[train_mask]
        X_test, y_test = X[test_mask], y[test_mask]
        train_subj_ids = [int(s) for s in np.unique(subjects[train_mask])]

        X_few = X_test[:N_FEWSHOT] if args.mode in ('full', 'orth_only', 'cov_only') else None
        y_few_pl = pseudo_label(X_few) if X_few is not None else None

        spc = max(1, int(GEN_RATIO * len(X_train)) // NUM_CLASSES)
        set_seed()
        gen_X, gen_y = generate_p5(model, cond_embed, style_enc, chart, covemb,
                                   spc, NUM_CLASSES, args.mode,
                                   train_subj_ids, W_subj,
                                   X_few=X_few, sigma0=sigma0_p5,
                                   z_rescale=args.z_rescale,
                                   X_ref=X_train, y_ref=y_train,
                                   z_source=args.z_source,
                                   X_pool=X_train, y_pool=y_train,
                                   latent_match=args.latent_match,
                                   X_few_pl=X_few, y_few_pl=y_few_pl,
                                   amp_calib=args.amp_calib)
        gen_X = np.nan_to_num(gen_X.astype(np.float32), nan=0.0)

        X_aug = np.concatenate([X_train, gen_X])
        y_aug = np.concatenate([y_train, gen_y])

        clf = ev.train_classifier(X_aug, y_aug, channels, input_length, NUM_CLASSES)
        pred = ev.predict(clf, X_test)
        acc = float(accuracy_score(y_test, pred))
        kappa = float(cohen_kappa_score(y_test, pred))
        results.append({'acc': acc, 'kappa': kappa})
        print(f'  被试 {test_subj+1}: Acc {acc*100:.2f}%, Kappa {kappa:.4f}')

    accs = [r['acc'] for r in results]
    kappas = [r['kappa'] for r in results]
    res = {'mean': float(np.mean(accs)), 'std': float(np.std(accs)),
           'per_subject': accs, 'mean_kappa': float(np.mean(kappas)),
           'std_kappa': float(np.std(kappas)), 'per_subject_kappa': kappas}

    print('\n' + '=' * 70)
    print(f'>>> P5 ({args.mode}) LOSO: {res["mean"]*100:.2f}% ± {res["std"]*100:.2f}% '
          f'(Kappa {res["mean_kappa"]:.4f})')
    print(f'    锚点: real-only {ANCHORS["real-only"]*100:.2f} / '
          f'P4-fewshot {ANCHORS["P4-fewshot"]*100:.2f} / EA-40 {ANCHORS["EA-40"]*100:.2f}')
    if res['mean'] > ANCHORS['EA-40'] + 0.005:
        print('    判决: 超越 EA-40 -> 生成式对齐方法成立!')
    elif res['mean'] > ANCHORS['P4-fewshot'] + 0.005:
        print('    判决: 超过 P4 但未超 EA-40 -> 协方差通路部分生效')
    else:
        print('    判决: 未超 P4 -> 协方差通路未生效 (回退机制解剖叙事)')
    print('=' * 70)

    suffix = f'_cfg{GUIDANCE_SCALE:g}' + ('_zr' if args.z_rescale else '') \
        + ('_enc' if args.z_source == 'encoder' else '') \
        + ('_lm' if args.latent_match else '') \
        + (f'_ac{args.amp_calib[0]}' if args.amp_calib != 'none' else '')
    out = PROJECT_ROOT / f'outputs/results/sb_sd_ldm_p5_{args.mode}_r{args.ratio}{suffix}.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, 'w', encoding='utf-8') as f:
        json.dump({'mode': args.mode, 'ratio': args.ratio, 'cfg': GUIDANCE_SCALE,
                   'z_rescale': args.z_rescale, 'z_source': args.z_source,
                   'latent_match': args.latent_match,
                   'amp_calib': args.amp_calib,
                   'quick': {'gen_cls_acc': float(gen_acc),
                             'd_rel_to_test': float(d_rel),
                             'd_to_train_mean': float(d_rand)},
                   'loso': res}, f, indent=2, ensure_ascii=False)
    print(f'结果已保存: {out}')


if __name__ == '__main__':
    main()
