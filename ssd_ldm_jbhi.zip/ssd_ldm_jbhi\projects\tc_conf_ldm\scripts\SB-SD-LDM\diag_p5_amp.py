#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
P5 诊断 2: 逐被试幅度保真度 — 谁是幅度离群被试
===============================================================
问题: decode(mu_z, e_s) 渲染被试 s 时幅度保真度多少? 哪些被试被封顶?
事实输出 (每被试一行):
  ||R_s||                真实协方差范数 (幅度离群识别)
  recon: ||R_recon||/||R_s||   decode(自身 trial mu_z, e_s) 的幅度保真
         (VAE 对该被试的幅度上限 — 若低, VAE 本身表示不了该幅度)
  chart: ||R_chart||/||R_s||   decode(混合 trial mu_z, chart(cov_s))
  chart d_rel             渲染协方差 vs R_s 的相对距离

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/diag_p5_amp.py
"""
import sys
from pathlib import Path

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from style_vae_cov import load_p5, compute_subject_R
from evaluate_p4_cross_subject import load_p2_model, set_seed, DEVICE

import importlib.util


def _load_ev():
    spec = importlib.util.spec_from_file_location(
        'evaluate_sb_ldm_3datasets',
        str(PROJECT_ROOT / 'projects/tc_conf_ldm/scripts/SB-LDM/evaluate_sb_ldm_3datasets.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


@torch.no_grad()
def batch_decode_R(model, cond_embed, mu_z, y, style_vec):
    cond = cond_embed(y)
    x = model.decode(mu_z, target_length=model.input_length,
                     cond=cond, style_vec=style_vec)
    return compute_subject_R(x.cpu().numpy())


def main():
    set_seed()
    ev = _load_ev()

    model, cond_embed = load_p2_model(
        PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p2/sb_sd_ldm_p2_epoch_500.pt')
    W_subj = model.subj_embed.weight.detach()
    chart, covemb, sigma0 = load_p5(
        PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p5/cov_chart_final.pt',
        device=DEVICE)

    X, y, subjects, sessions = ev.load_dataset_data('bci2a')
    subj_uniq = np.unique(subjects)
    if subj_uniq.max() != len(subj_uniq) - 1:
        remap = {s: i for i, s in enumerate(subj_uniq)}
        subjects = np.array([remap[s] for s in subjects])
    n_subj = len(np.unique(subjects))

    # 混合 mu_z 批 (chart 渲染用, 与 G1 同构)
    rs = np.random.RandomState(0)
    idx_fix = rs.choice(len(X), size=72, replace=False)
    xb = torch.FloatTensor(X[idx_fix]).to(DEVICE)
    yb = torch.LongTensor(y[idx_fix]).to(DEVICE)
    _, mu_mixed, _ = model.encode(xb, cond=cond_embed(yb))

    print('=' * 76)
    print('逐被试幅度保真度 (BCI2a, 原始空间)')
    print('=' * 76)
    print(f'{"被试":>4s} {"||R_s||":>9s} {"recon幅度":>9s} {"chart幅度":>9s} '
          f'{"chart d_rel":>11s} {"幅度离群":>8s}')
    print('-' * 60)

    norms = []
    for s in range(n_subj):
        Xs = X[subjects == s]
        ys = y[subjects == s]
        R_s = compute_subject_R(Xs)
        nR = np.linalg.norm(R_s)
        norms.append(nR)

        # recon: 自身 trial 的 mu_z + 自身锚点风格
        idx = rs.choice(len(Xs), size=min(72, len(Xs)), replace=False)
        xb_s = torch.FloatTensor(Xs[idx]).to(DEVICE)
        yb_s = torch.LongTensor(ys[idx]).to(DEVICE)
        _, mu_s, _ = model.encode(xb_s, cond=cond_embed(yb_s))
        R_recon = batch_decode_R(model, cond_embed, mu_s, yb_s,
                                 W_subj[s].unsqueeze(0).expand(len(idx), -1))

        # chart: 混合 mu_z + chart(cov_s)
        cov_s = torch.FloatTensor(covemb.embed(R_s)).to(DEVICE)
        style_s = chart(cov_s.unsqueeze(0)).expand(mu_mixed.size(0), -1)
        R_chart = batch_decode_R(model, cond_embed, mu_mixed, yb, style_s)

        amp_recon = np.linalg.norm(R_recon) / nR
        amp_chart = np.linalg.norm(R_chart) / nR
        d_chart = np.linalg.norm(R_chart - R_s) / nR
        print(f'{s+1:>4d} {nR:>9.2f} {amp_recon:>9.3f} {amp_chart:>9.3f} '
              f'{d_chart:>11.3f}')

    norms = np.array(norms)
    med = np.median(norms)
    print('-' * 60)
    print(f'||R_s|| 中位数 {med:.2f}, 最大/中位 = {norms.max()/med:.2f}x '
          f'(被试 {int(np.argmax(norms))+1})')
    print('判读: recon幅度 < 0.5 的被试 = VAE 幅度上限不足 (该被试做测试时'
          '\n      encoder 重渲染必塌缩, 需要幅度校准; chart幅度同理).')


if __name__ == '__main__':
    main()
