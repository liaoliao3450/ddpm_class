# KBS journal: BCI2b + PhysioNet full training chains (P1->P2->P4->P5)
# + BCI2a alignment-level ablations (L1-only, L1+L2) queued FIRST.
# Each step verifies product checkpoint exists before continuing; stop on any failure.
$ErrorActionPreference = 'Stop'
$env:PYTHONUTF8 = '1'
Set-Location F:\DS-DDPM-main
$root = 'F:\DS-DDPM-main'
$scripts = "$root\projects\tc_conf_ldm\scripts\SB-SD-LDM"
$ck = "$root\checkpoints\tc_conf_ldm"
$logdir = "$root\outputs\logs"
$okFile = "$logdir\journal_chains_status.txt"

function Write-Status($msg) {
    $ts = Get-Date -Format 'HH:mm:ss'
    "[$ts] $msg" | Tee-Object -FilePath $okFile -Append
}

# (name, script file, argument array, product file, log)
# ablations use product JSON as completion marker
$chain = @(
    @('ablation-L1',   'ea_latentEA_combo.py', @('--gen_mode','orth_only','--amp_calib','none','--tag','L1'),    "$root\outputs\results\ea_latentEA_combo_full_L1.json",   'journal_ablation_L1.log'),
    @('ablation-L1L2', 'ea_latentEA_combo.py', @('--gen_mode','cov_only','--amp_calib','none','--tag','L1L2'),  "$root\outputs\results\ea_latentEA_combo_full_L1L2.json", 'journal_ablation_L1L2.log'),
    @('bci2b-teacher', '..\pretrain_teacher_eegnet_bci2b.py', @('--dataset','bci2b'), "$ck\bci2b_shared\pretrained_teacher_eegnet.pt", 'journal_bci2b_teacher.log'),
    @('bci2b-P1', 'train_sb_sd_ldm.py',    @('--dataset','bci2b'), "$ck\sb_sd_ldm_bci2b\sb_sd_ldm_epoch_500.pt",       'journal_bci2b_p1.log'),
    @('bci2b-P2', 'train_sb_sd_ldm_p2.py', @('--dataset','bci2b'), "$ck\sb_sd_ldm_bci2b_p2\sb_sd_ldm_p2_epoch_500.pt", 'journal_bci2b_p2.log'),
    @('bci2b-P4', 'train_sb_sd_ldm_p4.py', @('--dataset','bci2b'), "$ck\sb_sd_ldm_bci2b_p4\style_vae_final.pt",        'journal_bci2b_p4.log'),
    @('bci2b-P5', 'train_sb_sd_ldm_p5.py', @('--dataset','bci2b'), "$ck\sb_sd_ldm_bci2b_p5\cov_chart_final.pt",        'journal_bci2b_p5.log'),
    @('physionet-P1', 'train_sb_sd_ldm.py',    @('--dataset','physionet'), "$ck\sb_sd_ldm_physionet\sb_sd_ldm_epoch_500.pt",       'journal_physionet_p1.log'),
    @('physionet-P2', 'train_sb_sd_ldm_p2.py', @('--dataset','physionet'), "$ck\sb_sd_ldm_physionet_p2\sb_sd_ldm_p2_epoch_500.pt", 'journal_physionet_p2.log'),
    @('physionet-P4', 'train_sb_sd_ldm_p4.py', @('--dataset','physionet'), "$ck\sb_sd_ldm_physionet_p4\style_vae_final.pt",        'journal_physionet_p4.log'),
    @('physionet-P5', 'train_sb_sd_ldm_p5.py', @('--dataset','physionet'), "$ck\sb_sd_ldm_physionet_p5\cov_chart_final.pt",        'journal_physionet_p5.log'),
    # budget sweep (Fig.7): N=40 复用 ea_latentEA_combo_full.json
    @('budget-nf10', 'ea_latentEA_combo.py', @('--n_fewshot','10','--tag','nf10'), "$root\outputs\results\ea_latentEA_combo_full_nf10.json", 'journal_budget_nf10.log'),
    @('budget-nf20', 'ea_latentEA_combo.py', @('--n_fewshot','20','--tag','nf20'), "$root\outputs\results\ea_latentEA_combo_full_nf20.json", 'journal_budget_nf20.log'),
    @('budget-nf60', 'ea_latentEA_combo.py', @('--n_fewshot','60','--tag','nf60'), "$root\outputs\results\ea_latentEA_combo_full_nf60.json", 'journal_budget_nf60.log'),
    @('budget-nf80', 'ea_latentEA_combo.py', @('--n_fewshot','80','--tag','nf80'), "$root\outputs\results\ea_latentEA_combo_full_nf80.json", 'journal_budget_nf80.log')
)

Write-Status '===== journal chains v3 START (ablations first) ====='

foreach ($step in $chain) {
    $name = $step[0]; $scriptFile = $step[1]; $argList = $step[2]; $product = $step[3]; $log = $step[4]

    if (Test-Path $product) {
        Write-Status "$name SKIP (product exists)"
        continue
    }
    Write-Status "$name START -> $log"
    # cmd /c 原生重定向: 规避 PowerShell *> 包装 stderr 的管道死锁
    # (NumPy DeprecationWarning 等 stderr 输出曾导致进程挂起)
    $argStr = $argList -join ' '
    cmd /c "python -u `"$scripts\$scriptFile`" $argStr > `"$logdir\$log`" 2>&1"
    if ($LASTEXITCODE -ne 0) {
        Write-Status "$name FAILED (exit=$LASTEXITCODE) - chain stopped, see $logdir\$log"
        exit 1
    }
    if (-not (Test-Path $product)) {
        Write-Status "$name FAILED (product missing: $product) - chain stopped"
        exit 1
    }
    Write-Status "$name DONE"
}

Write-Status '===== ALL STEPS COMPLETE ====='
