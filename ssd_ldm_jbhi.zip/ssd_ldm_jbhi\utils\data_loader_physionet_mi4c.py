"""
PhysioNet MI 四分类数据加载器

目标：
- 从 `data/processed/PhysioNetMI4C` 的子目录（如 S001R04, S001R06, ...）读取 X/y
- 解析被试与会话：
    - 被试键 = S001
    - 会话 = (R04/R06)->0, (R08/R10)->1, (R12/R14)->2
- 统一输出：X, y, subjects, sessions 以及 subject_key->idx 映射
"""

from __future__ import annotations

import ast
import json
import os
import re
from typing import Dict, Tuple

import numpy as np


def _parse_subject_from_path(path: str) -> int:
    """从文件路径解析被试编号"""
    # 路径格式类似: E:\\PhysioNetMI4C\\S001R04\\X.npy
    m = re.search(r'S(\d{3})', path, re.IGNORECASE)
    if m:
        return int(m.group(1)) - 1  # S001 -> 0, S002 -> 1, ...
    return 0

def _parse_session_from_path(path: str) -> int:
    """从文件路径解析会话编号"""
    # R04/R06 -> 0, R08/R10 -> 1, R12/R14 -> 2
    m = re.search(r'R(\d{2})', path, re.IGNORECASE)
    if m:
        run = int(m.group(1))
        if run in {4, 6}:
            return 0
        elif run in {8, 10}:
            return 1
        elif run in {12, 14}:
            return 2
    return 0

def parse_physionet4c_subject_session(name: str) -> Tuple[str, int]:
    m = re.search(r"S(\d{3})R(\d{2})", name, flags=re.IGNORECASE)
    if not m:
        return name, 0

    subject_key = f"S{m.group(1)}"
    run = int(m.group(2))
    if run in {4, 6}:
        session_idx = 0
    elif run in {8, 10}:
        session_idx = 1
    elif run in {12, 14}:
        session_idx = 2
    else:
        session_idx = 0
    return subject_key, session_idx


def load_physionet_mi4c_data(
    data_root: str = "data/processed/PhysioNetMI4C",
    standardize: bool = True,
):
    """
    加载 PhysioNet MI 4类数据集
    支持两种格式：
    1. 嵌套格式（优先）: PhysioNetMI4C/PhysioNetMI4C/S001R04/{X.npy, y.npy}, S001R06/, ...
    2. 整合格式: PhysioNetMI4C/PhysioNetMI4C/{X.npy, y.npy, meta.json}
    """
    if not os.path.isdir(data_root):
        raise FileNotFoundError(f"PhysioNetMI4C 处理后数据目录不存在: {data_root}")

    # 检查嵌套目录格式（优先）
    nested_data_root = os.path.join(data_root, "PhysioNetMI4C")
    subdirs = []
    
    if os.path.isdir(nested_data_root):
        # 遍历嵌套目录，查找包含 X.npy 的子目录
        for d in sorted(os.listdir(nested_data_root)):
            sub_path = os.path.join(nested_data_root, d)
            if os.path.isdir(sub_path) and os.path.exists(os.path.join(sub_path, "X.npy")):
                subdirs.append(os.path.join("PhysioNetMI4C", d))
    
    # 如果找到嵌套目录，优先使用
    if subdirs:
        print("[PhysioNetMI4C] 使用嵌套目录格式加载数据")
        return _load_from_nested_dirs(data_root, subdirs)
    
    # 否则尝试整合格式
    integrated_path = os.path.join(data_root, "PhysioNetMI4C")
    integrated_x = os.path.join(integrated_path, "X.npy")
    
    if os.path.exists(integrated_x):
        # 整合格式
        print("[PhysioNetMI4C] 使用整合格式加载数据")
        return _load_from_integrated(data_root)
    
    raise FileNotFoundError(f"无法找到 PhysioNet MI4C 数据文件")

def _load_from_nested_dirs(data_root, subdirs):
    """从嵌套目录加载数据"""
    X_list = []
    y_list = []
    subjects_list = []
    sessions_list = []
    
    for name in subdirs:
        sub_path = os.path.join(data_root, name)
        X_path = os.path.join(sub_path, "X.npy")
        y_path = os.path.join(sub_path, "y.npy")
        if not (os.path.exists(X_path) and os.path.exists(y_path)):
            continue
        
        X_file = np.load(X_path).astype(np.float32)
        y_file = np.load(y_path).astype(np.int64)
        
        # 解析被试和会话编号
        subject_key, session_idx = parse_physionet4c_subject_session(os.path.basename(name))
        # subject_key 格式为 "S001"，提取数字部分
        subj_num = int(subject_key[1:])  # "S001" -> 1
        subjects_file = np.full(len(X_file), subj_num, dtype=np.int64)
        sessions_file = np.full(len(X_file), session_idx, dtype=np.int64)
        
        X_list.append(X_file)
        y_list.append(y_file)
        subjects_list.append(subjects_file)
        sessions_list.append(sessions_file)
    
    X = np.concatenate(X_list)
    y = np.concatenate(y_list)
    subjects = np.concatenate(subjects_list)
    sessions = np.concatenate(sessions_list)
    
    # 将被试键映射为连续索引
    unique_subjects = sorted(set(subjects))
    subj_map = {s: i for i, s in enumerate(unique_subjects)}
    subjects = np.array([subj_map[s] for s in subjects], dtype=np.int64)
    
    print(f"[PhysioNetMI4C] 数据加载完成:")
    print(f"  X: {X.shape}, y: {y.shape}")
    print(f"  类别分布: {[sum(y==i) for i in range(4)]}")
    print(f"  被试数: {len(unique_subjects)}")
    print(f"  会话标签值: {sorted(set(sessions))}")
    
    return X, y, subjects, sessions, None

def _load_from_integrated(data_root):
    """从整合格式加载数据"""
    integrated_path = os.path.join(data_root, "PhysioNetMI4C")
    X = np.load(os.path.join(integrated_path, "X.npy")).astype(np.float32)
    y = np.load(os.path.join(integrated_path, "y.npy")).astype(np.int64)
    
    # 尝试从 meta.json 解析被试信息
    meta_path = os.path.join(integrated_path, "meta.json")
    if os.path.exists(meta_path):
        with open(meta_path, 'r') as f:
            meta = json.load(f)
        if 'files' in meta and meta['files']:
            try:
                file_list = ast.literal_eval(meta['files'])
                if isinstance(file_list, list) and len(file_list) > 0:
                    n_samples_per_file = len(X) // len(file_list)
                    subjects = np.repeat([_parse_subject_from_path(f) for f in file_list], n_samples_per_file)[:len(X)]
                    sessions = np.repeat([_parse_session_from_path(f) for f in file_list], n_samples_per_file)[:len(X)]
                    print(f"[PhysioNetMI4C] 整合数据: X={X.shape}, 从 {len(file_list)} 个文件解析被试信息")
                    return X, y, subjects, sessions, None
            except Exception as e:
                print(f"[PhysioNetMI4C] 警告: 解析 meta.json files 失败 ({e})")
    
    # 无法获取被试信息
    print("[PhysioNetMI4C] 警告: 无法获取被试信息，使用平均分配")
    subjects = np.repeat(np.arange(len(X) // 15), 15)[:len(X)]
    sessions = np.zeros(len(X), dtype=np.int64)
    return X, y, subjects, sessions, None


if __name__ == "__main__":
    # 测试数据加载
    X, y, subjects, sessions, _ = load_physionet_mi4c_data()
    print(f"\n最终汇总:")
    print(f"  X.shape: {X.shape}")
    print(f"  y.shape: {y.shape}")
    print(f"  subjects: 唯一值数量 = {len(set(subjects))}")
    print(f"  sessions: 唯一值 = {sorted(set(sessions))}")


