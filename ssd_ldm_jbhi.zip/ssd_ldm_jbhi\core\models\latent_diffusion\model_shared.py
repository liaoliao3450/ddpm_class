"""
共享骨干的潜在扩散模型 (Shared VAE-UNet Latent Diffusion)

设计目标：
1) VAE(Encoder/Decoder) 与 Diffusion-UNet 共享主体 ResBlocks，减少参数量
2) 支持 task condition（class/scenario/difficulty）在 VAE 与 UNet 中共同对齐（多任务对齐）
3) 维持与现有训练脚本类似的接口：encode/decode/forward/sample

条件化方式：
- FiLM(t+cond)：任务级 scale/shift，嵌入在所有共享 ResBlock 中。
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


# ============================================================
# Helpers
# ============================================================

def _pick_groupnorm_groups(ch: int) -> int:
    for g in (32, 16, 8, 4, 2, 1):
        if ch % g == 0:
            return g
    return 1


def sinusoidal_embedding(timesteps: torch.Tensor, dim: int = 128, max_period: int = 10000) -> torch.Tensor:
    half = dim // 2
    device = timesteps.device
    t = timesteps.float()
    freqs = torch.exp(-math.log(max_period) * torch.arange(0, half, device=device).float() / half)
    args = t[:, None] * freqs[None]
    emb = torch.cat([torch.cos(args), torch.sin(args)], dim=-1)
    if dim % 2 == 1:
        emb = F.pad(emb, (0, 1))
    return emb


# ============================================================
# SharedResBlock1D：FiLM 条件化
# ============================================================

class SharedResBlock1D(nn.Module):
    """
    共享 ResBlock，支持 FiLM 任务级条件化（time-step + class/scenario/difficulty）。
    """

    def __init__(self, channels: int, emb_dim: int):
        super().__init__()
        self.channels = channels

        g1 = _pick_groupnorm_groups(channels)
        g2 = _pick_groupnorm_groups(channels)
        self.norm1 = nn.GroupNorm(g1, channels)
        self.norm2 = nn.GroupNorm(g2, channels)
        self.act = nn.SiLU()

        self.conv1 = nn.Conv1d(channels, channels, kernel_size=3, padding=1)
        self.conv2 = nn.Conv1d(channels, channels, kernel_size=3, padding=1)

        # FiLM：任务级 scale/shift
        self.film = nn.Linear(emb_dim, 2 * channels)

        nn.init.zeros_(self.conv2.weight)
        if self.conv2.bias is not None:
            nn.init.zeros_(self.conv2.bias)

    def forward(
        self,
        x: torch.Tensor,
        emb: torch.Tensor,
    ) -> torch.Tensor:
        """
        device = next(self.parameters()).device
        z_channels, Lz = latent_shape
        z = torch.randn(n_samples, z_channels, Lz, device=device)
        eps = 1e-8

        for t_idx in reversed(range(self.timesteps)):
            t = torch.full((n_samples,), t_idx, device=device, dtype=torch.long)

            eps_cond = self.denoise_eps(z, t, cond=cond)
            if guidance_scale > 1.0 and cond is not None:
                eps_uncond = self.denoise_eps(z, t, cond=None)
                eps_pred = eps_uncond + guidance_scale * (eps_cond - eps_uncond)
            else:
                eps_pred = eps_cond

            ab  = self.alpha_bar[t].view(-1, 1, 1)
            a   = self.alpha[t].view(-1, 1, 1)
            sab = torch.sqrt(torch.clamp(ab,   min=eps))
            s1m = torch.sqrt(torch.clamp(1-ab, min=eps))

            if t_idx > 0:
                pz0 = (z - s1m * eps_pred) / sab
                abp = self.alpha_bar[t_idx - 1].view(-1, 1, 1)
                pm  = (
                    torch.sqrt(abp) * (1 - a) / (1 - ab + eps) * pz0
                    + torch.sqrt(a)  * (1 - abp) / (1 - ab + eps) * z
                )
                pv  = ((1 - abp) / (1 - ab + eps) * (1 - a)).clamp(min=eps)
                z   = pm + torch.sqrt(pv) * torch.randn_like(z)
            else:
                z = (z - s1m * eps_pred) / sab

        return z


__all__ = [
    "SharedBackboneConfig",
    "SharedVAEUNetLDM1D",
]
Args:
            x:   (B, C, L)
            emb: (B, emb_dim) 任务级嵌入
        """
        h = self.conv1(self.act(self.norm1(x)))

        # FiLM 调制
        scale_shift = self.film(emb)
        scale, shift = scale_shift.chunk(2, dim=1)
        h = self.norm2(h)
        h = h * (1.0 + scale.unsqueeze(-1)) + shift.unsqueeze(-1)

        h = self.conv2(self.act(h))
        return x + h


# ============================================================
# Down / Up sample
# ============================================================

class Downsample1D(nn.Module):
    def __init__(self, in_ch: int, out_ch: int):
        super().__init__()
        self.conv = nn.Conv1d(in_ch, out_ch, kernel_size=4, stride=2, padding=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.conv(x)


class Upsample1D(nn.Module):
    def __init__(self, in_ch: int, out_ch: int):
        super().__init__()
        self.deconv = nn.ConvTranspose1d(in_ch, out_ch, kernel_size=4, stride=2, padding=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.deconv(x)


@dataclass(frozen=True)
class SharedBackboneConfig:
    base: int = 64
    levels: Tuple[int, ...] = (1, 2, 4)
    blocks_per_level: int = 2


# ============================================================
# SharedBlockBank
# ============================================================

class SharedBlockBank(nn.Module):
    """按 level 共享 ResBlocks（供 VAE encoder/decoder 与 latent-UNet 共用）。"""

    def __init__(self, cfg: SharedBackboneConfig, emb_dim: int):
        super().__init__()
        self.cfg = cfg
        self.emb_dim = emb_dim
        self.level_channels = [cfg.base * m for m in cfg.levels]

        self.enc_blocks = nn.ModuleList()
        for ch in self.level_channels:
            self.enc_blocks.append(nn.ModuleList([
                SharedResBlock1D(ch, emb_dim)
                for _ in range(cfg.blocks_per_level)
            ]))

        mid_ch = self.level_channels[-1]
        self.mid_blocks = nn.ModuleList([
            SharedResBlock1D(mid_ch, emb_dim)
            for _ in range(cfg.blocks_per_level)
        ])

        self.dec_blocks = nn.ModuleList()
        for ch in reversed(self.level_channels):
            self.dec_blocks.append(nn.ModuleList([
                SharedResBlock1D(ch, emb_dim)
                for _ in range(cfg.blocks_per_level)
            ]))


# ============================================================
# 梯度反转层 (GRL, P2 解耦用)
# ============================================================

class GradientReversalFn(torch.autograd.Function):
    """前向恒等, 反向乘 -alpha.

    P2 解耦: subject_disc 经 GRL 读取 z 的被试信息 —
    判别器学分类 (正向梯度), 编码器被反转梯度逼着抹除被试信息 (负向梯度).
    """

    @staticmethod
    def forward(ctx, x: torch.Tensor, alpha: float) -> torch.Tensor:
        ctx.alpha = float(alpha)
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor):
        return grad_output.neg() * ctx.alpha, None


# ============================================================
# SharedVAEUNetLDM1D（主模型）
# ============================================================

class SharedVAEUNetLDM1D(nn.Module):
    """
    共享骨干潜在扩散模型。

    接口：
    - encode(x, cond)
    - decode(z, target_length, cond)
    - denoise_eps(z_t, t, cond)
    - forward(x, t, cond)  -> eps_pred, noise, mu, logvar, None
    - sample(n_samples, latent_shape, cond, guidance_scale)
    """

    def __init__(
        self,
        channels: int,
        input_length: int,
        z_channels: int = 64,
        timesteps: int = 1000,
        t_dim: int = 128,
        cond_dim: int = 64,
        backbone: SharedBackboneConfig = SharedBackboneConfig(),
        num_subjects: int = 0,
        adv_alpha: float = 0.1,
        subj_dim: int = 32,
        disentangle: bool = False,
    ) -> None:
        super().__init__()
        self.channels = int(channels)
        self.input_length = int(input_length)
        self.z_channels = int(z_channels)
        self.timesteps = int(timesteps)
        self.t_dim = int(t_dim)
        self.cond_dim = int(cond_dim)
        self.num_subjects = int(num_subjects)
        self.subj_dim = int(subj_dim)

        # 扩散调度（cosine）
        self.register_buffer("beta", self._cosine_beta_schedule(self.timesteps))
        self.register_buffer("alpha", 1.0 - self.beta)
        self.register_buffer("alpha_bar", torch.cumprod(self.alpha, dim=0))

        # 统一 embedding：time + cond -> t_dim
        self.time_mlp = nn.Sequential(
            nn.Linear(t_dim, t_dim * 4),
            nn.SiLU(),
            nn.Linear(t_dim * 4, t_dim),
        )
        self.cond_proj = nn.Sequential(
            nn.Linear(cond_dim, t_dim),
            nn.SiLU(),
            nn.Linear(t_dim, t_dim),
        )

        # 共享 block bank
        self.bank = SharedBlockBank(backbone, emb_dim=t_dim)
        chs = self.bank.level_channels
        bottleneck_ch = chs[-1]

        # -------- VAE Encoder --------
        self.enc_stem = nn.Conv1d(self.channels, chs[0], kernel_size=3, padding=1)
        self.enc_down = nn.ModuleList()
        for i in range(len(chs) - 1):
            self.enc_down.append(Downsample1D(chs[i], chs[i + 1]))

        self.mu_head = nn.Conv1d(bottleneck_ch, self.z_channels, kernel_size=1)
        self.logvar_head = nn.Conv1d(bottleneck_ch, self.z_channels, kernel_size=1)
        nn.init.zeros_(self.mu_head.weight)
        nn.init.zeros_(self.mu_head.bias)
        nn.init.zeros_(self.logvar_head.weight)
        nn.init.constant_(self.logvar_head.bias, -1.0)

        # -------- VAE Decoder --------
        self.dec_stem = nn.Conv1d(self.z_channels, bottleneck_ch, kernel_size=3, padding=1)
        self.dec_up = nn.ModuleList()
        for i in range(len(chs) - 1, 0, -1):
            self.dec_up.append(Upsample1D(chs[i], chs[i - 1]))
        self.dec_out = nn.Conv1d(chs[0], self.channels, kernel_size=3, padding=1)

        # -------- Diffusion UNet（潜空间）--------
        self.d_stem = nn.Conv1d(self.z_channels, bottleneck_ch, kernel_size=3, padding=1)
        self.d_down = nn.ModuleList()
        for i in range(len(chs) - 1, 0, -1):
            self.d_down.append(Downsample1D(chs[i], chs[i - 1]))
        self.d_up = nn.ModuleList()
        for i in range(0, len(chs) - 1):
            self.d_up.append(Upsample1D(chs[i], chs[i + 1]))
        self.eps_out = nn.Conv1d(bottleneck_ch, self.z_channels, kernel_size=1)

        # -------- z 被试判别器 (期刊版 SB-SD-LDM, P2 解耦) --------
        # GRL 对抗: 判别器学从 z 读被试信息, 编码器收反转梯度抹除它,
        # 被试信息只能经 P1 风格通路 (subj_embed) 进入 decode.
        self.disentangle = bool(disentangle) and self.num_subjects > 0
        if self.disentangle:
            self.subject_disc = nn.Sequential(
                nn.Conv1d(self.z_channels, 64, kernel_size=3, padding=1),
                nn.SiLU(),
                nn.Conv1d(64, 64, kernel_size=3, padding=1),
                nn.SiLU(),
                nn.AdaptiveAvgPool1d(1),
                nn.Flatten(),
                nn.Linear(64, self.num_subjects),
            )
        else:
            self.subject_disc = None

        # -------- 被试风格通路 (期刊版 SB-SD-LDM, P1) --------
        # 设计: z 只携带类内容, 被试风格经 subj_embed -> subj_proj 以独立 FiLM
        # 通路注入 decode; subj_head 用于验证风格信息是否真实到达输出.
        if self.num_subjects > 0:
            self.subj_embed = nn.Embedding(self.num_subjects, self.subj_dim)
            self.subj_proj = nn.Sequential(
                nn.Linear(self.subj_dim, t_dim),
                nn.SiLU(),
                nn.Linear(t_dim, t_dim),
            )
            # 风格检验头: 重建波形 -> 被试身份 (验证风格注入因果有效)
            self.subj_head = nn.Sequential(
                nn.Conv1d(self.channels, 64, kernel_size=7, padding=3),
                nn.SiLU(),
                nn.Conv1d(64, 64, kernel_size=5, padding=2),
                nn.SiLU(),
                nn.AdaptiveAvgPool1d(1),
                nn.Flatten(),
                nn.Linear(64, self.num_subjects),
            )
            # 零初始化最后一层: 风格注入从"无操作"起步, 训练初期等价于已修复的
            # SB-LDM 基线, 避免随机风格扰动破坏已验证的重建质量
            nn.init.zeros_(self.subj_proj[-1].weight)
            nn.init.zeros_(self.subj_proj[-1].bias)

    def _cosine_beta_schedule(self, timesteps: int, s: float = 0.008) -> torch.Tensor:
        steps = timesteps + 1
        x = torch.linspace(0, timesteps, steps)
        alphas_cumprod = torch.cos(((x / timesteps) + s) / (1 + s) * math.pi * 0.5) ** 2
        alphas_cumprod = alphas_cumprod / alphas_cumprod[0]
        betas = 1 - (alphas_cumprod[1:] / alphas_cumprod[:-1])
        return torch.clamp(betas, 1e-6, 0.999)

    def _make_emb(
        self,
        t: Optional[torch.Tensor],
        cond: Optional[torch.Tensor],
        batch: int,
        device,
    ) -> torch.Tensor:
        emb = torch.zeros(batch, self.t_dim, device=device)
        if t is not None:
            te = sinusoidal_embedding(t, dim=self.t_dim)
            emb = emb + self.time_mlp(te)
        if cond is not None:
            emb = emb + self.cond_proj(cond)
        return emb

    # ----------------------------------------------------------------
    # encode / decode / denoise_eps / forward / sample
    # ----------------------------------------------------------------

    def encode(
        self,
        x: torch.Tensor,
        cond: Optional[torch.Tensor] = None,
        subject_id: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        条件 VAE 编码。
        Args:
            x:    (B, C, T)
            cond: (B, cond_dim)
        Returns:
            z, mu, logvar: (B, z_channels, Lz)
        """
        B, device = x.size(0), x.device
        emb = self._make_emb(t=None, cond=cond, batch=B, device=device)

        h = self.enc_stem(x)
        for blk in self.bank.enc_blocks[0]:
            h = blk(h, emb)
        for lvl in range(1, len(self.bank.level_channels)):
            h = self.enc_down[lvl - 1](h)
            for blk in self.bank.enc_blocks[lvl]:
                h = blk(h, emb)
        for blk in self.bank.mid_blocks:
            h = blk(h, emb)

        mu = self.mu_head(h)
        logvar = self.logvar_head(h)
        std = torch.exp(0.5 * logvar)
        z = mu + torch.randn_like(std) * std
        return z, mu, logvar

    def predict_subject_from_z(
        self, z: torch.Tensor, grl_alpha: float = 0.0
    ) -> Optional[torch.Tensor]:
        """z -> 被试 logits (P2 解耦).

        grl_alpha > 0 时 z 先经 GRL: 反向传播时编码器收到反转梯度
        (学抹除被试信息), 判别器收到正常梯度 (学分类被试).
        grl_alpha = 0 时纯前向推断 (评估泄漏).
        """
        if self.subject_disc is None:
            return None
        if grl_alpha > 0.0:
            z = GradientReversalFn.apply(z, grl_alpha)
        return self.subject_disc(z)

    def decode(
        self,
        z: torch.Tensor,
        target_length: Optional[int] = None,
        cond: Optional[torch.Tensor] = None,
        subject_id: Optional[torch.Tensor] = None,
        style_vec: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """条件 VAE 解码 (z -> x)

        subject_id 注入被试风格 (SB-SD-LDM): z 携带类内容, 风格经独立 FiLM 通路
        调制 decoder. subject_id=None 时退化为 SB-LDM 行为 (风格通路跳过).

        style_vec (P3 生成用): 直接传入连续风格向量 (如 Dirichlet 混合
        s_mix = Σ αᵢ·subj_embed[i]), 绕过 embedding 查表 — 用于生成
        "新被试"风格. 与 subject_id 互斥, 优先级更高.
        """
        if target_length is None:
            target_length = self.input_length
        B, device = z.size(0), z.device
        emb = self._make_emb(t=None, cond=cond, batch=B, device=device)
        if style_vec is not None and self.num_subjects > 0 and hasattr(self, 'subj_embed'):
            emb = emb + self.subj_proj(style_vec)
        elif subject_id is not None and self.num_subjects > 0 and hasattr(self, 'subj_embed'):
            emb = emb + self.subj_proj(self.subj_embed(subject_id))

        h = self.dec_stem(z)
        for blk in self.bank.mid_blocks:
            h = blk(h, emb)
        for lvl, up in enumerate(self.dec_up):
            for blk in self.bank.dec_blocks[lvl]:
                h = blk(h, emb)
            h = up(h)
        for blk in self.bank.dec_blocks[len(self.dec_up)]:
            h = blk(h, emb)

        x = self.dec_out(h)
        if x.size(-1) != target_length:
            x = F.interpolate(x, size=target_length, mode="linear", align_corners=False)
        return x

    def q_sample(
        self,
        z0: torch.Tensor,
        t: torch.Tensor,
        noise: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """前向扩散（潜空间）"""
        if noise is None:
            noise = torch.randn_like(z0)
        t = torch.clamp(t, 0, self.alpha_bar.size(0) - 1)
        ab = self.alpha_bar[t].view(-1, 1, 1)
        return torch.sqrt(ab) * z0 + torch.sqrt(1 - ab) * noise

    def denoise_eps(
        self,
        z_t: torch.Tensor,
        t: torch.Tensor,
        cond: Optional[torch.Tensor] = None,
        subject_id: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """latent UNet：预测 eps"""
        B, device = z_t.size(0), z_t.device
        emb = self._make_emb(t=t, cond=cond, batch=B, device=device)

        h = self.d_stem(z_t)
        for blk in self.bank.mid_blocks:
            h = blk(h, emb)

        skips = []
        cur = h
        for lvl, down in enumerate(self.d_down):
            for blk in self.bank.dec_blocks[lvl]:
                cur = blk(cur, emb)
            skips.append(cur)
            cur = down(cur)

        for lvl, up in enumerate(self.d_up):
            cur = up(cur)
            skip = skips.pop()
            if cur.size(-1) != skip.size(-1):
                cur = F.interpolate(cur, size=skip.size(-1), mode="linear", align_corners=False)
            cur = cur + skip
            shared_lvl = lvl + 1
            for blk in self.bank.enc_blocks[shared_lvl]:
                cur = blk(cur, emb)

        return self.eps_out(cur)

    def forward(
        self,
        x: torch.Tensor,
        t: torch.Tensor,
        cond: Optional[torch.Tensor] = None,
        subject_id: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, None]:
        """
        训练前向：预测潜空间噪声。
        Returns:
            eps_pred, noise, mu, logvar, None
        """
        z, mu, logvar = self.encode(x, cond=cond)
        noise = torch.randn_like(z)
        z_t = self.q_sample(z, t, noise)
        eps_pred = self.denoise_eps(z_t, t, cond=cond)
        return eps_pred, noise, mu, logvar, None

    @torch.no_grad()
    def sample(
        self,
        n_samples: int,
        latent_shape: Tuple[int, int],
        cond: Optional[torch.Tensor] = None,
        guidance_scale: float = 1.0,
        subject_id: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        潜空间采样 z0（DDPM 逆向过程，支持 classifier-free guidance）。
        Args:
            latent_shape: (z_channels, Lz)
            cond:         (B, cond_dim)
        Returns:
            z0: (B, z_channels, Lz)
        """
        device = next(self.parameters()).device
        z_channels, Lz = latent_shape
        z = torch.randn(n_samples, z_channels, Lz, device=device)
        eps = 1e-8

        for t_idx in reversed(range(self.timesteps)):
            t = torch.full((n_samples,), t_idx, device=device, dtype=torch.long)

            eps_cond = self.denoise_eps(z, t, cond=cond)
            if guidance_scale > 1.0 and cond is not None:
                eps_uncond = self.denoise_eps(z, t, cond=None)
                eps_pred = eps_uncond + guidance_scale * (eps_cond - eps_uncond)
            else:
                eps_pred = eps_cond

            ab  = self.alpha_bar[t].view(-1, 1, 1)
            a   = self.alpha[t].view(-1, 1, 1)
            sab = torch.sqrt(torch.clamp(ab,   min=eps))
            s1m = torch.sqrt(torch.clamp(1-ab, min=eps))

            if t_idx > 0:
                pz0 = (z - s1m * eps_pred) / sab
                abp = self.alpha_bar[t_idx - 1].view(-1, 1, 1)
                pm  = (
                    torch.sqrt(abp) * (1 - a) / (1 - ab + eps) * pz0
                    + torch.sqrt(a)  * (1 - abp) / (1 - ab + eps) * z
                )
                pv  = ((1 - abp) / (1 - ab + eps) * (1 - a)).clamp(min=eps)
                z   = pm + torch.sqrt(pv) * torch.randn_like(z)
            else:
                z = (z - s1m * eps_pred) / sab

        return z


__all__ = [
    "SharedBackboneConfig",
    "SharedVAEUNetLDM1D",
]
        