"""
Task-aligned Confidence-conditioned EEG Latent Diffusion (TC-Conf-LDM).

该子工程实现置信度/难度条件的 latent diffusion 模型，
与主论文代码解耦，仅复用分类器和数据加载模块。
"""


