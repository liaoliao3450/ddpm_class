"""
数据预处理公共模块
包含所有数据集共用的功能和配置
"""

import os
import json
import numpy as np
import mne
import scipy.io as sio
from scipy.io import loadmat
from scipy.signal import butter, filtfilt, resample as sp_resample
from typing import Dict, List, Optional, Tuple, Callable
from pathlib import Path
import warnings

# NumPy 2.x兼容性补丁
def apply_numpy_compatibility_patch():
    """应用NumPy兼容性补丁"""
    # 忽略fromstring的废弃警告
    warnings.filterwarnings('ignore', message='.*fromstring.*', category=DeprecationWarning)
    warnings.filterwarnings('ignore', message='.*fromstring.*', category=FutureWarning)
    
    # 保存原始的fromstring函数
    if hasattr(np, 'fromstring'):
        _original_fromstring = np.fromstring
        
        def _compat_fromstring(string, dtype=float, count=-1, sep='', like=None):
            """NumPy 2.x 兼容的fromstring包装器"""
            try:
                return _original_fromstring(string, dtype=dtype, count=count, sep=sep, like=like)
            except (DeprecationWarning, TypeError, ValueError, FutureWarning) as e:
                error_msg = str(e).lower()
                if 'fromstring' in error_msg and 'frombuffer' in error_msg:
                    # 确保string是字节对象
                    if isinstance(string, str):
                        string = string.encode('latin-1')
                    
                    # 使用frombuffer作为替代
                    if sep == '' and count == -1:
                        return np.frombuffer(string, dtype=dtype)
                    elif sep == '':
                        return np.frombuffer(string, dtype=dtype, count=count)
                    else:
                        with warnings.catch_warnings():
                            warnings.simplefilter("ignore", (DeprecationWarning, FutureWarning))
                            return _original_fromstring(string, dtype=dtype, count=count, sep=sep, like=like)
                else:
                    raise e
        
        # 替换numpy的fromstring函数
        np.fromstring = _compat_fromstring

# 应用兼容性补丁
apply_numpy_compatibility_patch()

# -----------------------------
# 默认路径配置
# -----------------------------
DEFAULT_PATHS = {
    '2a': {
        'data_dir': r'E:\data\BCICIV_2a',
        'label_dir': r'E:\data\BCICIV_2a_label',
    },
    '2b': {
        'data_dir': r'E:\data\BCICIV_2b',
        'label_dir': r'E:\data\BCICIV_2b_label',
    },
    'seed': {
        'data_dir': r'E:\data\SEED\Preprocessed_EEG',
        'label_file': r'E:\data\SEED\Preprocessed_EEG\label.mat',
    },
    'physionet_mi': {
        'data_dir': r'E:\data\PhysioNetMI',
    },
}

def get_default_paths(dataset: str) -> Dict[str, str]:
    """获取数据集的默认路径"""
    if dataset not in DEFAULT_PATHS:
        raise ValueError(f"不支持的数据集: {dataset}")
    return DEFAULT_PATHS[dataset]

def save_processed_dataset(output_dir: str, dataset_name: str, X: np.ndarray, y: np.ndarray, 
                          metadata: Dict = None, per_file_data: List[Tuple[str, np.ndarray, np.ndarray]] = None):
    """保存处理后的数据集"""
    output_path = Path(output_dir) / dataset_name
    output_path.mkdir(parents=True, exist_ok=True)
    
    # 保存合并的数据
    np.save(output_path / 'X.npy', X)
    np.save(output_path / 'y.npy', y)
    
    # 保存每个文件的数据（如果提供）
    if per_file_data:
        for filename, X_file, y_file in per_file_data:
            file_name = os.path.splitext(os.path.basename(filename))[0]
            file_dir = output_path / file_name
            file_dir.mkdir(exist_ok=True)
            np.save(file_dir / 'X.npy', X_file)
            np.save(file_dir / 'y.npy', y_file)
    
    # 保存元数据
    unique_classes, counts = np.unique(y, return_counts=True)
    meta = {
        'dataset': dataset_name,
        'X_shape': list(X.shape),
        'y_shape': list(y.shape),
        'n_classes': int(len(unique_classes)),
        'class_distribution': {int(k): int(v) for k, v in zip(unique_classes, counts)},
    }
    
    if metadata:
        # 确保metadata中的所有值都是JSON可序列化的
        clean_metadata = {}
        for k, v in metadata.items():
            if isinstance(v, (str, int, float, bool, type(None))):
                clean_metadata[k] = v
            elif isinstance(v, dict):
                clean_metadata[k] = {str(kk): vv for kk, vv in v.items()}
            else:
                clean_metadata[k] = str(v)
        meta.update(clean_metadata)
    
    with open(output_path / 'meta.json', 'w', encoding='utf-8') as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)
    
    print(f'[{dataset_name}] 数据已保存到: {output_path}')
    print(f'[{dataset_name}] X={X.shape}, y={y.shape}')

def load_processed_dataset(dataset_path: str) -> Dict[str, np.ndarray]:
    """加载处理后的数据集"""
    dataset_path = Path(dataset_path)
    
    X_path = dataset_path / 'X.npy'
    y_path = dataset_path / 'y.npy'
    
    if not X_path.exists() or not y_path.exists():
        raise FileNotFoundError(f"数据集文件不存在: {dataset_path}")
    
    X = np.load(X_path)
    y = np.load(y_path)
    
    return {'X': X, 'y': y}

def extract_segment_trial(raw_gdb: mne.io.BaseRaw, tmin: float = 2.0, tmax: float = 6.0) -> Tuple[np.ndarray, np.ndarray]:
    """提取指定时间窗口的试验数据 (tmin到tmax秒)"""
    events = raw_gdb.info['temp']['events']
    raw_data = raw_gdb.get_data()
    sfreq = raw_gdb.info['sfreq']
    
    # 计算时间窗口的样本偏移
    start_offset = int(round(sfreq * tmin))  # 从事件开始后tmin秒开始
    end_offset = int(round(sfreq * tmax))    # 到事件开始后tmax秒结束
    window_length = end_offset - start_offset  # 窗口长度
    
    labels = np.array(events[:, 2])
    trials = []
    valid_labels = []
    
    for i, ev in enumerate(events):
        start = int(ev[0]) + start_offset
        stop = int(ev[0]) + end_offset
        
        # 检查边界
        if start < 0 or stop > raw_data.shape[1]:
            print(f"警告: 事件 {i} 超出数据边界 (start={start}, stop={stop}, data_shape={raw_data.shape})")
            continue
            
        segment = raw_data[:, start:stop]
        if segment.shape[-1] != window_length:
            print(f"警告: 事件 {i} 段长度不匹配 (expected={window_length}, actual={segment.shape[-1]})")
            continue
            
        trials.append(segment)
        valid_labels.append(labels[i])  # 只保存有效试验的标签
    
    if len(trials) == 0:
        raise ValueError("没有成功提取任何数据段")
        
    X = np.stack(trials, axis=0)
    y = np.array(valid_labels)
    return X, y

def apply_preprocessing(raw: mne.io.BaseRaw, l_freq: float = None, h_freq: float = None, 
                       notch_freq: float = None, car: bool = True, resample_freq: float = None) -> mne.io.BaseRaw:
    """应用数据预处理"""
    # 陷波滤波（50/60Hz及其二次谐波）
    if notch_freq and notch_freq > 0:
        try:
            raw.notch_filter(freqs=[notch_freq, notch_freq * 2], verbose='ERROR')
        except Exception:
            pass
    
    # 带通滤波
    if l_freq is not None or h_freq is not None:
        raw.filter(l_freq=l_freq, h_freq=h_freq, verbose='ERROR')
    
    # 重采样
    if resample_freq is not None:
        raw.resample(resample_freq, npad='auto')
    
    # 公共平均参考（CAR）
    if car:
        try:
            raw, _ = mne.set_eeg_reference(raw, 'average', projection=False, verbose='ERROR')
        except Exception:
            pass
    
    return raw