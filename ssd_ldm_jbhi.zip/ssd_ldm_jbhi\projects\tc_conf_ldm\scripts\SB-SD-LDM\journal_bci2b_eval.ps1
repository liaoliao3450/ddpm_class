# BCI2b Table III 评测: 三臂基线 (Real-only/SB-LDM/EA-40) -> Ours (Latent-EA fused)
# 顺序执行, 日志直写文件 (Start-Process 原生句柄重定向, 无 stderr 管道死锁)
$ErrorActionPreference = 'Stop'
$env:PYTHONUTF8 = '1'
Set-Location F:\DS-DDPM-main
$logdir = 'F:\DS-DDPM-main\outputs\logs'
$scripts = 'F:\DS-DDPM-main\projects\tc_conf_ldm\scripts\SB-SD-LDM'
$status = "$logdir\journal_bci2b_eval_status.txt"

function Write-Status($msg) {
    $ts = Get-Date -Format 'HH:mm:ss'
    "[$ts] $msg" | Tee-Object -FilePath $status -Append
}

function Run-Step($name, $argList, $log) {
    Write-Status "$name START -> $log"
    $p = Start-Process -FilePath python -ArgumentList $argList `
        -RedirectStandardOutput "$logdir\$log" -RedirectStandardError "$logdir\$log.err" `
        -NoNewWindow -PassThru -Wait
    if ($p.ExitCode -ne 0) {
        Write-Status "$name FAILED (exit=$($p.ExitCode)), see $logdir\$log.err"
        return $false
    }
    Write-Status "$name DONE"
    return $true
}

Write-Status '===== BCI2b Table III eval START ====='

$ok = Run-Step 'bci2b-arms' @('-u', "$scripts\journal_table3_arms.py", '--dataset', 'bci2b') 'journal_bci2b_arms.log'
if ($ok) {
    $ok = Run-Step 'bci2b-ours' @('-u', "$scripts\ea_latentEA_combo.py", '--dataset', 'bci2b') 'journal_bci2b_ours.log'
}

if ($ok) {
    Write-Status '===== BCI2b Table III eval COMPLETE ====='
} else {
    Write-Status '===== BCI2b Table III eval STOPPED (failure) ====='
}
