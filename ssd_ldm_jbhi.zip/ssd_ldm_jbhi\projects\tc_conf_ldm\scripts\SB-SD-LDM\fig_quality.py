#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
论文图 F2/F3/F6: 波形对比 / 逐被试幅度比 / PSD 对比 (BCI2a)
===============================================================
F2: 真实 vs 生成 trial 波形 (4 类 x C3/Cz/C4, 被试 1)
F3: 逐被试幅度比 g(RMS)/r(RMS) — SB-SD-LDM(few-shot latent-EA) vs SB-LDM
F6: Welch PSD 真实 vs 生成 (0-30Hz, 排除 31.25Hz 上采样伪影)

生成样本来源 (与论文主方法一致): ea_latentEA_combo 的生成端
  encoder mu_z + latent_match (L1) + chart(cov_test) 风格 (L2)
  + amp_calib=full (L3) — 产物即对齐
SB-LDM 对照: 被试嵌入 e_i 风格 (无 L1/L2/L3, 固定 VAE 池均值坍缩)

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/fig_quality.py
"""
import sys
from pathlib import Path

import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from style_vae import load_style_vae
from style_vae_cov import load_p5, compute_subject_R
from ea_baseline_loso import subject_Rs
from evaluate_p4_cross_subject import load_p2_model, set_seed, DEVICE
from evaluate_p5_cross_subject import generate_p5

import importlib.util

FS = 250
N_FEWSHOT = 40
NUM_CLASSES = 4
CLASS_NAMES = ['Left hand', 'Right hand', 'Feet', 'Tongue']
# BCI2a 22 通道中 C3/Cz/C4 的索引 (标准 10-20 排布)
CH_IDX = {'C3': 7, 'Cz': 11, 'C4': 15}
FIGDIR = PROJECT_ROOT / 'outputs/figures'
FIGDIR.mkdir(parents=True, exist_ok=True)


def _load_ev():
    spec = importlib.util.spec_from_file_location(
        'evaluate_sb_ldm_3datasets',
        str(PROJECT_ROOT / 'projects/tc_conf_ldm/scripts/SB-LDM/evaluate_sb_ldm_3datasets.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _gen_ours(model, cond_embed, style_enc, chart, covemb, sigma0_p5,
              X_few, y_few_pl, X_pool, y_pool, n_per_class):
    """主方法生成端: L1+L2+L3 (amp_calib full)."""
    gX, gy = generate_p5(
        model, cond_embed, style_enc, chart, covemb,
        n_per_class, NUM_CLASSES, 'cov_only', list(range(8)),
        model.subj_embed.weight.detach(),
        X_few=X_few, sigma0=sigma0_p5,
        z_source='encoder', X_pool=X_pool, y_pool=y_pool,
        latent_match=True, X_few_pl=X_few, y_few_pl=y_few_pl,
        amp_calib='full')
    return np.nan_to_num(gX.astype(np.float32), nan=0.0), np.asarray(gy)


def _gen_sbmldm(model, cond_embed, sigma0_p5, X_pool, y_pool, n_per_class):
    """SB-LDM 对照: prior 被试嵌入风格 (源被试分布回放), 无任何对齐."""
    gX, gy = generate_p5(
        model, cond_embed, style_enc=None, chart=None, covemb=None,
        n_per_class=n_per_class, num_classes=NUM_CLASSES, mode='prior',
        train_subj_ids=list(range(8)),
        W_subj=model.subj_embed.weight.detach(),
        sigma0=sigma0_p5,
        z_source='ddim', X_pool=X_pool, y_pool=y_pool,
        latent_match=False, amp_calib='none')
    return np.nan_to_num(gX.astype(np.float32), nan=0.0), np.asarray(gy)


# ----------------------------------------------------------------
def fig_waveform(X_real, y, gX, gy):
    """F2: 4 类 x 3 通道, 真实(黑) vs 生成(红), 前 1.5s 窗口."""
    t = np.arange(375) / FS
    fig, axes = plt.subplots(3, 4, figsize=(14, 7), sharex=True)
    for row, (ch, ci) in enumerate(CH_IDX.items()):
        for c in range(NUM_CLASSES):
            ax = axes[row, c]
            r = X_real[y == c][0, ci, :375]
            g = gX[gy == c][0, ci, :375]
            ax.plot(t, r, color='black', lw=0.8, label='Real')
            ax.plot(t, g, color='#e74c3c', lw=0.8, alpha=0.85, label='Generated')
            if row == 0:
                ax.set_title(CLASS_NAMES[c], fontsize=12)
            if c == 0:
                ax.set_ylabel(f'{ch}\namp (µV)', fontsize=10)
            if row == 2:
                ax.set_xlabel('time (s)', fontsize=9)
            ax.tick_params(labelsize=8)
    axes[0, 0].legend(fontsize=9, loc='upper right')
    fig.tight_layout()
    out = FIGDIR / 'fig_waveform_bci2a.pdf'
    fig.savefig(out, dpi=200, bbox_inches='tight')
    plt.close(fig)
    print(f'[F2] saved {out}')


def fig_amplitude():
    """deprecated — 见主流程逐折实现"""
    raise SystemExit('deprecated — 见主流程逐折实现')


def fig_psd(X_real, y, gX, gy):
    """F6: Welch PSD 真实 vs 生成, 0-30Hz."""
    from scipy.signal import welch
    fig, axes = plt.subplots(1, 4, figsize=(14, 3.2))
    for c in range(NUM_CLASSES):
        ax = axes[c]
        fr, pr = welch(X_real[y == c][:64], fs=FS, nperseg=256, axis=-1)
        fr, pg = welch(gX[gy == c][:64], fs=FS, nperseg=256, axis=-1)
        # 全通道平均 PSD
        ax.semilogy(fr, pr.mean(axis=(0, 1)), color='black', lw=1.2, label='Real')
        ax.semilogy(fr, pg.mean(axis=(0, 1)), color='#e74c3c', lw=1.2, alpha=0.9,
                    label='Generated')
        ax.axvspan(8, 12, color='#3498db', alpha=0.10)
        ax.axvspan(18, 26, color='#2ecc71', alpha=0.10)
        ax.set_xlim(0, 30)
        ax.set_title(CLASS_NAMES[c], fontsize=12)
        ax.set_xlabel('freq (Hz)', fontsize=9)
        if c == 0:
            ax.set_ylabel('PSD (a.u.)', fontsize=10)
            ax.legend(fontsize=9)
        ax.tick_params(labelsize=8)
    fig.suptitle('PSD: Real vs. Generated (0–30 Hz; shaded: mu / beta bands)', fontsize=13)
    fig.tight_layout(rect=[0, 0, 1, 0.92])
    out = FIGDIR / 'fig_psd_bci2a.pdf'
    fig.savefig(out, dpi=200, bbox_inches='tight')
    plt.close(fig)
    print(f'[F6] saved {out}')


def main():
    set_seed()
    ev = _load_ev()

    model, cond_embed = load_p2_model(
        PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p2/sb_sd_ldm_p2_epoch_500.pt')
    style_enc, _, sigma0_p4 = load_style_vae(
        PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p4/style_vae_final.pt',
        channels=22, input_length=1000, num_classes=4, device=DEVICE)
    chart, covemb, sigma0_p5 = load_p5(
        PROJECT_ROOT / 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a_p5/cov_chart_final.pt',
        device=DEVICE)

    from core.classifiers.eegnet import EEGNet
    teacher_ckpt = PROJECT_ROOT / 'checkpoints/tc_conf_ldm/bci2a_shared_margin/pretrained_teacher_eegnet.pt'
    teacher = EEGNet(n_channels=22, n_samples=1000, n_classes=4).to(DEVICE)
    state = torch.load(str(teacher_ckpt), map_location=DEVICE, weights_only=False)
    if isinstance(state, dict) and 'model_state_dict' in state:
        state = state['model_state_dict']
    teacher.load_state_dict(state, strict=False)
    teacher.eval()

    X, y, subjects, sessions = ev.load_dataset_data('bci2a')
    subj_uniq = np.unique(subjects)
    if subj_uniq.max() != len(subj_uniq) - 1:
        remap = {s: i for i, s in enumerate(subj_uniq)}
        subjects = np.array([remap[s] for s in subjects])
    n_subj = len(np.unique(subjects))

    # ---- F3: 逐被试幅度比 (9 折循环, 每折 200 样本/生成端) ----
    print('[F3] per-subject amplitude ratio sweep (9 folds) ...')
    ratios_ours = np.zeros(n_subj)
    ratios_sb = np.zeros(n_subj)
    for test_subj in range(n_subj):
        m_test = subjects == test_subj
        X_few = X[m_test][:N_FEWSHOT]
        with torch.no_grad():
            xb = torch.FloatTensor(X_few).unsqueeze(1).to(DEVICE)
            y_pl = teacher(xb).argmax(1).cpu().numpy()
        m_train = ~m_test
        X_pool, y_pool = X[m_train], y[m_train]
        set_seed()
        gX_o, _ = _gen_ours(model, cond_embed, style_enc, chart, covemb,
                            sigma0_p5, X_few, y_pl, X_pool, y_pool, 200)
        r = np.sqrt((X[m_test] ** 2).mean())
        ratios_ours[test_subj] = np.sqrt((gX_o ** 2).mean()) / r
        # SB-LDM 对照 (prior 风格, 无对齐): 同折
        set_seed()
        gX_s, _ = _gen_sbmldm(model, cond_embed, sigma0_p5, X_pool, y_pool, 200)
        ratios_sb[test_subj] = np.sqrt((gX_s ** 2).mean()) / r
        print(f'  S{test_subj + 1}: ours {ratios_ours[test_subj]:.3f} | '
              f'SB-LDM {ratios_sb[test_subj]:.3f}')

    fig, ax = plt.subplots(figsize=(8, 3.4))
    idx = np.arange(1, n_subj + 1)
    w = 0.38
    ax.bar(idx - w / 2, ratios_ours, w, color='#3498db', label='SB-SD-LDM (fused)')
    ax.bar(idx + w / 2, ratios_sb, w, color='#e67e22', label='SB-LDM (fixed-VAE)')
    ax.axhline(1.0, color='gray', ls='--', lw=1)
    ax.set_xticks(idx)
    ax.set_xticklabels([f'S{i}' for i in idx])
    ax.set_ylabel('generated / real RMS', fontsize=11)
    ax.set_ylim(0, max(1.6, ratios_sb.max() * 1.15))
    ax.legend(fontsize=10)
    ax.set_title('Per-subject amplitude fidelity (BCI2a LOSO)', fontsize=12)
    out = FIGDIR / 'fig_amplitude_ratio_bci2a.pdf'
    fig.savefig(out, dpi=200, bbox_inches='tight')
    plt.close(fig)
    print(f'[F3] saved {out}')

    # ---- F2 + F6: 被试 1 折, 生成 200/类 ----
    test_subj = 0
    m_test = subjects == test_subj
    X_few = X[m_test][:N_FEWSHOT]
    with torch.no_grad():
        xb = torch.FloatTensor(X_few).unsqueeze(1).to(DEVICE)
        y_pl = teacher(xb).argmax(1).cpu().numpy()
    m_train = ~m_test
    X_pool, y_pool = X[m_train], y[m_train]
    set_seed()
    gX, gy = _gen_ours(model, cond_embed, style_enc, chart, covemb,
                       sigma0_p5, X_few, y_pl, X_pool, y_pool, 200)
    fig_waveform(X[m_test], y[m_test], gX, gy)
    fig_psd(X[m_test], y[m_test], gX, gy)

    print('\nAll figures done ->', FIGDIR)


if __name__ == '__main__':
    main()
