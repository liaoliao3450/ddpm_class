"""
Confidence / difficulty estimation head for TC-Conf-LDM.

当前实现假设已经有预训练好的 EEGNet 分类器，
本模块只负责从 logits 计算置信度与难度标签。

提供两种难度量化:
- 基本难度 (compute_confidence_and_difficulty): diff = 1 - confidence
  仅反映目标类置信度,不区分"边界附近正确"与"边界附近错分"。
- 边界难度 (compute_margin_and_difficulty): margin = p(y_true) - max_{y!=y_true} p(y|x)
  margin 直接度量样本到决策边界的距离:
    高 margin (->1)  = 高置信度正确 = 远离边界 = Easy
    低/负 margin (->0/<0) = 不确定/错分 = 边界附近/越界 = Hard
  难度条件 q = clamp(1 - margin, 0, 1):
    margin=1   -> q=0   (最容易, 深边界内)
    margin=0.2 -> q=0.8 (边界附近, 低置信度但正确)
    margin<=0  -> q=1   (越界错分, clamp)
  此映射使 q=0.8 对应 margin≈0.2 (边界附近), 与原设计
  "q=0.8 生成决策边界附近 Hard 样本" 语义一致。
"""

from typing import Tuple

import torch
import torch.nn.functional as F


def compute_confidence_and_difficulty(
    logits: torch.Tensor,
    labels: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    根据分类 logits 计算每个样本的置信度与基本难度。

    Args:
        logits: (B, C) 分类输出
        labels: (B,) 真实标签

    Returns:
        confidence: (B,) 目标类别的置信度
        difficulty: (B,) 简单难度度量 = 1 - confidence
    """
    probs = F.softmax(logits, dim=-1)
    confidence = probs[torch.arange(probs.size(0)), labels]
    difficulty = 1.0 - confidence
    return confidence.detach(), difficulty.detach()


def compute_margin_and_difficulty(
    logits: torch.Tensor,
    labels: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    根据分类 logits 计算每个样本的 margin (边界距离) 与边界难度 q。

    margin(x) = p(y_true) - max_{y != y_true} p(y | x)  ∈ [-1, 1]
        高 margin = 远离边界 = Easy
        低/负 margin = 边界附近/越界 = Hard
    q(x) = clamp(1 - margin, 0, 1)  ∈ [0, 1]
        q=0 最易, q=1 最难 (越界错分被 clamp 到 1)

    Args:
        logits: (B, C) 分类输出
        labels: (B,) 真实标签

    Returns:
        margin: (B,) 目标类概率与次大类概率之差
        q: (B,) 边界难度, 用作 difficulty 条件
        confidence: (B,) 目标类置信度 (与 compute_confidence_and_difficulty 一致)
    """
    probs = F.softmax(logits, dim=-1)
    B = probs.size(0)
    idx = torch.arange(B, device=probs.device)
    confidence = probs[idx, labels]
    # 把目标类概率置 -inf 后取 max, 得到 max_{y != y_true} p(y|x)
    probs_masked = probs.clone()
    probs_masked[idx, labels] = -float("inf")
    max_other = probs_masked.max(dim=-1).values
    margin = confidence - max_other
    q = torch.clamp(1.0 - margin, min=0.0, max=1.0)
    return margin.detach(), q.detach(), confidence.detach()


__all__ = ["compute_confidence_and_difficulty", "compute_margin_and_difficulty"]


