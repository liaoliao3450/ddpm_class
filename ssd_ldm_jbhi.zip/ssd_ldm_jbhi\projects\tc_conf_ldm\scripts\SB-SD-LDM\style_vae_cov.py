#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
P5 v3: 协方差图表 CovChart (生成式 EA)
===============================================================
v1/v2 失败教训 (G1 ratio=1.00-1.01x):
  v1: dropout->被试锚 e_s — e_s 已含完整被试渲染信息, cov 通路零梯度
  v2: dropout->中性锚 e_mean + L_cov — e_mean 是 decoder 分布外风格点
      (decode(z,e_mean) 渲染 ~100x 幅度垃圾), 且 recon/L_cov 梯度在共享
      adapter 上冲突 (recon 0.005->0.34, cov 卡在 rel-Frob^2~2.5)

v3 设计 (解耦):
  CovChart g: cov_embed -> 风格空间 的映射图, 独立于 P4 recon 训练.
    g(cov) = [cov,1] @ A_ls + MLP(cov)
    A_ls = 最小二乘锚点拟合 (cov_t -> e_t), 初始精确过 9 锚点 (全分布内)
    MLP 末层零初始化 (初始 g = 线性锚点图)
  损失:
    L_reg = ||g(cov_t) - e_t||^2          锚点图表 (主监督, lambda 1.0)
    L_cov = relFrob^2(R_gen, R_t)         协方差匹配精修 (lambda 1.0)
      R_gen = batch 协方差 of decode(mu_z, g(cov_t+jitter))
      内容 mu_z 混合 (P2 已被试不变) -> R_gen 只由 cov 条件决定
  P4 recon 通路完全不动 (D1 恒 100%).

生成模式 (评估时):
  cov_only : style = g(cov_test)                      纯生成式 EA
  full     : style = mu_s_fewshot + (g(cov_test) - g_center)
             g_center = 训练锚点均值 (位移方向 = 锚点差方向, decoder 可响应)
  orth_only: style = mu_s_fewshot (P4 复刻)
  prior    : style = e_i + sigma0*eps (P4 prior 复刻)

POC 泄漏声明: CovEmbedding PCA 基在全部 9 被试 R_s 上拟合
  (与 P2 见过全部被试同口径); 严格 LOSO 需 per-fold 重拟合.
"""
import torch
import torch.nn as nn
import numpy as np

import sys
from pathlib import Path

_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from diag_style_cov_cca import subject_covariances, logm_sym


# ============================================================
# 协方差嵌入 (确定性)
# ============================================================

class CovEmbedding:
    """subject 级通道协方差 -> 低维嵌入.

    feat(R) = logm(R)[triu]  (22x22 -> 253d, log-Euclid 特征)
    embed(R) = PCA_k(feat(R) - mean)   (k 默认 8 = n_subjects-1)
    """

    def __init__(self, k: int = 8):
        self.k = k
        self.mean = None      # (D,) np
        self.basis = None     # (k, D) np
        self.dim = None       # D = C(C+1)/2

    @staticmethod
    def feat(R: np.ndarray) -> np.ndarray:
        C = R.shape[0]
        return logm_sym(R)[np.triu_indices(C)]

    def fit(self, R_list):
        F = np.stack([self.feat(R) for R in R_list])       # (S, D)
        self.dim = F.shape[1]
        self.mean = F.mean(axis=0)
        Fc = F - self.mean
        U, S, Vt = np.linalg.svd(Fc, full_matrices=False)
        k = min(self.k, Vt.shape[0])
        self.basis = Vt[:k]                                  # (k, D)
        self.k = k
        ev = (S ** 2) / max((S ** 2).sum(), 1e-12)
        self.explained_ratio = float(ev[:k].sum())
        return self

    def embed(self, R: np.ndarray) -> np.ndarray:
        f = self.feat(R) - self.mean
        return (self.basis @ f).astype(np.float32)           # (k,)

    def to_dict(self):
        return {'k': self.k, 'dim': self.dim,
                'mean': torch.from_numpy(self.mean).float(),
                'basis': torch.from_numpy(self.basis).float(),
                'explained_ratio': getattr(self, 'explained_ratio', None)}

    @classmethod
    def from_dict(cls, d):
        obj = cls(k=int(d['k']))
        obj.dim = int(d['dim'])
        obj.mean = d['mean'].cpu().numpy()
        obj.basis = d['basis'].cpu().numpy()
        obj.explained_ratio = d.get('explained_ratio')
        return obj


def compute_subject_R(X_subj: np.ndarray) -> np.ndarray:
    """R_s = mean_i x_i x_i^T / T (trial 不中心化, 与 EA/诊断脚本同口径)."""
    return subject_covariances(X_subj)


# ============================================================
# 协方差图表 (P5 v3 唯一可训练模块)
# ============================================================

class CovChart(nn.Module):
    """cov_embed -> 风格空间 映射图 (生成式 EA 的核心).

    g(cov) = [cov, 1] @ A + MLP(cov)
      A: (k+1, 32) 最小二乘锚点拟合, 冻结 (初始 = 线性锚点图)
      MLP: 残差精修, 末层零初始化
    初始时 g(cov_t) = e_t 精确过锚点 (decoder 分布内), L_cov 只做精修.
    """

    def __init__(self, cov_lookup: np.ndarray, W_subj: np.ndarray,
                 hidden: int = 64):
        super().__init__()
        k = cov_lookup.shape[1]
        # 增广最小二乘: [cov, 1] @ A ~= W_subj
        X_aug = np.concatenate([cov_lookup, np.ones((len(cov_lookup), 1))], axis=1)
        A, *_ = np.linalg.lstsq(X_aug, W_subj, rcond=None)   # (k+1, 32)
        self.register_buffer('A', torch.FloatTensor(A).float())
        self.mlp = nn.Sequential(
            nn.Linear(k, hidden), nn.SiLU(), nn.Linear(hidden, W_subj.shape[1]))
        nn.init.zeros_(self.mlp[-1].weight)
        nn.init.zeros_(self.mlp[-1].bias)
        self.k = k
        self.subj_dim = W_subj.shape[1]

    def forward(self, cov: torch.Tensor) -> torch.Tensor:
        """cov: (B, k) -> style: (B, subj_dim)."""
        one = torch.ones(cov.size(0), 1, device=cov.device)
        lin = torch.cat([cov, one], dim=1) @ self.A
        return lin + self.mlp(cov)


# ============================================================
# 保存 / 加载
# ============================================================

def save_p5(path, chart: CovChart, covemb: CovEmbedding,
            sigma0: float, meta: dict = None):
    torch.save({
        'chart_state_dict': chart.state_dict(),
        'cov_embedding': covemb.to_dict(),
        'sigma0': sigma0,
        'subj_dim': chart.subj_dim,
        'cov_dim': chart.k,
        'meta': meta or {},
    }, path)


def load_p5(path, device=torch.device('cpu')):
    ckpt = torch.load(str(path), map_location=device, weights_only=False)
    covemb = CovEmbedding.from_dict(ckpt['cov_embedding'])
    # 重建需要 cov_lookup/W_subj 形状 — 从 state_dict 推断
    A = ckpt['chart_state_dict']['A']                       # (k+1, subj_dim)
    k, subj_dim = A.shape[0] - 1, A.shape[1]
    chart = CovChart.__new__(CovChart)
    nn.Module.__init__(chart)
    chart.k, chart.subj_dim = k, subj_dim
    chart.mlp = nn.Sequential(
        nn.Linear(k, 64), nn.SiLU(), nn.Linear(64, subj_dim))
    chart.register_buffer('A', torch.zeros(k + 1, subj_dim))
    chart = chart.to(device)
    chart.load_state_dict(ckpt['chart_state_dict'])
    chart.eval()
    sigma0 = float(ckpt.get('sigma0', 0.5))
    return chart, covemb, sigma0
