"""
PhysioNet Motor Movement/Imagery Dataset (MI) - 四分类版本预处理脚本
参考: f:\DTTD-DDPM\data\physionet_mi.py

数据集包含109个被试的EEG数据，使用四分类运动想象任务：
- runs {4, 8, 12}: T1=左手, T2=右手
- runs {6, 10, 14}: T1=双拳, T2=双脚

数据采样率：160 Hz
通道数：64通道（基于10-10系统）

标签映射:
    0 = left hand
    1 = right hand
    2 = both fists
    3 = both feet
"""

import os
import json
import argparse
import numpy as np
import mne

# 四分类MI使用的runs
MI4C_RUNS = {4, 6, 8, 10, 12, 14}
MAX_SUBJECT_ID = 109

# 64通道名称（基于10-10系统）
CHANNEL_NAMES_64 = [
    'Fp1', 'Fpz', 'Fp2', 'AF7', 'AF3', 'AFz', 'AF4', 'AF8',
    'F7', 'F5', 'F3', 'F1', 'Fz', 'F2', 'F4', 'F6', 'F8',
    'FT7', 'FC5', 'FC3', 'FC1', 'FCz', 'FC2', 'FC4', 'FC6', 'FT8',
    'T7', 'C5', 'C3', 'C1', 'Cz', 'C2', 'C4', 'C6', 'T8',
    'TP7', 'CP5', 'CP3', 'CP1', 'CPz', 'CP2', 'CP4', 'CP6', 'TP8',
    'P7', 'P5', 'P3', 'P1', 'Pz', 'P2', 'P4', 'P6', 'P8',
    'PO7', 'PO3', 'POz', 'PO4', 'PO8',
    'O1', 'Oz', 'O2'
]


def parse_subject_run_from_name(filename: str):
    """从文件名解析被试和run号"""
    basename = os.path.basename(filename)
    subject = basename[:4]  # 'S001'
    run_str = basename[4:7]  # 'R01'
    run = int(run_str[1:])  # 1
    return subject, run


def load_physionet_events(raw, edf_path: str):
    """加载PhysioNet事件"""
    event_pairs = []
    
    # 方法1: 使用 mne.events_from_annotations
    try:
        events, event_id = mne.events_from_annotations(raw, verbose=False)
        desc_map = {1: 'T0', 2: 'T1', 3: 'T2', 4: 'T3', 5: 'T4',
                   768: 'START', 769: 'T0', 770: 'T1', 771: 'T2', 
                   772: 'T3', 773: 'T4'}
        
        for event in events:
            onset = event[0]
            code = event[2]
            desc = None
            for key, value in event_id.items():
                if value == code:
                    desc = key
                    break
            if desc is None:
                desc = desc_map.get(code, f'UNKNOWN_{code}')
            event_pairs.append((onset, desc))
        
        if len(event_pairs) > 0:
            return event_pairs
    except Exception as e:
        print(f"方法1失败: {e}")
    
    # 方法3: 尝试另一种注释访问方式
    try:
        onsets = raw.annotations.onset
        descriptions = raw.annotations.description
        sfreq = raw.info['sfreq']
        
        for onset, desc in zip(onsets, descriptions):
            onset_samples = int(onset * sfreq)
            event_pairs.append((onset_samples, desc))
        
        if len(event_pairs) > 0:
            return event_pairs
    except Exception as e:
        print(f"方法3失败: {e}")
    
    print(f"警告: 无法从 {edf_path} 读取事件")
    return event_pairs


def map_run_desc_to_label(run: int, desc: str) -> int:
    """根据run号和描述映射标签"""
    if run in {4, 8, 12}:
        if desc == "T1":
            return 0  # left hand
        if desc == "T2":
            return 1  # right hand
    elif run in {6, 10, 14}:
        if desc == "T1":
            return 2  # both fists
        if desc == "T2":
            return 3  # both feet
    return None


def apply_preprocessing(raw, fs=160, l_freq=4.0, h_freq=30.0, notch_freq=50.0):
    """应用预处理（重采样、滤波、CAR等）"""
    target_sfreq = fs
    if raw.info['sfreq'] != target_sfreq:
        raw.resample(target_sfreq, verbose=False)
    
    if notch_freq is not None:
        raw.notch_filter(notch_freq, verbose=False)
    
    raw.filter(l_freq, h_freq, fir_design='firwin', verbose=False)
    
    raw.set_eeg_reference('average', verbose=False)
    
    return raw


def extract_trials_from_edf(edf_path, fs=160, tmin=0.0, tmax=4.0):
    """从EDF文件提取四分类运动想象trials"""
    subject, run = parse_subject_run_from_name(os.path.basename(edf_path))
    
    raw = mne.io.read_raw_edf(edf_path, preload=True, verbose="ERROR")
    
    eeg_picks = mne.pick_types(raw.info, eeg=True, stim=False, eog=False, exclude="bads")
    raw.pick(eeg_picks)
    
    edf_ch_names = [ch.upper() for ch in raw.ch_names]
    reorder_idx = []
    for std_ch in CHANNEL_NAMES_64:
        std_upper = std_ch.upper()
        if std_upper in edf_ch_names:
            reorder_idx.append(edf_ch_names.index(std_upper))
    if len(reorder_idx) == len(raw.ch_names):
        raw.reorder_channels([raw.ch_names[i] for i in reorder_idx])
    
    raw = apply_preprocessing(raw, fs=fs)
    
    event_pairs = load_physionet_events(raw, edf_path)
    
    trial_segments = []
    trial_labels = []
    sfreq = raw.info["sfreq"]
    start_offset = int(round(tmin * sfreq))
    end_offset = int(round(tmax * sfreq))
    data = raw.get_data().astype(np.float32, copy=False)
    
    for onset, desc in event_pairs:
        if desc not in {"T1", "T2"}:
            continue
        
        label = map_run_desc_to_label(run, desc)
        if label is None:
            continue
        
        start = int(onset) + start_offset
        stop = int(onset) + end_offset
        
        if start < 0 or stop > data.shape[1] or stop <= start:
            continue
        
        seg = data[:, start:stop]
        if seg.shape[1] != (end_offset - start_offset):
            continue
        
        trial_segments.append(seg)
        trial_labels.append(label)
    
    if not trial_segments:
        return np.array([]), np.array([])
    
    X = np.stack(trial_segments, axis=0).astype(np.float32, copy=False)
    y = np.array(trial_labels, dtype=np.int64)
    return X, y


def load_single_subject(subject_id, data_path, runs=MI4C_RUNS, fs=160, tmin=0.0, tmax=4.0):
    """加载单个被试的数据"""
    subject_str = f'S{subject_id:03d}'
    data_dir = os.path.join(data_path, subject_str)
    
    if not os.path.exists(data_dir):
        raise FileNotFoundError(f"被试{subject_id}的数据目录不存在: {data_dir}")
    
    edf_files = []
    for f in os.listdir(data_dir):
        if f.lower().endswith('.edf'):
            try:
                _, run = parse_subject_run_from_name(f)
                if run in runs:
                    edf_files.append(os.path.join(data_dir, f))
            except Exception:
                continue
    
    if not edf_files:
        raise FileNotFoundError(f"被试{subject_id}未找到EDF文件（runs: {runs}）")
    
    edf_files.sort()
    
    all_data = []
    all_labels = []
    all_meta = []
    
    for edf_file in edf_files:
        _, run = parse_subject_run_from_name(os.path.basename(edf_file))
        X, y = extract_trials_from_edf(edf_file, fs=fs, tmin=tmin, tmax=tmax)
        if len(X) > 0:
            all_data.append(X)
            all_labels.append(y)
            for j in range(len(y)):
                all_meta.append({
                    "subject": subject_id,
                    "run": run,
                    "label": int(y[j]),
                })
            print(f"  {os.path.basename(edf_file)}: {len(X)} trials")
    
    if not all_data:
        return np.array([]), np.array([]), []
    
    return np.concatenate(all_data, axis=0), np.concatenate(all_labels, axis=0), all_meta


def process_physionet_mi4c_dataset(data_dir, output_dir, subject_ids=None, 
                                   fs=160, tmin=0.0, tmax=4.0):
    """处理PhysioNet MI4C数据集"""
    if not os.path.exists(data_dir):
        raise FileNotFoundError(f"数据目录不存在: {data_dir}")
    
    os.makedirs(output_dir, exist_ok=True)
    
    if subject_ids is None:
        subject_ids = list(range(1, MAX_SUBJECT_ID + 1))
    
    all_X = []
    all_y = []
    all_meta = []
    
    for sid in subject_ids:
        try:
            print(f"\n处理被试 {sid}...")
            X, y, meta = load_single_subject(sid, data_dir, fs=fs, tmin=tmin, tmax=tmax)
            if len(X) > 0:
                print(f"  处理后: X={X.shape}, y={y.shape}, classes={np.unique(y).tolist()}")
                
                all_X.append(X)
                all_y.append(y)
                all_meta.extend(meta)
            else:
                print(f"  警告: 被试 {sid} 没有有效数据")
        except Exception as e:
            print(f"  错误: 处理被试 {sid} 失败: {e}")
            continue
    
    if not all_X:
        raise RuntimeError("未成功处理任何数据")
    
    total_samples = sum([x.shape[0] for x in all_X])
    n_channels = all_X[0].shape[1]
    n_times = all_X[0].shape[2]
    
    X = np.concatenate(all_X, axis=0)
    y = np.concatenate(all_y, axis=0)
    
    # 全局归一化（按通道）
    data_mean = X.mean(axis=(0, 2), keepdims=True)
    data_std = X.std(axis=(0, 2), keepdims=True)
    X = (X - data_mean) / data_std
    
    class_counts = np.bincount(y)
    
    np.save(os.path.join(output_dir, "X.npy"), X.astype(np.float32))
    np.save(os.path.join(output_dir, "y.npy"), y.astype(np.int64))
    
    with open(os.path.join(output_dir, "meta.json"), "w", encoding="utf-8") as f:
        json.dump(all_meta, f, indent=2, ensure_ascii=False)
    
    print("\n" + "=" * 70)
    print("PhysioNet MI4C Dataset 预处理完成!")
    print(f"总样本数: X=({total_samples}, {n_channels}, {n_times}), y=({total_samples},)")
    print(f"类别分布: {class_counts}")
    print(f"数据均值范围: [{data_mean.min():.6f}, {data_mean.max():.6f}]")
    print(f"数据标准差范围: [{data_std.min():.6f}, {data_std.max():.6f}]")
    print("=" * 70)


def main():
    parser = argparse.ArgumentParser(description="PhysioNet MI4C Dataset 预处理")
    parser.add_argument("--data_dir", type=str, required=True, help="原始数据目录")
    parser.add_argument("--output_dir", type=str, default="data/processed/PhysioNetMI4C", help="输出目录")
    parser.add_argument("--fs", type=float, default=160.0, help="目标采样率")
    parser.add_argument("--tmin", type=float, default=0.0, help="起始时间")
    parser.add_argument("--tmax", type=float, default=4.0, help="结束时间")
    args = parser.parse_args()
    
    print("=" * 70)
    print("PhysioNet MI4C Dataset 预处理")
    print("=" * 70)
    print(f"输入目录: {args.data_dir}")
    print(f"输出目录: {args.output_dir}")
    print(f"目标采样率: {args.fs}Hz")
    print(f"时间窗口: {args.tmin}s - {args.tmax}s")
    
    process_physionet_mi4c_dataset(args.data_dir, args.output_dir, 
                                   fs=args.fs, tmin=args.tmin, tmax=args.tmax)


if __name__ == "__main__":
    main()