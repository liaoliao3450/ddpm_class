#!/usr/bin/env python3
from __future__ import annotations
"""
SB-LDM 消融实验脚本 — BCI2a 跨会话场景

训练 5 个变体 (full + 4 个消融) 并评估跨会话精度 (session 0 → session 1):
  - full:          完整 SB-LDM
  - no_erd:        lambda_erd=0 (移除 ERD 正则化)
  - no_distill:    lambda_feat=lambda_logit=lambda_conf=0 (移除 EEGNet 蒸馏)
  - no_latentcls:  lambda_cls=0 (移除潜空间分类头)
  - no_shared:     VAE 与 UNet 使用独立骨干 (移除共享骨干)

每个变体:
  - BCI2a 训练 300 epochs
  - checkpoint → checkpoints/tc_conf_ldm/ablation_{variant_name}/
  - 跨会话评估: 每个被试 session 0 训练 + 生成增强, session 1 测试
  - N_ENSEMBLE=3, CLASSIFIER_EPOCHS=200, DDIM_STEPS=50, GUIDANCE_SCALE=2.0, GEN_RATIO=1.0

Usage:
    # 训练 + 评估单个变体
    python projects/tc_conf_ldm/scripts/ablation_sb_ldm.py --variant no_erd
    # 训练 + 评估所有变体 (顺序)
    python projects/tc_conf_ldm/scripts/ablation_sb_ldm.py --all
    # 仅评估 (已有 checkpoint)
    python projects/tc_conf_ldm/scripts/ablation_sb_ldm.py --variant no_erd --eval-only
    # 仅打印已有结果汇总
    python projects/tc_conf_ldm/scripts/ablation_sb_ldm.py --summary
"""
import sys
import re
import json
import random
import argparse
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import accuracy_score, cohen_kappa_score

# ============================================================================
# 路径设置
# ============================================================================
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# 将 scripts 目录加入路径以便导入同级脚本中的工具函数
SCRIPTS_DIR = Path(__file__).resolve().parent
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

from core.classifiers.eegnet import EEGNet
from core.models.latent_diffusion.model_shared import (
    SharedBackboneConfig,
    SharedVAEUNetLDM1D,
    SharedBlockBank,
)

# 复用训练脚本的数据加载 / teacher 加载 / 配置
from train_sb_ldm import (
    load_config,
    load_dataset,
    load_teacher,
    DATASET_CONFIG as TRAIN_DATASET_CONFIG,
)

# 复用评估脚本的生成 / 分类 / 归一化 工具
from evaluate_sb_ldm_3datasets import (
    set_seed,
    load_dataset_data,
    normalize_to_real_stats,
    train_classifier,
    predict,
    generate_sb_ldm,
    DDIM_STEPS,
    GUIDANCE_SCALE,
    GEN_RATIO,
    N_ENSEMBLE,
    CLASSIFIER_EPOCHS,
)

# ============================================================================
# 全局常量
# ============================================================================
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
SEED = 42
NUM_EPOCHS = 300
DATASET = "bci2a"

RESULTS_DIR = PROJECT_ROOT / "outputs" / "results"
MERGED_RESULTS_PATH = RESULTS_DIR / "ablation_bci2a.json"
MERGED_RESULTS_MULTI_SEED_PATH = RESULTS_DIR / "ablation_bci2a_multiseed.json"


# ============================================================================
# NonSharedVAEUNetLDM1D — VAE 与 UNet 使用独立骨干
# ============================================================================

class NonSharedVAEUNetLDM1D(SharedVAEUNetLDM1D):
    """
    非共享骨干版本: VAE 的 bank (self.bank) 与 UNet 的 bank (self.unet_bank) 相互独立。

    继承 SharedVAEUNetLDM1D 的全部接口 (encode / decode / forward / sample)，
    仅重写 denoise_eps 使其使用独立的 unet_bank 而非共享的 self.bank。
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 为 UNet 创建独立的 SharedBlockBank (参数与 VAE bank 完全分离)
        backbone_cfg = kwargs.get("backbone", SharedBackboneConfig())
        self.unet_bank = SharedBlockBank(backbone_cfg, emb_dim=self.t_dim)

    def denoise_eps(self, z_t, t, cond=None, subject_id=None):
        """使用独立 UNet bank 进行去噪 (与 VAE bank 分离)。"""
        B, device = z_t.size(0), z_t.device
        emb = self._make_emb(t=t, cond=cond, batch=B, device=device)

        h = self.d_stem(z_t)
        for blk in self.unet_bank.mid_blocks:
            h = blk(h, emb)

        skips = []
        cur = h
        for lvl, down in enumerate(self.d_down):
            for blk in self.unet_bank.dec_blocks[lvl]:
                cur = blk(cur, emb)
            skips.append(cur)
            cur = down(cur)

        for lvl, up in enumerate(self.d_up):
            cur = up(cur)
            skip = skips.pop()
            if cur.size(-1) != skip.size(-1):
                cur = F.interpolate(
                    cur, size=skip.size(-1), mode="linear", align_corners=False
                )
            cur = cur + skip
            shared_lvl = lvl + 1
            for blk in self.unet_bank.enc_blocks[shared_lvl]:
                cur = blk(cur, emb)

        return self.eps_out(cur)


# ============================================================================
# 消融变体定义
# ============================================================================
# None 表示使用 YAML 配置中的默认值; 0.0 表示显式禁用该损失项
VARIANTS = {
    "full": {
        "lambda_erd": None,
        "lambda_feat": None,
        "lambda_logit": None,
        "lambda_conf": None,
        "lambda_cls": None,
        "shared": True,
    },
    "no_erd": {
        "lambda_erd": 0.0,
        "lambda_feat": None,
        "lambda_logit": None,
        "lambda_conf": None,
        "lambda_cls": None,
        "shared": True,
    },
    "no_distill": {
        "lambda_erd": None,
        "lambda_feat": 0.0,
        "lambda_logit": 0.0,
        "lambda_conf": 0.0,
        "lambda_cls": None,
        "shared": True,
    },
    "no_latentcls": {
        "lambda_erd": None,
        "lambda_feat": None,
        "lambda_logit": None,
        "lambda_conf": None,
        "lambda_cls": 0.0,
        "shared": True,
    },
    "no_shared": {
        "lambda_erd": None,
        "lambda_feat": None,
        "lambda_logit": None,
        "lambda_conf": None,
        "lambda_cls": None,
        "shared": False,
    },
}


# ============================================================================
# Checkpoint 辅助
# ============================================================================

def get_ckpt_dir(variant_name: str, seed: int = SEED) -> Path:
    # full 模型直接复用原始 SB-LDM checkpoint (500 epochs, 与三场景实验一致)
    if variant_name == "full":
        return PROJECT_ROOT / "checkpoints" / "tc_conf_ldm" / "sb_ldm_bci2a"
    return PROJECT_ROOT / "checkpoints" / "tc_conf_ldm" / f"ablation_{variant_name}_s{seed}"


def _extract_epoch(path: Path) -> int:
    m = re.search(r"epoch_(\d+)\.pt$", path.name)
    return int(m.group(1)) if m else -1


def get_latest_ckpt(variant_name: str, seed: int = SEED) -> Path | None:
    """返回变体最新的 checkpoint 路径, 不存在则返回 None。"""
    ckpt_dir = get_ckpt_dir(variant_name, seed)
    if not ckpt_dir.exists():
        return None
    cands = sorted(ckpt_dir.glob("sb_ldm_epoch_*.pt"), key=_extract_epoch)
    return cands[-1] if cands else None


# ============================================================================
# 训练
# ============================================================================

def train_variant(variant_name: str, num_epochs: int = NUM_EPOCHS,
                  batch_size: int = 64, lr: float = 1e-4, seed: int = SEED):
    """训练单个消融变体。"""
    var_cfg = VARIANTS[variant_name]
    cfg = TRAIN_DATASET_CONFIG[DATASET]
    yaml_cfg = load_config(cfg["yaml"])
    model_cfg = yaml_cfg.get("model", {})

    print("=" * 70)
    print(f"SB-LDM 消融训练: {variant_name} (seed={seed})")
    print(f"  shared={var_cfg['shared']}")
    print(f"  lambda_erd={var_cfg['lambda_erd']}, lambda_feat={var_cfg['lambda_feat']}, "
          f"lambda_logit={var_cfg['lambda_logit']}")
    print(f"  lambda_conf={var_cfg['lambda_conf']}, lambda_cls={var_cfg['lambda_cls']}")
    print(f"  epochs={num_epochs}, device={DEVICE}")
    print("=" * 70)

    set_seed(seed)

    # --- 1. 数据 ---
    X_train, y_train, subjects_train = load_dataset(DATASET)
    channels = cfg["channels"]
    input_length = cfg["input_length"]
    num_classes = cfg["num_classes"]
    fs = cfg["fs"]

    X_t = torch.FloatTensor(X_train)
    y_t = torch.LongTensor(y_train)
    subj_t = torch.LongTensor(subjects_train)
    ds = torch.utils.data.TensorDataset(X_t, y_t, subj_t)
    loader = torch.utils.data.DataLoader(
        ds, batch_size=batch_size, shuffle=True, num_workers=0, drop_last=False
    )

    # --- 2. 条件嵌入 (仅类别条件化) ---
    cond_dim = int(model_cfg.get("cond_embed_dim", 64))
    cond_embed = torch.nn.Embedding(num_classes, cond_dim).to(DEVICE)

    # --- 3. 模型 (shared / non-shared) ---
    backbone = SharedBackboneConfig(
        base=int(model_cfg.get("backbone_base", 64)),
        levels=tuple(int(x) for x in model_cfg.get("backbone_levels", [1, 2, 4])),
        blocks_per_level=int(model_cfg.get("backbone_blocks_per_level", 2)),
    )
    model_cls = NonSharedVAEUNetLDM1D if not var_cfg["shared"] else SharedVAEUNetLDM1D
    model = model_cls(
        channels=channels,
        input_length=input_length,
        z_channels=int(model_cfg.get("z_channels", 64)),
        timesteps=int(model_cfg.get("timesteps", 1000)),
        t_dim=int(model_cfg.get("t_dim", 128)),
        cond_dim=cond_dim,
        backbone=backbone,
        num_subjects=cfg["num_subjects"],
        adv_alpha=0.0,
    ).to(DEVICE)
    print(f"\n模型参数: {sum(p.numel() for p in model.parameters()):,}")

    # --- 4. 潜空间分类头 ---
    with torch.no_grad():
        dummy_x = torch.zeros(1, channels, input_length, device=DEVICE)
        dummy_cond = torch.zeros(1, cond_dim, device=DEVICE)
        z_dummy, _, _ = model.encode(dummy_x, cond=dummy_cond)
        latent_dim = z_dummy.shape[1] * z_dummy.shape[2]
    classifier_head = torch.nn.Linear(latent_dim, num_classes).to(DEVICE)

    # --- 5. Teacher ---
    teacher = load_teacher(DATASET, channels, input_length, num_classes)

    # --- 6. 损失权重 (None → 配置默认值) ---
    beta_kl_base = float(model_cfg.get("beta_kl", 1e-3))
    lambda_cls = (
        var_cfg["lambda_cls"]
        if var_cfg["lambda_cls"] is not None
        else float(model_cfg.get("lambda_cls", 1.0))
    )
    lambda_feat = (
        var_cfg["lambda_feat"]
        if var_cfg["lambda_feat"] is not None
        else float(model_cfg.get("lambda_feat", 0.4))
    )
    lambda_logit_base = (
        var_cfg["lambda_logit"]
        if var_cfg["lambda_logit"] is not None
        else float(model_cfg.get("lambda_logit", 0.8))
    )
    lambda_conf = (
        var_cfg["lambda_conf"]
        if var_cfg["lambda_conf"] is not None
        else float(model_cfg.get("lambda_conf", 0.15))
    )
    lambda_erd = (
        var_cfg["lambda_erd"]
        if var_cfg["lambda_erd"] is not None
        else float(model_cfg.get("lambda_erd", 2.0))
    )

    c3, c4 = cfg["erd_c3"], cfg["erd_c4"]

    # --- 7. 优化器 ---
    optim = torch.optim.AdamW(
        list(model.parameters())
        + list(cond_embed.parameters())
        + list(classifier_head.parameters()),
        lr=lr,
        weight_decay=1e-5,
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optim, T_max=num_epochs, eta_min=1e-6
    )

    # --- 8. Checkpoint 目录 ---
    ckpt_dir = get_ckpt_dir(variant_name, seed)
    ckpt_dir.mkdir(parents=True, exist_ok=True)

    # --- 9. 训练循环 ---
    print(f"\n开始训练 ({num_epochs} epochs)...")
    print("-" * 70)

    for epoch in range(1, num_epochs + 1):
        model.train()
        cond_embed.train()
        classifier_head.train()

        ep_loss = ep_eps = ep_kl = ep_cls = ep_recon = 0.0
        ep_feat = ep_logit = ep_conf = ep_erd = 0.0

        for X_batch, y_batch, subj_batch in loader:
            X_batch = X_batch.to(DEVICE)
            y_batch = y_batch.to(DEVICE)
            subj_batch = subj_batch.to(DEVICE)
            B = X_batch.size(0)

            cond = cond_embed(y_batch)
            t = torch.randint(0, int(model.timesteps), (B,), device=DEVICE, dtype=torch.long)
            eps_pred, noise, mu, logvar, _ = model(X_batch, t, cond=cond, subject_id=subj_batch)

            # 1. Diffusion loss
            loss_eps = F.mse_loss(eps_pred, noise)

            # 2. KL loss
            logvar_clamped = torch.clamp(logvar, min=-10, max=10)
            kl_per = -0.5 * (1 + logvar_clamped - mu.pow(2) - logvar_clamped.exp())
            kl_loss = torch.mean(kl_per)

            # 3. Reconstruction (仅早期)
            x_recon = model.decode(mu, target_length=X_batch.shape[-1], cond=cond)
            loss_recon = F.mse_loss(x_recon, X_batch)
            if epoch <= num_epochs * 0.2:
                loss_recon_w = 0.1 * (1 - epoch / (num_epochs * 0.2))
            else:
                loss_recon_w = 0.0

            # 4. Latent classification
            z0_flat = mu.view(B, -1)
            loss_cls = F.cross_entropy(classifier_head(z0_flat), y_batch)

            # 5. Teacher distillation (feat + logit + conf)
            X_real_t = X_batch.unsqueeze(1)
            X_recon_t = x_recon.unsqueeze(1)
            with torch.no_grad():
                feat_real = teacher._forward_features(X_real_t)
                logits_real = teacher(X_real_t)
            feat_recon = teacher._forward_features(X_recon_t)
            logits_recon = teacher(X_recon_t)

            loss_feat = F.mse_loss(feat_recon, feat_real)
            loss_logit = F.cross_entropy(logits_recon, y_batch)
            prob_real = F.softmax(logits_real, dim=1)
            prob_recon = F.softmax(logits_recon, dim=1)
            loss_conf = F.kl_div(prob_recon.log(), prob_real, reduction="batchmean")

            # 6. ERD regularization
            loss_erd = torch.tensor(0.0, device=DEVICE)
            if lambda_erd > 0 and epoch > int(num_epochs * 0.1):
                eps_fft = 1e-8

                def band_power(x_sig, low, high):
                    T_len = x_sig.shape[-1]
                    freqs = torch.fft.rfftfreq(T_len, d=1.0 / fs).to(x_sig.device)
                    spec = torch.fft.rfft(x_sig, dim=-1).abs().pow(2)
                    mask = (freqs >= low) & (freqs <= high)
                    return spec[..., mask].mean(dim=-1).clamp(min=eps_fft)

                mu_recon = band_power(x_recon, 8, 13)
                beta_recon = band_power(x_recon, 13, 30)
                mu_real = band_power(X_batch, 8, 13).detach()
                beta_real = band_power(X_batch, 13, 30).detach()

                lat_mu_recon = (mu_recon[:, c4] - mu_recon[:, c3]) / (mu_recon[:, c4] + mu_recon[:, c3] + eps_fft)
                lat_mu_real = (mu_real[:, c4] - mu_real[:, c3]) / (mu_real[:, c4] + mu_real[:, c3] + eps_fft)
                lat_beta_recon = (beta_recon[:, c4] - beta_recon[:, c3]) / (beta_recon[:, c4] + beta_recon[:, c3] + eps_fft)
                lat_beta_real = (beta_real[:, c4] - beta_real[:, c3]) / (beta_real[:, c4] + beta_real[:, c3] + eps_fft)

                loss_erd = F.mse_loss(lat_mu_recon, lat_mu_real) + F.mse_loss(lat_beta_recon, lat_beta_real)

            # KL anneal
            if epoch <= num_epochs * 0.2:
                kl_w = (epoch / (num_epochs * 0.2)) * 0.3
            elif epoch <= num_epochs * 0.5:
                kl_w = 0.3 + ((epoch - num_epochs * 0.2) / (num_epochs * 0.3)) * 0.4
            elif epoch <= num_epochs * 0.8:
                kl_w = 0.7 + ((epoch - num_epochs * 0.5) / (num_epochs * 0.3)) * 0.3
            else:
                kl_w = 1.0

            beta_kl = beta_kl_base * kl_w
            lambda_logit = lambda_logit_base * (1.0 + epoch / num_epochs)

            # Total loss
            loss = (
                loss_eps
                + beta_kl * kl_loss
                + lambda_cls * loss_cls
                + loss_recon_w * loss_recon
                + lambda_feat * loss_feat
                + lambda_logit * loss_logit
                + lambda_conf * loss_conf
                + lambda_erd * loss_erd
            )

            optim.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                list(model.parameters()) + list(cond_embed.parameters()), 1.0
            )
            optim.step()

            bs = float(B)
            ep_loss += loss.item() * bs
            ep_eps += loss_eps.item() * bs
            ep_kl += kl_loss.item() * bs
            ep_cls += loss_cls.item() * bs
            ep_recon += loss_recon.item() * bs
            ep_feat += loss_feat.item() * bs
            ep_logit += loss_logit.item() * bs
            ep_conf += loss_conf.item() * bs
            ep_erd += loss_erd.item() * bs

        n = float(len(ds))
        ep_loss /= n; ep_eps /= n; ep_kl /= n; ep_cls /= n; ep_recon /= n
        ep_feat /= n; ep_logit /= n; ep_conf /= n; ep_erd /= n

        scheduler.step()
        lr_now = scheduler.get_last_lr()[0]

        if epoch % 10 == 0 or epoch == 1:
            print(
                f"[Ep {epoch:3d}/{num_epochs}] "
                f"Loss:{ep_loss:.4f} | Diff:{ep_eps:.4f} | KL:{ep_kl:.4f}(w:{beta_kl:.1e}) | "
                f"Cls:{ep_cls:.4f} | Recon:{ep_recon:.4f} | Feat:{ep_feat:.4f} | "
                f"Logit:{ep_logit:.4f} | Conf:{ep_conf:.4f} | ERD:{ep_erd:.4f} | LR:{lr_now:.1e}"
            )

        if epoch % 50 == 0 or epoch == num_epochs:
            ckpt_path = ckpt_dir / f"sb_ldm_epoch_{epoch}.pt"
            torch.save(
                {
                    "epoch": epoch,
                    "config": yaml_cfg,
                    "variant_name": variant_name,
                    "variant_config": var_cfg,
                    "model_state_dict": model.state_dict(),
                    "cond_embed_state_dict": cond_embed.state_dict(),
                    "classifier_head_state_dict": classifier_head.state_dict(),
                },
                ckpt_path,
            )
            print(f"  保存: {ckpt_path}")

    print(f"\n变体 {variant_name} 训练完成")


# ============================================================================
# 模型加载 (评估用)
# ============================================================================

def load_ablation_model(variant_name: str, device=DEVICE, seed: int = SEED):
    """加载指定变体的最新 checkpoint, 返回 (model, cond_embed)。"""
    var_cfg = VARIANTS[variant_name]
    ckpt_path = get_latest_ckpt(variant_name, seed)
    if ckpt_path is None:
        raise FileNotFoundError(
            f"未找到变体 {variant_name} (seed={seed}) 的 checkpoint, 请先训练: "
            f"python ablation_sb_ldm.py --variant {variant_name} --seed {seed}"
        )

    print(f"加载 checkpoint: {ckpt_path}")
    checkpoint = torch.load(str(ckpt_path), map_location=device, weights_only=False)

    if isinstance(checkpoint, dict) and "config" in checkpoint:
        cfg_dict = checkpoint["config"]
    else:
        cfg_dict = load_config(TRAIN_DATASET_CONFIG[DATASET]["yaml"])

    model_cfg = cfg_dict.get("model", {})
    cfg = TRAIN_DATASET_CONFIG[DATASET]
    channels = cfg["channels"]
    input_length = cfg["input_length"]
    num_classes = cfg["num_classes"]
    cond_dim = int(model_cfg.get("cond_embed_dim", 64))

    backbone = SharedBackboneConfig(
        base=int(model_cfg.get("backbone_base", 64)),
        levels=tuple(int(x) for x in model_cfg.get("backbone_levels", [1, 2, 4])),
        blocks_per_level=int(model_cfg.get("backbone_blocks_per_level", 2)),
    )

    model_cls = NonSharedVAEUNetLDM1D if not var_cfg["shared"] else SharedVAEUNetLDM1D
    model = model_cls(
        channels=channels,
        input_length=input_length,
        z_channels=int(model_cfg.get("z_channels", 64)),
        timesteps=int(model_cfg.get("timesteps", 1000)),
        t_dim=int(model_cfg.get("t_dim", 128)),
        cond_dim=cond_dim,
        backbone=backbone,
        num_subjects=cfg["num_subjects"],
        adv_alpha=0.0,
    ).to(device)

    cond_embed = torch.nn.Embedding(num_classes, cond_dim).to(device)

    if isinstance(checkpoint, dict) and "model_state_dict" in checkpoint:
        model.load_state_dict(checkpoint["model_state_dict"], strict=False)
    if isinstance(checkpoint, dict) and "cond_embed_state_dict" in checkpoint:
        cond_embed.load_state_dict(checkpoint["cond_embed_state_dict"], strict=False)

    model.eval()
    cond_embed.eval()
    print(f"  模型加载成功 (variant={variant_name})")
    return model, cond_embed


# ============================================================================
# 跨会话评估 (session 0 → session 1)
# ============================================================================

def evaluate_cross_session(variant_name: str, seed: int = SEED):
    """对指定变体执行 BCI2a 跨会话评估 (每个被试 session 0 训练, session 1 测试)。"""
    print("\n" + "=" * 70)
    print(f"跨会话评估: {variant_name} (seed={seed})")
    print(f"  N_ENSEMBLE={N_ENSEMBLE}, CLASSIFIER_EPOCHS={CLASSIFIER_EPOCHS}")
    print(f"  DDIM_STEPS={DDIM_STEPS}, GUIDANCE_SCALE={GUIDANCE_SCALE}, GEN_RATIO={GEN_RATIO}")
    print("=" * 70)

    cfg = TRAIN_DATASET_CONFIG[DATASET]
    num_classes = cfg["num_classes"]

    # 加载全部数据 (两个 session, 通道 z-score) — 与 evaluate_sb_ldm_3datasets 一致
    X, y, subjects, sessions = load_dataset_data(DATASET)
    channels, input_length = X.shape[1], X.shape[2]

    model, cond_embed = load_ablation_model(variant_name, seed=seed)

    results = []
    unique_subjects = np.unique(subjects)
    n_subjects = len(unique_subjects)

    for si, test_subj in enumerate(unique_subjects):
        print(f"\n被试 {si + 1}/{n_subjects} (id={test_subj}):")
        # 跨会话: 该被试 session 0 训练, session 1 测试
        train_mask = (subjects == test_subj) & (sessions == 0)
        test_mask = (subjects == test_subj) & (sessions == 1)
        X_train, y_train = X[train_mask], y[train_mask]
        X_test, y_test = X[test_mask], y[test_mask]
        if len(X_train) == 0 or len(X_test) == 0:
            print(f"  跳过 (训练/测试样本不足: train={len(X_train)}, test={len(X_test)})")
            continue

        spc = max(1, int(GEN_RATIO * len(X_train)) // num_classes)
        set_seed()

        subj_for_gen = int(test_subj) if getattr(model, "num_subjects", 0) > 0 else None
        gen_X, gen_y = generate_sb_ldm(
            model, cond_embed, spc, num_classes, subj_for_gen
        )
        gen_X = normalize_to_real_stats(X_train, gen_X)

        X_aug = np.concatenate([X_train, gen_X])
        y_aug = np.concatenate([y_train, gen_y])

        clf = train_classifier(
            X_aug, y_aug, channels, input_length, num_classes
        )
        pred = predict(clf, X_test)
        acc = float(accuracy_score(y_test, pred))
        kappa = float(cohen_kappa_score(y_test, pred))
        results.append({"acc": acc, "kappa": kappa})
        print(f"  Acc: {acc * 100:.2f}%, Kappa: {kappa:.4f}")

    if not results:
        print("\n⚠️  无有效结果")
        return {"mean": 0.0, "std": 0.0, "mean_kappa": 0.0, "std_kappa": 0.0,
                "per_subject": [], "per_subject_kappa": []}

    accs = [r["acc"] for r in results]
    kappas = [r["kappa"] for r in results]
    result = {
        "mean": float(np.mean(accs)),
        "std": float(np.std(accs)),
        "mean_kappa": float(np.mean(kappas)),
        "std_kappa": float(np.std(kappas)),
        "per_subject": accs,
        "per_subject_kappa": kappas,
    }
    print(
        f"\n平均: {result['mean'] * 100:.2f}% ± {result['std'] * 100:.2f}%, "
        f"Kappa: {result['mean_kappa']:.4f} ± {result['std_kappa']:.4f}"
    )
    return result


# ============================================================================
# 结果保存 / 合并 / 汇总
# ============================================================================

def save_variant_result(variant_name: str, result: dict, seed: int = SEED):
    """保存单个变体的结果, 并合并所有已有结果到 ablation_bci2a.json。"""
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    # 1. 保存单变体单种子结果
    per_variant_path = RESULTS_DIR / f"ablation_bci2a_{variant_name}_s{seed}.json"
    with open(per_variant_path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
    print(f"  结果已保存: {per_variant_path}")

    # 2. 合并所有已有变体结果 (向后兼容: 无种子后缀的旧文件 + 带种子后缀的新文件)
    merge_results()


def merge_results() -> dict:
    """读取所有 ablation_bci2a_*.json 并合并到 ablation_bci2a.json。"""
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    merged = {}
    for variant_name in VARIANTS:
        # 优先读取无种子后缀的旧文件 (seed=42 的结果)
        per_variant_path = RESULTS_DIR / f"ablation_bci2a_{variant_name}.json"
        if per_variant_path.exists():
            with open(per_variant_path, "r", encoding="utf-8") as f:
                merged[variant_name] = json.load(f)

    with open(MERGED_RESULTS_PATH, "w", encoding="utf-8") as f:
        json.dump(merged, f, indent=2, ensure_ascii=False)
    print(f"  合并结果: {MERGED_RESULTS_PATH} ({len(merged)} 个变体)")
    return merged


def aggregate_seeds(seeds: list[int]):
    """聚合多个种子的结果, 计算均值和标准差。"""
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    aggregated = {}

    print("\n" + "=" * 70)
    print(f"多种子聚合 (seeds={seeds})")
    print("=" * 70)

    for variant_name in VARIANTS:
        all_accs = []
        all_kappas = []
        seed_results = {}

        for seed in seeds:
            # 读取带种子后缀的新文件
            per_seed_path = RESULTS_DIR / f"ablation_bci2a_{variant_name}_s{seed}.json"
            if per_seed_path.exists():
                with open(per_seed_path, "r", encoding="utf-8") as f:
                    r = json.load(f)
                seed_results[seed] = r
                all_accs.append(r["mean"])
                all_kappas.append(r["mean_kappa"])
            # 向后兼容: seed=42 时也尝试读取无后缀的旧文件
            elif seed == 42:
                old_path = RESULTS_DIR / f"ablation_bci2a_{variant_name}.json"
                if old_path.exists():
                    with open(old_path, "r", encoding="utf-8") as f:
                        r = json.load(f)
                    seed_results[seed] = r
                    all_accs.append(r["mean"])
                    all_kappas.append(r["mean_kappa"])

        if not all_accs:
            print(f"  {variant_name}: 无数据")
            continue

        aggregated[variant_name] = {
            "mean_acc": float(np.mean(all_accs)),
            "std_acc": float(np.std(all_accs)),
            "mean_kappa": float(np.mean(all_kappas)),
            "std_kappa": float(np.std(all_kappas)),
            "n_seeds": len(all_accs),
            "per_seed_acc": all_accs,
            "per_seed_kappa": all_kappas,
            "seed_results": seed_results,
        }
        print(f"  {variant_name}: Acc={np.mean(all_accs)*100:.2f}% ± {np.std(all_accs)*100:.2f}% "
              f"(n={len(all_accs)}), Kappa={np.mean(all_kappas):.4f} ± {np.std(all_kappas):.4f}")

    with open(MERGED_RESULTS_MULTI_SEED_PATH, "w", encoding="utf-8") as f:
        json.dump(aggregated, f, indent=2, ensure_ascii=False)
    print(f"\n  聚合结果已保存: {MERGED_RESULTS_MULTI_SEED_PATH}")

    # 打印汇总表
    print("\n" + "=" * 70)
    print("SB-LDM 消融实验多种子汇总 — BCI2a Cross-Session")
    print("=" * 70)
    header = f"{'变体':<16} {'Acc (%)':<20} {'Kappa':<20} {'n_seeds':<8}"
    print(header)
    print("-" * 64)
    for variant_name in VARIANTS:
        r = aggregated.get(variant_name)
        if r is None:
            print(f"{variant_name:<16} {'— (未完成)':<20}")
        else:
            acc_str = f"{r['mean_acc']*100:.2f} ± {r['std_acc']*100:.2f}"
            kappa_str = f"{r['mean_kappa']:.4f} ± {r['std_kappa']:.4f}"
            print(f"{variant_name:<16} {acc_str:<20} {kappa_str:<20} {r['n_seeds']:<8}")
    print("=" * 70)

    return aggregated


def print_summary(results: dict | None = None):
    """打印消融结果汇总表。"""
    if results is None:
        if MERGED_RESULTS_PATH.exists():
            with open(MERGED_RESULTS_PATH, "r", encoding="utf-8") as f:
                results = json.load(f)
        else:
            results = {}

    print("\n" + "=" * 70)
    print("SB-LDM 消融实验汇总 — BCI2a Cross-Session (Session 0 → Session 1)")
    print("=" * 70)
    header = f"{'变体':<16} {'Acc (%)':<20} {'Kappa':<20}"
    print(header)
    print("-" * 56)
    for variant_name in VARIANTS:
        r = results.get(variant_name)
        if r is None:
            print(f"{variant_name:<16} {'— (未完成)':<20}")
        else:
            acc_str = f"{r['mean'] * 100:.2f} ± {r['std'] * 100:.2f}"
            kappa_str = f"{r['mean_kappa']:.4f} ± {r['std_kappa']:.4f}"
            print(f"{variant_name:<16} {acc_str:<20} {kappa_str:<20}")
    print("=" * 70)


# ============================================================================
# 编排: 训练 + 评估单个变体
# ============================================================================

def run_variant(variant_name: str, num_epochs: int = NUM_EPOCHS,
                eval_only: bool = False, batch_size: int = 64, seed: int = SEED):
    """训练 (可选) + 评估单个变体, 并保存结果。"""
    print("\n" + "#" * 70)
    print(f"# 消融变体: {variant_name} (seed={seed})")
    print("#" * 70)

    if not eval_only:
        # 检查是否已有最终 checkpoint
        existing = get_latest_ckpt(variant_name, seed)
        if existing is not None:
            existing_epoch = _extract_epoch(existing)
            if existing_epoch >= num_epochs:
                print(f"  已存在 epoch={existing_epoch} checkpoint, 跳过训练: {existing}")
            else:
                train_variant(variant_name, num_epochs=num_epochs, batch_size=batch_size, seed=seed)
        else:
            train_variant(variant_name, num_epochs=num_epochs, batch_size=batch_size, seed=seed)
    else:
        existing = get_latest_ckpt(variant_name, seed)
        if existing is None:
            print(f"  ⚠️  --eval-only 但未找到 {variant_name} (seed={seed}) 的 checkpoint, 跳过")
            return

    # 评估时使用固定种子 (42) 以保证分类器评估的一致性
    set_seed(42)
    result = evaluate_cross_session(variant_name, seed=seed)
    save_variant_result(variant_name, result, seed=seed)


# ============================================================================
# Main
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="SB-LDM 消融实验 (BCI2a 跨会话)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "示例:\n"
            "  python ablation_sb_ldm.py --variant no_erd\n"
            "  python ablation_sb_ldm.py --all\n"
            "  python ablation_sb_ldm.py --variant no_erd --eval-only\n"
            "  python ablation_sb_ldm.py --variant no_erd --seed 123\n"
            "  python ablation_sb_ldm.py --summary\n"
            "  python ablation_sb_ldm.py --aggregate 42,123,456\n"
        ),
    )
    parser.add_argument(
        "--variant",
        type=str,
        default=None,
        choices=list(VARIANTS.keys()),
        help="训练/评估单个变体",
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="顺序训练+评估所有变体",
    )
    parser.add_argument(
        "--eval-only",
        action="store_true",
        help="仅评估 (跳过训练, 使用已有 checkpoint)",
    )
    parser.add_argument(
        "--summary",
        action="store_true",
        help="仅打印已有结果汇总表",
    )
    parser.add_argument(
        "--epochs",
        type=int,
        default=NUM_EPOCHS,
        help=f"训练 epochs (默认 {NUM_EPOCHS})",
    )
    parser.add_argument(
        "--batch_size",
        type=int,
        default=64,
        help="训练 batch size (默认 64)",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=SEED,
        help=f"训练随机种子 (默认 {SEED})",
    )
    parser.add_argument(
        "--aggregate",
        type=str,
        default=None,
        help="聚合多个种子的结果, 逗号分隔, 如 --aggregate 42,123,456",
    )
    args = parser.parse_args()

    # 设置随机种子
    set_seed(args.seed)

    print("=" * 70)
    print("SB-LDM 消融实验 — BCI2a Cross-Session (Session 0 → Session 1)")
    print(f"设备: {DEVICE}, 种子: {args.seed}")
    print(f"评估: N_ENSEMBLE={N_ENSEMBLE}, CLASSIFIER_EPOCHS={CLASSIFIER_EPOCHS}, "
          f"DDIM_STEPS={DDIM_STEPS}, GUIDANCE_SCALE={GUIDANCE_SCALE}, GEN_RATIO={GEN_RATIO}")
    print("=" * 70)

    # --- 聚合多种子结果 ---
    if args.aggregate:
        seeds = [int(s.strip()) for s in args.aggregate.split(",")]
        aggregate_seeds(seeds)
        return

    # --- 仅打印汇总 ---
    if args.summary:
        merge_results()
        with open(MERGED_RESULTS_PATH, "r", encoding="utf-8") as f:
            results = json.load(f)
        print_summary(results)
        return

    # --- 确定要运行的变体 ---
    if args.all:
        variants_to_run = list(VARIANTS.keys())
    elif args.variant:
        variants_to_run = [args.variant]
    else:
        parser.print_help()
        print("\n⚠️  请指定 --variant <NAME> 或 --all")
        return

    print(f"\n将运行 {len(variants_to_run)} 个变体: {variants_to_run} (seed={args.seed})")

    # --- 逐个执行 ---
    for variant_name in variants_to_run:
        try:
            run_variant(
                variant_name,
                num_epochs=args.epochs,
                eval_only=args.eval_only,
                batch_size=args.batch_size,
                seed=args.seed,
            )
        except Exception as e:
            print(f"\n❌ 变体 {variant_name} (seed={args.seed}) 失败: {e}")
            import traceback
            traceback.print_exc()
            continue

    # --- 最终汇总 ---
    merged = merge_results()
    print_summary(merged)


if __name__ == "__main__":
    main()
