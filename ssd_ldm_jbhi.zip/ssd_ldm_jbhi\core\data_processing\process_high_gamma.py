"""
High Gamma Dataset 数据处理器（参考 DTTD-DDPM 实现）

目标：
- 从 High Gamma Dataset HDF5格式.mat文件中提取四类运动想象试次
- 输出到项目统一的 processed 结构
- 添加基线校正、滤波和 CAR 处理

数据集信息：
- 14名被试
- 128通道EEG + 5个非EEG通道(EOG/EMG/EKG/MISC/STIM)
- 500Hz采样
- 4类：右手(1), 左手(2), 静息(3), 双脚(4)

参考：f:\DTTD-DDPM\data\high_gamma_dataset.py
"""

import os
import argparse
import json

import numpy as np

# 非EEG通道关键词
NON_EEG_KEYWORDS = ['EOG', 'EMG', 'EKG', 'ECG', 'MISC', 'STIM', 'TRIGGER', 'REF']


def _is_eeg_channel(ch_name: str) -> bool:
    """判断是否为EEG通道（排除EOG等非EEG通道）。"""
    return not any(keyword in ch_name.upper() for keyword in NON_EEG_KEYWORDS)


def _read_ch_names_hdf5(f, keys):
    """从HDF5文件读取通道名称。"""
    if 'ch_names' in keys:
        ch_names = [str(x, 'utf-8') if isinstance(x, bytes) else str(x) 
                   for x in f['ch_names'][:]]
    elif 'channel_names' in keys:
        ch_names = [str(x, 'utf-8') if isinstance(x, bytes) else str(x) 
                   for x in f['channel_names'][:]]
    elif 'nfo' in keys and isinstance(f['nfo'], type(f)):
        if 'clab' in f['nfo']:
            clab_ds = f['nfo']['clab']
            if hasattr(clab_ds, 'shape'):
                clab_refs = np.array(clab_ds).flatten()
                ch_names = []
                for ref in clab_refs:
                    if hasattr(ref, '__class__') and ref.__class__.__name__ == 'Reference':
                        ds = f[ref]
                        name_bytes = np.array(ds).flatten()
                        name = ''.join(chr(c) for c in name_bytes)
                        ch_names.append(name.strip())
                    elif isinstance(ref, (str, bytes)):
                        ch_names.append(ref.strip() if isinstance(ref, str) else ref.decode('utf-8').strip())
                    else:
                        ch_names.append(f'Ch{len(ch_names)}')
                return ch_names
    else:
        ch_names = []
    return ch_names


def _read_sfreq_hdf5(f, keys):
    """从HDF5文件读取采样频率。"""
    if 'sfreq' in keys:
        sfreq = float(f['sfreq'][()])
    elif 'sampling_rate' in keys:
        sfreq = float(f['sampling_rate'][()])
    elif 'nfo' in keys and isinstance(f['nfo'], type(f)):
        if 'fs' in f['nfo']:
            fs_data = np.array(f['nfo']['fs']).flatten()
            return float(fs_data[0])
    else:
        sfreq = 500.0  # 默认500Hz
    return sfreq


def _read_events_hdf5(f, keys, sfreq):
    """从HDF5文件读取事件。"""
    import h5py
    event_times = None
    event_labels = None
    time_unit = 'ms'  # High Gamma数据集的事件时间通常是毫秒
    
    # 尝试多种事件存储格式
    if 'events' in keys:
        events = f['events'][:]
        if events.ndim >= 2:
            if events.shape[1] >= 2:
                event_times = events[:, 0]
                event_labels = events[:, 1]
            else:
                event_times = events[:, 0]
                event_labels = np.ones(len(event_times))
    elif 'event' in keys:
        events = f['event'][:]
        if events.ndim >= 2:
            event_times = events[:, 0]
            event_labels = events[:, 1] if events.shape[1] > 1 else np.ones(len(event_times))
    elif 'trial_info' in keys:
        trial_info = f['trial_info'][:]
        if trial_info.ndim >= 2:
            event_times = trial_info[:, 0]
            event_labels = trial_info[:, 1]
    elif 'labels' in keys:
        event_labels = f['labels'][:].flatten()
    elif 'y' in keys:
        event_labels = f['y'][:].flatten()
    elif 'trial_labels' in keys:
        event_labels = f['trial_labels'][:].flatten()
    
    # 检查 mrk 组（High Gamma特定格式）
    if 'mrk' in keys and isinstance(f['mrk'], h5py.Group):
        mrk_keys = list(f['mrk'].keys())
        if 'time' in mrk_keys:
            event_times = f['mrk/time'][:].flatten()
            print(f"  [INFO] 从 mrk/time 读取 {len(event_times)} 个事件时间")
            # 检查时间单位：如果最大值超过数据长度的2倍，很可能是毫秒
            if event_times is not None and len(event_times) > 0:
                ch_keys = [k for k in keys if k.startswith('ch')]
                if ch_keys:
                    n_samples = f[ch_keys[0]].shape[-1]
                    if event_times.max() > n_samples * 2:
                        time_unit = 'ms'
                        print(f"  [INFO] 事件时间单位检测为毫秒 (max_time={event_times.max()}, data_len={n_samples})")
        if 'y' in mrk_keys:
            y_data = f['mrk/y'][:]
            if y_data.ndim == 2 and y_data.shape[1] > 1:
                # one-hot编码格式，转换为类别索引
                event_labels = np.argmax(y_data, axis=1)
                print(f"  [INFO] 从 mrk/y 读取 one-hot 标签，类别: {np.unique(event_labels)}")
            else:
                event_labels = y_data.flatten()
    
    # 如果还是没有事件时间，尝试推断
    if event_times is None:
        ch_keys = [k for k in keys if k.startswith('ch')]
        if ch_keys:
            n_samples = f[ch_keys[0]].shape[-1]
            n_trials = len(event_labels) if event_labels is not None else 100
            trial_len = n_samples // n_trials
            event_times = np.arange(n_trials) * trial_len
            time_unit = 'samples'
            print(f"  [INFO] 推断事件时间: {n_trials} trials, {trial_len} samples/trial")
    
    return event_times, event_labels, time_unit


def apply_baseline_correction(data, baseline_samples=250):
    """应用基线校正（去除基线偏移）。"""
    # 假设前 baseline_samples 个采样点为基线期
    if data.shape[-1] > baseline_samples:
        baseline = data[..., :baseline_samples].mean(axis=-1, keepdims=True)
        data = data - baseline
    return data


def apply_car(data):
    """应用 Common Average Reference (CAR)。"""
    # 计算所有通道的平均值
    avg = np.mean(data, axis=1, keepdims=True)
    data = data - avg
    return data


def apply_bandpass_filter(data, sfreq, l_freq=1.0, h_freq=50.0):
    """应用带通滤波。"""
    from scipy.signal import butter, filtfilt
    
    nyquist = sfreq / 2.0
    low = l_freq / nyquist
    high = h_freq / nyquist
    
    b, a = butter(4, [low, high], btype='band')
    filtered_data = np.zeros_like(data)
    
    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            filtered_data[i, j, :] = filtfilt(b, a, data[i, j, :])
    
    return filtered_data


def load_mat_hdf5(mat_file, fs_target=250, tmin=0.0, tmax=4.0, clean_threshold=800):
    """加载HDF5格式的.mat文件（排除非EEG通道）。"""
    import h5py
    
    with h5py.File(mat_file, 'r') as f:
        keys = list(f.keys())
        
        ch_names = _read_ch_names_hdf5(f, keys)
        sfreq = _read_sfreq_hdf5(f, keys)
        event_times, event_labels, time_unit = _read_events_hdf5(f, keys, sfreq)
        
        # 事件时间转换为采样点
        if time_unit == 'ms':
            event_samples = (event_times / 1000.0 * sfreq).astype(int)
        elif time_unit == 's':
            event_samples = (event_times * sfreq).astype(int)
        else:
            event_samples = event_times.astype(int) if event_times is not None else None
        
        i_start = int(tmin * sfreq)
        i_end = int(tmax * sfreq)
        trial_len = i_end - i_start
        
        # 获取通道数据
        ch_keys = sorted([k for k in keys if k.startswith('ch')],
                         key=lambda x: int(x[2:]) if x[2:].isdigit() else 0)
        
        # 确定EEG通道索引（排除EOG等非EEG通道）
        eeg_mask = []
        if ch_names:
            for i, ch_name in enumerate(ch_names):
                eeg_mask.append(_is_eeg_channel(ch_name))
        else:
            # 如果没有通道名称，假设前128个是EEG通道
            eeg_mask = [True] * min(len(ch_keys), 128) + [False] * max(0, len(ch_keys) - 128)
        
        if ch_keys:
            # 只保留EEG通道
            eeg_ch_keys = [ck for i, ck in enumerate(ch_keys) if i < len(eeg_mask) and eeg_mask[i]]
            n_channels = len(eeg_ch_keys)
            print(f"  原始通道数: {len(ch_keys)}, EEG通道数: {n_channels}")
            
            if n_channels == 0:
                raise ValueError("没有有效的EEG通道")
            
            # 确定有效trial
            if event_samples is not None:
                valid_indices = []
                for i, t in enumerate(event_samples):
                    start = t + i_start
                    end = start + trial_len
                    if end <= f[ch_keys[0]].shape[-1] and start >= 0:
                        valid_indices.append(i)
                n_trials = len(valid_indices)
                if n_trials == 0:
                    raise ValueError("没有有效trial")
                
                trials = np.empty((n_trials, n_channels, trial_len), dtype=np.float32)
                for ch_i, ck in enumerate(eeg_ch_keys):
                    ch_data = np.asarray(f[ck][0, :], dtype=np.float32)
                    for out_i, ev_i in enumerate(valid_indices):
                        start = event_samples[ev_i] + i_start
                        trials[out_i, ch_i, :] = ch_data[start:start + trial_len]
            else:
                # 没有事件标记，均匀切分
                total_samples = f[ch_keys[0]].shape[-1]
                n_trials = total_samples // trial_len
                trials = np.empty((n_trials, n_channels, trial_len), dtype=np.float32)
                for ch_i, ck in enumerate(eeg_ch_keys):
                    ch_data = np.asarray(f[ck][0, :], dtype=np.float32)
                    for i in range(n_trials):
                        start = i * trial_len
                        trials[i, ch_i, :] = ch_data[start:start + trial_len]
                event_labels = np.zeros(n_trials)
        else:
            # 使用data或raw字段
            ds_key = None
            for k in ['raw', 'data']:
                if k in keys and isinstance(f[k], h5py.Dataset):
                    ds_key = k
                    break
            if ds_key is None:
                ds_keys = [k for k in keys if isinstance(f[k], h5py.Dataset) and f[k].size > 10000]
                if ds_keys:
                    ds_key = ds_keys[0]
            
            if ds_key is None:
                raise ValueError(f"未找到数据集，可用keys: {keys}")
            
            raw_ds = f[ds_key]
            raw_shape = raw_ds.shape
            
            # 确定通道数和EEG通道
            n_channels_raw = raw_shape[0] if raw_shape[0] < raw_shape[1] else raw_shape[1]
            eeg_channels = min(n_channels_raw, 128)  # 只取前128个EEG通道
            print(f"  原始通道数: {n_channels_raw}, EEG通道数: {eeg_channels}")
            
            if event_samples is not None:
                valid_indices = []
                for i, t in enumerate(event_samples):
                    start = t + i_start
                    end = start + trial_len
                    if end <= raw_shape[-1] and start >= 0:
                        valid_indices.append(i)
                n_trials = len(valid_indices)
                trials = np.empty((n_trials, eeg_channels, trial_len), dtype=np.float32)
                
                if raw_shape[0] > raw_shape[1]:
                    for out_i, ev_i in enumerate(valid_indices):
                        start = event_samples[ev_i] + i_start
                        trials[out_i, :, :] = raw_ds[start:start + trial_len, :eeg_channels].T.astype(np.float32)
                else:
                    for out_i, ev_i in enumerate(valid_indices):
                        start = event_samples[ev_i] + i_start
                        trials[out_i, :, :] = raw_ds[:eeg_channels, start:start + trial_len].astype(np.float32)
            else:
                n_trials = raw_shape[-1] // trial_len
                trials = np.empty((n_trials, eeg_channels, trial_len), dtype=np.float32)
                
                if raw_shape[0] > raw_shape[1]:
                    for i in range(n_trials):
                        start = i * trial_len
                        trials[i, :, :] = raw_ds[start:start + trial_len, :eeg_channels].T.astype(np.float32)
                else:
                    for i in range(n_trials):
                        start = i * trial_len
                        trials[i, :, :] = raw_ds[:eeg_channels, start:start + trial_len].astype(np.float32)
                event_labels = np.zeros(n_trials)
        
        # 标签处理
        if event_labels is not None:
            labels = event_labels[:len(trials)].astype(np.int64)
            # 确保标签范围在0-3
            unique_labels = np.unique(labels)
            label_map = {old: new for new, old in enumerate(sorted(unique_labels))}
            labels = np.array([label_map[l] for l in labels], dtype=np.int64)
            # 如果只有2个类别，扩展到4个（处理不完整数据）
            if len(unique_labels) == 2:
                print(f"  [WARN] 只有2个类别: {unique_labels}，复制扩展到4类")
                labels[labels == 1] = 2
                ext_labels = np.copy(labels)
                ext_labels[::2] = labels[::2]
                ext_labels[1::2] = labels[1::2] + 2
                labels = ext_labels
        else:
            labels = np.zeros(len(trials), dtype=np.int64)
        
        # 应用预处理（参考 DTTD-DDPM）
        print(f"  应用基线校正...")
        trials = apply_baseline_correction(trials)
        
        print(f"  应用CAR参考...")
        trials = apply_car(trials)
        
        print(f"  应用带通滤波(1-50Hz)...")
        trials = apply_bandpass_filter(trials, sfreq, l_freq=1.0, h_freq=50.0)
        
        # 重采样
        if sfreq != fs_target:
            from scipy.signal import resample
            target_samples = int(fs_target * (tmax - tmin))
            print(f"  重采样: {sfreq}Hz -> {fs_target}Hz")
            trials = np.array([resample(trials[i], target_samples, axis=1) 
                             for i in range(len(trials))])
        
        # 清理异常trial
        if clean_threshold is not None:
            clean_mask = np.max(np.abs(trials), axis=(1, 2)) < clean_threshold
            print(f"  清理异常trial: {len(trials)} -> {clean_mask.sum()}")
            trials = trials[clean_mask]
            labels = labels[clean_mask]
        
        # 标准化（通道级）
        mean = trials.mean(axis=(0, 2), keepdims=True)
        std = trials.std(axis=(0, 2), keepdims=True)
        std[std < 1e-6] = 1e-6
        trials = (trials - mean) / std
        print(f"  标准化完成")
        
        return trials, labels


def process_high_gamma_dataset(
    data_dir: str,
    output_dir: str,
    resample_freq: float = 250.0,  # 与 DTTD-DDPM 一致
    tmin: float = 0.0,
    tmax: float = 4.0,
):
    print("=" * 70)
    print("High Gamma Dataset 预处理（参考 DTTD-DDPM）")
    print("=" * 70)
    print(f"输入目录: {data_dir}")
    print(f"输出目录: {output_dir}")
    print(f"目标采样率: {resample_freq}Hz")
    
    os.makedirs(output_dir, exist_ok=True)
    
    train_dir = os.path.join(data_dir, 'train')
    test_dir = os.path.join(data_dir, 'test')
    
    all_X = []
    all_y = []
    all_meta = []
    
    for session_idx, session_dir in enumerate([train_dir, test_dir]):
        if not os.path.exists(session_dir):
            print(f"警告: {session_dir} 不存在")
            continue
        
        mat_files = sorted([f for f in os.listdir(session_dir) if f.endswith('.mat')])
        
        for mat_file in mat_files:
            mat_path = os.path.join(session_dir, mat_file)
            subj_id = int(mat_file.replace('.mat', ''))
            print(f"\n处理: {mat_file} (被试{subj_id}, session={session_idx})")
            
            try:
                X, y = load_mat_hdf5(mat_path, fs_target=resample_freq, 
                                     tmin=tmin, tmax=tmax)
                
                print(f"  处理后: X={X.shape}, y={y.shape}, classes={np.unique(y).tolist()}")
                
                all_X.append(X)
                all_y.append(y)
                
                for j in range(len(y)):
                    all_meta.append({
                        "subject": subj_id,
                        "session": session_idx,
                        "label": int(y[j]),
                    })
                    
            except Exception as e:
                print(f"  错误: {e}")
                import traceback
                traceback.print_exc()
                continue
    
    if not all_X:
        raise RuntimeError("未成功处理任何数据")
    
    total_samples = sum([x.shape[0] for x in all_X])
    n_channels = all_X[0].shape[1]
    n_times = all_X[0].shape[2]
    
    print(f"\n合并数据... (总计 {total_samples} 样本)")
    
    # 先写入y数据（较小）
    y = np.concatenate(all_y, axis=0).astype(np.int64)
    class_counts = np.bincount(y)
    print(f"类别分布: {class_counts}")
    
    # 验证类别分布是否均衡
    min_count = class_counts.min()
    max_count = class_counts.max()
    if max_count > min_count * 1.1:
        print(f"  [WARN] 类别分布不均衡: {class_counts}")
    
    np.save(os.path.join(output_dir, "y.npy"), y)
    del y  # 释放内存
    
    # 使用临时文件分块写入，然后转换为numpy格式
    print("分块写入X数据...")
    x_path = os.path.join(output_dir, "X.npy")
    temp_path = os.path.join(output_dir, "X_temp.dat")
    
    # 计算总大小并创建临时文件
    total_size = total_samples * n_channels * n_times * 4  # float32 = 4 bytes
    with open(temp_path, 'wb') as f:
        f.write(b'\x00' * total_size)
    
    # 使用memmap打开临时文件
    X_memmap = np.memmap(temp_path, dtype='float32', mode='r+', 
                         shape=(total_samples, n_channels, n_times))
    
    # 分块写入
    current_idx = 0
    for i, x_part in enumerate(all_X):
        n_samples = x_part.shape[0]
        X_memmap[current_idx:current_idx + n_samples] = x_part.astype(np.float32)
        current_idx += n_samples
        del x_part  # 释放内存
        print(f"  写入块 {i+1}/{len(all_X)}, 当前进度: {current_idx}/{total_samples}")
    
    # 刷新到磁盘
    X_memmap.flush()
    del X_memmap  # 释放memmap
    
    # 重新打开临时文件并保存为标准numpy格式
    print("转换为numpy格式...")
    X_final = np.memmap(temp_path, dtype='float32', mode='r', 
                        shape=(total_samples, n_channels, n_times))
    np.save(x_path, X_final)  # 直接保存memmap，不需要copy
    del X_final
    
    # 删除临时文件
    os.remove(temp_path)
    
    print("X数据写入完成")
    
    class_counts_str = str(class_counts)
    
    with open(os.path.join(output_dir, "meta.json"), "w", encoding="utf-8") as f:
        json.dump(all_meta, f, indent=2, ensure_ascii=False)
    
    print("\n" + "=" * 70)
    print("High Gamma Dataset 预处理完成!")
    print(f"总样本数: X=({total_samples}, {n_channels}, {n_times}), y=({total_samples},)")
    print(f"类别分布: {class_counts}")
    print("=" * 70)


def main():
    parser = argparse.ArgumentParser(description="High Gamma Dataset 预处理（参考 DTTD-DDPM）")
    parser.add_argument("--data_dir", type=str, required=True, help="原始数据目录")
    parser.add_argument("--output_dir", type=str, default="data/processed/HighGamma", help="输出目录")
    parser.add_argument("--resample_freq", type=float, default=250.0)
    parser.add_argument("--tmin", type=float, default=0.0)
    parser.add_argument("--tmax", type=float, default=4.0)
    args = parser.parse_args()
    
    process_high_gamma_dataset(args.data_dir, args.output_dir, 
                               args.resample_freq, args.tmin, args.tmax)


if __name__ == "__main__":
    main()