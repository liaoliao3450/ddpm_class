#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""论文静态检查: ref/label 配对, 环境配对, 表格列数, 图形文件, 常见排版隐患."""
import re
from pathlib import Path
from collections import Counter

PAPER = Path('F:/DS-DDPM-main/paper/SB_SD_LDM_JBHI.tex')
FIGDIR = PAPER.parent.parent / 'outputs/figures'
tex = PAPER.read_text(encoding='utf-8')

issues = []

# 1. label/ref 配对
labels = re.findall(r'\\label\{([^}]+)\}', tex)
refs = re.findall(r'\\(?:ref|eqref)\{([^}]+)\}', tex)
label_set = set(labels)
dup_labels = [k for k, v in Counter(labels).items() if v > 1]
if dup_labels:
    issues.append(f'重复 label: {dup_labels}')
undef_refs = [r for r in refs if r not in label_set]
if undef_refs:
    issues.append(f'未定义 ref: {sorted(set(undef_refs))}')
unused_labels = [l for l in label_set if l not in refs]
print(f'[label/ref] label {len(labels)} 个, ref {len(refs)} 个, '
      f'未定义 ref {len(set(undef_refs))}, 未引用 label {len(set(unused_labels))}: {sorted(set(unused_labels))}')

# 2. 环境配对
begins = re.findall(r'\\begin\{(\w+\*?)\}', tex)
ends = re.findall(r'\\end\{(\w+\*?)\}', tex)
bc, ec = Counter(begins), Counter(ends)
for env in sorted(set(begins) | set(ends)):
    if bc[env] != ec[env]:
        issues.append(f'环境不配对: {env} begin={bc[env]} end={ec[env]}')
print(f'[env] begin/end 计数: {dict(bc)}')
if bc == ec:
    print('[env] 所有环境配对 OK')

# 3. 图形文件存在性
figs = re.findall(r'\\includegraphics\[[^\]]*\]\{([^}]+)\}', tex)
for f in figs:
    p = FIGDIR / f
    if not p.exists():
        p2 = PAPER.parent / f
        if not p2.exists():
            issues.append(f'图形文件缺失: {f} (graphicspath 下不存在)')
        else:
            print(f'[fig] {f} 在 paper/ 目录找到')
print(f'[fig] includegraphics {len(figs)} 个, 缺失 {sum(1 for f in figs if not (FIGDIR/f).exists() and not (PAPER.parent/f).exists())}')

# 4. 表格列数一致性 (处理 @{} 嵌套花括号的 spec)
for m in re.finditer(r'\\begin\{tabular\}(\{(?:[^{}]|\{[^{}]*\})*\})(.*?)\\end\{tabular\}', tex, re.S):
    spec_raw, body = m.group(1), m.group(2)
    spec = re.sub(r'@\{[^}]*\}', '', spec_raw)  # 去掉 @{...}
    spec = re.sub(r'[>|<]', '', spec)  # 去掉对齐修饰
    ncol = spec.count('c') + spec.count('l') + spec.count('r')
    ncols_p = len(re.findall(r'p\{[^}]*\}', spec))
    ncol += ncols_p
    rows = [r for r in body.split('\\\\') if '&' in r]
    bad = []
    for i, r in enumerate(rows):
        r2 = re.sub(r'\\cmidrule\([^)]*\)\{[^}]*\}', '', r)
        r2 = re.sub(r'\\multicolumn\{\d+\}\{[^}]*\}', 'X', r2)
        n_amp = r2.count('&')
        if n_amp != ncol - 1:
            bad.append((i + 1, n_amp + 1))
    if bad:
        issues.append(f'tabular (spec={spec_raw}, {ncol}列) 行列数不符: {bad}')

# 5. 常见隐患
# 5a. 行内 $$ (IEEEtran 禁用)
if '$$' in tex:
    issues.append('存在 $$ (IEEEtran 应使用 \\[ \\])')
# 5b. 未转义 % & _ (粗查: 行尾奇数个 % 不算注释符的情况略过, 查文本中的裸 &)
for i, line in enumerate(tex.split('\n'), 1):
    # 跳过注释行
    s = line.split('%')[0]
    if re.search(r'(?<!\\)\bfootnote\{[^}]*&', s):
        issues.append(f'L{i}: footnote 内有未转义 &')
# 5c. caption 中的 \label 顺序 (label 应在 caption 之后)
for m in re.finditer(r'\\begin\{(table|figure)\*?\}.*?\\end\{\1\*?\}', tex, re.S):
    blk = m.group(0)
    cap = re.search(r'\\caption', blk)
    lab = re.search(r'\\label', blk)
    if cap and lab and lab.start() < cap.start():
        issues.append('某 table/figure 的 \\label 在 \\caption 之前 (交叉引用会编号错)')
# 5d. TODO/占位残留
for i, line in enumerate(tex.split('\n'), 1):
    if re.search(r'TODO|XXX|placeholder|FIXME', line) and not line.strip().startswith('%'):
        issues.append(f'L{i}: 正文残留 TODO/占位: {line.strip()[:70]}')

# 6. 摘要/关键词/章节结构
for cmd in ['\\begin{abstract}', '\\end{abstract}', '\\begin{IEEEkeywords}',
            '\\end{IEEEkeywords}', '\\title{', '\\author{']:
    if cmd not in tex:
        issues.append(f'缺少 {cmd}')

print()
if issues:
    print(f'=== 发现 {len(issues)} 个问题 ===')
    for it in issues:
        print(' -', it)
else:
    print('=== 静态检查全部通过 ===')
