"""
High Gamma Dataset (Schirrmeister et al., 2017) 数据加载

数据集信息:
- 128通道高密度EEG + 5个非EEG通道(EOG/EMG), 500Hz采样
- 14个健康被试
- 4类: 右手(1), 左手(2), 静息(3), 双脚(4)
- 每被试约1000个4秒trial
- 训练集: 前11个run (~880 trials)
- 测试集: 后2个run (~160 trials)

DTTD实验设定:
- 输入: 16通道 (标准10-20运动皮层位置)
- 输出: 128通道 (仅EEG通道, 排除EOG/EMG)

数据下载:
1. 从GIN下载: https://web.gin.g-node.org/robintibor/high-gamma-dataset
   或使用: gin get robintibor/high-gamma-dataset && gin download --content
2. 目录结构:
   data_path/
     train/1.edf ... 14.edf
     test/1.edf ... 14.edf
"""
import os
import numpy as np


NON_EEG_KEYWORDS = ['EOG', 'EMG', 'EKG', 'MISC', 'STIM']

MOTOR_CORTEX_44 = [
    'FC5', 'FC1', 'FC2', 'FC6', 'C3', 'C4', 'CP5',
    'CP1', 'CP2', 'CP6', 'FC3', 'FCz', 'FC4', 'C5', 'C1', 'C2',
    'C6', 'CP3', 'CPz', 'CP4', 'FFC5h', 'FFC3h', 'FFC4h', 'FFC6h',
    'FCC5h', 'FCC3h', 'FCC4h', 'FCC6h', 'CCP5h', 'CCP3h', 'CCP4h',
    'CCP6h', 'CPP5h', 'CPP3h', 'CPP4h', 'CPP6h', 'FFC1h', 'FFC2h',
    'FCC1h', 'FCC2h', 'CCP1h', 'CCP2h', 'CPP1h', 'CPP2h'
]

INPUT_CH_16 = [
    'Fp1', 'Fp2', 'F7', 'F3', 'Fz', 'F4', 'F8',
    'C3', 'Cz', 'C4',
    'P3', 'Pz', 'P4',
    'T7', 'T8', 'P7'
]

INPUT_CH_22 = INPUT_CH_16

EVENT_MAP = {
    'Right Hand': 1,
    'Left Hand': 2,
    'Rest': 3,
    'Feet': 4
}


def _match_channel_name(raw_ch_name, target_name):
    raw_lower = raw_ch_name.lower().replace(' ', '').replace('-', '').replace('_', '')
    target_lower = target_name.lower().replace(' ', '').replace('-', '').replace('_', '')
    if raw_lower == target_lower:
        return True
    if raw_lower.endswith(target_lower) and raw_lower != target_lower:
        prefix = raw_lower[:-len(target_lower)]
        if prefix in ('eeg',):
            return True
    if raw_lower.startswith('eeg' + target_lower):
        return True
    return False


def _find_channel_indices(raw_ch_names, target_names):
    indices = []
    for target in target_names:
        found = False
        for i, raw_name in enumerate(raw_ch_names):
            if _match_channel_name(raw_name, target):
                indices.append(i)
                found = True
                break
        if not found:
            print(f"  [WARN] 通道 '{target}' 未找到，跳过")
    return indices


def load_subject_edf(data_path, subject_id, session='train', fs_target=250,
                     tmin=0.0, tmax=4.0, clean_threshold=800):
    subject_file = os.path.join(data_path, session, f'{subject_id}.edf')

    if not os.path.exists(subject_file):
        subject_file_mat = os.path.join(data_path, session, f'{subject_id}.mat')
        if os.path.exists(subject_file_mat):
            return load_subject_mat(data_path, subject_id, session, fs_target,
                                    tmin, tmax, clean_threshold)
        else:
            raise FileNotFoundError(f"找不到数据文件: {subject_file} 或 {subject_file_mat}")

    import mne
    raw = mne.io.read_raw_edf(subject_file, preload=True, verbose=False)

    raw.pick_types(eeg=True, exclude=[])
    ch_names = raw.ch_names

    eeg_indices = mne.pick_types(raw.info, eeg=True)
    if len(eeg_indices) == 0:
        eeg_indices = list(range(min(len(ch_names), 128)))

    sfreq = raw.info['sfreq']

    try:
        events, event_id = mne.events_from_annotations(raw, verbose=False)
    except Exception:
        try:
            stim_chs = mne.pick_types(raw.info, stim=True)
            if len(stim_chs) > 0:
                events = mne.find_events(raw, verbose=False)
                event_id = {str(v): v for v in np.unique(events[:, 2]) if v > 0}
            else:
                raise ValueError("无法提取事件标记")
        except Exception:
            print(f"  [WARN] 被试{subject_id}无法提取事件，尝试从信号推断")
            return _load_from_inferred_events(raw, eeg_indices, fs_target, tmin, tmax,
                                              clean_threshold, subject_id)

    valid_event_codes = []
    for code in [1, 2, 3, 4, 768, 769, 770, 771, 772]:
        for ev_code in event_id.values():
            if ev_code == code:
                valid_event_codes.append(code)

    if not valid_event_codes:
        all_codes = sorted(set(events[:, 2]) - {0})
        if len(all_codes) >= 4:
            valid_event_codes = all_codes[:4]
        else:
            print(f"  [WARN] 被试{subject_id}事件码不足: {all_codes}")
            return None, None

    selected_events = events[np.isin(events[:, 2], valid_event_codes)]
    if len(selected_events) == 0:
        return None, None

    label_map = {}
    for i, code in enumerate(sorted(set(selected_events[:, 2]))):
        label_map[code] = i

    epochs = mne.Epochs(raw, selected_events, event_id=label_map,
                        tmin=tmin, tmax=tmax, baseline=None,
                        preload=True, verbose=False)

    data = epochs.get_data().astype(np.float32)
    labels = np.array([label_map[epochs.events[i, 2]] for i in range(len(epochs))], dtype=np.int64)

    if sfreq != fs_target:
        data = _resample_data(data, sfreq, fs_target)

    if clean_threshold is not None:
        clean_mask = np.max(np.abs(data), axis=(1, 2)) < clean_threshold
        data = data[clean_mask]
        labels = labels[clean_mask]

    full_ch_names = [ch_names[i] for i in eeg_indices] if len(eeg_indices) <= len(ch_names) else ch_names

    return data, labels, full_ch_names


def _load_from_inferred_events(raw, eeg_indices, fs_target, tmin, tmax,
                               clean_threshold, subject_id):
    data_full, _ = raw[:, :]
    data_eeg = data_full[eeg_indices]

    n_channels, n_times = data_eeg.shape
    trial_len = int(fs_target * (tmax - tmin))

    print(f"  [INFO] 被试{subject_id}: 使用固定trial切分 ({n_times} 采样点)")
    n_trials = n_times // trial_len
    if n_trials < 10:
        return None, None

    data = data_eeg[:, :n_trials * trial_len].reshape(n_channels, n_trials, trial_len)
    data = data.transpose(1, 0, 2).astype(np.float32)
    labels = np.zeros(n_trials, dtype=np.int64)

    if clean_threshold is not None:
        clean_mask = np.max(np.abs(data), axis=(1, 2)) < clean_threshold
        data = data[clean_mask]
        labels = labels[clean_mask]

    ch_names = [raw.ch_names[i] for i in eeg_indices]
    return data, labels, ch_names


def load_subject_mat(data_path, subject_id, session='train', fs_target=250,
                     tmin=0.0, tmax=4.0, clean_threshold=800):
    mat_file = os.path.join(data_path, session, f'{subject_id}.mat')
    if not os.path.exists(mat_file):
        raise FileNotFoundError(f"找不到数据文件: {mat_file}")

    file_size = os.path.getsize(mat_file)
    if file_size < 1024:
        with open(mat_file, 'r', errors='ignore') as f:
            content = f.read(256)
        if 'git' in content or 'annex' in content or content.startswith('../'):
            raise FileNotFoundError(
                f"文件 {mat_file} 是git-annex符号链接(仅{file_size}字节)，"
                f"请先下载数据: gin download --content"
            )

    try:
        import h5py
        return _load_mat_hdf5(mat_file, fs_target, tmin, tmax, clean_threshold)
    except Exception as e:
        print(f"  [WARN] h5py加载失败({type(e).__name__}: {e}), 尝试scipy...")
        from scipy.io import loadmat as sio_loadmat
        return _load_mat_scipy(mat_file, fs_target, tmin, tmax, clean_threshold)


def _load_mat_hdf5(mat_file, fs_target, tmin, tmax, clean_threshold):
    import h5py

    with h5py.File(mat_file, 'r') as f:
        keys = list(f.keys())

        ch_names = _read_ch_names_hdf5(f, keys)
        sfreq = _read_sfreq_hdf5(f, keys)
        event_times, event_labels, time_unit = _read_events_hdf5(f, keys, sfreq)

        ch_keys = sorted([k for k in keys if k.startswith('ch')],
                         key=lambda x: int(x[2:]))

        if time_unit == 'ms':
            event_samples = (event_times / 1000.0 * sfreq).astype(int)
        else:
            event_samples = event_times.astype(int)

        i_start = int(tmin * sfreq)
        i_end = int(tmax * sfreq)
        trial_len = i_end - i_start

        valid_indices = []
        for i, t in enumerate(event_samples):
            start = t + i_start
            end = start + trial_len
            if end <= f[ch_keys[0]].shape[-1] and start >= 0:
                valid_indices.append(i)

        if not valid_indices:
            raise ValueError("没有有效trial")

        n_channels = len(ch_keys) if ch_keys else 0
        n_trials = len(valid_indices)

        if ch_keys:
            n_channels = len(ch_keys)
            trial_starts = []
            for ev_i in valid_indices:
                trial_starts.append(event_samples[ev_i] + i_start)
            trials = np.empty((n_trials, n_channels, trial_len), dtype=np.float32)
            for ch_i, ck in enumerate(ch_keys):
                ch_data = np.asarray(f[ck][0, :], dtype=np.float32)
                for out_i, s in enumerate(trial_starts):
                    trials[out_i, ch_i, :] = ch_data[s:s + trial_len]
        else:
            ds_key = None
            for k in ['raw', 'data']:
                if k in keys and isinstance(f[k], h5py.Dataset):
                    ds_key = k
                    break
            if ds_key is None:
                ds_keys = [k for k in keys if isinstance(f[k], h5py.Dataset) and f[k].size > 10000]
                if ds_keys:
                    ds_key = ds_keys[0]

            if ds_key is None:
                raise ValueError(f"未找到数据集，可用keys: {keys}")

            raw_ds = f[ds_key]
            raw_shape = raw_ds.shape
            if raw_shape[0] > raw_shape[1]:
                for out_i, ev_i in enumerate(valid_indices):
                    start = event_samples[ev_i] + i_start
                    end = start + trial_len
                    trials[out_i, :, :] = raw_ds[start:end, :].T.astype(np.float32)
                n_channels = raw_shape[1]
            else:
                for out_i, ev_i in enumerate(valid_indices):
                    start = event_samples[ev_i] + i_start
                    end = start + trial_len
                    trials[out_i, :, :] = raw_ds[:, start:end].astype(np.float32)
                n_channels = raw_shape[0]

        if len(ch_names) != n_channels:
            ch_names = [f'Ch{i}' for i in range(n_channels)]

        valid_labels = event_labels[valid_indices] if len(event_labels) > 0 else np.zeros(n_trials, dtype=np.int64)

        unique_labels = sorted(set(valid_labels))
        label_map = {old: new for new, old in enumerate(unique_labels)}
        labels = np.array([label_map[l] for l in valid_labels], dtype=np.int64)

        if sfreq != fs_target:
            trials = _resample_data(trials, sfreq, fs_target)

        if clean_threshold is not None:
            eeg_ch_indices = []
            for idx, name in enumerate(ch_names):
                upper = name.upper()
                if not any(kw in upper for kw in ['EOG', 'EMG', 'EKG', 'MISC', 'STIM']):
                    eeg_ch_indices.append(idx)
            if eeg_ch_indices:
                eeg_max = np.max(np.abs(trials[:, eeg_ch_indices, :]), axis=(1, 2))
                clean_mask = eeg_max < clean_threshold
            else:
                clean_mask = np.max(np.abs(trials), axis=(1, 2)) < clean_threshold
            trials = trials[clean_mask]
            labels = labels[clean_mask]

        return trials, labels, ch_names


def _read_ch_names_hdf5(f, keys):
    import h5py
    if 'nfo' in keys and isinstance(f['nfo'], h5py.Group):
        nfo = f['nfo']
        if 'clab' in nfo:
            clab_ds = nfo['clab']
            if isinstance(clab_ds, h5py.Dataset):
                clab_refs = np.array(clab_ds).flatten()
                ch_names = []
                for ref in clab_refs:
                    if isinstance(ref, h5py.Reference):
                        ds = f[ref]
                        name_bytes = np.array(ds).flatten()
                        name = ''.join(chr(c) for c in name_bytes)
                        ch_names.append(name.strip())
                    elif isinstance(ref, (str, bytes)):
                        ch_names.append(ref.strip() if isinstance(ref, str) else ref.decode('utf-8').strip())
                    else:
                        try:
                            ds = f[ref]
                            name_bytes = np.array(ds).flatten()
                            name = ''.join(chr(c) for c in name_bytes)
                            ch_names.append(name.strip())
                        except Exception:
                            ch_names.append(f'Ch{len(ch_names)}')
                if ch_names:
                    return ch_names
            elif isinstance(clab_ds, h5py.Group):
                sub_keys = list(clab_ds.keys())
                if sub_keys:
                    ch_data = np.array(clab_ds[sub_keys[0]])
                    if ch_data.size > 0:
                        return [str(c).strip() for c in ch_data.flatten()]

    return []


def _read_sfreq_hdf5(f, keys):
    import h5py
    if 'nfo' in keys and isinstance(f['nfo'], h5py.Group):
        nfo = f['nfo']
        if 'fs' in nfo:
            fs_data = np.array(nfo['fs']).flatten()
            return float(fs_data[0])
    return 500.0


def _read_events_hdf5(f, keys, sfreq=None):
    import h5py
    event_times = np.array([])
    event_labels = np.array([])
    time_unit = 'samples'

    if 'mrk' in keys and isinstance(f['mrk'], h5py.Group):
        mrk = f['mrk']
        if 'time' in mrk:
            event_times = np.array(mrk['time']).flatten()
        elif 'event' in mrk:
            event_times = np.array(mrk['event']).flatten()

        if sfreq is not None and len(event_times) > 0:
            nfo = f.get('nfo')
            if nfo is not None and 'T' in nfo:
                T = np.array(nfo['T']).flatten()[0]
                if event_times.max() > T:
                    time_unit = 'ms'

        if 'y' in mrk:
            y_ds = mrk['y']
            if isinstance(y_ds, h5py.Dataset):
                y_data = np.array(y_ds)
                if y_data.ndim == 2 and y_data.shape[0] < y_data.shape[1]:
                    y_data = y_data.T
                if y_data.ndim == 2 and y_data.shape[1] > 1:
                    event_labels = np.argmax(y_data, axis=1)
                else:
                    event_labels = y_data.flatten()
            elif isinstance(y_ds, h5py.Group):
                sub_keys = list(y_ds.keys())
                if sub_keys:
                    event_labels = np.array(y_ds[sub_keys[0]]).flatten()
        elif 'className' in mrk:
            event_labels = np.array(mrk['className']).flatten()

    return event_times, event_labels, time_unit


def _load_mat_scipy(mat_file, fs_target, tmin, tmax, clean_threshold):
    from scipy.io import loadmat

    mat = loadmat(mat_file, squeeze_me=True)

    keys = [k for k in mat.keys() if not k.startswith('__')]
    eeg_data = None
    ch_names = None
    sfreq = 500.0
    event_times = np.array([])
    event_labels = np.array([])

    if 'raw' in keys:
        raw = mat['raw']
        if isinstance(raw, np.ndarray) and raw.ndim >= 2:
            eeg_data = raw
            if eeg_data.shape[0] < eeg_data.shape[1]:
                pass
            else:
                eeg_data = eeg_data.T
    elif 'data' in keys:
        eeg_data = mat['data']
        if eeg_data.shape[0] > eeg_data.shape[1]:
            eeg_data = eeg_data.T

    if eeg_data is None:
        for k in keys:
            v = mat[k]
            if isinstance(v, np.ndarray) and v.ndim == 2 and v.size > 1000:
                eeg_data = v
                if eeg_data.shape[0] > eeg_data.shape[1]:
                    eeg_data = eeg_data.T
                break

    if eeg_data is None:
        raise ValueError(f"未找到EEG数据，可用keys: {keys}")

    if np.iscomplexobj(eeg_data):
        eeg_data = eeg_data.real.astype(np.float32)

    if 'nfo' in keys:
        nfo = mat['nfo']
        if isinstance(nfo, dict) or hasattr(nfo, 'dtype'):
            if 'clab' in (nfo.dtype.names if hasattr(nfo, 'dtype') and nfo.dtype.names else []):
                clab = nfo['clab'].item()
                ch_names = [str(c).strip() for c in np.array(clab).flatten()]
            if 'fs' in (nfo.dtype.names if hasattr(nfo, 'dtype') and nfo.dtype.names else []):
                sfreq = float(np.array(nfo['fs']).flatten()[0])

    if 'mrk' in keys:
        mrk = mat['mrk']
        if hasattr(mrk, 'dtype') and mrk.dtype.names:
            if 'time' in mrk.dtype.names:
                event_times = np.array(mrk['time']).flatten()
            if 'y' in mrk.dtype.names:
                event_labels = np.array(mrk['y']).flatten()

    if ch_names is None:
        ch_names = [f'Ch{i}' for i in range(eeg_data.shape[0])]

    return _extract_trials(eeg_data, ch_names, sfreq, event_times, event_labels,
                           fs_target, tmin, tmax, clean_threshold, time_unit='samples')


def _extract_trials(eeg_data, ch_names, sfreq, event_times, event_labels,
                    fs_target, tmin, tmax, clean_threshold, time_unit='samples'):
    if len(event_times) == 0:
        trial_len = int(sfreq * (tmax - tmin))
        n_trials = eeg_data.shape[1] // trial_len
        data = eeg_data[:, :n_trials * trial_len].reshape(eeg_data.shape[0], n_trials, trial_len)
        data = data.transpose(1, 0, 2).astype(np.float32)
        labels = np.zeros(n_trials, dtype=np.int64)
    else:
        if time_unit == 'ms':
            event_samples = (event_times / 1000.0 * sfreq).astype(int)
        else:
            event_samples = event_times.astype(int)

        i_start = int(tmin * sfreq)
        i_end = int(tmax * sfreq)
        trial_len = i_end - i_start

        trials = []
        trial_labels = []
        for i, t in enumerate(event_samples):
            start = t + i_start
            end = start + trial_len
            if end <= eeg_data.shape[1] and start >= 0:
                trials.append(eeg_data[:, start:end])
                if i < len(event_labels):
                    trial_labels.append(int(event_labels[i]))
                else:
                    trial_labels.append(0)

        data = np.array(trials, dtype=np.float32)
        labels = np.array(trial_labels, dtype=np.int64)

        unique_labels = sorted(set(labels))
        label_map = {old: new for new, old in enumerate(unique_labels)}
        labels = np.array([label_map[l] for l in labels], dtype=np.int64)

    if sfreq != fs_target:
        data = _resample_data(data, sfreq, fs_target)

    if clean_threshold is not None:
        eeg_ch_indices = []
        for idx, name in enumerate(ch_names):
            upper = name.upper()
            if not any(kw in upper for kw in ['EOG', 'EMG', 'EKG', 'MISC', 'STIM']):
                eeg_ch_indices.append(idx)
        if eeg_ch_indices:
            eeg_max = np.max(np.abs(data[:, eeg_ch_indices, :]), axis=(1, 2))
            clean_mask = eeg_max < clean_threshold
        else:
            clean_mask = np.max(np.abs(data), axis=(1, 2)) < clean_threshold
        data = data[clean_mask]
        labels = labels[clean_mask]

    eeg_mask = []
    for name in ch_names:
        upper = name.upper()
        eeg_mask.append(not any(kw in upper for kw in NON_EEG_KEYWORDS))
    if not all(eeg_mask):
        eeg_indices = [i for i, m in enumerate(eeg_mask) if m]
        ch_names = [ch_names[i] for i in eeg_indices]
        data = data[:, eeg_indices, :]

    return data, labels, ch_names


def _resample_data(data, sfreq_orig, sfreq_target):
    from scipy.signal import resample
    n_trials, n_channels, n_times = data.shape
    n_times_new = int(n_times * sfreq_target / sfreq_orig)
    resampled = resample(data, n_times_new, axis=2)
    return resampled.astype(np.float32)


class HighGammaDataset:
    """
    High Gamma Dataset 加载器

    Args:
        data_path: 数据根目录 (包含train/和test/子目录)
        subject_ids: 被试ID列表 (1-14)
        sessions: 加载哪些session ('train', 'test', 'both')
        fs_target: 目标采样率 (默认250Hz)
        tmin: trial开始时间 (秒, 相对于事件)
        tmax: trial结束时间 (秒, 相对于事件)
        clean_threshold: 清洗阈值 (µV), 超过此值的trial被剔除
    """

    def __init__(self, data_path, subject_ids=None, sessions='both',
                 fs_target=250, tmin=0.0, tmax=4.0, clean_threshold=800):
        self.data_path = data_path
        self.fs_target = fs_target
        self.tmin = tmin
        self.tmax = tmax

        if subject_ids is None:
            subject_ids = list(range(1, 15))

        all_data = []
        all_labels = []
        all_ch_names = None

        for sid in subject_ids:
            sessions_to_load = ['train', 'test'] if sessions == 'both' else [sessions]

            for session in sessions_to_load:
                try:
                    result = load_subject_edf(data_path, sid, session, fs_target,
                                              tmin, tmax, clean_threshold)
                    if result is None or result[0] is None:
                        print(f"  被试{sid} {session}: 无数据，跳过")
                        continue

                    if len(result) == 3:
                        data, labels, ch_names = result
                        if all_ch_names is None:
                            all_ch_names = ch_names
                    else:
                        data, labels = result
                        if all_ch_names is None:
                            all_ch_names = [f'Ch{i}' for i in range(data.shape[1])]

                    all_data.append(data)
                    all_labels.append(labels)
                    print(f"  被试{sid} {session}: {len(data)} trials, {data.shape[1]}ch, {data.shape[2]}时间点")

                except Exception as e:
                    print(f"  被试{sid} {session}: 加载失败 - {e}")

        if not all_data:
            raise RuntimeError("没有成功加载任何数据！请检查数据路径和格式。")

        self.data = np.concatenate(all_data, axis=0).astype(np.float32)
        self.labels = np.concatenate(all_labels, axis=0)
        self.ch_names = all_ch_names

        eeg_mask = []
        for name in self.ch_names:
            upper = name.upper()
            eeg_mask.append(not any(kw in upper for kw in NON_EEG_KEYWORDS))

        if not all(eeg_mask):
            eeg_indices = [i for i, m in enumerate(eeg_mask) if m]
            removed = [self.ch_names[i] for i, m in enumerate(eeg_mask) if not m]
            print(f"  排除非EEG通道: {removed}")
            self.data = self.data[:, eeg_indices, :]
            self.ch_names = [self.ch_names[i] for i in eeg_indices]

        n_channels = self.data.shape[1]
        self.input_ch_indices = _find_channel_indices(self.ch_names, INPUT_CH_16)

        if len(self.input_ch_indices) < 14:
            print(f"[WARN] 只找到{len(self.input_ch_indices)}个输入通道，使用均匀采样替代")
            step = max(1, n_channels // 16)
            self.input_ch_indices = list(range(0, n_channels, step))[:16]

        self.num_input_channels = len(self.input_ch_indices)
        self.num_output_channels = n_channels

        print(f"\n数据集加载完成:")
        print(f"  总样本数: {len(self.data)}")
        print(f"  类别分布: {np.bincount(self.labels)}")
        print(f"  输出通道: {self.num_output_channels} (EEG only)")
        print(f"  输入通道: {self.num_input_channels} (索引: {self.input_ch_indices})")
        print(f"  时间步: {self.data.shape[2]}")
        print(f"  采样率: {self.fs_target}Hz")


def get_hgd_data(data_path, subject_ids=None, sessions='both', fs_target=250):
    dataset = HighGammaDataset(data_path, subject_ids, sessions, fs_target)
    return dataset
