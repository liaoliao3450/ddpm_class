#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SB-SD-LDM (Subject-Style Disentangled LDM) — 期刊版 P1 阶段训练
===============================================================
P1 目标: 验证被试风格通路有效性 (不改 z, 不做解耦对抗).

架构改动 (model_shared.py):
  - subj_embed (N, subj_dim) + subj_proj -> decode 的独立 FiLM 注入
  - subj_head: 重建波形 -> 被试身份 (风格检验头)
  - 零初始化注入层: 训练起点等价于已修复的 SB-LDM 基线

P1 训练损失 (在修复版 SB-LDM 全部损失之上):
  L_style (正确 s): CE(subj_head(decode(mu, s_true)), s_true)
      — 风格信息到达输出的必要条件
  L_swap  (交换 s): CE(subj_head(decode(mu.detach(), s_other)), s_other)
      — 因果验证: 同一 z 换 s, 输出风格必须跟着 s 变.
        s 是唯一差异 => 只能通过风格通路满足 => 逼通路上班.

P1 验收门 (validate_p1_style.py):
  A1 重建判类 (teacher) >= 95%  — 风格注入不破坏重建质量
  A2 风格判回 (subj_head, 正确 s) >= 90%
  A3 交换控制 (subj_head 预测 s_other) >= 70% — 风格因果有效

Usage:
    $env:PYTHONUTF8='1'; python projects/tc_conf_ldm/scripts/SB-SD-LDM/train_sb_sd_ldm.py --dataset bci2a
"""
import sys
import json
import argparse
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
import yaml
from torch.utils.data import DataLoader, TensorDataset

# 项目根路径 (scripts/SB-SD-LDM/ -> 5 级向上)
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from core.classifiers.eegnet import EEGNet
from core.models.latent_diffusion.model_shared import SharedBackboneConfig, SharedVAEUNetLDM1D

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ============================================================================
# 数据集配置 (teacher 路径已修正: v1 的 bci2a_v2 teacher 是随机权重网络)
# ============================================================================
DATASET_CONFIG = {
    'bci2a': {
        'channels': 22,
        'input_length': 1000,
        'num_classes': 4,
        'fs': 250,
        'erd_c3': 7,
        'erd_c4': 11,
        'num_subjects': 9,
        'yaml': 'projects/tc_conf_ldm/configs/bci2a_tc_conf_ldm_shared.yaml',
        'teacher_ckpt': 'checkpoints/tc_conf_ldm/bci2a_shared_margin/pretrained_teacher_eegnet.pt',
        'teacher_fallback': 'checkpoints/tc_conf_ldm/bci2a_shared/pretrained_teacher_eegnet.pt',
        'ckpt_dir': 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2a',
    },
    'bci2b': {
        'channels': 3,
        'input_length': 1000,
        'num_classes': 2,
        'fs': 250,
        'erd_c3': 0,
        'erd_c4': 2,
        'num_subjects': 9,
        'yaml': 'projects/tc_conf_ldm/configs/bci2b_tc_conf_ldm_shared.yaml',
        'teacher_ckpt': 'checkpoints/tc_conf_ldm/bci2b_shared/pretrained_teacher_eegnet.pt',
        'teacher_fallback': None,
        'ckpt_dir': 'checkpoints/tc_conf_ldm/sb_sd_ldm_bci2b',
    },
    'physionet': {
        'channels': 64,
        'input_length': 640,
        'num_classes': 4,
        'fs': 160,
        'erd_c3': 17,
        'erd_c4': 48,
        'num_subjects': 109,  # load_physionet_mi4c_data 实际被试数 (0..108); 97 会致嵌入越界
        'yaml': 'projects/tc_conf_ldm/configs/physionet_mi4c_tc_conf_ldm_shared.yaml',
        'teacher_ckpt': 'checkpoints/tc_conf_ldm/physionet_mi4c_shared/pretrained_teacher_eegnet.pt',
        'teacher_fallback': None,
        'ckpt_dir': 'checkpoints/tc_conf_ldm/sb_sd_ldm_physionet',
    },
}


def load_config(yaml_path: str) -> dict:
    full_path = PROJECT_ROOT / yaml_path
    if full_path.exists():
        with open(full_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    return {}


def load_dataset(dataset: str):
    """加载数据, 只用 session 0 训练, 按通道 z-score。"""
    print(f'加载 {dataset} 数据...')
    if dataset == 'bci2a':
        from utils.data_loader import load_bci2a_data
        X, y, subjects, sessions = load_bci2a_data()
    elif dataset == 'bci2b':
        from utils.data_loader_bci2b import load_bci2b_data
        X, y, subjects, sessions, _ = load_bci2b_data()
    elif dataset == 'physionet':
        from utils.data_loader_physionet_mi4c import load_physionet_mi4c_data
        X, y, subjects, sessions, _ = load_physionet_mi4c_data()
    else:
        raise ValueError(f'未知数据集: {dataset}')

    X = X.astype(np.float32)
    y = y.astype(np.int64)
    subjects = np.asarray(subjects)
    sessions = np.asarray(sessions)

    cfg = DATASET_CONFIG[dataset]
    num_classes = cfg['num_classes']
    y = y - y.min()
    mask = y < num_classes
    X, y = X[mask], y[mask]
    subjects = subjects[mask]
    sessions = sessions[mask]

    train_mask = sessions == 0
    X_train = X[train_mask]
    y_train = y[train_mask]
    subjects_train = subjects[train_mask]

    X_train = (X_train - X_train.mean(axis=(0, 2), keepdims=True)) / (X_train.std(axis=(0, 2), keepdims=True) + 1e-8)

    # 被试 ID 重映射为 0..N-1 (嵌入表索引)
    uniq = np.unique(subjects_train)
    subj_map = {s: i for i, s in enumerate(uniq)}
    subjects_train = np.array([subj_map[s] for s in subjects_train], dtype=np.int64)

    print(f'  训练数据: {X_train.shape}, 类别分布: {np.bincount(y_train)}')
    print(f'  被试数: {len(uniq)} (ID 重映射: {uniq[0]}..{uniq[-1]} -> 0..{len(uniq)-1})')
    return X_train, y_train, subjects_train


def load_teacher(dataset: str, channels: int, input_length: int, num_classes: int):
    """加载 EEGNet teacher (用于 feat/logit/conf 蒸馏)。"""
    cfg = DATASET_CONFIG[dataset]
    teacher = EEGNet(n_channels=channels, n_samples=input_length, n_classes=num_classes).to(DEVICE)

    ckpt_path = PROJECT_ROOT / cfg['teacher_ckpt']
    if not ckpt_path.exists() and cfg['teacher_fallback']:
        ckpt_path = PROJECT_ROOT / cfg['teacher_fallback']

    if ckpt_path.exists():
        print(f'  加载 teacher: {ckpt_path}')
        state = torch.load(str(ckpt_path), map_location=DEVICE, weights_only=False)
        if isinstance(state, dict) and 'model_state_dict' in state:
            state = state['model_state_dict']
        teacher.load_state_dict(state, strict=False)
        print('  teacher 加载成功')
    else:
        raise FileNotFoundError(f'teacher 不存在: {ckpt_path}')

    for p in teacher.parameters():
        p.requires_grad = False
    teacher.eval()
    return teacher


@torch.no_grad()
def eval_style_quality(model, cond_embed, teacher, X_t, y_t, subj_t,
                       num_subjects, n=300, bs=100):
    """P1 监控: 重建判类 + 风格判回 + 交换控制."""
    model.eval()
    teacher.eval()
    idx = np.random.RandomState(0).choice(len(X_t), min(n, len(X_t)), replace=False)
    Xs, ys, ss = X_t[idx], y_t[idx], subj_t[idx]
    rec_true, rec_swap = [], []
    s_other_all = []
    for i in range(0, len(Xs), bs):
        xb = Xs[i:i + bs].to(DEVICE)
        yb = ys[i:i + bs].to(DEVICE)
        sb = ss[i:i + bs].to(DEVICE)
        cond = cond_embed(yb)
        mu, _, _ = model.encode(xb, cond=cond)
        # 正确 s 重建
        rec_true.append(model.decode(mu, target_length=xb.shape[-1],
                                     cond=cond, subject_id=sb).cpu())
        # 交换 s 重建 (其他被试)
        s_other = (sb + torch.randint(1, num_subjects, (len(sb),), device=DEVICE)) % num_subjects
        s_other_all.append(s_other.cpu())
        rec_swap.append(model.decode(mu, target_length=xb.shape[-1],
                                     cond=cond, subject_id=s_other).cpu())
    rec_true = torch.cat(rec_true)
    rec_swap = torch.cat(rec_swap)
    s_other_all = torch.cat(s_other_all)

    # teacher 判类 (需要 (B,1,C,T)); orig 与 recon 分开收集
    t_orig, t_rec = [], []
    for i in range(0, len(rec_true), bs):
        xb = Xs[i:i + bs].to(DEVICE)
        rb = rec_true[i:i + bs].to(DEVICE)
        t_orig.append(teacher(xb.unsqueeze(1)).argmax(1).cpu())
        t_rec.append(teacher(rb.unsqueeze(1)).argmax(1).cpu())
    t_rec = torch.cat(t_rec)
    recon_class_acc = float((t_rec == torch.as_tensor(ys)).float().mean())

    # 风格判回 / 交换控制 (subj_head)
    h_true = model.subj_head(rec_true.to(DEVICE)).argmax(1).cpu()
    h_swap = model.subj_head(rec_swap.to(DEVICE)).argmax(1).cpu()
    s_t = torch.as_tensor(ss)
    style_acc = float((h_true == s_t).float().mean())
    swap_acc = float((h_swap == s_other_all).float().mean())
    swap_backfire = float((h_swap == s_t).float().mean())  # 交换后仍判回原被试 (通路死)

    # MSE 对比: 正确 s vs 交换 s 的重建误差
    mse_true = float(((Xs - rec_true.numpy()) ** 2).mean())
    mse_swap = float(((Xs - rec_swap.numpy()) ** 2).mean())

    model.train()
    return {'recon_class_acc': recon_class_acc, 'style_acc': style_acc,
            'swap_acc': swap_acc, 'swap_backfire': swap_backfire,
            'mse_true': mse_true, 'mse_swap': mse_swap}


def train(dataset: str, num_epochs: int = 500, batch_size: int = 64, lr: float = 1e-4,
          ckpt_dir_override: str = None, subj_dim: int = 32,
          lambda_style: float = 0.3, swap_p: float = 0.25):
    cfg = DATASET_CONFIG[dataset]
    yaml_cfg = load_config(cfg['yaml'])

    print('=' * 70)
    print(f'SB-SD-LDM 训练 (期刊版 P1: 风格通路验证)')
    print(f'数据集: {dataset}, 设备: {DEVICE}')
    print(f'subj_dim={subj_dim}, lambda_style={lambda_style}, swap_p={swap_p}')
    print('=' * 70)

    # 1) 加载数据
    X_train, y_train, subjects_train = load_dataset(dataset)
    channels = cfg['channels']
    input_length = cfg['input_length']
    num_classes = cfg['num_classes']
    fs = cfg['fs']
    num_subjects = cfg['num_subjects']

    X_t = torch.FloatTensor(X_train)
    y_t = torch.LongTensor(y_train)
    subj_t = torch.LongTensor(subjects_train)

    dataset_t = TensorDataset(X_t, y_t, subj_t)
    loader = DataLoader(dataset_t, batch_size=batch_size, shuffle=True, num_workers=0, drop_last=False)

    # 2) 条件嵌入 (类别)
    model_cfg = yaml_cfg.get('model', {})
    cond_dim = int(model_cfg.get('cond_embed_dim', 64))
    cond_embed = torch.nn.Embedding(num_classes, cond_dim).to(DEVICE)

    # 3) 共享骨干模型 (带被试风格通路)
    backbone = SharedBackboneConfig(
        base=int(model_cfg.get('backbone_base', 64)),
        levels=tuple(int(x) for x in model_cfg.get('backbone_levels', [1, 2, 4])),
        blocks_per_level=int(model_cfg.get('backbone_blocks_per_level', 2)),
    )
    model = SharedVAEUNetLDM1D(
        channels=channels,
        input_length=input_length,
        z_channels=int(model_cfg.get('z_channels', 64)),
        timesteps=int(model_cfg.get('timesteps', 1000)),
        t_dim=int(model_cfg.get('t_dim', 128)),
        cond_dim=cond_dim,
        backbone=backbone,
        num_subjects=num_subjects,
        adv_alpha=0.0,
        subj_dim=subj_dim,
    ).to(DEVICE)
    assert hasattr(model, 'subj_embed'), 'num_subjects>0 应创建风格通路'

    print(f'\n模型参数: {sum(p.numel() for p in model.parameters()):,}')

    # 4) 潜空间分类头
    with torch.no_grad():
        dummy_x = torch.zeros(1, channels, input_length, device=DEVICE)
        dummy_cond = torch.zeros(1, cond_dim, device=DEVICE)
        z_dummy, _, _ = model.encode(dummy_x, cond=dummy_cond)
        latent_dim = z_dummy.shape[1] * z_dummy.shape[2]
    classifier_head = torch.nn.Linear(latent_dim, num_classes).to(DEVICE)

    # 5) Teacher + 质量校验 (v1 根因#2: 随机 teacher 会毒化 decoder)
    teacher = load_teacher(dataset, channels, input_length, num_classes)
    with torch.no_grad():
        idx = np.random.RandomState(0).choice(len(X_t), 500, replace=False)
        t_pred = teacher(X_t[idx].unsqueeze(1).to(DEVICE)).argmax(1).cpu().numpy()
        teacher_acc = float((t_pred == y_t[idx].numpy()).mean())
    rand_level = 1.0 / num_classes
    print(f'  teacher 校验: 判类 {teacher_acc*100:.1f}% (随机={rand_level*100:.0f}%)')
    if teacher_acc < rand_level * 1.5:
        raise RuntimeError(
            f'teacher 质量不足 ({teacher_acc*100:.1f}%), 中止训练 — 随机 teacher 会毁掉 decoder')

    # 6) 优化器
    optim = torch.optim.AdamW(
        list(model.parameters()) + list(cond_embed.parameters()) + list(classifier_head.parameters()),
        lr=lr, weight_decay=1e-5,
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optim, T_max=num_epochs, eta_min=1e-6)

    # 7) Checkpoint 目录
    ckpt_dir = PROJECT_ROOT / (ckpt_dir_override or cfg['ckpt_dir'])
    ckpt_dir.mkdir(parents=True, exist_ok=True)

    # 8) 训练循环
    print(f'\n开始训练 ({num_epochs} epochs)...')
    print('-' * 70)

    beta_kl_base = float(model_cfg.get('beta_kl', 1e-3))
    lambda_cls = float(model_cfg.get('lambda_cls', 1.0))
    lambda_feat = float(model_cfg.get('lambda_feat', 0.4))
    lambda_logit_base = float(model_cfg.get('lambda_logit', 0.8))
    lambda_conf = float(model_cfg.get('lambda_conf', 0.15))
    lambda_erd = float(model_cfg.get('lambda_erd', 2.0))

    c3, c4 = cfg['erd_c3'], cfg['erd_c4']

    for epoch in range(1, num_epochs + 1):
        model.train()
        cond_embed.train()
        classifier_head.train()

        ep = {'loss': 0.0, 'eps': 0.0, 'kl': 0.0, 'cls': 0.0, 'recon': 0.0,
              'feat': 0.0, 'logit': 0.0, 'conf': 0.0, 'erd': 0.0, 'style': 0.0, 'swap': 0.0}

        for X_batch, y_batch, subj_batch in loader:
            X_batch = X_batch.to(DEVICE)
            y_batch = y_batch.to(DEVICE)
            subj_batch = subj_batch.to(DEVICE)

            B = X_batch.size(0)

            cond = cond_embed(y_batch)

            t = torch.randint(0, int(model.timesteps), (B,), device=DEVICE, dtype=torch.long)
            eps_pred, noise, mu, logvar, _ = model(X_batch, t, cond=cond, subject_id=subj_batch)

            # 1. Diffusion loss
            loss_eps = F.mse_loss(eps_pred, noise)

            # 2. KL loss
            logvar_clamped = torch.clamp(logvar, min=-10, max=10)
            kl_per = -0.5 * (1 + logvar_clamped - mu.pow(2) - logvar_clamped.exp())
            kl_loss = torch.mean(kl_per)

            # 3. Reconstruction (带被试风格注入; 权重恒定 — v1 衰减归零 bug 已修复)
            x_recon = model.decode(mu, target_length=X_batch.shape[-1],
                                   cond=cond, subject_id=subj_batch)
            loss_recon = F.mse_loss(x_recon, X_batch)
            loss_recon_w = 1.0

            # 4. Latent classification
            z0_flat = mu.view(B, -1)
            loss_cls = F.cross_entropy(classifier_head(z0_flat), y_batch)

            # 5. Teacher distillation (feat + logit + conf)
            X_real_t = X_batch.unsqueeze(1)
            X_recon_t = x_recon.unsqueeze(1)
            with torch.no_grad():
                feat_real = teacher._forward_features(X_real_t)
                logits_real = teacher(X_real_t)
            feat_recon = teacher._forward_features(X_recon_t)
            logits_recon = teacher(X_recon_t)

            loss_feat = F.mse_loss(feat_recon, feat_real)
            loss_logit = F.cross_entropy(logits_recon, y_batch)
            prob_real = F.softmax(logits_real, dim=1)
            prob_recon = F.softmax(logits_recon, dim=1)
            loss_conf = F.kl_div(prob_recon.log(), prob_real, reduction="batchmean")

            # 6. ERD regularization
            loss_erd = torch.tensor(0.0, device=DEVICE)
            if epoch > int(num_epochs * 0.1):
                eps_fft = 1e-8

                def band_power(x_sig, low, high):
                    T_len = x_sig.shape[-1]
                    freqs = torch.fft.rfftfreq(T_len, d=1.0 / fs).to(x_sig.device)
                    spec = torch.fft.rfft(x_sig, dim=-1).abs().pow(2)
                    mask = (freqs >= low) & (freqs <= high)
                    return spec[..., mask].mean(dim=-1).clamp(min=eps_fft)

                mu_recon = band_power(x_recon, 8, 13)
                beta_recon = band_power(x_recon, 13, 30)
                mu_real = band_power(X_batch, 8, 13).detach()
                beta_real = band_power(X_batch, 13, 30).detach()

                lat_mu_recon = (mu_recon[:, c4] - mu_recon[:, c3]) / (mu_recon[:, c4] + mu_recon[:, c3] + eps_fft)
                lat_mu_real = (mu_real[:, c4] - mu_real[:, c3]) / (mu_real[:, c4] + mu_real[:, c3] + eps_fft)
                lat_beta_recon = (beta_recon[:, c4] - beta_recon[:, c3]) / (beta_recon[:, c4] + beta_recon[:, c3] + eps_fft)
                lat_beta_real = (beta_real[:, c4] - beta_real[:, c3]) / (beta_real[:, c4] + beta_real[:, c3] + eps_fft)

                loss_erd = F.mse_loss(lat_mu_recon, lat_mu_real) + F.mse_loss(lat_beta_recon, lat_beta_real)

            # 7. P1 风格损失 --------------------------------------------------
            # (a) 正确 s: 风格头应从重建波形读出被试身份
            loss_style = F.cross_entropy(model.subj_head(x_recon), subj_batch)

            # (b) 交换 s: 同一 z (detach) 换成其他被试解码, 风格头必须判出"新"被试
            #     s 是唯一差异 => 只能通过风格通路满足 => 因果逼通路生效
            n_swap = max(1, int(B * swap_p))
            swap_idx = torch.randperm(B, device=DEVICE)[:n_swap]
            s_other = (subj_batch[swap_idx]
                       + torch.randint(1, num_subjects, (n_swap,), device=DEVICE)) % num_subjects
            x_swap = model.decode(mu[swap_idx].detach(),
                                  target_length=X_batch.shape[-1],
                                  cond=cond[swap_idx].detach(), subject_id=s_other)
            loss_swap = F.cross_entropy(model.subj_head(x_swap), s_other)

            # KL anneal
            if epoch <= num_epochs * 0.2:
                kl_w = (epoch / (num_epochs * 0.2)) * 0.3
            elif epoch <= num_epochs * 0.5:
                kl_w = 0.3 + ((epoch - num_epochs * 0.2) / (num_epochs * 0.3)) * 0.4
            elif epoch <= num_epochs * 0.8:
                kl_w = 0.7 + ((epoch - num_epochs * 0.5) / (num_epochs * 0.3)) * 0.3
            else:
                kl_w = 1.0

            beta_kl = beta_kl_base * kl_w
            lambda_logit = lambda_logit_base * (1.0 + epoch / num_epochs)

            # Total loss
            loss = (
                loss_eps
                + beta_kl * kl_loss
                + lambda_cls * loss_cls
                + loss_recon_w * loss_recon
                + lambda_feat * loss_feat
                + lambda_logit * loss_logit
                + lambda_conf * loss_conf
                + lambda_erd * loss_erd
                + lambda_style * loss_style
                + lambda_style * loss_swap
            )

            optim.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                list(model.parameters()) + list(cond_embed.parameters()), 1.0)
            optim.step()

            bs = float(B)
            ep['loss'] += loss.item() * bs
            ep['eps'] += loss_eps.item() * bs
            ep['kl'] += kl_loss.item() * bs
            ep['cls'] += loss_cls.item() * bs
            ep['recon'] += loss_recon.item() * bs
            ep['feat'] += loss_feat.item() * bs
            ep['logit'] += loss_logit.item() * bs
            ep['conf'] += loss_conf.item() * bs
            ep['erd'] += loss_erd.item() * bs
            ep['style'] += loss_style.item() * bs
            ep['swap'] += loss_swap.item() * bs

        n = float(len(dataset_t))
        for k in ep:
            ep[k] /= n

        scheduler.step()
        lr_now = scheduler.get_last_lr()[0]

        if epoch % 10 == 0 or epoch == 1:
            print(
                f'[Ep {epoch:3d}/{num_epochs}] '
                f'Loss:{ep["loss"]:.4f} | Diff:{ep["eps"]:.4f} | KL:{ep["kl"]:.4f} | '
                f'Cls:{ep["cls"]:.4f} | Recon:{ep["recon"]:.4f} | '
                f'Style:{ep["style"]:.4f} | Swap:{ep["swap"]:.4f} | ERD:{ep["erd"]:.4f} | LR:{lr_now:.1e}'
            )

        if epoch % 50 == 0 or epoch == num_epochs:
            metrics = eval_style_quality(model, cond_embed, teacher, X_t, y_t, subj_t,
                                         num_subjects)
            ckpt_path = ckpt_dir / f'sb_sd_ldm_epoch_{epoch}.pt'
            torch.save({
                'epoch': epoch,
                'config': yaml_cfg,
                'model_state_dict': model.state_dict(),
                'cond_embed_state_dict': cond_embed.state_dict(),
                'classifier_head_state_dict': classifier_head.state_dict(),
                'stage': 'P1_style_pathway',
                'p1_metrics': metrics,
                'subj_dim': subj_dim,
                'num_subjects': num_subjects,
            }, ckpt_path)
            m = metrics
            print(f'  保存: {ckpt_path.name} | '
                  f'recon_cls={m["recon_class_acc"]*100:.1f}% '
                  f'style={m["style_acc"]*100:.1f}% '
                  f'swap={m["swap_acc"]*100:.1f}% (backfire={m["swap_backfire"]*100:.1f}%) '
                  f'mse_true={m["mse_true"]:.4f} mse_swap={m["mse_swap"]:.4f}')

    summary = {
        'config': yaml_cfg,
        'dataset': dataset,
        'model_type': 'SB-SD-LDM P1 (style pathway)',
        'num_epochs': num_epochs,
        'subj_dim': subj_dim,
        'lambda_style': lambda_style,
        'swap_p': swap_p,
    }
    summary_path = ckpt_dir / 'train_summary.json'
    with open(summary_path, 'w', encoding='utf-8') as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print(f'\n训练完成: {summary_path}')


def main():
    parser = argparse.ArgumentParser(description='SB-SD-LDM P1 训练 (风格通路)')
    parser.add_argument('--dataset', type=str, required=True,
                        choices=['bci2a', 'bci2b', 'physionet'])
    parser.add_argument('--epochs', type=int, default=500)
    parser.add_argument('--batch_size', type=int, default=64)
    parser.add_argument('--lr', type=float, default=1e-4)
    parser.add_argument('--ckpt_dir', type=str, default=None)
    parser.add_argument('--subj_dim', type=int, default=32)
    parser.add_argument('--style_w', type=float, default=0.3)
    parser.add_argument('--swap_p', type=float, default=0.25)
    args = parser.parse_args()

    torch.manual_seed(42)
    np.random.seed(42)

    train(args.dataset, num_epochs=args.epochs, batch_size=args.batch_size, lr=args.lr,
          ckpt_dir_override=args.ckpt_dir, subj_dim=args.subj_dim,
          lambda_style=args.style_w, swap_p=args.swap_p)


if __name__ == '__main__':
    main()
