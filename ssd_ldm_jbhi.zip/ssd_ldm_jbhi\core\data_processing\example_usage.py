"""
数据预处理使用示例
展示如何使用新的模块化数据处理器
"""

import os
import sys
from pathlib import Path

# 添加当前目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from process_bci2a import process_bci2a_dataset
from process_bci2b import process_bci2b_dataset
from process_seed import process_seed_dataset
from common import get_default_paths

def example_process_bci2a():
    """BCI2a数据集处理示例"""
    print("=" * 50)
    print("BCI2a数据集处理示例")
    print("=" * 50)
    
    # 获取默认路径
    paths = get_default_paths('2a')
    data_dir = paths['data_dir']
    label_dir = paths['label_dir']
    output_dir = 'processed'
    
    print(f"数据目录: {data_dir}")
    print(f"标签目录: {label_dir}")
    print(f"输出目录: {output_dir}")
    
    # 处理整个数据集
    success = process_bci2a_dataset(
        data_dir=data_dir,
        label_dir=label_dir,
        output_dir=output_dir,
        l_freq=4.0,
        h_freq=30.0,
        notch_freq=50.0,
        car=True,
        resample_freq=250.0,
        tmin=0.0,
        tmax=4.0
    )
    
    if success:
        print("✅ BCI2a数据集处理成功!")
    else:
        print("❌ BCI2a数据集处理失败!")
    
    return success

def example_process_bci2b():
    """BCI2b数据集处理示例"""
    print("=" * 50)
    print("BCI2b数据集处理示例")
    print("=" * 50)
    
    # 获取默认路径
    paths = get_default_paths('2b')
    data_dir = paths['data_dir']
    label_dir = paths['label_dir']
    output_dir = 'processed'
    
    print(f"数据目录: {data_dir}")
    print(f"标签目录: {label_dir}")
    print(f"输出目录: {output_dir}")
    
    # 处理整个数据集
    success = process_bci2b_dataset(
        data_dir=data_dir,
        label_dir=label_dir,
        output_dir=output_dir,
        l_freq=4.0,
        h_freq=30.0,
        notch_freq=50.0,
        car=True,
        resample_freq=250.0,
        tmin=0.0,
        tmax=4.0
    )
    
    if success:
        print("✅ BCI2b数据集处理成功!")
    else:
        print("❌ BCI2b数据集处理失败!")
    
    return success

def example_process_seed():
    """SEED数据集处理示例"""
    print("=" * 50)
    print("SEED数据集处理示例")
    print("=" * 50)
    
    # 获取默认路径
    paths = get_default_paths('seed')
    data_dir = paths['data_dir']
    output_dir = 'processed'
    
    print(f"数据目录: {data_dir}")
    print(f"输出目录: {output_dir}")
    
    # 处理整个数据集
    success = process_seed_dataset(
        data_dir=data_dir,
        output_dir=output_dir,
        seed_sfreq=200.0
    )
    
    if success:
        print("✅ SEED数据集处理成功!")
    else:
        print("❌ SEED数据集处理失败!")
    
    return success

def example_process_single_subject():
    """处理单个被试示例"""
    print("=" * 50)
    print("处理单个被试示例")
    print("=" * 50)
    
    # 获取默认路径
    paths = get_default_paths('2a')
    data_dir = paths['data_dir']
    label_dir = paths['label_dir']
    output_dir = 'processed'
    
    # 只处理A01E被试
    success = process_bci2a_dataset(
        data_dir=data_dir,
        label_dir=label_dir,
        output_dir=output_dir,
        subject='A01E',  # 只处理这个被试
        l_freq=4.0,
        h_freq=30.0,
        notch_freq=50.0,
        car=True,
        resample_freq=250.0,
        tmin=0.0,
        tmax=4.0
    )
    
    if success:
        print("✅ 单个被试处理成功!")
    else:
        print("❌ 单个被试处理失败!")
    
    return success

def main():
    """主函数"""
    print("数据预处理模块使用示例")
    print("=" * 60)
    
    # 检查原始数据是否存在
    paths_2a = get_default_paths('2a')
    paths_2b = get_default_paths('2b')
    paths_seed = get_default_paths('seed')
    
    print("检查原始数据路径:")
    print(f"  BCI2a: {paths_2a['data_dir']} (存在: {os.path.exists(paths_2a['data_dir'])})")
    print(f"  BCI2b: {paths_2b['data_dir']} (存在: {os.path.exists(paths_2b['data_dir'])})")
    print(f"  SEED:  {paths_seed['data_dir']} (存在: {os.path.exists(paths_seed['data_dir'])})")
    print()
    
    # 选择要处理的数据集
    print("选择要处理的数据集:")
    print("1. BCI2a (运动想象)")
    print("2. BCI2b (运动想象)")
    print("3. SEED (情感识别)")
    print("4. 处理单个被试 (A01E)")
    print("5. 处理所有数据集")
    
    choice = input("请输入选择 (1-5): ").strip()
    
    if choice == '1':
        example_process_bci2a()
    elif choice == '2':
        example_process_bci2b()
    elif choice == '3':
        example_process_seed()
    elif choice == '4':
        example_process_single_subject()
    elif choice == '5':
        print("处理所有数据集...")
        example_process_bci2a()
        example_process_bci2b()
        example_process_seed()
    else:
        print("无效选择!")
    
    print("\n示例完成!")

if __name__ == '__main__':
    main()